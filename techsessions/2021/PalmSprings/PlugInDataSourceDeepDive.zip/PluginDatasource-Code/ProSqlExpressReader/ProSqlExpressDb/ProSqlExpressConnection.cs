﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProSqlExpressDb
{
	public class ProSqlExpressConnection
	{
		private static Dictionary<string, string> SqlConnections = new Dictionary<string, string>();
		private static ProSqlExpressConnection _this = null;
		public static string PathSeperator = @"\\\";
		public static string[] PathSeperators => new string[] { PathSeperator };

		/// <summary>
		/// Returns unique instance of ProSqlExpressConnection
		/// </summary>
		public static ProSqlExpressConnection Instance
		{
			get
			{
				if (_this == null) _this = new ProSqlExpressConnection();
				return _this;
			}
		}

		/// <summary>
		/// Clears the connection strings
		/// </summary>
		public void ClearConnections()
		{
			SqlConnections.Clear();
		}

		/// <summary>
		/// Adds a new connection to a static list of connection strings.
		/// </summary>
		/// <param name="connectionString">format: Server=localhost\sqlexpress;Database=TestSqlExpress;Integrated Security=SSPI;</param>
		/// <returns>connection Key if the connection string was added and formatted properly
		/// otherwise string.empty is returned
		/// </returns>
		public string AddConnection (string connectionString)
		{
			var parts = connectionString.Split(new char[] { ';' });
			foreach (var part in parts)
			{
				if (part.StartsWith ("database=", StringComparison.OrdinalIgnoreCase))
				{
					var subParts = part.Split(new char[] { '=' });
					if (subParts.Length != 2) return string.Empty;
					var connectionKey = subParts[subParts.Length - 1];
					if (!SqlConnections.ContainsKey(connectionKey))
						SqlConnections.Add(connectionKey, connectionString);
					return connectionKey;
				}
			}
			return string.Empty;
		}

		/// <summary>
		/// Finds the connection string from a static list of connection strings.
		/// </summary>
		/// <param name="sqlConnectionKey">database </param>
		/// <returns>emtpy string if connection string was not found</returns>
		public string FindConnectionString (string sqlConnectionKey)
		{
			if (!SqlConnections.ContainsKey(sqlConnectionKey)) return string.Empty;
			return SqlConnections[sqlConnectionKey];
		}

		/// <summary>
		/// Finds the connection string from a static list of connection strings.
		/// </summary>
		/// <param name="sqlexpressFilePath">Uri for the complete sql path using the PathSeperator</param>
		/// <returns>emtpy string if connection string was not found</returns>
		public string FindConnectionStringFromPath(string sqlexpressFileUri)
		{
			var parts = sqlexpressFileUri.Split(PathSeperators, StringSplitOptions.RemoveEmptyEntries);
			var sqlexpressFilePath = parts[0];
			var sqlConnectionKey = parts[1];
			var sqlConnectionLines = System.IO.File.ReadAllLines(sqlexpressFilePath);
			foreach (var sqlConnection in sqlConnectionLines)
			{
				AddConnection(sqlConnection);
			}
			if (!SqlConnections.ContainsKey(sqlConnectionKey)) return string.Empty;
			return SqlConnections[sqlConnectionKey];
		}

		/// <summary>
		/// Get the path to the connection file from a Pro SQL URI path string
		/// </summary>
		/// <param name="sqlexpressFileUri"></param>
		/// <returns>path to the connection file</returns>
		public string GetPathFromUriPath (string sqlexpressFileUri)
		{
			var parts = sqlexpressFileUri.Split(PathSeperators, StringSplitOptions.RemoveEmptyEntries);
			return parts[0];
		}

		/// <summary>
		/// Gets the collection of all SqlConnection keys
		/// </summary>
		public Dictionary<string, string>.KeyCollection SqlConnectionKeys
		{
			get
			{
				return SqlConnections.Keys;
			}
		}
	}
}
