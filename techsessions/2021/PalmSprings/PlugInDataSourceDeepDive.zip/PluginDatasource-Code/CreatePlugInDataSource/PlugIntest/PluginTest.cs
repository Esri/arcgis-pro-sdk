﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.PluginDatastore;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlugIntest
{
	internal class PluginTest : Button
	{
		protected override void OnClick()
		{
			var pluginId = @"ProSqlExpressPluginDatasource";
			var filePathUri = new Uri(@"C:\Data\PluginData\SQLExpressData\SqlExpress.sqlexpress\\\FdTestSqlExpress");
			var conSql = new PluginDatasourceConnectionPath(pluginId, filePathUri);
			QueuedTask.Run(() =>
			{
				using (var pluginSql = new PluginDatastore(conSql))
					foreach (var tableName in pluginSql.GetTableNames())
						using (var tbl = pluginSql.OpenTable(tableName))
							if (tbl is FeatureClass fc)
							{
								//Add as a layer to the active map or scene
								LayerFactory.Instance.CreateFeatureLayer(fc, MapView.Active.Map);
							}
			});
		}
	}
}
