﻿/*

   Copyright 2021 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

   See the License for the specific language governing permissions and
   limitations under the License.

*/
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Events;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WhatsNew
{
  internal class EventSpyViewModel : DockPane
  {
    private const string _dockPaneID = "WhatsNew_EventSpy";

    protected EventSpyViewModel()
    {
      AddEntry("Click 'Start Events' to start listening to events.");

      _spyEditEvents = true;
    }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

    private bool _listening = false;
    public bool IsListening => _listening;

    public string ButtonText => _listening ? "Stop Events" : "Start Events";


    private ICommand _clearCmd = null;
    public ICommand ClearTextCmd
    {
      get
      {
        if (_clearCmd == null)
          _clearCmd = new RelayCommand(() => ClearEntries());
        return _clearCmd;
      }
    }

    private bool _spyEditEvents;
    public bool SpyEditEvents
    {
      get => _spyEditEvents;
      set
      {
        if (_listening)
          StopListening();
        SetProperty(ref _spyEditEvents, value);
      }
    }

    #region Register / Unregister

    private bool _firstStart = true;

    private Dictionary<string, List<SubscriptionToken>> _rowevents = new Dictionary<string, List<SubscriptionToken>>();
    private List<SubscriptionToken> _editEvents = new List<SubscriptionToken>();

    private ICommand _startStopCmd;
    public ICommand StartStopCmd
    {
      get
      {
        if (_startStopCmd == null)
        {
          _startStopCmd = new RelayCommand(() =>
          {
            if (_firstStart)
            {
              ClearEntries();
              _firstStart = false;
            }

            if (_listening)
            {
              StopListening();
            }
            else
            {
              StartListening();
            }
          });
        }
        return _startStopCmd;
      }
    }

    private void StartListening()
    {
      if (_listening)
        return;

      _listening = RegisterEditEvents();
      NotifyPropertyChanged(nameof(ButtonText));
      NotifyPropertyChanged(nameof(IsListening));
    }
    private void StopListening()
    {
      if (!_listening)
        return;

      _listening = UnregisterEditEvents();
      NotifyPropertyChanged(nameof(ButtonText));
      NotifyPropertyChanged(nameof(IsListening));
    }

    private bool RegisterEditEvents()
    {
      var layers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
      QueuedTask.Run(() =>
      {
        foreach (var fl in layers)
        {
          var fc = fl.GetFeatureClass();
          if (fc != null)
          {
            var tokens = new List<SubscriptionToken>();
            //These events are fired once ~per feature~,
            //per table
            tokens.Add(RowCreatedEvent.Subscribe((rc) => RowCreatedHandler(rc), fc));
            tokens.Add(RowChangedEvent.Subscribe((rc) => RowChangedHandler(rc), fc));
            tokens.Add(RowDeletedEvent.Subscribe((rc) => RowDeletedHandler(rc), fc));
            _rowevents[fl.Name] = tokens;
          }
        }

        //This event is fired once when the edit operation commences
        _editEvents.Add(EditStartedEvent.Subscribe(HandleEditStarted));

        //This event is fired once per edit execute just prior to completion
        //Note: This event won't fire if the edits were cancelled
        _editEvents.Add(EditCompletingEvent.Subscribe(HandleEditCompleting));

        //This event is fired after all the edits are completed (and on
        //save, discard, undo, redo) and is fired once
        _editEvents.Add(EditCompletedEvent.Subscribe(HandleEditCompletedEvent));

      });

      AddEntry("Listening Edit Events");

      return true;
    }

    private bool UnregisterEditEvents()
    {
      //Careful here - events have to be unregistered on the same
      //thread they were registered on...hence the use of the
      //Queued Task
      QueuedTask.Run(() =>
      {
        //One kvp per layer....of which there is only one in the sample
        //out of the box but you can add others and register for events
        foreach (var kvp in _rowevents)
        {
          RowCreatedEvent.Unsubscribe(kvp.Value[0]);
          RowChangedEvent.Unsubscribe(kvp.Value[1]);
          RowDeletedEvent.Unsubscribe(kvp.Value[2]);
          kvp.Value.Clear();
        }
        _rowevents.Clear();

        // other edit events
        EditStartedEvent.Unsubscribe(_editEvents[0]);
        EditCompletingEvent.Unsubscribe(_editEvents[1]);
        EditCompletedEvent.Unsubscribe(_editEvents[2]);
        _editEvents.Clear();
      });


      AddEntry("Not listening");

      return false;
    }
    #endregion RegisterUnregister

    #region Flags

    private bool _cancelCreates;
    public bool CancelCreates
    {
      get => _cancelCreates;
      set => SetProperty(ref _cancelCreates, value);
    }

    private bool _canceLGeometryUpdates;
    public bool CancelGeometryUpdates
    {
      get => _canceLGeometryUpdates;
      set => SetProperty(ref _canceLGeometryUpdates, value);
    }
    private bool _udpateAttributes;
    public bool UpdateAttributes
    {
      get => _udpateAttributes;
      set => SetProperty(ref _udpateAttributes, value);
    }
    private bool _cancelEdits;
    public bool CancelEdits
    {
      get => _cancelEdits;
      set => SetProperty(ref _cancelEdits, value);
    }

    private bool _addAuditRecord;
    public bool AddAuditRecord
    {
      get => _addAuditRecord;
      set => SetProperty(ref _addAuditRecord, value);
    }
    #endregion

    #region eventLog

    private static readonly object _lock = new object();
    private List<string> _entries = new List<string>();

    public string EventLog
    {
      get
      {
        string contents = "";
        lock (_lock)
        {
          contents = string.Join("\r\n", _entries.ToArray());
        }
        return contents;
      }
    }

    private void ClearEntries()
    {
      lock (_lock)
      {
        _entries.Clear();
      }
      NotifyPropertyChanged(nameof(EventLog));
    }

    private void AddEntry(string entry)
    {
      lock (_lock)
      {
        _entries.Add($"{entry}");
      }
      NotifyPropertyChanged(nameof(EventLog));
    }

    private void RecordEvent(string eventName, string entry)
    {
      var dateTime = DateTime.Now.ToString("G");
      AddEntry($"{dateTime}: {eventName} {entry}");
    }

    private void RecordEvent(RowChangedEventArgs rc, Table table)
    {
      var eventName = $"Row{rc.EditType.ToString()}dEvent";

      var entry = $"{table.GetName()}, oid:{rc.Row.GetObjectID()}";
      RecordEvent(eventName, entry);
    }

    #endregion

    #region Row Events

    // ===================================
    // what can I do in the RowEvents?

    // 1.  Cancel edits using args.CancelEdit
    // 2.  update values in args.Row
    // 3.  Determine if field values have changed
    // 4.  use args.Operation to add aditional items to the EditOperation
    // ===================================

    private void RowCreatedHandler(RowChangedEventArgs args)
    {
      var row = args?.Row;
      if (row == null)
        return;

      using (var table = row.GetTable())
      {
        RecordEvent(args, table);

        // Cancel flag is set.
        if (CancelCreates)
        {
          //cancel the edit
          args.CancelEdit($"{args.EditType} for {table.GetName()} cancelled");
          AddEntry("*** edit cancelled");
          AddEntry("---------------------------------");
        }
      }

      if (UpdateAttributes)
      {
        var oid = row.GetObjectID();

        // assign values to fields
        var fldIndx = row.FindField("Name");
        if (fldIndx != -1)
          row["Name"] = "Point " + oid.ToString();
      }


      // add additional items to the editOperation
      //   for example - audit trail

      // add audit record
      if (AddAuditRecord)
        AddChange(args.Operation, row);
    }

    private static Guid guidOperation = Guid.Empty;
    private void RowChangedHandler(RowChangedEventArgs args)
    {
      var row = args?.Row;
      if (row == null)
        return;


      using (var table = args.Row.GetTable())
      {
        RecordEvent(args, table);
      }

      // prevent geometry edits, but allow attribute edits
      if (CancelGeometryUpdates)
      {
        // find shape field
        int fldIndex = row.FindField("Shape");
        if (fldIndex != -1)
        {
          // if edits have been made to this field
          if (row.HasValueChanged(fldIndex))
          {
            args.CancelEdit("No geometry edits are allowed", false);
            return;
          }
        }
      }

      if (UpdateAttributes)
      {
        // update a dependant attribute
        row["ModifiedBy"] = Environment.UserName;
        // store
        // row.Store();      // BE CAREFUL - calling Store causes an additional RowChangedEvent
                             //  use args.Guid to avoid re-entrancy and infinite loops
      }

      // add additional items to the editOperation
      //   for example - audit trail

      // add audit record
      if (AddAuditRecord) 
        AddChange(args.Operation, row);
    }

    private void RowDeletedHandler(RowChangedEventArgs args)
    {
      using (var table = args.Row.GetTable())
      {
        RecordEvent(args, table);
      }
    }

    private void AddChange(EditOperation op, Row row)
    {
      if ((op == null) || (row == null))
        return;

      string desc = "";
      using (var table = row.GetTable())
      {
        desc = "Table:" + table.GetName() + ",OID:" + row.GetObjectID().ToString() + "," + DateTime.Now.ToString("g");
      }

      AddChange(op, desc);
    }

    private void AddChange(EditOperation op, string desc)
    {
      if (op == null)
        return;

      var historyLayer = MapView.Active.Map.FindStandaloneTables("CHANGEHISTORY").FirstOrDefault();
      if (historyLayer == null)
        return;

      Dictionary<string, object> values = new Dictionary<string, object>();
      values.Add("Description", desc);
      values.Add("ModifiedBy", Environment.UserName);

      op.Create(historyLayer, values);
    }

    #endregion

    #region Edit Events

    private void HandleEditStarted(EditStartedEventArgs args)
    {
      RecordEvent("EditStartedEvent", "");

      // ===================================
      // what can I do in EditStartedEvemt?

      // 1.  use args.Operation to add aditional items to the EditOperation
      // ===================================

      if (AddAuditRecord)
        AddChange(args.Operation, Environment.UserName + " starting edit");
    }

    private void HandleEditCompleting(EditCompletingEventArgs args)
    {
      RecordEvent("EditCompletingEvent", "");

      // ===================================
      // what can I do in EditCompletingEvent

      // 1.  Cancel edits using args.CancelEdit
      // 2.  Use args.Operation to add aditional items to the EditOperation
      // ===================================


      //can also cancel edit in the completing event...
      //cancels everything (that is cancealable)
      if (CancelEdits)
      {
        args.CancelEdit($"EditCompletingEvent, edit cancelled");

        AddEntry("*** edits cancelled");
        AddEntry("---------------------------------");

        return;
      }

      if (AddAuditRecord)
      {
        AddChange(args.Operation, Environment.UserName + " completing edit");

        // also add a new feature to a layer that we have subscribed to RowCreated on
        var layer = MapView.Active.Map.GetLayersAsFlattenedList().FirstOrDefault();
        args.Operation.Create(layer);
      }
      // no way to obtain the list of creates, modifies, deletes from the args
      // have to manually do it via the rowEvents 
    }

    private Task HandleEditCompletedEvent(EditCompletedEventArgs args)
    {
      RecordEvent("EditCompletedEvent", args.CompletedType.ToString());


      // ===================================
      // what can I do in EditCompletedEvent

      // 1.  Identify features created, modified, deleted
      // 2   Identify if changes exist for a layer
      // ===================================

      StringBuilder adds = new StringBuilder();
      StringBuilder mods = new StringBuilder();
      StringBuilder dels = new StringBuilder();
      adds.AppendLine("Adds");
      mods.AppendLine("Modifies");
      dels.AppendLine("Deletes");

      if (args.Creates != null)
      {
        foreach (var kvp in args.Creates)
        {
          var oids = string.Join(",", kvp.Value.Select(n => n.ToString()).ToArray());
          adds.AppendLine($" {kvp.Key.Name} {oids}");
        }
      }
      else
      {
        adds.AppendLine("  No Adds");
      }
      if (args.Modifies != null)
      {
        foreach (var kvp in args.Modifies)
        {
          var oids = string.Join(",", kvp.Value.Select(n => n.ToString()).ToArray());
          mods.AppendLine($" {kvp.Key.Name} {oids}");
        }
      }
      else
      {
        mods.AppendLine("  No Modifies");
      }
      if (args.Deletes != null)
      {
        foreach (var kvp in args.Deletes)
        {
          var oids = string.Join(",", kvp.Value.Select(n => n.ToString()).ToArray());
          dels.AppendLine($" {kvp.Key.Name} {oids}");
        }
      }
      else
      {
        dels.AppendLine("  No Deletes");
      }
      AddEntry(adds.ToString());
      AddEntry(mods.ToString());
      AddEntry(dels.ToString());
      AddEntry("---------------------------------");


      // do changes exist for a layer
      //var featuresCreated = args.FeaturesCreated(Layer);

      return Task.CompletedTask;
    }

    #endregion

  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class EventSpy_ShowButton : Button
  {
    protected override void OnClick()
    {
      EventSpyViewModel.Show();
    }
  }
}
