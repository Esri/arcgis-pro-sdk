﻿/*

   Copyright 2021 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

   See the License for the specific language governing permissions and
   limitations under the License.

*/
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WhatsNew
{
  internal class LayerSnapModesViewModel : DockPane
  {
    private const string _dockPaneID = "WhatsNew_LayerSnapModes";

    protected LayerSnapModesViewModel() 
    {
      ActiveMapViewChangedEvent.Subscribe(OnActiveMapViewChanged);
    }

    private void OnActiveMapViewChanged(ActiveMapViewChangedEventArgs obj)
    {
      if (obj.IncomingView == null)
        return;
      //populate the snap list with layers in the incoming active map
      PopulateSnapList();
      PopulateLayerList();
    }


    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      PopulateSnapList();
      PopulateLayerList();
      pane.Activate();
    }


    private ICommand _SetSnappingCmd = null;
    public ICommand SetSnappingCmd
    {
      get
      {
        if (_SetSnappingCmd == null)
          _SetSnappingCmd = new RelayCommand(() => SetSnapping());
        return _SetSnappingCmd;
      }
    }

    private async Task SetSnapping()
    {
      //turn snapping on
      Snapping.IsEnabled = true;

      // configure snapModes

      // turn all off
      Snapping.SetSnapModes();

      // point, vertex, edge, end on
      Snapping.SetSnapMode(SnapMode.Point, true);
      Snapping.SetSnapMode(SnapMode.Vertex, true);
      Snapping.SetSnapMode(SnapMode.Edge, true);
      Snapping.SetSnapMode(SnapMode.End, true);

      // configure layer snappability

      //turn them all on
      var flayers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().ToList();

      if (flayers.Count() > 0)
      {
        await QueuedTask.Run(() => {
          foreach (var fl in flayers)
          {
            // use an extension method
            //  (must be called inside QueuedTask)
            fl.SetSnappable(true);
          }
        });
      }
    }

    private bool _SetAllIsChecked;
    public bool SetAllIsChecked
    {
      get => _SetAllIsChecked;
      set => SetProperty(ref _SetAllIsChecked, value);
    }

    private ICommand _SetAllCmd = null;
    public ICommand SetAllCmd
    {
      get
      {
        if (_SetAllCmd == null)
          _SetAllCmd = new RelayCommand(() => SetAll());
        return _SetAllCmd;
      }
    }

    // update all layerSnapModes for a set of layers either ON or OFF
    private void SetAll()
    {
      var layerlist = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
      Snapping.SetLayerSnapModes(layerlist, SetAllIsChecked);

      // refresh;
      PopulateSnapList();
    }
   
    private string _selectedLayerName;
    public string  SelectedLayerName
    {
      get => _selectedLayerName;
      set => SetProperty(ref _selectedLayerName, value);
    }

    private int _SingleLSMIndex;
    public int SingleLSMIndex
    {
      get => _SingleLSMIndex;
      set => SetProperty(ref _SingleLSMIndex, value);
    }

    private ICommand _SetLayerLSMCmd = null;
    public ICommand SetLayerLSMCmd
    {
      get
      {
        if (_SetLayerLSMCmd == null)
          _SetLayerLSMCmd = new RelayCommand(() => SetLayerLSM());
        return _SetLayerLSMCmd;
      }
    }

    // update layerSnapModes for a particular layer
    private void SetLayerLSM()
    {
      if (string.IsNullOrEmpty(_selectedLayerName))
        return;

      if (SingleLSMIndex == -1)
        return;

      // find the layer
      var layer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == _selectedLayerName);
      if (layer == null)
        return;

      // initialize a new LayerSnapModes so all are false
      var lsm = new LayerSnapModes(false);

      // set the appropriate snapMode
      switch (SingleLSMIndex)
      {
        case 0:
          lsm.Vertex = true;
          break;
        case 1:
          lsm.Edge = true;
          break;
        case 2:
          lsm.End = true;
          break;
      }

      // assign
      Snapping.SetLayerSnapModes(layer, lsm);

      // refresh;
      PopulateSnapList();
    }


    private ICommand _CustomSnapModeCmd = null;
    public ICommand CustomSnapModeCmd
    {
      get
      {
        if (_CustomSnapModeCmd == null)
          _CustomSnapModeCmd = new RelayCommand(() => SetCustomLayerSnapModes());
        return _CustomSnapModeCmd;
      }
    }

    // update a dictionary of LayerSnapModes 
    private void SetCustomLayerSnapModes()
    {
      var layers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().ToList();

      var dict = new Dictionary<Layer, LayerSnapModes>();

      for (int idx = 0; idx < 4; idx++)
      {
        var layer = layers[idx];

        var lsm = Snapping.GetLayerSnapModes(layer);
        if (idx % 2 == 0)
        {
          lsm.Vertex = false;
          lsm.Edge = true;
          lsm.End = true;
        } 
        else
        {
          lsm.Vertex = true;
          lsm.Edge = false;
          lsm.End = true;
        }
        dict.Add(layer, lsm);
      }
      Snapping.SetLayerSnapModes(dict, false);    // false = dont reset other layers

      // refresh;
      PopulateSnapList();
    }


    private static ObservableCollection<SnapAgent> _snapCollection = new ObservableCollection<SnapAgent>();
    public static void PopulateSnapList()
    {
      //populate the snaplist for the active map with feature layers
      _snapCollection.Clear();
      var layerlist = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
      foreach (var layer in layerlist)
      {
        LayerSnapModes lsm = Snapping.GetLayerSnapModes(layer);
        _snapCollection.Add(new SnapAgent(layer, lsm.Vertex, lsm.Edge, lsm.End));
      }
    }

    private static ObservableCollection<string> _layerList = new ObservableCollection<string>();
    public static void PopulateLayerList()
    {
      //populate the snaplist for the active map with feature layers
      _layerList.Clear();
      var layerlist = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
      foreach (var layer in layerlist)
      {
        _layerList.Add(layer.Name);
      }
    }

    /// <summary>
    /// Collection bound to datagrid
    /// </summary>
    public ObservableCollection<SnapAgent> SnapList
    {
      get => _snapCollection;
      set => SetProperty(ref _snapCollection, value);
    }

    /// <summary>
    /// Collection bound to datagrid
    /// </summary>
    public ObservableCollection<string> LayerNameList
    {
      get => _layerList;
      set => SetProperty(ref _layerList, value);
    }
  }

  internal class SnapAgent : ViewModelBase
  {
    public SnapAgent(Layer layer, bool vertex, bool edge, bool end) { this.layer = layer; _vertex = vertex; _edge = edge; _end = end; }

    private bool _vertex;
    private bool _edge;
    private bool _end;
    public Layer layer { get; set; }
    public bool Vertex
    {
      get => _vertex;
      set
      {
        SetProperty(ref _vertex, value);
        Snapping.SetLayerSnapModes(layer, SnapMode.Vertex, value);
      }
    }
    public bool Edge
    {
      get => _edge;
      set
      {
        SetProperty(ref _edge, value);
        Snapping.SetLayerSnapModes(layer, SnapMode.Edge, value);
      }
    }
    public bool End
    {
      get => _end;
      set
      {
        SetProperty(ref _end, value);
        Snapping.SetLayerSnapModes(layer, SnapMode.End, value);
      }
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
  internal class LayerSnapModes_ShowButton : Button
  {
    protected override void OnClick()
    {
      LayerSnapModesViewModel.Show();
    }
  }
}
