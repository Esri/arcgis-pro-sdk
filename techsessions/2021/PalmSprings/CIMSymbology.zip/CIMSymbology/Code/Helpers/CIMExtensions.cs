﻿using ArcGIS.Core.CIM;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CIMSymbologyDemo.Helpers
{
	public static class CIMExtensions
	{
    public static CIMObject Clone(this CIMObject cimObject)
    {
      var typename = cimObject.GetType().ToString();
      var clone = Activator.CreateInstance(
                   "ArcGIS.Core", typename).Unwrap() as CIMObject;
      using (var stringReader = new StringReader(cimObject.ToXml()))
      {
        using (var xmlReader = new XmlTextReader(stringReader))
        {
          clone.ReadXml(xmlReader);
          return clone;
        }
      }
    }
  }
}
