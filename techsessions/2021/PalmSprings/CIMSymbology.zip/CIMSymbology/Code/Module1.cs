﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using CIMSymbologyDemo.Helpers;

namespace CIMSymbologyDemo
{

	public enum DemoExamples
	{
		Example1_SymbolLayerOrder = 0,
		Example2_GeometricEffects_Step1,
		Example2_GeometricEffects_Step2,
		Example2_GeometricEffects_Step3,
		Example3_CrossHatch1,
		Example3_CrossHatch2,
		Example3_CrossHatch3,
		Example3_CrossHatch4,
		Example4_DimensionSymbol_Step1,
		Example4_DimensionSymbol_Step2,
		Example4_DimensionSymbol_Step3,
		Example4_DimensionSymbol_Step4,
		Example5_Extra_StippleFill_Fixed,
		Example5_Extra_StippleFill_Random,
		Example6_Extra_DropShadow
	}

	public enum DemoSymbolType
	{
		Point = 0,
		Line,
		Polygon,
		Text
	}

	internal class Module1 : Module
	{
		private static Module1 _this = null;

		/// <summary>
		/// Retrieve the singleton instance to this module here
		/// </summary>
		public static Module1 Current
		{
			get
			{
				return _this ?? (_this = (Module1)FrameworkApplication.FindModule("CIMSymbologyDemo_Module"));
			}
		}

		public static readonly string DimensionTextPrimitiveName = "Dimension_Text";

		public DemoExamples CurrentExample { get; set; }

		public bool SwitchLayerOrder { get; set; }

		public GraphicsLayer CurrentGraphicsLayer
		{
			get
			{

				var graphicsLayer = MapView.Active.GetSelectedLayers().OfType<GraphicsLayer>().FirstOrDefault();
				if (graphicsLayer == null)
					graphicsLayer = MapView.Active.Map.GetLayersAsFlattenedList()
							.OfType<ArcGIS.Desktop.Mapping.GraphicsLayer>().FirstOrDefault();
				StyleItemType x;
				return graphicsLayer;
			}
		}

		public CIMSymbol GetSymbolForExample(DemoExamples example, DemoSymbolType symbolType, string text = "")
		{
			if (example == DemoExamples.Example1_SymbolLayerOrder)
			{
				if (symbolType == DemoSymbolType.Point)
				{
					var poly_symbol = Example1SymbolLayerOrderPolygon(!this.SwitchLayerOrder);
					var pointSymbol = SymbolFactory.Instance.DefaultPointSymbol;
					pointSymbol.SetSize(40);
					//Swizzle the poly symbol for the marker graphics
					var marker = pointSymbol.SymbolLayers[0] as CIMVectorMarker;
					marker.MarkerGraphics[0].Symbol = poly_symbol;
					return pointSymbol;
				}
				else if (symbolType == DemoSymbolType.Line)
				{
					return Example1SymbolLayerOrderLine(!this.SwitchLayerOrder);
				}
				else if (symbolType == DemoSymbolType.Polygon)
				{
					return Example1SymbolLayerOrderPolygon(!this.SwitchLayerOrder);
				}
				else if (symbolType == DemoSymbolType.Text)
				{
					var text_symbol = SymbolFactory.Instance.ConstructTextSymbol(80);
					//Swizzle the poly symbol for the text
					text_symbol.Symbol = Example1SymbolLayerOrderPolygon(!this.SwitchLayerOrder);
					return text_symbol;
				}
			}
			else if (example == DemoExamples.Example2_GeometricEffects_Step1 ||
					example == DemoExamples.Example2_GeometricEffects_Step2 ||
					example == DemoExamples.Example2_GeometricEffects_Step3)
			{
				//Example 2 was for line symbol only
				if (symbolType == DemoSymbolType.Line)
				{
					return Example2GeometricEffects(example);
				}
				return null;
			}
			else if (example == DemoExamples.Example3_CrossHatch1 ||
					example == DemoExamples.Example3_CrossHatch2 ||
					example == DemoExamples.Example3_CrossHatch3 ||
					example == DemoExamples.Example3_CrossHatch4)
			{
				//Example 3 was for poly symbol only
				if (symbolType == DemoSymbolType.Polygon)
				{
					return Example3HatchFill(example);
				}
				return null;
			}
			else if (example == DemoExamples.Example4_DimensionSymbol_Step1 ||
					example == DemoExamples.Example4_DimensionSymbol_Step2 ||
					example == DemoExamples.Example4_DimensionSymbol_Step3 ||
					example == DemoExamples.Example4_DimensionSymbol_Step4)
			{
				//Example 4 was for line symbol only
				if (symbolType == DemoSymbolType.Line)
				{
					return Example4DimensionLineSymbol(example, text);
				}
				return null;
			}
			else if (example == DemoExamples.Example5_Extra_StippleFill_Fixed ||
				example == DemoExamples.Example5_Extra_StippleFill_Random)
			{
				//Example5, Extra is for polygons only
				if (symbolType == DemoSymbolType.Polygon)
				{
					var purple = ColorFactory.Instance.CreateRGBColor(100, 0, 180);
					//change to make bigger/smaller stipple
					double stipple_size = 3;

					return Example5StippleFillPolygonSymbol(purple,
						example == DemoExamples.Example5_Extra_StippleFill_Fixed ?
						PlacementGridType.Fixed :
						PlacementGridType.Random, stipple_size);
				}
				return null;
			}
			else if (example == DemoExamples.Example6_Extra_DropShadow)
			{
				var symbol = GetSymbolForExample(DemoExamples.Example1_SymbolLayerOrder, symbolType, text);
				var shadowColor = ColorFactory.Instance.CreateRGBColor(130, 130, 130);//grey

				return Example6AddDropShadow(symbol,
								 ConstructDropShadowLayer(shadowColor, symbolType));
			}
			return null;
		}

		private CIMPolygonSymbol Example1SymbolLayerOrderPolygon(bool strokeOnTop = true)
		{
			var stroke = SymbolFactory.Instance.ConstructStroke(
				ColorFactory.Instance.BlackRGB, 2.0);
			var fill = SymbolFactory.Instance.ConstructSolidFill(
				ColorFactory.Instance.RedRGB);

			return new CIMPolygonSymbol()
			{
				SymbolLayers = strokeOnTop ?
						new CIMSymbolLayer[] { stroke, fill } :
						new CIMSymbolLayer[] { fill, stroke }
			};
		}

		private CIMLineSymbol Example1SymbolLayerOrderLine(bool thickLineDrawsFirst = true)
		{
			var stroke = SymbolFactory.Instance.ConstructStroke(
				ColorFactory.Instance.BlackRGB, 5.0);

			var stroke2 = SymbolFactory.Instance.ConstructStroke(
				ColorFactory.Instance.RedRGB, 3.0);

			return new CIMLineSymbol()
			{
				SymbolLayers = thickLineDrawsFirst ?
						new CIMSymbolLayer[] { stroke2, stroke } :
						new CIMSymbolLayer[] { stroke, stroke2 }
			};
		}

		private CIMLineSymbol Example2GeometricEffects(DemoExamples example)
		{
			if (example == DemoExamples.Example2_GeometricEffects_Step1)
			{
				return new CIMLineSymbol
				{
					SymbolLayers = CheckerBoardLayers().ToArray()
				};
			}
			else if (example == DemoExamples.Example2_GeometricEffects_Step2)
			{
				var stroke_layers = CheckerBoardLayers();
				var checker1 = stroke_layers[0] as CIMSolidStroke;
				var checker2 = stroke_layers[1] as CIMSolidStroke;
				//Apply necessary Geometric Effects
				//Offset +width and -width
				var offset = checker1.Width / 2;
				//checker layer 1 is offset +y direction
				var offset_effect1 = new CIMGeometricEffectOffset()
				{
					Offset = offset,
					Method = GeometricEffectOffsetMethod.Mitered
				};
				//checker layer 2 is offset -y direction
				var offset_effect2 = new CIMGeometricEffectOffset()
				{
					Offset = -offset,
					Method = GeometricEffectOffsetMethod.Mitered
				};
				//Create the checkers - dash template
				//Each dash/space combo will be length of DashTemplate array
				var dash_effect1 = new CIMGeometricEffectDashes()
				{
					DashTemplate = new double[] { checker1.Width, checker1.Width },
				};
				var dash_effect2 = new CIMGeometricEffectDashes()
				{
					DashTemplate = new double[] { checker1.Width, checker1.Width },
				};
				checker1.Effects = new CIMGeometricEffect[]
				{
					offset_effect1, dash_effect1
				};
				checker2.Effects = new CIMGeometricEffect[]
				{
					offset_effect2, dash_effect2
				};
				return new CIMLineSymbol
				{
					SymbolLayers = new CIMSymbolLayer[]
					{
						checker1, checker2, stroke_layers[2], stroke_layers[3]
					}
				};
			}
			else if (example == DemoExamples.Example2_GeometricEffects_Step3)
			{
				var line_symbol = Example2GeometricEffects(DemoExamples.Example2_GeometricEffects_Step2);
				//Offset the dash effect of one of the "checker" layers
				var checker1 = line_symbol.SymbolLayers[0] as CIMStroke;
				var effects = checker1.Effects.ToList();
				//get out dash effect
				var dash_effect = effects[1] as CIMGeometricEffectDashes;
				//Change the offset to "skip" a pattern and get the
				//checkerboard effect
				dash_effect.DashTemplate = new double[] { 0, checker1.Width, checker1.Width, 0 };
				effects[1] = dash_effect;
				//apply the change back to the layer
				checker1.Effects = effects.ToArray();
				//apply the changed layer back to the symbol
				line_symbol.SymbolLayers[0] = checker1;
				return line_symbol;
			}
			return null;
		}

		private CIMPolygonSymbol Example3HatchFill(DemoExamples example)
		{
			var poly_symbol = SymbolFactory.Instance.ConstructPolygonSymbol(null,
													SymbolFactory.Instance.ConstructStroke(
														ColorFactory.Instance.BlueRGB, 2.0));
			var layers = poly_symbol.SymbolLayers.ToList();
			layers.AddRange(CreateHatches(example));
			poly_symbol.SymbolLayers = layers.ToArray();
			return poly_symbol;
		}

		private CIMLineSymbol Example4DimensionLineSymbol(DemoExamples example, string text)
		{
			var layers = DimensionStyleLayers(example, text);
			return new CIMLineSymbol()
			{
				SymbolLayers = layers.ToArray()
			};
		}

		private CIMPolygonSymbol Example5StippleFillPolygonSymbol(CIMColor color,
			PlacementGridType placementGridType, double stipple_size)
		{
			var layers = CreateStippleFill(color, placementGridType, stipple_size);
			return new CIMPolygonSymbol()
			{
				SymbolLayers = layers.ToArray()
			};
		}

		private CIMSymbol Example6AddDropShadow(CIMSymbol symbol, CIMSymbolLayer dropShadow)
		{
			if (symbol is CIMLineSymbol lineSymbol)
			{
				//Add the drop shadow
				var layers = lineSymbol.SymbolLayers.ToList();
				var last_stroke = layers.OfType<CIMStroke>().LastOrDefault();
				if (last_stroke == null)
					//Drop shadow wont really work on this kind of line symbol
					return symbol;
				((CIMStroke)dropShadow).Width = last_stroke.Width;//make sure they match
				layers.Add(dropShadow);
				//apply the change
				lineSymbol.SymbolLayers = layers.ToArray();
			}
			else if (symbol is CIMPolygonSymbol polySymbol)
			{
				//Add the drop shadow
				var layers = polySymbol.SymbolLayers.ToList();
				layers.Add(dropShadow);
				//apply the change
				polySymbol.SymbolLayers = layers.ToArray();
			}
			else if (symbol is CIMTextSymbol textSymbol)
			{
				//Either add the drop shadow fill layer to the text's poly symbol
				textSymbol.Symbol = Example6AddDropShadow(textSymbol.Symbol, dropShadow) as CIMPolygonSymbol;

				//Or...just use textSymbol.ShadowColor and Shadow offset properties
				//directly...basically the end result is the same...
				//
				//textSymbol.ShadowColor = ((CIMSolidFill)dropShadow).Color;
				//var moveEffect = dropShadow.Effects[0] as CIMGeometricEffectMove;
				//textSymbol.ShadowOffsetX = moveEffect.OffsetX;
				//textSymbol.ShadowOffsetY = moveEffect.OffsetY;
			}
			else if (symbol is CIMPointSymbol pointSymbol)
			{
				var symbol_layers = pointSymbol.SymbolLayers.ToList();
				var last_layer = symbol_layers.Last() as CIMMarker;
				if (last_layer == null)
					return symbol;
				if (last_layer is CIMVectorMarker vectorMarker)
				{
					var markerGraphics = vectorMarker.MarkerGraphics.ToList();
					var markerGraphic = markerGraphics.Last();
					markerGraphic.Symbol = Example6AddDropShadow(
								markerGraphic.Symbol, dropShadow);
					vectorMarker.MarkerGraphics = markerGraphics.ToArray();
				}
				else if (last_layer is CIMCharacterMarker characterMarker)
				{
					characterMarker.Symbol = Example6AddDropShadow(
								characterMarker.Symbol, dropShadow) as CIMPolygonSymbol;
				}
				pointSymbol.SymbolLayers = symbol_layers.ToArray();
			}
			return symbol;
		}

		private List<CIMSymbolLayer> CheckerBoardLayers()
		{
			var stroke_base = SymbolFactory.Instance.ConstructStroke(
															ColorFactory.Instance.BlackRGB, 10.0);
			stroke_base.CapStyle = LineCapStyle.Butt;

			var stroke_background = SymbolFactory.Instance.ConstructStroke(
												ColorFactory.Instance.WhiteRGB, 8.0);
			stroke_background.CapStyle = LineCapStyle.Butt;

			var checkers1 = SymbolFactory.Instance.ConstructStroke(
												ColorFactory.Instance.BlackRGB, 4.0);
			checkers1.CapStyle = LineCapStyle.Butt;

			var checkers2 = SymbolFactory.Instance.ConstructStroke(
												ColorFactory.Instance.BlackRGB, 4.0);
			checkers2.CapStyle = LineCapStyle.Butt;

			return new List<CIMSymbolLayer>()
			{
				checkers1, checkers2, stroke_background, stroke_base,
			};
		}

		private List<CIMHatchFill> CreateHatches(DemoExamples example)
		{
			//separation and angle can be what u want.
			//0 degrees is Horizontal. 90 degrees is vertical ("north"), etc.
			if (example == DemoExamples.Example3_CrossHatch1)
			{
				//Easiest to use symbol factory to make the hatch layers
				var hatchFill = SymbolFactory.Instance.ConstructHatchFill(
					ColorFactory.Instance.BlueRGB, 45.0, 5) as CIMHatchFill;
				//customize the hatch line symbol if needed
				//hatchFill.LineSymbol = ....;

				return new List<CIMHatchFill>() { hatchFill };
			}
			else if (example == DemoExamples.Example3_CrossHatch2)
			{
				var layers = CreateHatches(example - 1);

				var hatchFill2 = SymbolFactory.Instance.ConstructHatchFill(
					ColorFactory.Instance.BlueRGB, -45.0, 5) as CIMHatchFill;
				//customize the hatch line symbol if needed
				//hatchFill2.LineSymbol = ....;

				layers.Add(hatchFill2);
				return layers;
			}
			else if (example == DemoExamples.Example3_CrossHatch3)
			{
				var layers = CreateHatches(example - 1);
				var hatchFill3 = SymbolFactory.Instance.ConstructHatchFill(
					ColorFactory.Instance.BlueRGB, 90.0, 5) as CIMHatchFill;
				//customize the hatch line symbol if needed
				//hatchFill3.LineSymbol = ....;

				//Z order doesnt really matter
				layers.Add(hatchFill3);
				return layers;
			}
			else
			{
				//and so on and so on - roll your own by varying angle (and separation)
				var layers = CreateHatches(example - 1);
				var hatchFill4 = SymbolFactory.Instance.ConstructHatchFill(
					ColorFactory.Instance.BlueRGB, 0, 5) as CIMHatchFill;
				//customize the hatch line symbol if needed
				//hatchFill4.LineSymbol = ....;

				//Z order doesnt really matter
				layers.Add(hatchFill4);
				return layers;
			}
		}

		private List<CIMSymbolLayer> DimensionStyleLayers(DemoExamples example, string text = "")
		{
			var symbol_layers = new List<CIMSymbolLayer>();

			var stroke = SymbolFactory.Instance.ConstructStroke(
											ColorFactory.Instance.BlackRGB, 2.0);
			//End arrow
			var arrow = SymbolFactory.Instance.ConstructMarker(
											63, "ESRI Arrowhead", "Regular", 10) as CIMCharacterMarker;

			//For end and middle dashes
			var end_dash = SymbolFactory.Instance.ConstructMarker(95, "Arial", "Regular", 12);
			end_dash.Rotation = 90;

			//Marker placement on ends
			var endMarkerPlacement = new CIMMarkerPlacementAtExtremities()
			{
				ExtremityPlacement = ExtremityPlacement.Both,
				PlacePerPart = false,
				AngleToLine = true
			};
			arrow.MarkerPlacement = endMarkerPlacement;
			end_dash.MarkerPlacement = endMarkerPlacement;

			//reverse Z-order
			symbol_layers.Add(end_dash);
			symbol_layers.Add(arrow);
			symbol_layers.Add(stroke);

			if (example == DemoExamples.Example4_DimensionSymbol_Step1)
				return symbol_layers;

			if (example >= DemoExamples.Example4_DimensionSymbol_Step2)
			{
				//Offset Arrowhead to have the tip at the end of the
				//line
				arrow.AnchorPoint = MapPointBuilder.CreateMapPoint(0.5, 0.0);
				arrow.AnchorPointUnits = SymbolUnits.Relative;//Default is absolute
				arrow.OffsetX = 0.5;//places arrow point tip on the end of the line
			}
			if (example >= DemoExamples.Example4_DimensionSymbol_Step3)
			{
				var middle_dash = end_dash.Clone() as CIMMarker;
				//Marker placement on middle
				var middleMarkerPlacement = new CIMMarkerPlacementOnLine()
				{
					PlacePerPart = true,
					AngleToLine = true,
					RelativeTo = PlacementOnLineRelativeTo.LineMiddle
				};
				middle_dash.MarkerPlacement = middleMarkerPlacement;
				symbol_layers.Insert(0, middle_dash);
			}

			if (example >= DemoExamples.Example4_DimensionSymbol_Step4)
			{
				//We need a VectorMarker to use for the text
				var vectorMarker = SymbolFactory.Instance.ConstructMarker() as CIMVectorMarker;
				vectorMarker.Size = 10.0;

				//swizzle the MarkerGraphics to be a TextSymbol
				var textSymbol = SymbolFactory.Instance.DefaultTextSymbol;
				textSymbol.SetSize(10);
				//Assign the textsymbol and text to the markergraphic
				var markerGraphic = new CIMMarkerGraphic()
				{
					Geometry = MapPointBuilder.CreateMapPoint(0, 0),
					Symbol = textSymbol,
					TextString = text,
					PrimitiveName = DimensionTextPrimitiveName
				};
				//Do the switch
				vectorMarker.MarkerGraphics[0] = markerGraphic;

				//Marker placement on middle
				var middleMarkerPlacement = new CIMMarkerPlacementOnLine()
				{
					PlacePerPart = false,
					AngleToLine = true,
					RelativeTo = PlacementOnLineRelativeTo.LineMiddle
				};
				vectorMarker.MarkerPlacement = middleMarkerPlacement;

				//Offset the text up and to the left
				vectorMarker.OffsetX = -vectorMarker.Size;
				vectorMarker.OffsetY = 5;

				//add the layer to the mix
				symbol_layers.Insert(0, vectorMarker);
			}
			return symbol_layers;
		}

		private List<CIMSymbolLayer> CreateStippleFill(CIMColor color,
			PlacementGridType placementGridType, double stipple_size)
		{
			var stroke = SymbolFactory.Instance.ConstructStroke(
											color, 2.0);
			//either eliminate this layer or set it transparent to remove
			//the white background to the fill
			var fill = SymbolFactory.Instance.ConstructSolidFill(
									 ColorFactory.Instance.WhiteRGB);

			//Make the stipple. We will use dots but the marker can be anything
			//stipple_size controls the size of the pattern.
			//It will be repeated, as needed, to fill each
			//polygon symbolized with the stipple effect
			var stipple = SymbolFactory.Instance.ConstructMarker(
											color, stipple_size, SimpleMarkerStyle.Circle);

			//The stipple is controlled by a CIMMarkerPlacementInsidePolygon
			var stipple_effect = new CIMMarkerPlacementInsidePolygon()
			{
				//Play with these settings as desired to examine their
				//effect on the resulting stipple pattern
				PlacePerPart = true,
				GridType = placementGridType,

				Randomness = 100,//100% random - ignored for
												 //GridType = PlacementGridType.Fixed

				Seed = 11,//Used in conjunction with Randomness to generate a random
									//stipple pattern. Ignored when GridType = PlacementGridType.Fixed

				ShiftOddRows = true,//true to offset rows for GridType = PlacementGridType.Fixed only

				StepX = stipple_size * 2,//Ideally, bigger than the marker size
				StepY = stipple_size * 2,

				Clipping = PlacementClip.ClipAtBoundary//Various clip options
			};
			//assign the marker placement
			stipple.MarkerPlacement = stipple_effect;
			return new List<CIMSymbolLayer>()
			{
				stroke, stipple, fill
			};
		}

		private CIMSymbolLayer ConstructDropShadowLayer(CIMColor shadowColor, DemoSymbolType symbolType, double width = 1.0)
		{
			CIMSymbolLayer shadowLayer = null;
			var offsetx = -5;
			var offsety = -5;
			//Change offset to reposition drop shadow as needed
			//Negative is left and down, positive is right and up.
			if (symbolType == DemoSymbolType.Point)
			{
				offsetx = offsety = -3;
				shadowLayer = SymbolFactory.Instance.ConstructSolidFill(shadowColor) as CIMSolidFill;
			}
			else if (symbolType == DemoSymbolType.Line)
			{
				offsetx = -15;
				offsety = -2;
				shadowLayer = SymbolFactory.Instance.ConstructStroke(shadowColor, width) as CIMSolidStroke;
			}
			else if (symbolType == DemoSymbolType.Polygon)
			{
				offsetx = offsety = -10;
				shadowLayer = SymbolFactory.Instance.ConstructSolidFill(shadowColor) as CIMSolidFill;
			}
			else
			{
				//text
				offsetx = -10;
				offsety = -5;
				shadowLayer = SymbolFactory.Instance.ConstructSolidFill(shadowColor) as CIMSolidFill;
			}

			shadowLayer.Effects = new CIMGeometricEffect[]
			{
				new CIMGeometricEffectMove()
				{
					OffsetX = offsetx,
					OffsetY = offsety
				}
			};
			return shadowLayer;
		}

		#region Overrides
		/// <summary>
		/// Called by Framework when ArcGIS Pro is closing
		/// </summary>
		/// <returns>False to prevent Pro from closing, otherwise True</returns>
		protected override bool CanUnload()
		{
			//TODO - add your business logic
			//return false to ~cancel~ Application close
			return true;
		}

		#endregion Overrides

	}
}
