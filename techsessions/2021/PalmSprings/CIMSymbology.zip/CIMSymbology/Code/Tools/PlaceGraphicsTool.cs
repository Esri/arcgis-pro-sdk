﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace CIMSymbologyDemo.Tools
{
	internal abstract class PlaceGraphicsTool : MapTool
	{
		
		public PlaceGraphicsTool()
		{
			IsSketchTool = true;
			SketchType = SketchGeometryType.Rectangle;
			SketchOutputMode = SketchOutputMode.Map;
		}

		protected DemoSymbolType DemoSymbolType { get; set; }

		protected override Task OnToolActivateAsync(bool active)
		{
			return base.OnToolActivateAsync(active);
		}

		protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
		{
			return QueuedTask.Run(() =>
			{
				var symbol = Module1.Current.GetSymbolForExample(
						Module1.Current.CurrentExample, this.DemoSymbolType);
				if (symbol == null)
					return true;//There is no symbol example for this combination
				Module1.Current.CurrentGraphicsLayer?.AddElement(geometry, symbol);
				return true;
			});
		}
	}

	internal class PlaceLineTool : PlaceGraphicsTool
	{
		public PlaceLineTool()
		{
			IsSketchTool = true;
			SketchType = SketchGeometryType.Line;
			SketchOutputMode = SketchOutputMode.Map;
			this.DemoSymbolType = DemoSymbolType.Line;
		}

		protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
		{
			return QueuedTask.Run(() =>
			{
				CIMSymbol symbol = null;
				if (Module1.Current.CurrentExample == DemoExamples.Example4_DimensionSymbol_Step4)
				{
					var length = ((Polyline)geometry).Length;
					//Round it - 1 digit of precision
					var len_string = $"{Math.Truncate(length * 10) / 10}";
					symbol = Module1.Current.GetSymbolForExample(
						Module1.Current.CurrentExample, this.DemoSymbolType, len_string);
				}
				else
				{
					symbol = Module1.Current.GetSymbolForExample(
						Module1.Current.CurrentExample, this.DemoSymbolType);
				}
				if (symbol == null)
					return true;//There is no symbol example for this combination

				Module1.Current.CurrentGraphicsLayer?.AddElement(geometry as Polyline, symbol);
				return true;
			});
		}
	}

	internal class PlacePointTool : PlaceGraphicsTool
	{
		public PlacePointTool()
		{
			IsSketchTool = true;
			SketchType = SketchGeometryType.Point;
			SketchOutputMode = SketchOutputMode.Map;
			this.DemoSymbolType = DemoSymbolType.Point;
		}
	}

	internal class PlacePolygonTool : PlaceGraphicsTool
	{
		public PlacePolygonTool()
		{
			IsSketchTool = true;
			SketchType = SketchGeometryType.Polygon;
			SketchOutputMode = SketchOutputMode.Map;
			this.DemoSymbolType = DemoSymbolType.Polygon;
		}
	}

	internal class PlaceTextTool : PlaceGraphicsTool
	{
		public PlaceTextTool()
		{
			IsSketchTool = true;
			SketchType = SketchGeometryType.Point;
			SketchOutputMode = SketchOutputMode.Map;
			this.DemoSymbolType = DemoSymbolType.Text;
		}

		protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
		{
			return QueuedTask.Run(() =>
			{
				var symbol = Module1.Current.GetSymbolForExample(
						Module1.Current.CurrentExample, this.DemoSymbolType);
				if (symbol == null)
					return true;//There is no symbol example for this combination

				Module1.Current.CurrentGraphicsLayer?.AddElement(geometry as MapPoint, "Text",
					                                                      symbol as CIMTextSymbol);
				return true;
			});
		}
	}
}
