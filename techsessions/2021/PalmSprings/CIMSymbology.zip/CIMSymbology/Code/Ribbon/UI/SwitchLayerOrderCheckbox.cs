﻿using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMSymbologyDemo.Ribbon.UI
{
	class SwitchLayerOrderCheckbox : CheckBox
	{
		public SwitchLayerOrderCheckbox()
		{
			IsChecked = false;
		}

		protected override void OnClick()
		{
			Module1.Current.SwitchLayerOrder = this.IsChecked ?? false;
		}
	}
}
