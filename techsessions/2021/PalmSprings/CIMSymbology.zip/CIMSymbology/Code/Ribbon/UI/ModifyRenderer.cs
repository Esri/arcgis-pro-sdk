﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace CIMSymbologyDemo.Ribbon.UI
{
	internal class ModifyRenderer : Button
	{
		protected override void OnClick()
		{
			//DimensionTextPrimitiveName
			var lineFeatures = MapView.Active.Map.GetLayersAsFlattenedList()
													 .FirstOrDefault(fl => fl.Name == "DemoLineFeatures") as FeatureLayer;
			if (lineFeatures == null)
			{
				MessageBox.Show("Line feature layer: DemoLineFeatures not found", "Modify Renderer");
				return;
			}

			QueuedTask.Run(() =>
			{
				var renderer = lineFeatures.GetRenderer() as CIMSimpleRenderer;
				renderer.Symbol =
					 Module1.Current.GetSymbolForExample(DemoExamples.Example4_DimensionSymbol_Step4, DemoSymbolType.Line).MakeSymbolReference();
				var primitiveOverride = new CIMPrimitiveOverride()
				{
					PrimitiveName = Module1.DimensionTextPrimitiveName,
					PropertyName = "TextString",
					ValueExpressionInfo = new CIMExpressionInfo()
					{
						Title = "Custom Dimensioning",
						Expression = "round(number($feature.Shape_Length), 1)",
						ReturnType = ExpressionReturnType.Default
					}
				};
				//assign the override to the renderer
				renderer.Symbol.PrimitiveOverrides = new List<CIMPrimitiveOverride>()
				{
					primitiveOverride
				}.ToArray();
				//commit the changes
				lineFeatures.SetRenderer(renderer);
			});
		}
	}
}
