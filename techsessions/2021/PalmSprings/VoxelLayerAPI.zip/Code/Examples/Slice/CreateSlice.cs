﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Voxel;

namespace VoxelLayerAPI.Examples.Slice
{
	internal class CreateSlice : Button
	{
		protected override void OnClick()
		{
			//Selected voxel layer
			var voxelLayer = MapView.Active.GetSelectedLayers().OfType<VoxelLayer>().FirstOrDefault();
			if (voxelLayer == null)
			{
				voxelLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<VoxelLayer>().FirstOrDefault();
				if (voxelLayer == null)
					return;
			}

			QueuedTask.Run(() =>
			{
				if (voxelLayer.Visualization != VoxelVisualization.Volume)
					voxelLayer.SetVisualization(VoxelVisualization.Volume);
				voxelLayer.SetSliceContainerExpanded(true);
				voxelLayer.SetSliceContainerVisibility(true);

				//Create a slice
				//Define Location, Orientation, Tilt
				(double volx, double voly, double volz) = voxelLayer.GetVolumeSize();
				var location =
					new Coordinate3D(volx / 2, voly / 2, volz / 2);
				var orientation = 90.0; //West
				var tilt = 0.0; //Vertical

				//Define the SectionDefinition
				voxelLayer.CreateSlice(new SliceDefinition()
				{
					Name = "Middle Slice",
					//Location in voxel space
					VoxelPosition = location,
					//Use GetNormal w/ orientation and tilt
					Normal = voxelLayer.GetNormal(orientation, tilt),
					//Use GetOrientationAndTilt to translate back
					IsVisible = true
				});
				
			});
		}
	}
}
