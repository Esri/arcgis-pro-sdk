﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace VoxelLayerAPI.Examples
{
	internal class CreateLayer : Button
	{

		private string _path = "";
		protected override void OnClick()
		{
			var local_scene = MapView.Active.Map;

			//Set path to a .NetCDF
			_path = $@"{Module1.DemoPath}VoxelData\atlantic_stride_56.nc";

			QueuedTask.Run(() =>  {
				//Can also just use the path....
				var createParams = VoxelLayerCreationParams.Create(_path);
				createParams.IsVisible = true;
				//Use VoxelLayerCreationParams to enumerate the available 
				//variables in the data set

				//Customize as needed
				//e.g. Remove unwanted variables
				createParams.Variables[2].IsSelected = false;
				createParams.Variables[3].IsSelected = false;

				//Pick a default variable
				createParams.SetDefaultVariable(createParams.Variables[1]);

				//Create the layer - map must be a local scene!
				LayerFactory.Instance.CreateLayer<VoxelLayer>(createParams, local_scene);
			});
		}
	}
}





//_path = @"E:\Data\SDK\DevSummit\2021\PalmSprings\VoxelLayerAPI\VoxelData\china_epa.nc";
