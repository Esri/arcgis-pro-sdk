﻿/*

   Copyright 2021 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

   See the License for the specific language governing permissions and
   limitations under the License.

*/
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhatsNewSketch
{
  internal class SketchTool : MapTool
  {
    string streetName = "";

    public SketchTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;

      SketchOutputMode = SketchOutputMode.Map;

      UseSnapping = true;
    }

    private bool oldSnapping;
    private IEnumerable<SnapMode> oldSnapModes;
    private List<bool> oldSnappable = new List<bool>();

    protected override Task OnToolActivateAsync(bool active)
    {
      // cache snapping settings
      oldSnapping = Snapping.IsEnabled;
      oldSnapModes = Snapping.SnapModes;

      // ensure snapping is on
      Snapping.IsEnabled = true;
      // ensure only vertex, edge, end snapping is set
      Snapping.SetSnapModes(SnapMode.Vertex, SnapMode.Edge, SnapMode.End);

      //turn them all off
      var flayers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().ToList();
      var sLayer = MapView.Active.Map.GetLayersAsFlattenedList().FirstOrDefault(l => l.Name == "Streets") as FeatureLayer;

      if (flayers.Count() > 0)
      {
        QueuedTask.Run(() => {
          foreach (var fl in flayers)
          {
            // use an extension method
            //  (must be called inside QueuedTask)
            oldSnappable.Add(fl.IsSnappable);
            fl.SetSnappable(false);
          }

          if (sLayer != null)
            sLayer.SetSnappable(true);
        });
      }

      return base.OnToolActivateAsync(active);
    }

    protected override Task OnToolDeactivateAsync(bool hasMapViewChanged)
    {
      // restore previous snapping
      Snapping.IsEnabled = oldSnapping;
      Snapping.SnapModes = oldSnapModes;

      // restore layer snappability
      var flayers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().ToList();

      if (flayers.Count() > 0)
      {
        QueuedTask.Run(() =>
        {
          int idx = 0;
          foreach (var fl in flayers)
          {
            // use an extension method
            //  (must be called inside QueuedTask)
            fl.SetSnappable(oldSnappable[idx]);
            idx++;
          }
        });
      }
      
      return base.OnToolDeactivateAsync(hasMapViewChanged);
    }
    protected override async Task<bool> OnSketchModifiedAsync()
    {
      await base.OnSketchModifiedAsync();

      var sketch = await this.GetCurrentSketchAsync();

      // if this is the first point when i'm identifying
      if ((sketch.PointCount == 1) && (SketchType == SketchGeometryType.Point))
      {
        // did I snap to a feature?
        var results = this.SnappingResults;
        var snapResult = results[0];
        if ((snapResult.Layer != null) && (snapResult.OID != -1))
        {
          // get the "Name" attribute - if it exists
          var (success, value) = await GetAttributeFromFeature(snapResult.Layer, snapResult.OID, "Name");
          streetName = (success) ? value : "";

          // force the sketch to restart but change sketch type to rectangle to collect features 
          await ClearSketchAsync();
          SketchType = SketchGeometryType.Rectangle;
          await StartSketchAsync();
        }

        // else
        //   no snap result... i want to keep sketching 
      }
      return true;
    }

    private Task<Tuple<bool, string>> GetAttributeFromFeature(Layer layer, long oid, string fieldName)
    {
      return QueuedTask.Run(() =>
      {
        var insp = new Inspector();
        insp.Load(layer, oid);

        var att = insp.FirstOrDefault(a => a.FieldName == fieldName);
        if (att == null)
          return Tuple.Create(false, "");

        var sValue = att.CurrentValue.ToString();
        return Tuple.Create(true, sValue);
      });
    }


    protected override async Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      // ignore the point sketch type (Identify single feature mode)
      //   only act when the sketch type is rectangle 
      if (SketchType != SketchGeometryType.Rectangle)
        return true;

      // retrieve the parcel layer
      var layer = MapView.Active.Map.GetLayersAsFlattenedList().FirstOrDefault(l => l.Name == "Parcels") as BasicFeatureLayer;
      if (layer != null)
      {
        await QueuedTask.Run(() =>
        {
          // get all the features that intersect the rectangle
          var features = MapView.Active.GetFeatures(geometry);
          // if there's some on the layer we're interested in
          if (features.ContainsKey(layer))
          {
            // create an edit operation
            var op = new EditOperation();
            op.Name = "Assign Attributes";
            op.SelectModifiedFeatures = true;

            // set up the new attribute
            Dictionary<string, object> newAtts = new Dictionary<string, object>();
            newAtts.Add("FULL_STR", streetName);

            // modify each of the features
            foreach (var oid in features[layer])
            {
              op.Modify(layer, oid, newAtts);
            }

            // execute the operation
            op.ExecuteAsync();
          }
        });
      }
      // change sketch type to Point to start again
      SketchType = SketchGeometryType.Point;

      return true;

    }
  }
}
