﻿/*

   Copyright 2021 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

   See the License for the specific language governing permissions and
   limitations under the License.

*/
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Events;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WhatsNewSketch
{
  internal class SketchEventsViewModel : DockPane
  {
    private const string _dockPaneID = "WhatsNewSketch_SketchEvents";

    protected SketchEventsViewModel() 
    {
      AddEntry("Click 'Start Events' to start listening to events.");
    }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

    private bool _listening = false;
    public bool IsListening => _listening;

    private ICommand _clearCmd = null;
    public ICommand ClearTextCmd
    {
      get
      {
        if (_clearCmd == null)
          _clearCmd = new RelayCommand(() => ClearEntries());
        return _clearCmd;
      }
    }

    public string ButtonText => _listening ? "Stop Events" : "Start Events";

    #region Register / Unregister

    private bool _firstStart = true;
    private List<SubscriptionToken> _sketchEvents = new List<SubscriptionToken>();

    private ICommand _startStopCmd;
    public ICommand StartStopCmd
    {
      get
      {
        if (_startStopCmd == null)
        {
          _startStopCmd = new RelayCommand(() =>
          {
            if (_firstStart)
            {
              ClearEntries();
              _firstStart = false;
            }

            if (_listening)
            {
              StopListening();
            }
            else
            {
              StartListening();
            }
          });
        }
        return _startStopCmd;
      }
    }

    private void StartListening()
    {
      if (_listening)
        return;

      _listening = Register();
      NotifyPropertyChanged(nameof(ButtonText));
      NotifyPropertyChanged(nameof(IsListening));
    }
    private void StopListening()
    {
      if (!_listening)
        return;

      _listening = Unregister();
      NotifyPropertyChanged(nameof(ButtonText));
      NotifyPropertyChanged(nameof(IsListening));
    }

    private bool Register()
    => RegisterSketchEvents();

    private bool Unregister()
      => UnregisterSketchEvents();

    private bool RegisterSketchEvents()
    {
      _sketchEvents.Add(SketchCancelledEvent.Subscribe(OnSketchCancelled));
      _sketchEvents.Add(SketchModifiedEvent.Subscribe(OnSketchModified));
      _sketchEvents.Add(BeforeSketchCompletedEvent.Subscribe(OnBeforeSketchCompleted));
      _sketchEvents.Add(SketchCompletedEvent.Subscribe(OnSketchCompleted));

      AddEntry("Listening Sketch Events");

      return true;
    }

    private bool UnregisterSketchEvents()
    {
      // remember to unsubscribe in the same order
      SketchCancelledEvent.Unsubscribe(_sketchEvents[0]);
      SketchModifiedEvent.Unsubscribe(_sketchEvents[1]);
      BeforeSketchCompletedEvent.Unsubscribe(_sketchEvents[2]);
      SketchCompletedEvent.Unsubscribe(_sketchEvents[3]);

      _sketchEvents.Clear();

      AddEntry("Not listening");

      return false;
    }

   #endregion RegisterUnregister

    #region eventLog

    private static readonly object _lock = new object();
    private List<string> _entries = new List<string>();

    public string EventLog
    {
      get
      {
        string contents = "";
        lock (_lock)
        {
          contents = string.Join("\r\n", _entries.ToArray());
        }
        return contents;
      }
    }

    private void ClearEntries()
    {
      lock (_lock)
      {
        _entries.Clear();
      }
      NotifyPropertyChanged(nameof(EventLog));
    }

    private void AddEntry(string entry)
    {
      lock (_lock)
      {
        _entries.Add($"{entry}");
      }
      NotifyPropertyChanged(nameof(EventLog));
    }

    private void RecordEvent(string eventName, string entry)
    {
      var dateTime = DateTime.Now.ToString("G");
      AddEntry($"{dateTime}: {eventName} {entry}");
    }


    #endregion

    #region Sketch Events
    private void OnSketchCancelled(SketchCancelledEventArgs args)
    {
      AddEntry("SketchCancelled event");
      AddEntry("---------------------------------");
    }

    private void OnSketchModified(SketchModifiedEventArgs args)
    {
      AddEntry("SketechModified event");
      AddEntry("    " + args.SketchOperationType.ToString() + "; " + args.IsUndo.ToString());

    }

    private Task OnBeforeSketchCompleted(BeforeSketchCompletedEventArgs args)
    {
      AddEntry("BeforeSketchCompleted event");
      AddEntry("---------------------------------");

      return Task.CompletedTask;
    }

    private void OnSketchCompleted(SketchCompletedEventArgs args)
    {
      AddEntry("SketchCompleted event");
      AddEntry("---------------------------------");
    }
    #endregion

    #region BeforeSketchCompleted - Removing Curves

    public string BSC_Curves => (_bsc_CurvesTok != null) ? "Stop Events" : "Start Events";

    private SubscriptionToken _bsc_CurvesTok;
    private ICommand _startStop_BSC_Curves_Cmd;
    public ICommand StartStop_BSC_Curves_Cmd
    {
      get
      {
        if (_startStop_BSC_Curves_Cmd == null)
        {
          _startStop_BSC_Curves_Cmd = new RelayCommand(() =>
          {
            if (_bsc_CurvesTok != null)
            {
              BeforeSketchCompletedEvent.Unsubscribe(_bsc_CurvesTok);
              _bsc_CurvesTok = null;
            }
            else
            {
              _bsc_CurvesTok = BeforeSketchCompletedEvent.Subscribe(OnRemoveCurves);
            }

            NotifyPropertyChanged(nameof(BSC_Curves));
          });
        }
        return _startStop_BSC_Curves_Cmd;
      }
    }

    private Task OnRemoveCurves(BeforeSketchCompletedEventArgs args)
    {
      AddEntry("BeforeSketchCompleted event - OnRemoveCurves");

      // check for a map
      var map = args?.MapView?.Map;
      if (map == null)
        return Task.CompletedTask;

      var sketch = args?.Sketch;
      if (sketch == null)
        return Task.CompletedTask;

      int oldCount = sketch.PointCount;

      if (sketch is Polyline polyline && polyline.HasCurves)
      {
        var newGeom = GeometryEngine.Instance.DensifyByLength(sketch, 20);

        int newCount = newGeom.PointCount;
        bool hasCurves = (newGeom as Polyline).HasCurves;

        // update the sketch geometry 
        args.SetSketchGeometry(newGeom);
      }
      return Task.CompletedTask;
    }

    #endregion

    #region BeforeSketchCompleted - Two Points

    public string BSC_TwoPoints => (_bscC_TwoPointsTok != null) ? "Stop Events" : "Start Events";

    private SubscriptionToken _bscC_TwoPointsTok;
    private ICommand _startStop_BSC_TwoPoints_Cmd;
    public ICommand StartStop_BSC_TwoPoints_Cmd
    {
      get
      {
        if (_startStop_BSC_TwoPoints_Cmd == null)
        {
          _startStop_BSC_TwoPoints_Cmd = new RelayCommand(() =>
          {
            if (_bscC_TwoPointsTok != null)
            {
              BeforeSketchCompletedEvent.Unsubscribe(_bscC_TwoPointsTok);
              _bscC_TwoPointsTok = null;
            }
            else
            {
              _bscC_TwoPointsTok = BeforeSketchCompletedEvent.Subscribe(OnTwoPoints);
            }

            NotifyPropertyChanged(nameof(BSC_TwoPoints));
          });
        }
        return _startStop_BSC_TwoPoints_Cmd;
      }
    }

    private Task OnTwoPoints(BeforeSketchCompletedEventArgs args)
    {
      AddEntry("BeforeSketchCompleted event - OnTwoPoints");

      // check for a map
      var map = args?.MapView?.Map;
      if (map == null)
        return Task.CompletedTask;

      var sketch = args?.Sketch;
      if (sketch == null)
        return Task.CompletedTask;

      int oldCount = sketch.PointCount;

      if ((sketch is Polyline polyline) && oldCount > 1)
      {
        var startPt = polyline.Points[0];
        var endPt = polyline.Points[polyline.PointCount - 1];

        var pts = new List<MapPoint>() { startPt, endPt };
        var newLine = PolylineBuilder.CreatePolyline(pts);

        // update the sketch geometry 
        args.SetSketchGeometry(newLine);
      }

      return Task.CompletedTask;
    }




    #endregion

    #region BeforeSketchCompleted - Set Zs / Ms

    public string BSC_ZsMs => (_bscC_ZsMsTok != null) ? "Stop Events" : "Start Events";

    private SubscriptionToken _bscC_ZsMsTok;
    private ICommand _startStop_BSC_ZsMs_Cmd;
    public ICommand StartStop_BSC_ZsMs_Cmd
    {
      get
      {
        if (_startStop_BSC_ZsMs_Cmd == null)
        {
          _startStop_BSC_ZsMs_Cmd = new RelayCommand(() =>
          {
            if (_bscC_ZsMsTok != null)
            {
              BeforeSketchCompletedEvent.Unsubscribe(_bscC_ZsMsTok);
              _bscC_ZsMsTok = null;
            }
            else
            {
              _bscC_ZsMsTok = BeforeSketchCompletedEvent.Subscribe(OnSetZsMs);
            }

            NotifyPropertyChanged(nameof(BSC_ZsMs));
          });
        }
        return _startStop_BSC_ZsMs_Cmd;
      }
    }

    /// Sets the Z values of the sketch to the specified elevation surface
    /// regardless of the current Z environment and any existing Z values the sketch may have
    /// 
    readonly string surfaceName = "Ground";
    private async Task OnSetZsMs(BeforeSketchCompletedEventArgs args)
    {
      AddEntry("BeforeSketchCompleted event - OnSetZsMs");

      // check for a map
      var map = args?.MapView?.Map;
      if (map == null)
        return;

      var sketch = args?.Sketch;
      if (sketch == null)
        return;

      int numPoints = sketch.PointCount;

      //check if surfacename is in the map
      if (map.ElevationSurfaces.Count(s => s.Name == surfaceName) == 0)
      {
        MessageBox.Show("Surface: " + surfaceName + " is not in the map");
        return;
      }

      //get a new geometry with the Z values from the specified elevation surface
      var ZResult = await map.GetZsFromSurfaceAsync(sketch, surfaceName);
      if (ZResult.Status == SurfaceZsResultStatus.Ok)
        // update the sketch geometry 
        args.SetSketchGeometry(ZResult.Geometry);
    }




    #endregion

    #region BeforeSketchCompleted - Set Empty

    public string BSC_Empty => (_bscC_EmptyTok != null) ? "Stop Events" : "Start Events";

    private SubscriptionToken _bscC_EmptyTok;
    private ICommand _startStop_BSC_Empty_Cmd;
    public ICommand StartStop_BSC_Empty_Cmd
    {
      get
      {
        if (_startStop_BSC_Empty_Cmd == null)
        {
          _startStop_BSC_Empty_Cmd = new RelayCommand(() =>
          {
            if (_bscC_EmptyTok != null)
            {
              BeforeSketchCompletedEvent.Unsubscribe(_bscC_EmptyTok);
              _bscC_EmptyTok = null;
            }
            else
            {
              _bscC_EmptyTok = BeforeSketchCompletedEvent.Subscribe(OnSetEmpty);
            }

            NotifyPropertyChanged(nameof(BSC_Empty));
          });
        }
        return _startStop_BSC_Empty_Cmd;
      }
    }

    private Task OnSetEmpty(BeforeSketchCompletedEventArgs args)
    {
      AddEntry("BeforeSketchCompleted event - OnSetEmpty");

      // check for a map
      var map = args?.MapView?.Map;
      if (map == null)
        return Task.CompletedTask;

      var sketch = args?.Sketch;
      if (sketch == null)
        return Task.CompletedTask; 

      int numPoints = sketch.PointCount;

      Geometry newSketch = null;

      // update the sketch geometry to null
      args.SetSketchGeometry(newSketch);

      return Task.CompletedTask;
    }

    #endregion
  }


  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class SketchEvents_ShowButton : Button
  {
    protected override void OnClick()
    {
      SketchEventsViewModel.Show();
    }
  }
}
