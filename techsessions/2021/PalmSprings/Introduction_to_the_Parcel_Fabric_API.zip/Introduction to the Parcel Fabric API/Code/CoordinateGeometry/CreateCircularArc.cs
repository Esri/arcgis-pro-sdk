﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CoordinateGeometrySDK
{
  internal class CreateCircularArc : Button
  {
    protected override void OnClick()
    {
      //Check for one selected layer
      if (MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().Count() != 1)
      {
        System.Windows.MessageBox.Show("Please select one line feature layer in the table of contents", "Construct Circular Arc");
        return;
      }

      var featLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();

      //Run on MCT
      QueuedTask.Run( () =>
      {
        #region get polyline feature layer
        var fcDefinition = featLyr?.GetFeatureClass()?.GetDefinition();
        if (fcDefinition == null)
          return;

        if (fcDefinition.GetShapeType() != GeometryType.Polyline)
        {
          System.Windows.MessageBox.Show("Please select a line feature layer in the table of contents", "Construct Circular Arc");
          return;
        }
        #endregion

        //Example scenario. Make a circular arc that has 30 meter radius and 30 meter chord, N10°E chord bearing
        //=====================================================
        //User Entry Values
        //=====================================================
        double dRadius = 30;  //in meters
        double dChord = 30; //in meters
        //double dChordBearing = 80 * Math.PI /180; //polar cartesian equivalent converted to radians
        string QuadrantBearingChord = "n10-00-0e";
        bool curveLeft = true; //curve turning towards the left when traveling from start point towards end point.
        //=====================================================

        #region get the ground to grid corrections
        //Get the active map view.
        var mapView = MapView.Active;
        if (mapView?.Map == null)
          return;

        var cimDefinition = mapView.Map?.GetDefinition();
        if (cimDefinition == null) return;
        var cimG2G = cimDefinition.GroundToGridCorrection;

        //These extension methods automatically check if ground to grid is active, etc.
        double dG2G_ScaleFactor = cimG2G.GetConstantScaleFactor();
        double dG2G_DirectionOffsetCorrection = cimG2G.GetDirectionOffset() * Math.PI / 180;
        //this property is in decimal degrees. Converted to radians for use in circular arc creation

        #endregion

        double dMetersPerUnit = 1;
        if (fcDefinition.GetSpatialReference().IsProjected)
          dMetersPerUnit = fcDefinition.GetSpatialReference().Unit.ConversionFactor;

        dRadius /= dMetersPerUnit;  //30 meters divided by meters per unit
        dChord /= dMetersPerUnit;
        double dChordBearing = QuadrantBearingDMSToPolarRadians(QuadrantBearingChord); 
        //using DirectionUnitFormatConversion class

        esriArcOrientation CCW = curveLeft ? esriArcOrientation.esriArcCounterClockwise : esriArcOrientation.esriArcClockwise;
        dRadius *= dG2G_ScaleFactor;
        dChord *= dG2G_ScaleFactor;
        dChordBearing += dG2G_DirectionOffsetCorrection;

        var circArcStartPoint = MapView.Active.Extent.Center;
        if (circArcStartPoint == null)
          return;

        //Create the circular arc geometry
        EllipticArcSegment pCircArc = null;

        try
        {
          pCircArc = EllipticArcBuilder.CreateEllipticArcSegment(circArcStartPoint, dChord, dChordBearing,
            dRadius, CCW, MinorOrMajor.Minor);
        }
        catch
        {
          System.Windows.MessageBox.Show("Circular arc parameters not valid.", "Construct Circular Arc");
          return;
        }

        var newPolyline = PolylineBuilder.CreatePolyline(pCircArc);

        Dictionary<string, object> MyAttributes = new Dictionary<string, object>();
        MyAttributes.Add(fcDefinition.GetShapeField(), newPolyline);

        //check to make sure line is COGO enabled
        if (fcDefinition.IsCOGOEnabled())
        {
          double COGOEnteredChord = 
              PolarRadiansToNorthAzimuthDecimalDegrees(dChordBearing - dG2G_DirectionOffsetCorrection);
          //storing the entered direction in northazimuth decimal degrees
          MyAttributes.Add("Direction", COGOEnteredChord);

          if (curveLeft)
            dRadius = -dRadius; //store curves to the left with negative radius.

          MyAttributes.Add("Radius", dRadius / dG2G_ScaleFactor);
          MyAttributes.Add("Arclength", pCircArc.Length / dG2G_ScaleFactor);
        }

        var op = new EditOperation
        {
          Name = "Construct Circular Arc",
          SelectNewFeatures = true
        };
        op.Create(featLyr, MyAttributes);
        op.Execute();
      });
    }

    private double QuadrantBearingDMSToPolarRadians(string InQuadBearingDMS)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };
      return AngConv.ConvertToDouble(InQuadBearingDMS, ConvDef);
    }

    private double PolarRadiansToNorthAzimuthDecimalDegrees(double InPolarRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InPolarRadians, ConvDef);
    }
  }
}
