﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.DragDrop;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;



namespace ParcelsFromTraverseFiles
{
  internal class DropHandler1 : DropHandlerBase
  {
    private string folderPath;
    private string parcelRecordNameFromPath;
    private string parcelTypeNameFromPath;
    private List<string> traverseFiles;
    public override void OnDragOver(DropInfo dropInfo)
    {
      //default is to accept our data types
      dropInfo.Effects = DragDropEffects.All;
    }

    public override async void OnDrop(DropInfo dropInfo)
    {
      //eg, if you are accessing a dropped file
      //string filePath = dropInfo.Items[0].Data.ToString();

      #region OnDrop Traverse File
      if (FrameworkApplication.Panes.ActivePane is IMapPane)
      {
        //a drag is being made on the active map
        var view = ((IMapPane)FrameworkApplication.Panes.ActivePane).MapView;
        // globe or local
        if (view.ViewingMode == MapViewingMode.SceneGlobal ||
          view.ViewingMode == MapViewingMode.SceneLocal)
        {
          //skip since not supported on 3D;
        }
        else
        {
          //we are in 2D - COGO

          var myParcelFabricLayer =
            MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();

          //if there is no fabric in the map then bail
          if (myParcelFabricLayer == null)
            return;// "Please add a parcel fabric to the map.";

          traverseFiles = new List<string>();
          for (int i = 0; i < dropInfo.Items.Count(); i++)
          {
            var cbi = (ClipboardItem)dropInfo.Items[i].Data;
            traverseFiles.Add(cbi.CatalogPath);
          }

          folderPath = System.IO.Path.GetDirectoryName(traverseFiles[0]);
          string[] s = folderPath.Split(System.IO.Path.DirectorySeparatorChar);
          parcelRecordNameFromPath = s[s.Length - 1];
          parcelTypeNameFromPath = s[s.Length - 2];

          #region Get feature layers from parcel type name string
          // Get the feature layers from the parcel type name
          var polygonParcelTypeFeatLayer = 
           ParcelUtils.GetFirstFeatureLayerFromParcelTypeName(myParcelFabricLayer, parcelTypeNameFromPath, GeometryType.Polygon).Result;
          var lineParcelTypeFeatLayer =
            ParcelUtils.GetFirstFeatureLayerFromParcelTypeName(myParcelFabricLayer, parcelTypeNameFromPath, GeometryType.Polyline).Result;

          // Confirm that there are feature layers to write to
          if (polygonParcelTypeFeatLayer == null && lineParcelTypeFeatLayer == null)
            return; // "The parcel type " + parcelTypeNameFromPath + " was not found in the map.";
          #endregion

          #region Record management
          //check to see if there is a record with this name.
          var parcRecord = await myParcelFabricLayer.GetRecordAsync(parcelRecordNameFromPath);
          bool bRecordExists = parcRecord != null;
          var editOper1 = new EditOperation();
          if (bRecordExists)
          {// if it exists then set it as the Active record 
            await myParcelFabricLayer.SetActiveRecordAsync(parcelRecordNameFromPath);
          }
          else
          {
            var recordsLayer = await myParcelFabricLayer.GetRecordsLayerAsync();
            var editOper = new EditOperation();

            Dictionary<string, object> RecordAttributes = new Dictionary<string, object>();
            RecordAttributes.Add("Name", parcelRecordNameFromPath);
            editOper.CreateEx(recordsLayer.FirstOrDefault(), RecordAttributes);
            if (!editOper.Execute())
              return; // editOper.ErrorMessage;
            await myParcelFabricLayer.SetActiveRecordAsync(parcelRecordNameFromPath);
            parcRecord = await myParcelFabricLayer.GetRecordAsync(parcelRecordNameFromPath);
            editOper1 = editOper.CreateChainedOperation();
          }
          #endregion


          #region Create parcel features
          editOper1.Name = "Create Parcel Features from Traverse Files.";
          List<string> sTraverseFileLines = ParcelUtils.TraverseCoursesFromFiles(traverseFiles);

          //get current selection from polygonParcelTypeFeatLayer
          var ids = new List<long>(polygonParcelTypeFeatLayer.GetSelection().GetObjectIDs());

          bool bOK = await ParcelUtils.CreateFeaturesFromCourses(sTraverseFileLines, lineParcelTypeFeatLayer, editOper1);
          bool bOK2 = await ParcelUtils.CreateFeaturesFromCourses(sTraverseFileLines, polygonParcelTypeFeatLayer, editOper1);
          if (bOK | bOK2)
            editOper1.Execute();
          #endregion

        }
      }

      #endregion
      dropInfo.Handled = true;
    }
  }
}
