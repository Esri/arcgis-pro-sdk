﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcelsFromTraverseFiles
{
  internal class ParcelsFromTraverseFiles : Button
  {
    static private string AssemblyDirectory
    {
      get
      {
        string codeBase = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
        UriBuilder uri = new UriBuilder(codeBase);
        string path = Uri.UnescapeDataString(uri.Path);
        return System.IO.Path.GetDirectoryName(path);
      }
    }
    private string folderPath;
    private string parcelRecordNameFromPath;
    private string parcelTypeNameFromPath;
    private List<string> traverseFiles;

    protected async override void OnClick()
    {
      //first check for a valid license
      var lic = ArcGIS.Core.Licensing.LicenseInformation.Level;
      if (lic < ArcGIS.Core.Licensing.LicenseLevels.Standard)
      {
        MessageBox.Show("Insufficient License Level.");
        return;
      }

      /*get the source traverse files and location
      the parcel type, and target record are derived from the files' directory path
      the parcel name is based on the file name
      ..\[parcel type]\[record]\[name].txt
        Example: ..\Lot\SP12-32\77.txt
      */

      if (!GetSourceFilesAndFolder())
        return;
      var myParcelFabricLayer =
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();

      string errorMessage = await QueuedTask.Run(async () =>
     {
       //if there is no fabric in the map then bail
       if (myParcelFabricLayer == null)
         return "Please add a parcel fabric to the map.";
      try
      {
        #region Get feature layers from parcel type name string
         // Get the feature layers from the parcel type name
         var polygonParcelTypeFeatLayer =
          ParcelUtils.GetFirstFeatureLayerFromParcelTypeName(myParcelFabricLayer, parcelTypeNameFromPath, GeometryType.Polygon).Result;
         var lineParcelTypeFeatLayer =
           ParcelUtils.GetFirstFeatureLayerFromParcelTypeName(myParcelFabricLayer, parcelTypeNameFromPath, GeometryType.Polyline).Result;

        // Confirm that there are feature layers to write to
        if (polygonParcelTypeFeatLayer == null && lineParcelTypeFeatLayer == null)
          return "The parcel type " + parcelTypeNameFromPath + " was not found in the map.";
        #endregion

        #region Record management
         //check to see if there is a record with this name.
         var parcRecord = await myParcelFabricLayer.GetRecordAsync(parcelRecordNameFromPath);
         bool bRecordExists = parcRecord != null;
         var editOper1 = new EditOperation();
         if (bRecordExists)
         {// if it exists then set it as the Active record 
           await myParcelFabricLayer.SetActiveRecordAsync(parcelRecordNameFromPath);
         }
         else
         {
           var recordsLayer = await myParcelFabricLayer.GetRecordsLayerAsync();
           var editOper = new EditOperation();

           Dictionary<string, object> RecordAttributes = new Dictionary<string, object>();
           RecordAttributes.Add("Name", parcelRecordNameFromPath);
           editOper.CreateEx(recordsLayer.FirstOrDefault(), RecordAttributes);
           if (!editOper.Execute())
             return editOper.ErrorMessage;
           await myParcelFabricLayer.SetActiveRecordAsync(parcelRecordNameFromPath);
           parcRecord = await myParcelFabricLayer.GetRecordAsync(parcelRecordNameFromPath);
           editOper1 = editOper.CreateChainedOperation();
         }
         #endregion

        bool bCreateLines = true;
        bool bCreatePolygons = true;
        
        #region Create parcel features
        editOper1.Name = "Create Parcel Features from Traverse Files.";
        List<string> sTraverseFileLines = ParcelUtils.TraverseCoursesFromFiles(traverseFiles);

        //get current selection from polygonParcelTypeFeatLayer
        var ids = new List<long>(polygonParcelTypeFeatLayer.GetSelection().GetObjectIDs());
        bool bOK = false;
        bool bOK2 = false;
        if (bCreateLines)
          bOK = await ParcelUtils.CreateFeaturesFromCourses(sTraverseFileLines, lineParcelTypeFeatLayer, editOper1);
        if(bCreatePolygons)
          bOK2 = await ParcelUtils.CreateFeaturesFromCourses(sTraverseFileLines, polygonParcelTypeFeatLayer, editOper1);
        bool bCreateSucceeded = bOK | bOK2;
        if (bCreateSucceeded)
          editOper1.Execute();
        else 
           return "Features were not created.";
        #endregion

        bool bShrinkToSeeds = true;
        #region Shrink to Seeds
         //shrink to seeds
         var editOper2 = new EditOperation();
         if (bShrinkToSeeds)
        {
          editOper2 = editOper1.CreateChainedOperation();
          //the following function will include any pre-existing features in the same record that are selected.
          var kvp = ParcelUtils.KeyValuePairForFeatureLayerAndRecord(polygonParcelTypeFeatLayer, ids, parcRecord);
          var sourceParcelFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp };
          editOper2.ShrinkParcelsToSeeds(myParcelFabricLayer, sourceParcelFeatures);
          editOper2.Execute();
        }
        #endregion

        bool bBuildActiveRecord = true;
        #region Build the Record
         if (bBuildActiveRecord)
         {
           //build the record
           bool bUpdateStatedArea = true;
           var editOper3 = new EditOperation();
           editOper3 = editOper2.CreateChainedOperation();

           EditOperation editOper4 = await BuildByRecord(myParcelFabricLayer, parcRecord,
             parcelTypeNameFromPath, bUpdateStatedArea, 0.25, editOper3);
           if (editOper4 != null)
             editOper4.Execute();
         }
         #endregion

       }
       catch (Exception ex)
       {
         return ex.Message;
       }
       return "";
     });

      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage);
    }
    private bool GetSourceFilesAndFolder()
    {
      folderPath = Properties.Settings.Default["LastUsedSourceFolder"] as string;
      BrowseProjectFilter bf = new BrowseProjectFilter(ItemFilters.textFiles);
      //Display the filter in an Open Item dialog
      OpenItemDialog aBrowseForFolder = new OpenItemDialog
      {
        Title = "Select Source Traverse Files",
        InitialLocation = folderPath,
        MultiSelect = true,
        BrowseFilter = bf,
      };
      bool? ok = aBrowseForFolder.ShowDialog();
      if (ok == true)
      {
        traverseFiles = new List<string>();
        foreach (var item in aBrowseForFolder.Items)
          traverseFiles.Add(item.Path);
        folderPath = System.IO.Path.GetDirectoryName(aBrowseForFolder.Items.First().Path);
        string[] s = folderPath.Split(System.IO.Path.DirectorySeparatorChar);
        parcelRecordNameFromPath = s[s.Length - 1];
        parcelTypeNameFromPath = s[s.Length - 2];
        Properties.Settings.Default["LastUsedSourceFolder"] = folderPath;
        Properties.Settings.Default.Save();
        return true;
      }
      else
        return false;
    }

    private async Task<EditOperation> BuildByRecord(ParcelLayer myParcelFabricLayer, ParcelRecord parcRecord, 
      string parcelTypeName, bool bUpdateStatedArea, double MinimumAcreStatedAreaTolerance, EditOperation editOper3)
    {
      //MinimumAcreStatedAreaTolerance - if the calculated area returned and converted to acres is equal to or higher,
      //then the parcel's Stated Area will be set to this value in units of Acres, otherwise it will be written in 
      //the same unit as the spatial reference's linear unit (squared).
      //
      //1 acre = 43560 sq.feet
      //1 acre = 4046.86 sq.meters
      //area unit domain values
      /* Hectare = 109401
       * Acre = 109402
       * Acre US = 109403
       * Square Meter = 109404
       * Square Foot = 109405
       * Square Foot US = 109406
       */
    //  enum AreaUnits
    //{ }

      try
      {
        double dMetersPerUnit = 1;
        var pSR = myParcelFabricLayer.GetSpatialReference();
        if (pSR.IsProjected)
            dMetersPerUnit = pSR.Unit.ConversionFactor; //meters per unit

        if (!bUpdateStatedArea)
        {
          editOper3.BuildParcelsByRecord(myParcelFabricLayer, parcRecord.Guid);
          return editOper3;
        }
        else
        {
          var parcelLayers = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(parcelTypeName); ;
          var MyParcelEditToken = editOper3.BuildParcelsByRecord(myParcelFabricLayer, parcRecord.Guid, parcelLayers);
          editOper3.Execute();
          //var FeatSetCreated = MyParcelEditToken.CreatedFeatures;
          var FeatSetModified = MyParcelEditToken.ModifiedFeatures;

          var editOper4 = editOper3.CreateChainedOperation();
          string sReportResult = "";
          Dictionary<string, object> ParcelAttributes = new Dictionary<string, object>();
          foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetModified)
          {
            foreach (long oid in kvp.Value)
            {
              //get the calculated area
              var insp = kvp.Key.Inspect(oid);
              double calcArea = (double)insp["CALCULATEDAREA"];
              var Acreage = (calcArea * dMetersPerUnit*dMetersPerUnit)/ 4046.86;//1 acre = 4046.86 sq.meters
              if (Acreage >= MinimumAcreStatedAreaTolerance)
              {
                ParcelAttributes.Add("StatedArea", Acreage.ToString("0.00"));
                ParcelAttributes.Add("StatedAreaUnit", 109402);
              }
              else 
              {
                ParcelAttributes.Add("StatedArea", calcArea.ToString("0"));
                ParcelAttributes.Add("StatedAreaUnit", 109405);
              }
              editOper4.Modify(kvp.Key, oid, ParcelAttributes);
              ParcelAttributes.Clear();
            }
            sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + " features modified." +
                Environment.NewLine;
          }
          //editOper4.Execute();
          return editOper4;
        }
      }
      catch
      {
         return null;
      }
    }
  }
}
