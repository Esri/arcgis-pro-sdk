﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ParcelFabricSDK
{
  internal class AddControlPoint : Button
  {
    protected async override void OnClick()
    {
      string errorMessage = await QueuedTask.Run( async () =>
      {
        var lic = ArcGIS.Core.Licensing.LicenseInformation.Level;
        if (lic < ArcGIS.Core.Licensing.LicenseLevels.Standard)
          return "Insufficient License Level.";

        //make sure there is a fabric and an active record
        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList()
                                                    .OfType<ParcelLayer>()
                                                    .FirstOrDefault();
        
        if (myParcelFabricLayer == null)
          return "Please select a parcel fabric layer in the table of contents.";

        // Create and change to a new version (stay in non-default version if set)
        Map map = MapView.Active.Map;
        await SDKUtilities.CreateChangeEditVersion(map, myParcelFabricLayer);

        try
        {
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";

          var pointLyrEnum = await myParcelFabricLayer.GetPointsLayerAsync();
          if (pointLyrEnum.Count() == 0)
            return "No point layer found.";

          // Get the Points layer
          var pointLyr = pointLyrEnum.FirstOrDefault();

          // Create the point geometry
          MapPoint newPoint = MapPointBuilder.CreateMapPoint(209667.73, 212194.96, myParcelFabricLayer.GetSpatialReference());
          if (newPoint == null)
            return "";

          // Add some attributes to the new row
          Dictionary<string, object> PointAttributes = new Dictionary<string, object>();
          PointAttributes.Add("Name", "MyTestPoint");
          PointAttributes.Add("AdjustmentConstraint", 2);
          var editOper = new EditOperation()
          {
            Name = "Create a test parcel fabric point",
            ProgressMessage = "Create a test parcel fabric point...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };

          // Create the point
          editOper.CreateEx(pointLyr, newPoint, PointAttributes);
          if (!editOper.Execute())
            return editOper.ErrorMessage;
        }
        catch (Exception ex)
        {
          errorMessage=ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Add Control Point");
    }
  }
}
