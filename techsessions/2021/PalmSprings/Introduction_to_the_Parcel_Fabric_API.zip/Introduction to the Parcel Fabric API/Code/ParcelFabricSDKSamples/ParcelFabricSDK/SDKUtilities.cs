﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Version = ArcGIS.Core.Data.Version;

namespace ParcelFabricSDK
{
  public class SDKUtilities
  {
    public static async Task CreateChangeEditVersion(Map map, ParcelLayer parcelLayer)
    {
      // unique timestamp to append to version name
      int unixTimestamp = (int)(DateTime.Now.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
      string newVersionName = $"SDK_{unixTimestamp}";

      Geodatabase geodatabase = null;

      var parcelFabricContainer = await parcelLayer.GetRecordsLayerAsync();
      FeatureLayer recordsFeatureLayer = parcelLayer.Layers[0] as FeatureLayer;
      await QueuedTask.Run(() =>
      {
        using (Table table = recordsFeatureLayer.GetTable())
        {
          Datastore datastore = table.GetDatastore();
          geodatabase = datastore as Geodatabase;

          if (geodatabase.IsVersioningSupported())
          {
            using(VersionManager versionManager = geodatabase.GetVersionManager())
            {
              try
              {
                var currentVersion = versionManager.GetCurrentVersion();
                if (!currentVersion.GetName().ToUpper().Contains("DEFAULT"))
                {
                  MessageBox.Show($"Already in a version: {currentVersion.GetName()}", "Branch Version");
                  return;
                }
                VersionDescription versionDescription = new VersionDescription(newVersionName, "Created by SDK", VersionAccessType.Public);
                versionManager.CreateVersion(versionDescription);
                Version newVersion = versionManager.GetVersion(newVersionName);

                map.ChangeVersion(currentVersion, newVersion);
              }
              catch(Exception ex)
              {
                MessageBox.Show(ex.Message);
              }
            }

          }
        }
      });
    }

    public static async Task<string> GetParcelTypeNameFromFeatureLayer(ParcelLayer myParcelFabricLayer, FeatureLayer featLayer, GeometryType geomType)
    {
      if (featLayer == null) //nothing to do return empty string
        return String.Empty;
      IEnumerable<string> parcelTypeNames = await myParcelFabricLayer.GetParcelTypeNames();
      foreach (string parcelTypeName in parcelTypeNames)
      {
        if (geomType == GeometryType.Polygon)
        {
          var polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
          polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelPolygonLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
        if (geomType == GeometryType.Polyline)
        {
          var lineLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelLineLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
          lineLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelLineLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
      }
      return String.Empty;
    }
  }
}
