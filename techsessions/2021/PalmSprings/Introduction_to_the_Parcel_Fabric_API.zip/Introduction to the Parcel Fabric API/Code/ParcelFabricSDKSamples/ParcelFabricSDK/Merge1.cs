﻿using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Linq;

namespace ParcelFabricSDK
{
  internal class Merge1 : Button
  {
    protected async override void OnClick()
    {
      // check for selected layer
      if (MapView.Active.GetSelectedLayers().Count == 0)
      {
        MessageBox.Show("Please select a feature layer in the table of contents", "Merge");
        return;
      }
      //jump to the cim thread
      string errorMessage = await QueuedTask.Run( () =>
      {
        //first get the feature layer that's selected in the table of contents
        var featLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        var opMerge1 = new EditOperation()
        {
          Name = "Merge1",
          ProgressMessage = "Merging parcels...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };
        opMerge1.Merge(featLyr, featLyr.GetSelection().GetObjectIDs());
        if (!opMerge1.Execute())
          return opMerge1.ErrorMessage;
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Merge Parcels");
    }
  }
}