﻿using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualBasic;

namespace ParcelFabricSDK
{
  internal class CreateNewRecord : Button
  {
    protected async override void OnClick()
    {
      // Check the license level
      var lic = ArcGIS.Core.Licensing.LicenseInformation.Level;
      if (lic < ArcGIS.Core.Licensing.LicenseLevels.Standard)
      {
        MessageBox.Show($"Insufficent license level( {lic} )");
        return;
      }

      // Get the parcel fabric layer object
      var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList()
                                                  .OfType<ParcelLayer>()
                                                  .FirstOrDefault();
      // If there is no fabric in the map then bail
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Create Parcel Fabric Record");
        return;
      }

      // Create and change to a new version (stay in non-default version if already set)
      Map map = MapView.Active.Map;
      await SDKUtilities.CreateChangeEditVersion(map, myParcelFabricLayer);

      // Get the name of the new record (string)
      string sNewRecord = Interaction.InputBox("New Record Name:", "Create Parcel Fabric Record", "MyRecordName");
      if (sNewRecord.Trim().Length == 0)
        return;

      //check to make sure there is no record by this name.
      var x = await myParcelFabricLayer.GetRecordAsync(sNewRecord);
      if (x != null)
      { 
        MessageBox.Show("Record with this name already exists.", "Create Parcel Fabric Record");
        return;      
      }

      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        try
        {
          var recordsLayer = await myParcelFabricLayer.GetRecordsLayerAsync();
          var editOper = new EditOperation()
          {
            Name = "Create Parcel Fabric Record",
            ProgressMessage = "Create Parcel Fabric Record...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = false,
            SelectModifiedFeatures = false
          };

          // Update record feature attributes
          Dictionary<string, object> RecordAttributes = new Dictionary<string, object>();
          RecordAttributes.Add("Name", sNewRecord);

          // Execute the Edit Operation
          editOper.CreateEx(recordsLayer.FirstOrDefault(), RecordAttributes);
          if (!editOper.Execute())
            return editOper.ErrorMessage;

          // Set the new record as active in the map
          await myParcelFabricLayer.SetActiveRecordAsync(sNewRecord);

          return "";
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Create Parcel Fabric Record");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Create Parcel Fabric Record");
    }
  }
}
