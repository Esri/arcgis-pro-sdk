﻿using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ParcelFabricSDK
{
  internal class BuildActiveRecord : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer =
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Copy Line Features To Parcel Type");
        return;
      }
      string sReportResult = "";
      bool bFirstExecuteOK = true;
      string errorMessage = await QueuedTask.Run(async () =>
      {
        var editOper = new EditOperation()
        {
          Name = "Build Parcels",
          ProgressMessage = "Build Parcels...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };
        bool bHasActiveRecord = false;
        Guid guid = new Guid();
        try
        {
          // Get the active record
          var theActiveRecord = myParcelFabricLayer.GetActiveRecord();
          bHasActiveRecord = (theActiveRecord != null);
          if (bHasActiveRecord)
            guid = theActiveRecord.Guid;

          // Gather up parcel layers into a List of feature layers
          List<FeatureLayer> parcelLayers = new List<FeatureLayer>();
          List<string> sParcelTypes = new List<string> { "Tax", "Lot" };
          foreach (string sParcTyp in sParcelTypes)
          {
            IEnumerable<FeatureLayer> lyrs = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(sParcTyp);
            parcelLayers.Add(lyrs.FirstOrDefault());
            lyrs = await myParcelFabricLayer.GetParcelLineLayerByTypeName(sParcTyp);
            parcelLayers.Add(lyrs.FirstOrDefault());
          }
          IEnumerable<FeatureLayer> ptLyrs = await myParcelFabricLayer.GetPointsLayerAsync();
          parcelLayers.Add(ptLyrs.FirstOrDefault());

          // Create a ParcelEditToken for Build
          ParcelEditToken peToken = null;
          if (bHasActiveRecord)
            peToken = editOper.BuildParcelsByRecord(myParcelFabricLayer, guid, parcelLayers);
          else
            return "Must have active record set";

          if (!editOper.Execute())
          {
            bFirstExecuteOK = false;
            return editOper.ErrorMessage;
          }

          // Chain an edit operation to continue work on the modified features
          var FeatSetModified = peToken.ModifiedFeatures;

          var editOperation2 = editOper.CreateChainedOperation();
          sReportResult = "";

          Dictionary<string, object> ParcelAttributes = new Dictionary<string, object>();
          foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetModified)
          {
            foreach (long oid in kvp.Value)
            {
              ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
              editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
              ParcelAttributes.Clear();
            }
            sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name +
            " features modified." + Environment.NewLine;
          }
          if (!editOperation2.Execute())
            return editOperation2.ErrorMessage;
        }
        catch (Exception ex)
        {
          if (bFirstExecuteOK)//means partial success, so roll-back first edit
          {
            await editOper.UndoAsync(); //TODO: the operation is undone, but still on the undo stack, so remove it
          }
          errorMessage = ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Build Parcels");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Build Parcels");
    }
  }
}
