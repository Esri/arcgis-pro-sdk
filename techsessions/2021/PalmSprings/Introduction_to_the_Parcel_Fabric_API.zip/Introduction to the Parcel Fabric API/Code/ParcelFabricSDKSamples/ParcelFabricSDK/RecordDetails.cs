﻿using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Linq;

namespace ParcelFabricSDK
{
  internal class RecordDetails : Button
  {
    protected async override void OnClick()
    {
      string errorMessage = await QueuedTask.Run(() =>
      {
        var myParcelFabricLayer =
          MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        //if there is no fabric in the map then bail
        if (myParcelFabricLayer == null)
          return "There is no fabric layer in the map.";
        try
        {
          var activeRecord = myParcelFabricLayer.GetActiveRecord();
          if (activeRecord != null)
          {
            MessageBox.Show($"Record Name: {activeRecord.Name}\nRecord GUID: {activeRecord.Guid.ToString().ToUpper()}");
          }
            
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Set Active Parcel Record");
    }
  }
}
