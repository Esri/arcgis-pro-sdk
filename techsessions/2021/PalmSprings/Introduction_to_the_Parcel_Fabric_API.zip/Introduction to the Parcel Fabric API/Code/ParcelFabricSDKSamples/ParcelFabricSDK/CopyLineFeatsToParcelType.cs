﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ParcelFabricSDK
{
  internal class CopyLineFeatsToParcelType : Button
  {
    protected async override void OnClick()
    {
      /*
           CopyLineFeaturesToParcelType params:
            - srcFeatLyr: The line feature class with the lines to copy
            - selection_oids: The OIDs of the selected line features to copy
            - destPolygonLyr, destLineLyr: Feature classes of the target parcel type.
       */
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Copy Line Features To Parcel Type");
        return;
      }
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a target parcel polygon layer in the table of contents.";

        //first get the feature layer that's selected in the table of contents
        var destPolygonLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();

        try
        {
          // Create and change to a new version (stay in non-default version if set)
          Map map = MapView.Active.Map;
          await SDKUtilities.CreateChangeEditVersion(map, myParcelFabricLayer);

          // Get active parcel record
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";
          
          // Get the parcel type name from the selected polygon layer
          string ParcelTypeName = await SDKUtilities.GetParcelTypeNameFromFeatureLayer(myParcelFabricLayer, destPolygonLyr, GeometryType.Polygon);
          if (string.IsNullOrEmpty(ParcelTypeName))
            return "Please select a target parcel polygon layer in the table of contents.";
          
          // Get the non-fabric lines that are to be copied into the parcel type
          var srcFeatLyr = MapView.Active.Map.GetLayersAsFlattenedList()
                                             .OfType<FeatureLayer>()
                                             .FirstOrDefault(l => l.Name.Contains("sdk") && l.IsVisible);
          if (srcFeatLyr == null)
            return "Source layer with string *_Lines not found in the table of contents.";
          
          // Get the line layer for the target parcel type
          var destLineLyrEnum = await myParcelFabricLayer.GetParcelLineLayerByTypeName(ParcelTypeName);
          if (destLineLyrEnum.Count() == 0) //make sure there is one in the map
            return "No line layer found.";

          var destLineLyr = destLineLyrEnum.FirstOrDefault();
          if (destLineLyr == null || destPolygonLyr == null)
            return "";

          // Get the OIDs of the lines to copy
          var selection_oids = new List<long>((srcFeatLyr as FeatureLayer).GetSelection().GetObjectIDs());
          if (selection_oids.Count == 0)
            return "No selected lines were found. Please select line features and try again.";

          // Create an edit operation
          var editOper = new EditOperation()
          {
            Name = "Copy Line Features To Parcel Type",
            ProgressMessage = "Copy Line Features To Parcel Type...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };

          // Get a parcel edit token
          // github.com/Esri/arcgis-pro-sdk/wiki/ProConcepts-Parcel-Fabric#using-a-parcel-edit-token
          ParcelEditToken peToken = editOper.CopyLineFeaturesToParcelType(srcFeatLyr, 
                                                                          selection_oids,
                                                                          destLineLyr, 
                                                                          destPolygonLyr);
          // Execute the edit operation
          if(!editOper.Execute())
            return editOper.ErrorMessage;

          // Make use of the parcel edit token
          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetCreated)
            {
              foreach (long oid in kvp.Value)
              {
                // Do something here (e.g. calculate an attribute, etc.)
              }
              // Print some details of the edit
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name + 
              " features created." + Environment.NewLine;
            }
          }
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage,"Copy Line Features To Parcel Type");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult,"Copy Line Features To Parcel Type");
    }
    
  }
}
