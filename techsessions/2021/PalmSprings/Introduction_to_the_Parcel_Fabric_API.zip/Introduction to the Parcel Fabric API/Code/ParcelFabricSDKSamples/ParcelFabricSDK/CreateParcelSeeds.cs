﻿using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ParcelFabricSDK
{
  internal class CreateParcelSeeds : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Create Parcel Seeds");
        return;
      }
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        try
        {
           var pRec = myParcelFabricLayer.GetActiveRecord();
           if (pRec == null)
             return "There is no Active Record. Please set the active record and try again.";
           var guid = pRec.Guid;
           var editOper = new EditOperation()
           {
             Name = "Create Parcel Seeds",
             ProgressMessage = "Create Parcel Seeds...",
             ShowModalMessageAfterFailure = true,
             SelectNewFeatures = true,
             SelectModifiedFeatures = false
           };
          List<FeatureLayer> parcelLayers = new List<FeatureLayer>();
          List<string> sParcelTypes = new List<string> { "Tax", "Lot" };
          foreach (string sParcTyp in sParcelTypes)
          {
            IEnumerable<FeatureLayer> lyrs = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(sParcTyp);
            parcelLayers.Add(lyrs.FirstOrDefault());
            lyrs = await myParcelFabricLayer.GetParcelLineLayerByTypeName(sParcTyp);
            parcelLayers.Add(lyrs.FirstOrDefault());
          }
          var peToken = editOper.CreateParcelSeedsByRecord(myParcelFabricLayer, guid, MapView.Active.Extent, parcelLayers);
          if (!editOper.Execute())
            return editOper.ErrorMessage;

          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetCreated)
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name + " features created." +
                  Environment.NewLine;
            }
          }
          if (FeatSetModified != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetModified)
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + " features modified." +
                  Environment.NewLine;
            }
          }
        }
        catch (Exception ex)
        {
           return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Create Parcel Seeds");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Create Parcel Seeds");
    }
  }
}
