﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompReporter
{
	/// <summary>
	/// Comp data contains details for each Comp
	/// </summary>
	public class CompData : 
		ArcGIS.Desktop.Framework.Contracts.PropertyChangedBase
	{
		#region private declarations
		private string _id;
		private ArcGIS.Core.Geometry.Geometry _shape;
		private int _type;
		private int _label;
		private string _description;
		private long _oid;
		private string _url;
		#endregion private declarations

		internal CompData (string id,
										ArcGIS.Core.Geometry.Geometry shape,
										int type, int label, string description,
										long oid, string url)
		{
			Id = id;
			Shape = shape;
			Type = type;
			Label = label;
			Description = description;
			Oid = oid;
			Url = url;
		}

		/// <summary>
		/// Unique Parcel Id key (TMK)
		/// </summary>
		public string Id {
			get { return _id; }
			set
			{
				SetProperty(ref _id, value, () => Id);
			}
		}
		/// <summary>
		/// Shape of Comp parcel
		/// </summary>
		public ArcGIS.Core.Geometry.Geometry Shape {
			get { return _shape; }
			set
			{
				SetProperty(ref _shape, value, () => Shape);
			}
		}
		/// <summary>
		/// Type of Comp: subject, lower, higher assessed
		/// </summary>
		public int Type {
			get { return _type; }
			set
			{
				SetProperty(ref _type, value, () => Type);
			}
		}
		/// <summary>
		/// Label on Map
		/// </summary>
		public int Label {
			get { return _label; }
			set
			{
				SetProperty(ref _label, value, () => Label);
			}
		}
		/// <summary>
		/// Comp Description summary
		/// </summary>
		public string Description {
			get { return _description; }
			set
			{
				SetProperty(ref _description, value, () => Description);
			}
		}
		/// <summary>
		/// Object Id link to Parcel Layer
		/// </summary>
		public long Oid {
			get { return _oid; }
			set
			{
				SetProperty(ref _oid, value, () => Oid);
			}
		}
		/// <summary>
		/// Url to detailed description of parcel
		/// </summary>
		public string Url {
			get { return _url; }
			set
			{
				SetProperty(ref _url, value, () => Url);
			}
		}
	}
}
