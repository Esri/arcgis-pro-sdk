﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CompReporter
{
  /// <summary>
  /// cursor position
  /// </summary>
  public struct POINT
  {
    /// <summary>
    /// cursor X
    /// </summary>
    public int X;
    /// <summary>
    /// cursor Y
    /// </summary>
    public int Y;
  }

  public class MouseCursorPosition
  {
    [DllImport("user32.dll")]
    public static extern bool GetCursorPos(out POINT pt);

    public static POINT pt;

    /// <summary>
    /// returns the current mouse cursor position
    /// </summary>
    /// <returns></returns>
    public static Point GetMouseCursorPosition()
    {
      GetCursorPos(out pt);
      return new Point(pt.X, pt.Y);
    }
  }
}
