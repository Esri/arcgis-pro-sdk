﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompReporter
{
	internal class AddCompBySelection : MapTool
	{
		public AddCompBySelection()
		{
			IsSketchTool = true;
			SketchType = SketchGeometryType.Point;
			SketchOutputMode = SketchOutputMode.Map;
		}

		protected override Task OnToolActivateAsync(bool active)
		{
			return base.OnToolActivateAsync(active);
		}

		protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
		{
      var fcParcelLyr = CompReportingViewModel.GetTaxParcelLayer();
      if (fcParcelLyr == null)
        throw new ArgumentException($@"The Tax Parcel Layer is invalid");

      // execute the select on the MCT
      return QueuedTask.Run(() =>
			{
				try
				{
					// define the spatial query filter
					var spatialQuery = new SpatialQueryFilter() { FilterGeometry = geometry, SpatialRelationship = SpatialRelationship.Intersects };
					var parcelCursor = fcParcelLyr.GetFeatureClass().Search(spatialQuery);
					if (parcelCursor.MoveNext())
					{
						var parcelFeature = parcelCursor.Current as Feature;
						var parcelPolygon = parcelFeature.GetShape().Clone();
						var url = parcelFeature["qpub_link"].ToString();
						var parcelOid = parcelFeature.GetObjectID();
						var id = parcelFeature["TMK_txt"].ToString();
						var newRow = new CompData(id, parcelPolygon, 1, 
							++CompReportingViewModel.Instance.CurrentMaxLabelNo, 
							GetParcelDetail (parcelOid), parcelOid, url);
						lock (CompReportingViewModel.Instance.CompsLock)
							CompReportingViewModel.Instance.Comps.Add(newRow);
					}
				}
				catch (Exception ex)
				{
					System.Diagnostics.Debug.WriteLine($@"Error in OnSketchCompleteAsync: {ex.ToString()}");
				}
				return Task.FromResult(true);
			});
		}

		private string GetParcelDetail (long parcelOid)
		{
			return "$1.10M - 3 bd, 3 ba - 2,170 sqft";
		}
	}
}
