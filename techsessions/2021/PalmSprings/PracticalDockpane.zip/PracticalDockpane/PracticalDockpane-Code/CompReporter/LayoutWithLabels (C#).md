## LayoutWithLabels

<!-- TODO: Write a brief abstract explaining this sample -->
This sample shows how to create a layout with custom labeling for a selected set of polygon features.  In order to do this the sample is using the following functionality:  
* A layer file containing a 'labeled' polygon layer is loaded by the add-in and dynamically added to the map  
* The add-in then reads a csv file containing some Ids of polygon features that have to be labeled with 'customized' text strings  
* The labels (using call-out labels) are placed on the map (using the dynamically loaded 'labeled' polygon layer  
* A control can then be used to re-position the labels on the map  
* The add-in adds a layout that contains the labeled map and a tabular list of all labeled features.  
  


<a href="http://pro.arcgis.com/en/pro-app/sdk/" target="_blank">View it live</a>

<!-- TODO: Fill this section below with metadata about this sample-->
```
Language:              C#
Subject:               Layouts
Contributor:           ArcGIS Pro SDK Team <arcgisprosdk@esri.com>
Organization:          Esri, http://www.esri.com
Date:                  12/01/2020
ArcGIS Pro:            2.7
Visual Studio:         2019
.NET Target Framework: 4.8
```

## Resources

* [API Reference online](https://pro.arcgis.com/en/pro-app/sdk/api-reference)
* <a href="https://pro.arcgis.com/en/pro-app/sdk/" target="_blank">ArcGIS Pro SDK for .NET (pro.arcgis.com)</a>
* [arcgis-pro-sdk-community-samples](https://github.com/Esri/arcgis-pro-sdk-community-samples)
* [ArcGIS Pro DAML ID Reference](https://github.com/Esri/arcgis-pro-sdk/wiki/ArcGIS-Pro-DAML-ID-Reference)
* [FAQ](https://github.com/Esri/arcgis-pro-sdk/wiki/FAQ)
* [ArcGIS Pro SDK icons](https://github.com/Esri/arcgis-pro-sdk/releases/tag/2.4.0.19948)

![ArcGIS Pro SDK for .NET Icons](https://Esri.github.io/arcgis-pro-sdk/images/Home/Image-of-icons.png  "ArcGIS Pro SDK Icons")

### Samples Data

* Sample data for ArcGIS Pro SDK Community Samples can be downloaded from the [repo releases](https://github.com/Esri/arcgis-pro-sdk-community-samples/releases) page.  

## How to use the sample
<!-- TODO: Explain how this sample can be used. To use images in this section, create the image file in your sample project's screenshots folder. Use relative url to link to this image using this syntax: ![My sample Image](FacePage/SampleImage.png) -->
1. Download the Community Sample data (see under the 'Resources' section for downloading sample data)  
1. Make sure that the Sample data is unzipped in c:\data   
1. The project used for this sample is 'C:\Data\LocalGovernment\LocalGovernment.aprx'  
1. In Visual Studio click the Build menu. Then select Build Solution.  
1. Click Start button to open ArcGIS Pro.  
1. ArcGIS Pro will open, select the LocalGovernment.aprx project  
1. Click on the ADD-IN tab and the click the 'Label Selected Parcels' button.  
![UI](Screenshots/Screenshot1.png)  
  
1. Click the "load Layer Package" button on the "SelectParcelsToLabel" dockpane.  This loads a layer file  containing a 'labeled' polygon layer and dynamically adds it to the map  
![UI](Screenshots/Screenshot2.png)  
  
1. Now that the "Read from File" button is enabled, click the "Read from File" button in order to load a sample csv file that contains records that are identified by using a unique parcel Id field.  
1. The loaded features are displayed in a table on the "SelectParcelsToLabel" dockpane and highlighted and labeled on the map using the 'labeled' polygon layer.  
![UI](Screenshots/Screenshot3.png)  
  
1. You can use the "Label leader line length" control on the "SelectParcelsToLabel" dockpane to manipulate the leader line length.  
![UI](Screenshots/Screenshot4.png)  
  
1. Finally to generate the layout select a 'Map Layout" and click the "Make Layout" button.  
![UI](Screenshots/Screenshot5.png)  
  


<!-- End -->

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="https://esri.github.io/arcgis-pro-sdk/images/ArcGISPro.png"  alt="ArcGIS Pro SDK for Microsoft .NET Framework" height = "20" width = "20" align="top"  >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
[Home](https://github.com/Esri/arcgis-pro-sdk/wiki) | <a href="https://pro.arcgis.com/en/pro-app/sdk/api-reference" target="_blank">API Reference</a> | [Requirements](https://github.com/Esri/arcgis-pro-sdk/wiki#requirements) | [Download](https://github.com/Esri/arcgis-pro-sdk/wiki#installing-arcgis-pro-sdk-for-net) | <a href="https://github.com/esri/arcgis-pro-sdk-community-samples" target="_blank">Samples</a>
