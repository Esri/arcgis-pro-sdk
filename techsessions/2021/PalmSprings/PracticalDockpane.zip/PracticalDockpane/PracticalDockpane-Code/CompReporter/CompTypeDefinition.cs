/*

   Copyright 2020 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

   See the License for the specific language governing permissions and
   limitations under the License.

*/
using ArcGIS.Core.CIM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompReporter
{
	/// <summary>
	/// Holds the definitions for all Comp Types
	/// Contains the enum, description, and color
	/// </summary>
	public class CompTypeDefinition
	{
		public int Value { get; set; }
		public string Description { get; set; }
		public CIMColor FillColor { get; set; }
		public CIMColor OutlineColor { get; set; }

		private CompTypeDefinition(Int16 val,
			string description, 
			CIMColor outlineColor,
			CIMColor fillColor)
		{
			Value = val;
			Description = description;
			FillColor = fillColor;
			OutlineColor = outlineColor;
		}

		private static List<CompTypeDefinition> _lstCompTypes = new List<CompTypeDefinition>();
		private static ObservableCollection<KeyValuePair<int, string>> _compTypes;
		private static Dictionary<int, CIMColor> _outlineColors;
		private static Dictionary<int, CIMColor> _fillColors;

		private static void Init()
		{
			if (_lstCompTypes.Count > 0) return;
			_lstCompTypes.Add(new CompTypeDefinition(-1, "Other", CIMColor.CreateRGBColor(255, 255, 0), CIMColor.CreateRGBColor(248, 252, 197, 50)));
			_lstCompTypes.Add(new CompTypeDefinition(0, "Subject Parcel", CIMColor.CreateRGBColor(255, 0, 0), CIMColor.CreateRGBColor(255, 0, 0, 50)));
			_lstCompTypes.Add(new CompTypeDefinition(1, "Lower", CIMColor.CreateRGBColor(0, 255, 0), CIMColor.CreateRGBColor(0, 255, 0, 50)));
			_lstCompTypes.Add(new CompTypeDefinition(2, "Higher", CIMColor.CreateRGBColor(0, 0, 255), CIMColor.CreateRGBColor(0, 0, 255, 30)));
			_compTypes = new ObservableCollection<KeyValuePair<int, string>>();
			_outlineColors = new Dictionary<int, CIMColor>();
			_fillColors = new Dictionary<int, CIMColor>();
			foreach (var compTypeDef in _lstCompTypes)
			{
				if (compTypeDef.Value >= 0)
				{
					_compTypes.Add(new KeyValuePair<int, string>((int)compTypeDef.Value, compTypeDef.Description));
				}
				_outlineColors.Add((short)compTypeDef.Value, compTypeDef.OutlineColor);
				_fillColors.Add((short)compTypeDef.Value, compTypeDef.FillColor);
			}
		}

		public static ObservableCollection<KeyValuePair<int, string>> CompTypes
		{
			get
			{
				Init();
				return _compTypes;
			}
		}

		public static Dictionary<int, CIMColor> OutlineColors
		{
			get
			{
				Init();
				return _outlineColors;
			}
		}

		public static Dictionary<int, CIMColor> FillColors
		{
			get
			{
				Init();
				return _fillColors;
			}
		}
	}
}
