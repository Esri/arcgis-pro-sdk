/*

   Copyright 2020 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

   See the License for the specific language governing permissions and
   limitations under the License.

*/
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Layouts.Control;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Controls;
using Microsoft.VisualBasic.FileIO;
using System.Collections.Specialized;

namespace CompReporter
{
	internal class CompReportingViewModel : DockPane
	{
		private const string _dockPaneID = "CompReporter_CompReporting";
		private readonly SetPages _setPages = new SetPages();
		private readonly ObservableCollection<SetPage> _mapPageLayouts = new ObservableCollection<SetPage>();
		private bool _cmdMakeLayoutEnabled = false;
		
		private ObservableCollection<CompData> _comps = new ObservableCollection<CompData>();
		internal readonly object CompsLock = new object();
		
		private CompData _selectedComp; 
		private Dictionary<long, GraphicElement> _txtGraphicElement = new Dictionary<long, GraphicElement>();
		private Dictionary<long, GraphicElement> _polyGraphicElement = new Dictionary<long, GraphicElement>();
		private static CompReportingViewModel _instance = null;

		protected CompReportingViewModel()
		{
			_instance = this;
			_comps.CollectionChanged += Comps_CollectionChanged;
			BindingOperations.EnableCollectionSynchronization(_comps, CompsLock);
			_ = UpdateOverviewMapContent();
		}

		/// <summary>
		/// Called when Dockpane is initialized.
		/// </summary>
		protected override Task InitializeAsync()
		{
			QueuedTask.Run(() =>
			{
				var gl = GetGraphicsLayer(ParcelMap);
				if (gl != null)
				{
					gl.RemoveElements();
				}
				var glOverlay = GetGraphicsLayer(OverviewMap);
				if (glOverlay != null)
				{
					glOverlay.RemoveElements();
				}
			});
			return base.UninitializeAsync();
		}

		#region Public Static members

		internal static CompReportingViewModel Instance => _instance;

		#endregion Public Static members

		#region Dockpane Commands

		public bool CmdMakeLayoutEnabled
		{
			get
			{
				return _cmdMakeLayoutEnabled;
			}
			set { SetProperty(ref _cmdMakeLayoutEnabled, value, () => CmdMakeLayoutEnabled); }
		}

		/// <summary>
		/// Reads the comp records from a csv input file
		/// </summary>
		public ICommand CmdReadComps
		{
			get
			{
				return new RelayCommand(async () =>
				{
					string csvPath = string.Empty;
					try
					{
						// read csv file with comps
						// open the CSV file
						var bpf = new BrowseProjectFilter("esri_browseDialogFilters_textFiles_csv")
						{
							Name = "Comp file to load (CSV)"
						};
						//Display the filter in an Open Item dialog
						OpenItemDialog openItemDialog = new OpenItemDialog
						{
							Title = "Comp file to load (CSV)",
							InitialLocation = @"C:\Work\DevSummit\2021\Data\Island",
							MultiSelect = false,
							BrowseFilter = bpf
						};
						bool? ok = openItemDialog.ShowDialog();
						if (ok.Value == false)
						{
							return;
						}
						var env = await QueuedTask.Run(async () =>
						{
							// clear previous graphic elements
							ClearAllGraphicElements();
							// find the parcel layer to find a matched tax record for each CSV item
							var parcelLayer = GetTaxParcelLayer();
							csvPath = openItemDialog.Items.ToArray()[0].Path;
							_ = await ReadCsvIntoCollection(Comps, csvPath, parcelLayer);
							Geometry geomEnvelope = null;
							foreach (CompData row in Comps)
							{
								if (geomEnvelope == null)
								{
									geomEnvelope = row.Shape.Clone();
									continue;
								}
								geomEnvelope = GeometryEngine.Instance.Union(geomEnvelope, row.Shape);
							}
							var resultEnv = GeometryEngine.Instance.Expand(geomEnvelope.Extent, 1.5, 1.5, true);
							MapView.Active?.ZoomTo(resultEnv, new TimeSpan(0, 0, 3));
							return resultEnv;
						});
						CmdMakeLayoutEnabled = true;
						_ = SetOverviewMapArea(env);
					}
					catch (Exception ex)
					{
						ClearAllGraphicElements();
						MessageBox.Show($@"Unable to read the CSV file from: {csvPath} {ex}");
					}
				}, true);
			}
		}

		public ICommand CmdRowSelect
		{
			get
			{
				return new RelayCommand(async () =>
				{
					var mapPane = await ActivateParcelMapAsync();
					if (mapPane == null)
					{
						MessageBox.Show("No such map was found: 'Parcel Map'");
						return;
					}
					if (_selectedComp == null)
					{
						MessageBox.Show("No Comp was selected");
						return;
					}
					SelectComp(_selectedComp);
				});
			}
		}

		public ICommand CmdRowZoom
		{
			get
			{
				return new RelayCommand(async () =>
				{
					var mapPane = await ActivateParcelMapAsync();
					if (mapPane == null)
					{
						MessageBox.Show("No such map was found: 'Parcel Map'");
						return;
					}
					if (_selectedComp == null)
					{
						MessageBox.Show("No parcel was selected");
						return;
					}
					ZoomToCompRecord(_selectedComp, mapPane.MapView);
				});
			}
		}

		public ICommand CmdIdentify
		{
			get
			{
				return new RelayCommand(() =>
				{
					if (_selectedComp != null)
					{
						// show the detail pane for this parcel
						var url = _selectedComp.Url;
						var id = _selectedComp.Id;
						CompDetailPaneViewModel.Create(id, url);
					}
				});
			}
		}

		public ICommand CmdMove
		{
			get
			{
				return new RelayCommand(async () =>
				{
					var mapPane = await ActivateParcelMapAsync();
					if (mapPane == null)
					{
						MessageBox.Show("No such map was found: 'Parcel Map'");
						return;
					}
					if (_selectedComp != null)
					{
						var oid = _selectedComp.Oid;
						// select the label for this parcel so that it can be moved on the map
						if (!_txtGraphicElement.ContainsKey(oid)) return;
						await QueuedTask.Run(() =>
						{
							GetGraphicsLayer(MapView.Active?.Map).SelectElement(_txtGraphicElement[oid]);
						});
						// use the esri_layouts_selectByRectangleTool
						IPlugInWrapper wrapper = FrameworkApplication.GetPlugInWrapper("esri_layouts_selectByRectangleTool");
						if (wrapper is ICommand toolCmd)
						{
							toolCmd.Execute(null); // if it is a tool, execute will set current tool
						}
					}
				});
			}
		}

		public ICommand CmdAddNewComp
		{
			get
			{
				return new RelayCommand(async () =>
				{
					var mapPane = await ActivateParcelMapAsync();
					if (mapPane == null)
					{
						MessageBox.Show("No such map was found: 'Parcel Map'");
						return;
					}
					await QueuedTask.Run(() =>
					{
						GetGraphicsLayer(MapView.Active?.Map).ClearSelection();
					});
					// use the CompReporter_AddCompBySelection
					IPlugInWrapper wrapper = FrameworkApplication.GetPlugInWrapper("CompReporter_AddCompBySelection");
					if (wrapper is ICommand toolCmd)
					{
						toolCmd.Execute(null); // if it is a tool, execute will set current tool
					}
				});
			}
		}

		public ICommand CmdCleanMap
		{
			get
			{
				return new RelayCommand(async () =>
				{
					var mapPane = await ActivateParcelMapAsync();
					if (mapPane == null)
					{
						MessageBox.Show("No such map was found: 'Parcel Map'");
						return;
					}
					await QueuedTask.Run(() =>
					{
						GetGraphicsLayer(MapView.Active?.Map).ClearSelection();
					});
					// use the esri_layouts_selectByRectangleTool
					IPlugInWrapper wrapper = FrameworkApplication.GetPlugInWrapper(DAML.Tool.esri_mapping_exploreTool);
					if (wrapper is ICommand toolCmd)
					{
						toolCmd.Execute(null); // if it is a tool, execute will set current tool
					}
				});
			}
		}

		public ICommand CmdMakeLayout
		{
			get
			{
				return new RelayCommand(async () =>
				{
					var mapPane = await ActivateParcelMapAsync();
					if (mapPane == null)
					{
						MessageBox.Show("No such map was found: 'Parcel Map'");
						return;
					}
					var currentCamera = MapView.Active?.Camera;
					try
					{
						var title = await PrepareDataAsync();

						var theLayout = await CreateLayout(currentCamera, title);

						//CREATE, OPEN LAYOUT VIEW (must be in the GUI thread)
						ILayoutPane layoutPane = await LayoutFrameworkExtender.CreateLayoutPaneAsync(ProApp.Panes, theLayout);
					}
					catch (Exception ex)
					{
						MessageBox.Show($@"Error in create layout: {ex}");
					}
				}, () => SelectedPageLayout != null);
			}
		}

		#endregion Dockpane Commands

		#region Overview Map properties

		private async Task UpdateOverviewMapContent(Envelope env = null)
		{
			try
			{
				await QueuedTask.Run(() =>
				{
					var overviewMap = OverviewMap;
					if (overviewMap == null) return;
					var ext = env ?? overviewMap.GetDefaultExtent();
					_overviewMapContent = MapControlContentFactory.Create(overviewMap,
						ext, overviewMap.DefaultViewingMode);
				});
				NotifyPropertyChanged(() => OverviewMapContent);
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine($@"Execption in UpdateOverviewMapContent: {ex.ToString()}");
			}
		}

		private async Task SetOverviewMapArea(Envelope env = null)
		{
			try { 
				await QueuedTask.Run(() =>
				{
					var overviewMap = OverviewMap;
					if (overviewMap == null) return;				
					var poly = new PolygonBuilder(GeometryEngine.Instance.Expand(env, 5, 5, true)).ToGeometry();
					var graphicsLyr = GetGraphicsLayer(overviewMap);
					if (graphicsLyr == null) return;
					CIMStroke outlineStroke = SymbolFactory.Instance.ConstructStroke(CompTypeDefinition.OutlineColors[0], 2.0, SimpleLineStyle.Solid);
					var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(CompTypeDefinition.FillColors[0], SimpleFillStyle.BackwardDiagonal, outlineStroke);
					var polyGraphic = new CIMPolygonGraphic
					{
						Polygon = poly,
						Symbol = polySymbol.MakeSymbolReference()
					};
					graphicsLyr.AddElement(polyGraphic);
				});
				NotifyPropertyChanged(() => OverviewMapContent);
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine($@"Execption in SetOverviewMapArea: {ex.ToString()}");
			}
		}

		private MapControlContent _overviewMapContent;
		public MapControlContent OverviewMapContent
		{
			get { return _overviewMapContent; }
			set
			{
				SetProperty(ref _overviewMapContent, value, () => OverviewMapContent);
			}
		}

		private Camera _overviewMapCamera;
		public Camera OverviewMapCamera
		{
			get { return _overviewMapCamera; }
			set
			{
				SetProperty(ref _overviewMapCamera, value, () => OverviewMapCamera);
			}
		}

		#endregion Overview Map properties

		#region DataGrid properties

		private string _heading = "No Comps available";
		public string Heading
		{
			get { return _heading; }
			set
			{
				SetProperty(ref _heading, value, () => Heading);
			}
		}

		/// <summary>
		/// List of Comps for the datagrid
		/// </summary>
		public ObservableCollection<CompData> Comps
		{
			get { return _comps; }
			set 
			{ 
				SetProperty(ref _comps, value, () => Comps); 
			}
		}

		/// <summary>
		/// One row of the Comps grid was selected
		/// </summary>
		public CompData SelectedComp
		{
			get { return _selectedComp; }
			set
			{
				SetProperty(ref _selectedComp, value, () => SelectedComp);
			}
		}

		private ObservableCollection<KeyValuePair<int, string>> _lstCompTypes = null;
		/// <summary>
		/// Values for the Comp Types drop down
		/// </summary>
		public ObservableCollection<KeyValuePair<int, string>> CompTypes => CompTypeDefinition.CompTypes;

		#endregion DataGrid properties

		#region Layout Create Properties

		private SetPage _myPageLyt = null;

		public SetPage SelectedPageLayout
		{
			get { return _myPageLyt; }
			set { SetProperty(ref _myPageLyt, value, () => SelectedPageLayout); }
		}

		public IReadOnlyCollection<SetPage> PageLayouts
		{
			get
			{
				if (_mapPageLayouts.Count == 0)
				{
					foreach (var setPg in _setPages.SetPageList)
					{
						_mapPageLayouts.Add(setPg);
					}
				}
				return _mapPageLayouts;
			}
		}

		#endregion Layout Create Properties

		#region Helper Functions

		private Task<IMapPane> ActivateParcelMapAsync()
		{
			try
			{
				MapProjectItem mapProjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item =>
																							item.Name.Equals(ParcelMapName));
				if (mapProjItem != null)
				{
					// we found the existing MapProjectItem
					var mapPanes = ProApp.Panes.OfType<IMapPane>();
					foreach (Pane pane in mapPanes)
					{
						if (pane.Caption == ParcelMapName)
						{
							pane.Activate();
							return Task<IMapPane>.FromResult((IMapPane)pane);
						}
					}
					//Opening the map in a mapview
					return QueuedTask.Run<IMapPane>(() =>
					{
						return ProApp.Panes.CreateMapPaneAsync(mapProjItem.GetMap());
					});
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($@"An error occurred in ActivateParcelMapAsync: {ex.ToString()}");
			}
			return Task.FromResult((IMapPane)null);
		}

		/// <summary>
		/// Call from MCT
		/// </summary>
		/// <param name="thisPoly"></param>
		/// <param name="txt"></param>
		/// <param name="type"></param>
		/// <param name="oid"></param>
		private void SymbolizeComp(Polygon thisPoly, string txt, int type, long oid)
		{
			SymbolizeBoundary(oid, thisPoly, type);
			var callOutPnt = GeometryEngine.Instance.Move(thisPoly.Extent.Center, thisPoly.Extent.Width / 2, 0);
			var lines = txt.Split(new char[] { '-' });
			var labeltext = lines.Length > 0 ? lines[0] : string.Empty; 
			SymbolizeCallOut(callOutPnt, labeltext, type, oid);
		}

		/// <summary>
		/// Call from MCT
		/// </summary>
		/// <param name="oid"></param>
		/// <param name="thisPoly"></param>
		/// <param name="type"></param>
		private void SymbolizeBoundary(long oid, Polygon thisPoly, int type)
		{
			CIMPolygonSymbol polySymbol;

			var colorKey = CompTypeDefinition.FillColors.ContainsKey(type) ? type : -1;
			CIMStroke outlineStroke = SymbolFactory.Instance.ConstructStroke(CompTypeDefinition.OutlineColors[colorKey], 2.0, SimpleLineStyle.Solid);
			polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(CompTypeDefinition.FillColors[colorKey], SimpleFillStyle.BackwardDiagonal, outlineStroke);
			var polyGraphic = new CIMPolygonGraphic
			{
				Polygon = thisPoly,
				Symbol = polySymbol.MakeSymbolReference()
			};
			_polyGraphicElement.Add (oid, GetGraphicsLayer(MapView.Active?.Map).AddElement(polyGraphic));
		}

		/// <summary>
		/// SymbolizeCallOut: Call from MCT
		/// </summary>
		/// <param name="geom"></param>
		/// <param name="text"></param>
		/// <param name="type"></param>
		/// <param name="oid"></param>
		private void SymbolizeCallOut (Geometry geom, string text, int type, long oid)
		{
			var colorKey = CompTypeDefinition.FillColors.ContainsKey(type) ? type : -1;
			CIMTextSymbol balloonCallout = CreateBalloonCallout(CompTypeDefinition.FillColors[colorKey]);
			if (balloonCallout == null) return;
			var textGraphic = new CIMTextGraphic
			{
				Symbol = balloonCallout.MakeSymbolReference(),
				Shape = geom as MapPoint,
				Text = text
			};
			if (_txtGraphicElement.ContainsKey (oid))
				_txtGraphicElement[oid].SetGraphic(textGraphic);
			else
				_txtGraphicElement.Add (oid, GetGraphicsLayer(MapView.Active?.Map).AddElement(textGraphic));
			GetGraphicsLayer(MapView.Active?.Map).ClearSelection();
		}

		/// <summary>
		/// Call from MCT
		/// </summary>
		/// <returns></returns>
		private static CIMTextSymbol CreateBalloonCallout(CIMColor balloonColor, BalloonCalloutStyle calloutStyle = BalloonCalloutStyle.RoundedRectangle)
		{
			//create a text symbol
			var textSymbol = SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 8, "Verdana", "Bold");
			//A balloon callout
			var balloonCallout = new CIMBalloonCallout
			{
				//set the callout's style
				BalloonStyle = calloutStyle
			};
			//Create a solid fill polygon symbol for the callout.
			var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(balloonColor, SimpleFillStyle.Solid);
			//Set the callout's background to be the black polygon symbol
			balloonCallout.BackgroundSymbol = polySymbol;
			//margin inside the callout to place the text
			balloonCallout.Margin = new CIMTextMargin
			{
				Left = 5,
				Right = 5,
				Bottom = 5,
				Top = 5
			};
			//assign the callout to the text symbol's callout property
			textSymbol.Callout = balloonCallout;
			return textSymbol;
		}

		private void ZoomToCompRecord(CompData selectedComp, MapView mapView)
		{
			var parcelLayer = GetTaxParcelLayer();
			if (parcelLayer != null)
			{
				_ = QueuedTask.Run(() =>
				{
					var geom = selectedComp.Shape;
					var env = GeometryEngine.Instance.Expand(geom.Extent, 5, 5, true);
					mapView.ZoomToAsync(env, new TimeSpan(0, 0, 3));
				});
			}
		}

		private void SelectComp(CompData selectedComp)
		{
			var parcelLayer = GetTaxParcelLayer();
			if (parcelLayer != null)
			{
				_ = QueuedTask.Run(() =>
					{
						parcelLayer.Select(new QueryFilter() { ObjectIDs = new long[] { selectedComp.Oid } });
					});
			}
		}

		private async void FlashSelectedLabelAsync(DataRowView selectedLabelrv)
		{
			// Flash the Feature
			// find the labeling layer and add the table content
			var fcName = "PolygonLabels";
			if (!(ParcelMap.GetLayersAsFlattenedList().Where((l) => l.Name == fcName).FirstOrDefault() is FeatureLayer labelLayer))
			{
				MessageBox.Show($@"Unable to find {fcName} in the active map");
				return;
			}
			var oid = await QueuedTask.Run(() =>
			{
				var qf = new QueryFilter()
				{
					WhereClause = $@"{selectedLabelrv.Row.Table.Columns[0]} = '{selectedLabelrv.Row[0]}'"
				};
				long ret = -1;
				using (var cursor = labelLayer.Search(qf))
				{
					if (cursor.MoveNext())
					{
						using (var parcelFeature = cursor.Current as Feature)
						{
							ret = parcelFeature.GetObjectID();
						}
					}
				}
				return ret;
			});
			if (oid == -1) return;
			IReadOnlyDictionary<BasicFeatureLayer, List<long>> flashFeature = new Dictionary<BasicFeatureLayer, List<long>>()
										{{labelLayer as BasicFeatureLayer, new List<long>(){oid}}};
			FlashFeaturesAsync(flashFeature);
		}

		/// <summary>
		/// Flash the selected features
		/// </summary>
		/// <param name="flashFeatures"></param>
		private async void FlashFeaturesAsync(IReadOnlyDictionary<BasicFeatureLayer, List<long>> flashFeatures)
		{
			//Get the active map view.
			var mapView = MapView.Active;
			if (mapView == null) return;
			await QueuedTask.Run(() =>
			{
				//Flash the collection of features.
				mapView.FlashFeature(flashFeatures);
			});
		}

		private CIMPointSymbol GetPointSymbolFromLayer(Layer layer)
		{
			if (!(layer is FeatureLayer)) return null;
			var fLyr = layer as FeatureLayer;
			if (!(fLyr.GetRenderer() is CIMSimpleRenderer renderer) || renderer.Symbol == null) return null;
			return renderer.Symbol.Symbol as CIMPointSymbol;
		}

		#endregion Helper Functions

		#region Layer / Map Access Functions

		/// <summary>
		/// Call from MCT
		/// </summary>
		/// <returns></returns>
		private static GraphicsLayer GetGraphicsLayer(Map map)
		{
			if (map == null) return null;
			var graphicsLyr = map.GetLayersAsFlattenedList().OfType<GraphicsLayer>().FirstOrDefault();
			if (graphicsLyr == null)
			{
				var graphicsLayerCreationParams = new GraphicsLayerCreationParams { Name = "Comp Parcels" };
				graphicsLyr = LayerFactory.Instance.CreateLayer<GraphicsLayer>(graphicsLayerCreationParams, map, LayerPosition.AutoArrange);
			}
			return graphicsLyr;
		}

		private static string ParcelMapName => "Parcel Map";

		private static string ParcelInfoName => "ParcelInfo";

		private static StandaloneTable ParcelInfoTable
		{
			get
			{
				return ParcelMap.FindStandaloneTables(ParcelInfoName).FirstOrDefault();
			}
		}

		internal static FeatureLayer GetTaxParcelLayer()
		{
			var parcelLayerName = "TaxParcels";
			FeatureLayer parcelLayer = null;
			try
			{
				if (ParcelMap == null) return null;
				parcelLayer = ParcelMap.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(f => f.Name == parcelLayerName);
			}
			catch { }
			if (parcelLayer == null)
			{
				MessageBox.Show($@"Unable to find {parcelLayerName} in the active map");
				return null;
			}
			return parcelLayer;
		}

		private static Map _parcelMap = null;

		private static Map ParcelMap
		{
			get
			{
				if (_parcelMap == null)
				{
					var map = QueuedTask.Run(() =>
					{
						if (Project.Current == null) return null;
						MapProjectItem mapProjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals(ParcelMapName));
						return mapProjItem?.GetMap();
					});
					_parcelMap = map.Result;
				}
				return _parcelMap;
			}
		}

		private static Map _overviewMap = null;

		private static Map OverviewMap
		{
			get
			{
				if (_overviewMap == null)
				{
					var map = QueuedTask.Run(() =>
					{
						MapProjectItem mapProjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals("Overview Map"));
						return mapProjItem?.GetMap();
					});
					_overviewMap = map.Result;
				}
				return _overviewMap;
			}
		}

		#endregion Layer / Map Access Functions

		#region Layout Helpers

		private async Task<string> PrepareDataAsync()
		{
			var parcelTbl = ParcelInfoTable;
			var title = await QueuedTask.Run(() =>
			{
				var tmk = string.Empty;
				parcelTbl.GetTable().DeleteRows(new QueryFilter());
				var editOp = new EditOperation
				{
					Name = $@"Update: {ParcelInfoName}"
				};
				foreach (CompData row in Comps)
				{
					var label = row.Label;
					var parcelId = row.Id;
					var description = row.Description.Replace (" - ", "\n");
					var type = row.Type;
					if (type == 0)
					{
						// subject parcel
						tmk += parcelId;
					}
					var attributes = new Dictionary<string, object>
						{
							{ "ParcelId", parcelId },
							{ "Description", description },
							{ "Label", label }
						};
					editOp.Create(parcelTbl, attributes);
				}
				var result1 = editOp.Execute();
				if (result1 != true || editOp.IsSucceeded != true)
					throw new Exception($@"{editOp.Name} update failed: {editOp.ErrorMessage}");
				return tmk;
			});
			var dtStamp = DateTime.Now;
			return $@"Comps Report TMK: {title}{Environment.NewLine}{dtStamp.ToShortDateString()} {dtStamp.ToShortTimeString()}";
		}

		private Task<Layout> CreateLayout(Camera currentCamera, string title)
		{
			return QueuedTask.Run<Layout>(() =>
			{
				//Set up a page
				CIMPage newPage = new CIMPage
				{
					//required
					Width = SelectedPageLayout.Width,
					Height = SelectedPageLayout.Height,
					Units = SelectedPageLayout.LinearUnit
				};
				Layout layout = LayoutFactory.Instance.CreateLayout(newPage);
				var tp = title.Split(new string[] { @"TMK: ", $@"{Environment.NewLine}" }, StringSplitOptions.RemoveEmptyEntries);
				if (tp.Length > 2) layout.SetName(tp[1]);

				//Add Map Frame
				Coordinate2D llMap = new Coordinate2D(SelectedPageLayout.MarginLayout, SelectedPageLayout.MarginLayout);
				Coordinate2D urMAP = new Coordinate2D(SelectedPageLayout.WidthMap, SelectedPageLayout.Height - SelectedPageLayout.MarginLayout);
				Envelope envMap = EnvelopeBuilder.CreateEnvelope(llMap, urMAP);

				//Reference map, create Map Frame and add to layout
				Map theMap = ParcelMap;
				MapFrame mfElm = LayoutElementFactory.Instance.CreateMapFrame(layout, envMap, theMap);
				mfElm.SetName("Comps Map");
				if (currentCamera != null)
					mfElm.SetCamera(currentCamera);

				// Scale bar
				Coordinate2D llScalebar = new Coordinate2D(2 * SelectedPageLayout.MarginLayout, 2 * SelectedPageLayout.MarginLayout);
				LayoutElementFactory.Instance.CreateScaleBar(layout, llScalebar, mfElm);

				// NorthArrow
				Coordinate2D llNorthArrow = new Coordinate2D(SelectedPageLayout.WidthMap - SelectedPageLayout.MarginLayout, 3 * SelectedPageLayout.MarginLayout);
				var northArrow = LayoutElementFactory.Instance.CreateNorthArrow(layout, llNorthArrow, mfElm);
				northArrow.SetAnchor(Anchor.CenterPoint);
				northArrow.SetLockedAspectRatio(true);
				//northArrow.SetWidth(2 * northArrow.GetWidth());

				// Title: dynamic text: <dyn type="page" property="name"/>
				Coordinate2D llTitle = new Coordinate2D(SelectedPageLayout.XOffsetMapMarginalia, SelectedPageLayout.Height - 2 * SelectedPageLayout.MarginLayout);
				CIMTextSymbol balloonCallout = CreateBalloonCallout(CompTypeDefinition.FillColors[-1], BalloonCalloutStyle.Rectangle);

				var titleGraphics = LayoutElementFactory.Instance.CreatePointTextGraphicElement(layout, llTitle, null, balloonCallout) as TextElement ;
				titleGraphics.SetTextProperties(new TextProperties(title, "Arial", 12, "Bold"));

				// Table 1
				AddTableToLayout(layout, theMap, mfElm, ParcelInfoName, SelectedPageLayout, 3 * SelectedPageLayout.HeightPartsMarginalia);

				// Overview map
				Coordinate2D llOMap = new Coordinate2D(SelectedPageLayout.XOffsetMapMarginalia, SelectedPageLayout.MarginLayout);
				Coordinate2D urOMap = new Coordinate2D(SelectedPageLayout.XOffsetMapMarginalia + SelectedPageLayout.XWidthMapMarginalia, SelectedPageLayout.HeightPartsMarginalia);
				Envelope envOverviewMap = EnvelopeBuilder.CreateEnvelope(llOMap, urOMap);

				Map theOverviewMap = OverviewMap;
				MapFrame omfElm = LayoutElementFactory.Instance.CreateMapFrame(layout, envOverviewMap, theOverviewMap);
				mfElm.SetName("Overview Map");

				return layout;
			});
		}

		private void AddTableToLayout(Layout layout, Map theMap, MapFrame mfElm, string layerName, SetPage setPage, double yOffset)
		{
			var tbls = theMap.FindStandaloneTables(layerName);
			if (tbls.Count > 0)
			{
				var tbl = tbls[0];
				Coordinate2D llTab1 = new Coordinate2D(setPage.XOffsetMapMarginalia, yOffset - 2 * setPage.HeightPartsMarginalia);
				Coordinate2D urTab1 = new Coordinate2D(setPage.XOffsetMapMarginalia + setPage.XWidthMapMarginalia, yOffset);
				var theTable = LayoutElementFactory.Instance.CreateTableFrame(layout, EnvelopeBuilder.CreateEnvelope(llTab1, urTab1), mfElm, tbl, new string[] { "Label", "ParcelId", "Description" });
				var def = theTable.GetDefinition() as CIMTableFrame;
				def.FillingStrategy = TableFrameFillingStrategy.ShowAllRows;
				def.Alternate1RowBackgroundCount = 1;
				var row1Background = SymbolFactory.Instance.ConstructPolygonSymbol(CIMColor.CreateRGBColor (224, 224, 224, 50), SimpleFillStyle.Solid);
				def.Alternate1RowBackgroundSymbol = row1Background.MakeSymbolReference();
				def.Alternate2RowBackgroundCount = 1;
				var headerBackground = SymbolFactory.Instance.ConstructPolygonSymbol(CompTypeDefinition.FillColors[-1], SimpleFillStyle.Solid);
				def.Alternate2RowBackgroundSymbol = headerBackground.MakeSymbolReference();
				def.HeadingBackgroundSymbol = headerBackground.MakeSymbolReference();
				theTable.SetDefinition(def);
			}
		}

		#endregion Layout Helpers

		#region ObservableCollection Helpers

		private void Comps_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			switch (e.Action)
			{
				case NotifyCollectionChangedAction.Add:
					foreach (CompData item in e.NewItems)
					{
						item.PropertyChanged += CompsManageRowContentChange;
						CompsManageRow(DataRowAction.Add, item);
					}
					break;
				case NotifyCollectionChangedAction.Remove:
					foreach (CompData item in e.OldItems)
					{
						item.PropertyChanged -= CompsManageRowContentChange;
						CompsManageRow(DataRowAction.Delete, item);
					}
					break;
			}
		}

		private void CompsManageRowContentChange(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			if (!(sender is CompData cd)) return;
			CompsManageRow(DataRowAction.Change, cd);
		}

		private void CompsManageRow(DataRowAction action, CompData compData)
		{
			if (!(compData.Shape is Polygon thisPoly)) return;
			var txt = compData.Description;
			var label = compData.Label;
			var type = compData.Type;
			txt = $@"{label}: {txt}";
			var oid = compData.Oid;
			// subsequent code must be called from the MCT
			QueuedTask.Run(() =>
				 {
					 switch (action)
					 {
						 case DataRowAction.Change:  // change the text
							 var lines = txt.Split(new char[] { '-' });
							 var labeltext = lines.Length > 0 ? lines[0] : string.Empty;
							 var callOutPnt = GeometryEngine.Instance.Move(thisPoly.Extent.Center, thisPoly.Extent.Width / 2, 0);
							 SymbolizeCallOut(callOutPnt, labeltext, type, oid);
							 break;
						 case DataRowAction.Add:
							 SymbolizeComp(thisPoly, txt, type, oid);
							 // Update the heading for the comps datagrid
							 Heading = $@"No. of Comps: {CurrentMaxLabelNo}";
							 break;
						 case DataRowAction.Delete:
							 var gl = GetGraphicsLayer(ParcelMap);
							 if (gl != null)
							 {
								 if (_polyGraphicElement.ContainsKey(oid))
								 {
									 gl.RemoveElement(_polyGraphicElement[oid]);
									 _polyGraphicElement.Remove(oid);
								 }
								 if (_txtGraphicElement.ContainsKey(oid))
								 {
									 gl.RemoveElement(_txtGraphicElement[oid]);
									 _txtGraphicElement.Remove(oid);
								 }
							 }
							 break;
					 }
				 });
		}

		private void ClearAllGraphicElements ()
		{
			var gl = GetGraphicsLayer(ParcelMap);
			if (gl != null)
			{
				gl.RemoveElements(_txtGraphicElement.Values);
				_txtGraphicElement.Clear();
				gl.RemoveElements(_polyGraphicElement.Values);
				_polyGraphicElement.Clear();
			}
			var glOverlay = GetGraphicsLayer(OverviewMap);
			if (glOverlay != null)
			{
				glOverlay.RemoveElements();
			}
		}

		private async Task SymbolizeRow()
		{
			Geometry geomEnvelope = null;
			// symbolize all comps and zoom to extent
			await QueuedTask.Run(() =>
			{
				foreach (CompData row in Comps)
				{
					if (!(row.Shape is Polygon thisPoly)) continue;
					var txt = row.Description;
					var type = row.Type;
					var oid = row.Oid;
					SymbolizeComp(thisPoly, txt, type, oid);
					if (geomEnvelope == null)
					{
						geomEnvelope = thisPoly.Clone();
						continue;
					}
					geomEnvelope = GeometryEngine.Instance.Union(geomEnvelope, thisPoly);
				}
				var env = GeometryEngine.Instance.Expand(geomEnvelope.Extent, 1.5, 1.5, true);
				MapView.Active?.ZoomTo(env, new TimeSpan(0, 0, 3));
				_ = SetOverviewMapArea(env);
			});
		}

		internal int CurrentMaxLabelNo = -1;

		/// <summary>
		/// Read a CSV file and read into an ObservableCollection
		/// </summary>
		/// <param name="comps">ObservableCollection to read CSV into</param>
		/// <param name="csvPath">csv path and file name</param>
		/// <param name="taxParcelLayer">Tax parcel layer for match the each csv record to</param>
		/// <returns>A Database with all valid CSV recoerds</returns>
		/// <exception cref="ArgumentException">Thrown when a csv format was bad or a record not found</exception>
		private async Task<ObservableCollection<CompData>> ReadCsvIntoCollection(
			ObservableCollection<CompData> comps, 
			string csvPath, 
			FeatureLayer taxParcelLayer)
		{
			// csv file columns: ID, Type, Description, Label
			return await QueuedTask.Run<ObservableCollection<CompData>>(() =>
			{
				if (taxParcelLayer == null
					|| !(taxParcelLayer.GetTable() is FeatureClass fcSource))
					throw new ArgumentException($@"The Tax Parcel Layer is invalid");

				// Open a TextFieldParser using these delimiters.
				string[] delimiters = { "," };
				CurrentMaxLabelNo = 0;
				using (TextFieldParser parser = FileSystem.OpenTextFieldParser(csvPath, delimiters))
				{
					while (!parser.EndOfData)
					{
						//Processing row
						string[] fields = parser.ReadFields();
						if (fields.Length != 4) throw new ArgumentException($@"The csv format is not correct: {csvPath}");
						var theLabelId = fields[0];
						var theType = Convert.ToInt32(fields[1]);
						var theDescription = fields[2];
						var theLabelNo = Convert.ToInt32(fields[3]);
						if (theLabelNo >= CurrentMaxLabelNo) CurrentMaxLabelNo = theLabelNo;
						// search the source of the matching parcel record
						var parcelIdFieldName = "TMK_txt";
						var qf = new QueryFilter()
						{
							WhereClause = $@"{parcelIdFieldName} = '{theLabelId}'"
						};
						Geometry parcelPolygon = null;
						var url = string.Empty;
						long parcelOid = 0;
						using (var cursor = fcSource.Search(qf))
						{
							if (cursor.MoveNext())
							{
								using (var parcelFeature = cursor.Current as Feature)
								{
									parcelPolygon = parcelFeature.GetShape().Clone();
									url = parcelFeature["qpub_link"].ToString();
									parcelOid = parcelFeature.GetObjectID();
								}
							}
						}
						if (parcelPolygon == null)
						{
							MessageBox.Show($@"The add-in was not able to find parcel where '{qf.WhereClause}' is true.");
							return null;
						}
						var newRow = new CompData(theLabelId, parcelPolygon, 
																			theType, theLabelNo, 
																			theDescription, parcelOid, url);
						lock (CompsLock)
							comps.Add(newRow);
					}
				}
				return comps;
			});
		}

		#endregion ObservableCollection Helpers

		/// <summary>
		/// Show the DockPane.
		/// </summary>
		internal static void Show()
		{
			DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
			if (pane == null) return;
			pane.Activate();
		}

	}

	/// <summary>
	/// Button implementation to show the DockPane.
	/// </summary>
	internal class CompReporting_ShowButton : Button
	{
		protected override void OnClick()
		{
			CompReportingViewModel.Show();
		}
	}
}
