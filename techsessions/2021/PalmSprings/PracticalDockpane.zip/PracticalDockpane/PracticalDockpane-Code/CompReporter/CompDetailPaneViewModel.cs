﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompReporter
{
	internal class CompDetailPaneViewModel : ViewStatePane
	{
		private const string _viewPaneID = "CompReporter_CompDetailPane";

		/// <summary>
		/// Consume the passed in CIMView. Call the base constructor to wire up the CIMView.
		/// </summary>
		public CompDetailPaneViewModel(CIMView view)
			: base(view) { }

		/// <summary>
		/// Closes all CompDetail Panes
		/// </summary>
		internal static void CloseAllCompDetailPanes ()
		{
			var lstToClose = new List<uint>();

			// Find all CompDetailPanes
			var panes = ProApp.Panes.Find(_viewPaneID);
			foreach (Pane pane in panes)
			{
				lstToClose.Add (pane.InstanceID);
			}
			// and close them
			foreach (var instId in lstToClose)
			{
				ProApp.Panes.ClosePane(instId);
			}
		}

		/// <summary>
		/// Create a new instance of the CompDetail pane.
		/// </summary>
		internal static void Create(string title, string htmlPath)
		{
			// first check if the title is already displayed
			var lstPanes = FrameworkApplication.Panes.Find(_viewPaneID);
			foreach (var pane in lstPanes)
			{
				if (pane.Caption.Equals(title))
				{
					pane?.Activate();
					return;
				}
			}
			var view = new CIMGenericView
			{
				ViewType = _viewPaneID
			};
			var vm = FrameworkApplication.Panes.Create(_viewPaneID, 
																									new object[] { view }) as CompDetailPaneViewModel;
			vm.HtmlSource = !string.IsNullOrEmpty(htmlPath) ? new Uri(htmlPath) : null;
			vm.Caption = title;
			return;
		}

		private Uri _HtmlSource = null;
		public Uri HtmlSource
		{
			get
			{
				return _HtmlSource;
			}
			set
			{
				SetProperty(ref _HtmlSource, value, () => HtmlSource);
			}
		}

		#region Pane Overrides

		/// <summary>
		/// Must be overridden in child classes used to persist the state of the view to the CIM.
		/// </summary>
		public override CIMView ViewState
		{
			get
			{
				_cimView.InstanceID = (int)InstanceID;
				return _cimView;
			}
		}

		/// <summary>
		/// Called when the pane is initialized.
		/// </summary>
		protected async override Task InitializeAsync()
		{
			await base.InitializeAsync();
		}

		/// <summary>
		/// Called when the pane is uninitialized.
		/// </summary>
		protected async override Task UninitializeAsync()
		{
			await base.UninitializeAsync();
		}

		#endregion Pane Overrides
	}

	/// <summary>
	/// Button implementation to create a new instance of the pane and activate it.
	/// </summary>
	internal class CompDetailPane_OpenButton : Button
	{
		protected override void OnClick()
		{
			CompDetailPaneViewModel.Create("esri", @"https://www.esri.com");
		}
	}
}
