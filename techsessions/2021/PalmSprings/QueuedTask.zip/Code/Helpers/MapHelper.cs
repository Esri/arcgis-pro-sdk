﻿using ArcGIS.Core;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DemoQueuedTask.Helpers
{
	public static class MapHelper
	{


		public static int SelectWithExtent(this MapView mv, double delta, bool asRatio)
		{
			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			//select features in the middle of the mapview
			if (mv.ViewingMode != ArcGIS.Core.CIM.MapViewingMode.Map)
				throw new ArgumentException("MapView must be 2D");

			var extent = mv.Extent.Expand(0.5, 0.5, true);
			var sel = mv.SelectFeatures(extent);
			mv.ZoomToSelected(new TimeSpan(0, 0, 2));
			return sel.Values.Sum(oids => oids.Count());
		}

		public static Task<int> SelectWithExtentAsync(this MapView mv,
			double delta, bool asRatio)
		{
			return QueuedTask.Run(() =>
			{
				return mv.SelectWithExtent(delta, asRatio);
			});
		}

		//Using the CancelableProgressorSource
		internal static Task<bool> SelectAndProcessFeaturesAsync(
			this MapView mv, double delta, bool asRatio,
			CancelableProgressorSource progSource)
		{
			return QueuedTask.Run(() =>
			{
				return mv.SelectAndProcessFeatures(delta, asRatio, progSource);
			}, progSource.Progressor);
		}

		internal static bool SelectAndProcessFeatures(
		     this MapView mv, double delta, bool asRatio,
		     CancelableProgressorSource progSource)
		{
			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			//select features in the middle of the mapview
			if (mv.ViewingMode != ArcGIS.Core.CIM.MapViewingMode.Map)
				throw new ArgumentException("MapView must be 2D");

			var extent = mv.Extent.Expand(delta, delta, asRatio);
			var selection = mv.SelectFeatures(extent);

			progSource.Progressor.Max = (uint)selection.Keys.Count();
			progSource.Value = 0;

			foreach (var featureLayer in selection.Keys)
			{
				progSource.Status = $"{featureLayer.Name}";
				progSource.Value++;

				foreach (var oid in selection.Values)
				{
					//TODO - processing of selection
					//Have we been canceled?
					progSource.CancellationTokenSource.Token.ThrowIfCancellationRequested();
				}
				//Simulate processing
				try
				{
					Task.Delay(2000, progSource.CancellationTokenSource.Token).Wait();
				}
				catch (AggregateException ae)
				{
					if (ae.InnerExceptions.Any(e => e is TaskCanceledException))
						progSource.CancellationTokenSource.Token.ThrowIfCancellationRequested();
				}
			}
			return true;
		}

		//Using the Cancel Token
		internal static Task<bool> SelectAndProcessFeatures2Async(
										this MapView mv, double delta, bool asRatio,
										CancellationToken token)
		{
			return QueuedTask.Run(() =>
			{
				return mv.SelectAndProcessFeatures2(delta, asRatio, token);
			});
		}

		internal static bool SelectAndProcessFeatures2(
				this MapView mv, double delta, bool asRatio,
				CancellationToken token)
		{
			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			//select features in the middle of the mapview
			if (mv.ViewingMode != ArcGIS.Core.CIM.MapViewingMode.Map)
				throw new ArgumentException("MapView must be 2D");

			var extent = mv.Extent.Expand(delta, delta, asRatio);
			var selection = mv.SelectFeatures(extent);


			foreach (var featureLayer in selection.Keys)
			{
				foreach (var oid in selection.Values)
				{
					//TODO - do post processing of selection
					//Have we been canceled?
					token.ThrowIfCancellationRequested();
				}
				//Simulate processing
				try
				{
					Task.Delay(2000, token).Wait();
				}
				catch (AggregateException ae)
				{
					if (ae.InnerExceptions.Any(e => e is TaskCanceledException))
						token.ThrowIfCancellationRequested();
				}
			}
			return true;
		}

		public static Task ClearSelectAsync(this MapView mv)
		{
			return QueuedTask.Run(() =>
			{
				var feat_layers = mv.Map.GetLayersAsFlattenedList().OfType<BasicFeatureLayer>();
				foreach (var fl in feat_layers)
					fl.ClearSelection();
			});
		}
	}
}
