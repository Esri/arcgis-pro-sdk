﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using DemoQueuedTask.Helpers;

namespace DemoQueuedTask.Ribbon
{
	internal class SelectWithCancelToken : Button
	{
		protected async override void OnClick()
		{
			var mv = MapView.Active;
			if (mv == null)
				return;

			if (!Module1.Current.StartProcess())
				return;

			try
			{
				await mv.SelectAndProcessFeatures2Async(
					0.5, true, Module1.Current.CancelToken);
			}
			catch (ArgumentException ae)
			{
				MessageBox.Show(ae.Message);
			}
			catch (OperationCanceledException oce)
			{
				MessageBox.Show("Canceled");
			}
			finally
			{
				Module1.Current.StopProcess();
				mv.ClearSelectAsync();
			}
		}
	}
}
