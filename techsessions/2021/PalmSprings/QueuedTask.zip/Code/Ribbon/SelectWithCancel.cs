﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using DemoQueuedTask.Helpers;

namespace DemoQueuedTask.Ribbon
{
	internal class SelectWithCancel : Button
	{
		protected async override void OnClick()
		{
			var mv = MapView.Active;
			if (mv == null)
				return;

			try
			{
				var progSource = new CancelableProgressorSource(
					"Processing features", "Cancel process");
				await mv.SelectAndProcessFeaturesAsync(0.5, true, progSource);
			}
			catch (ArgumentException ae)
			{
				MessageBox.Show(ae.Message);
			}
			catch(OperationCanceledException oce)
			{
				MessageBox.Show("Canceled");
			}
			finally
			{
				mv.ClearSelectAsync();
			}
		}
	}
}
