﻿using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using GetSymbolSwatch;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GetSymbolSwatchTests
{
  [TestClass]
  public class ShowSymbolSwatchDockpaneViewModelTests
  {
    static Map _map = null;
    static IEnumerable<Layer> _layers = null;

    [ClassInitialize]
    public static void ClassInitialize(TestContext testContext)
    {
      Project project = Project.OpenAsync(@"..\DevSummit21\DevSummit21.aprx").Result;
      QueuedTask.Run(() =>
      {
        _map = project.GetItems<MapProjectItem>().Where(x => x.Name.Equals("Map")).FirstOrDefault().GetMap();
        _layers = _map.GetLayersAsFlattenedList();
      }).Wait();
    }

    [ClassCleanup]
    public static void ClassCleanup()
    {
    }

    [TestInitialize]
    public void TestInitialize()
    {
    }

    [TestCleanup]
    public void TestCleanup()
    {
    }

    [TestMethod]
    public async Task SwatchCountTest()
    {
      ShowSymbolSwatchDockpaneViewModel showSymbolSwatchDockpaneViewModel = new ShowSymbolSwatchDockpaneViewModel();

      //var cmdRefreshSwatches = showSymbolSwatchDockpaneViewModel.CmdRefreshSwatches;
      //await _map.OpenViewAsync();
      //cmdRefreshSwatches.Execute(null);

      await showSymbolSwatchDockpaneViewModel.UpdateCollection(_layers.OfType<FeatureLayer>());

      Assert.AreEqual(3, showSymbolSwatchDockpaneViewModel.SymbolSwatchInfoList.Count, "SymbolSwatchList does not contain expected number of swatches");

    }


    [DataTestMethod]
    [DataRow(0, "Cities", "CIMSimpleRenderer", null, DisplayName = "SimpleRenderer")]
    [DataRow(0, "Volcanos", "CIMClassBreaksRenderer", "127.000000 - 141.000000", DisplayName = "ClassBreaksRenderer")]
    [DataRow(1, "Volcanos", "CIMClassBreaksRenderer", "141.000001 - 165.000000", DisplayName = "ClassBreaksRenderer")]
    public async Task SwatchInfoTest(int swatchIndex, string featureLayerName, string rendererType, string note)
    {
      ShowSymbolSwatchDockpaneViewModel showSymbolSwatchDockpaneViewModel = new ShowSymbolSwatchDockpaneViewModel();
      await showSymbolSwatchDockpaneViewModel.UpdateCollection(_layers.Where((layer) => { if (layer.Name == featureLayerName) return true; else return false; }).OfType<FeatureLayer>());

      SymbolSwatchInfo swatchInfo = showSymbolSwatchDockpaneViewModel.SymbolSwatchInfoList[swatchIndex];
      Assert.AreEqual(featureLayerName, swatchInfo.FeatureClassName, "SwatchInfo feature layer name does not match expected value");
      Assert.AreEqual(rendererType, swatchInfo.RendererType, "SwatchInfo feature renderer type does not match expected value");

      if (note is null)
        Assert.IsNull(note);
      else
        Assert.AreEqual(note, swatchInfo.Note);
    }
  }
}
