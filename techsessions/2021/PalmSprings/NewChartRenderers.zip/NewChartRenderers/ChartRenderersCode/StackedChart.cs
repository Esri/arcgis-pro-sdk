﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace ChartRenderersDemo
{
  internal class StackedChart : Button
  {
    protected async override void OnClick()
    {
      //Check feature layer name
      //Code works with the USDemographics feature layer available with the ArcGIS Pro SDK Sample data
      var featureLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(f => f.Name == "USDemographics");
      if (featureLayer == null) return;
      
      await QueuedTask.Run(() =>
      {
        StyleProjectItem style = Project.Current.GetItems<StyleProjectItem>().FirstOrDefault(s => s.Name == "ColorBrewer Schemes (RGB)"); //ColorBrewer Schemes (RGB)
        if (style == null) return;
        var colorRampList = style.SearchColorRamps("Red-Blue (4 Classes)");
        if (colorRampList == null || colorRampList.Count == 0) return;
        CIMColorRamp colorRamp = colorRampList[0].ColorRamp;
        var chartFields = new string[]
            {
                "WHITE10",
                 "BLACK10",
                 "ASIAN10",
                 "HISPPOP10",
            };        
          StackedChartRendererDefinition stackedChartRendererDefn = new StackedChartRendererDefinition()
          {
            ChartFields = chartFields,
            ColorRamp = colorRamp,
            Orientation = ChartOrientation.Vertical,
            SizeOption = StackChartSizeOptions.Fixed,
            ShowOutline = true,
            StackWidth = 18,
            StackLength = 40
          };
        //Creates a "CIMRenderer"
        var stackedBarChartRenderer = featureLayer.CreateRenderer(stackedChartRendererDefn) as CIMChartRenderer;
        //Set visualization properties to improve display
        //Add a background to the renderer to visualize the bar chart symbols.
        stackedBarChartRenderer.BaseSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.CreateRGBColor(199, 215, 158), SimpleFillStyle.Solid).MakeSymbolReference();
        stackedBarChartRenderer.NormalizationField = "TOTPOP10";
        stackedBarChartRenderer.NormalizationType = DataNormalizationMethod.Field;
        //Sets the feature layer's renderer
        featureLayer.SetRenderer(stackedBarChartRenderer);
      });
    }
  }
}
