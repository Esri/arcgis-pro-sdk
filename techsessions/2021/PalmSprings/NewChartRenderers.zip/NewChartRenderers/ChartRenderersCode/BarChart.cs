﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace ChartRenderersDemo
{
  internal class BarChart : Button
  {
    protected async override void OnClick()
    {
      //Check feature layer name
      //Code works with the USDemographics feature layer available with the ArcGIS Pro SDK Sample data
      var featureLayer = MapView.Active?.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(f => f.Name == "USDemographics");
      if (featureLayer == null) return;
      await QueuedTask.Run(() =>
      {
        var chartFields = new string[]
            {
                "WHITE10",
                "BLACK10",
                "ASIAN10",
                "HISPPOP10",
            };
        #region Get a Color ramp to use for the Bar chart
        StyleProjectItem style = Project.Current.GetItems<StyleProjectItem>().FirstOrDefault(s => s.Name == "ColorBrewer Schemes (RGB)"); //ColorBrewer Schemes (RGB)
        if (style == null) return;
        var colorRampList = style.SearchColorRamps("Red-Blue (4 Classes)");
        if (colorRampList == null || colorRampList.Count == 0) return;
        CIMColorRamp colorRamp = colorRampList[0].ColorRamp;
        #endregion
        BarChartRendererDefinition barChartRendererDefn = new BarChartRendererDefinition()
        {
          ChartFields = chartFields,
          Orientation = ChartOrientation.Vertical,
          ColorRamp = colorRamp,
          BarWidth = 12,
          BarSpacing = 1,
          MaximumBarLength = 65,
          ShowAxes = true,
        };
        //Creates a "CIMChartRenderer"
        var barChartRenderer = featureLayer.CreateRenderer(barChartRendererDefn) as CIMChartRenderer;
        //Set visualization properties to improve display
        //Add a background to the renderer to visualize the bar chart symbols.
        barChartRenderer.BaseSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.CreateRGBColor(199, 215, 158), SimpleFillStyle.Solid).MakeSymbolReference();
        barChartRenderer.NormalizationField = "TOTPOP10";
        //Sets the feature layer's renderer
        featureLayer.SetRenderer(barChartRenderer);
      });
    }   
  }
}
