﻿/*

   Copyright 2021 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

   See the License for the specific language governing permissions and
   limitations under the License.

*/
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Events;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.DeviceLocation;
using ArcGIS.Desktop.Core.DeviceLocation.Events;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.DeviceLocation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DeviceLocation
{
  internal class DeviceTrackingViewModel : DockPane
  {
    private const string _dockPaneID = "DeviceLocation_DeviceTracking";

    private int LoggingPoints = 0;

    private int MaxPointsInPolyline = 5;

    private Layer ptLayer;
    private Layer lineLayer;

    protected DeviceTrackingViewModel()
    {
      LogAsFeature = false;
      LogFeature = LoggingPoints;
    }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

    protected override void OnActivate(bool isActive)
    {
      base.OnActivate(isActive);
      NotifyPropertyChanged(nameof(HasSource));
    }

    #region Source

    private string _InputSourcePort;
    public string InputSourcePort
    {
      get => _InputSourcePort;
      set => SetProperty(ref _InputSourcePort, value);
    }

    private string _InputSourceAccuracy;
    public string InputSourceAccuracy
    {
      get => _InputSourceAccuracy;
      set => SetProperty(ref _InputSourceAccuracy, value);
    }

    private RelayCommand _OpenSourceCmd;
    public ICommand OpenSourceCmd => _OpenSourceCmd ?? (_OpenSourceCmd = new RelayCommand(() => OpenSource(), true));

    private async void OpenSource()
    {
      if (string.IsNullOrEmpty(InputSourcePort))
      {
        MessageBox.Show("Please enter source details. A ComPort is required.");
        return;
      }

      var service = DeviceLocationService.Instance;
     
      var newSrc = new SerialPortDeviceLocationSource();
      newSrc.ComPort = InputSourcePort;
      //newSrc.BaudRate = baudRate;    
      //newSrc.AntennaHeight = AntennaHeight
      //newSrc.DataBits = 6; //  8;
      //newSrc.Parity = System.IO.Ports.Parity.Odd;   // none
      //newSrc.StopBits = System.IO.Ports.StopBits.OnePointFive; // .One;
      // etc

      double dValue;
      // include source accuracy 
      DeviceLocationProperties props = null;
      if (double.TryParse(InputSourceAccuracy, out dValue))
      {
        props = new DeviceLocationProperties();
        props.AccuracyThreshold = dValue;
      }

      try
      {
        await QueuedTask.Run(() =>
        {
          var src = service.GetSource();

          // close any existing source
          if (src != null)
            service.Close();

          // open the new one
          service.Open(newSrc, props);
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }

      NotifyPropertyChanged(nameof(HasSource));
    }

    private RelayCommand _UpdateSourceCmd;
    public ICommand UpdateSourceCmd => _UpdateSourceCmd ?? (_UpdateSourceCmd = new RelayCommand(() => UpdateSource()));    // DoesSourceExist

    private async Task UpdateSource()
    {
      // find the existing device location source
      var service = DeviceLocationService.Instance;
      var src = service.GetSource();
      // if there isn't one, exit
      if (src == null)
        return;

      await QueuedTask.Run(() =>
      {
        int iValue;
        double dValue;
        //if (src is SerialPortDeviceLocationSource portSrc)
        //{
        //portSrc.BaudRate = baudRate;
        //portSrc.AntennaHeight = antennaHeight;
        //portSrc.DataBits = 6; //  8;
        //portSrc.Parity = System.IO.Ports.Parity.Odd;   // none
        //portSrc.StopBits = System.IO.Ports.StopBits.OnePointFive; // .One;

        //service.UpdateSource(portSrc);
        //}


        // update properties
        if (double.TryParse(InputSourceAccuracy, out dValue))
        {
          var dlProps = service.GetProperties();
          dlProps.AccuracyThreshold = dValue;

          service.UpdateProperties(dlProps);
        }
      });
    }

    private RelayCommand _CloseSourceCmd;
    public ICommand CloseSourceCmd => _CloseSourceCmd ?? (_CloseSourceCmd = new RelayCommand(() => CloseSource(), DoesSourceExist));
    private async void CloseSource()
    {
      var service = DeviceLocationService.Instance;

      var src = service.GetSource();
      if (src == null)
        return;

      bool isConnected = service.IsDeviceConnected();

      await QueuedTask.Run(() =>
      {
        service.Close();
      });

      isConnected = service.IsDeviceConnected();
      NotifyPropertyChanged(nameof(HasSource));
    }

    private bool DoesSourceExist
    {
      get
      {
        var service = DeviceLocationService.Instance;

        var src = service.GetSource();
        if (src == null)
          return false;

        return true;
      }
    }

    public bool HasSource => DoesSourceExist;

    #endregion

    #region Map Properties


    private RelayCommand _ToggleEnableSourceCmd;
    public ICommand ToggleEnableSourceCmd => _ToggleEnableSourceCmd ?? (_ToggleEnableSourceCmd = new RelayCommand(() => ToggleEnableSource(), DoesSourceExist));

    private void ToggleEnableSource()
    {
      try
      {
        bool enabled = MapDeviceLocationService.Instance.IsDeviceLocationEnabled;

        // dont await
        QueuedTask.Run(() =>
        {
          enabled = !enabled;
          MapDeviceLocationService.Instance.SetDeviceLocationEnabled(enabled);

          if (enabled)
          {
            // get the existing map options
            var mapService = MapDeviceLocationService.Instance;
            var options = mapService.GetDeviceLocationOptions();
            LocationOptions_ShowLocation = options.DeviceLocationVisibility;
            LocationOptions_KeepAtCenter = options.NavigationMode == MappingDeviceLocationNavigationMode.KeepAtCenter;
            LocationOptions_TrackUp = options.TrackUpNavigation;
          }
        });
      }
      catch (InvalidOperationException e)
      {
        MessageBox.Show(e.Message);
      }
    }

    private bool _LocationOptions_ShowLocation;
    public bool LocationOptions_ShowLocation
    {
      get => _LocationOptions_ShowLocation;
      set => SetProperty(ref _LocationOptions_ShowLocation, value);
    }

    private bool _LocationOptions_KeepAtCenter;
    public bool LocationOptions_KeepAtCenter
    {
      get => _LocationOptions_KeepAtCenter;
      set => SetProperty(ref _LocationOptions_KeepAtCenter, value);
    }

    private bool _LocationOptions_TrackUp;
    public bool LocationOptions_TrackUp
    {
      get => _LocationOptions_TrackUp;
      set => SetProperty(ref _LocationOptions_TrackUp, value);
    }

    private RelayCommand _UpdateMapLocationOptionsCmd;
    public ICommand UpdateMapLocationOptionsCmd => _UpdateMapLocationOptionsCmd ?? (_UpdateMapLocationOptionsCmd = new RelayCommand(() => UpdateMapLocationOptions()));

    private async void UpdateMapLocationOptions()
    {
      var mapService = MapDeviceLocationService.Instance;

      var options = mapService.GetDeviceLocationOptions();
      options.DeviceLocationVisibility = LocationOptions_ShowLocation;
      options.NavigationMode = LocationOptions_KeepAtCenter ? MappingDeviceLocationNavigationMode.KeepAtCenter : MappingDeviceLocationNavigationMode.None;
      options.TrackUpNavigation = LocationOptions_TrackUp;

      var error = await QueuedTask.Run(() =>
      {
        try
        {
          mapService.SetDeviceLocationOptions(options);
        }
        catch (InvalidOperationException e)
        {
          return e.Message;
        }

        return "";
      });
      if (!string.IsNullOrEmpty(error))
      {
        MessageBox.Show(error);
      }
    }

    private RelayCommand _ZoomPanToLocationCmd;
    public ICommand ZoomPanToLocationCmd => _ZoomPanToLocationCmd ?? (_ZoomPanToLocationCmd = new RelayCommand(() => ZoomPanToLocation()));

    private async void ZoomPanToLocation()
    {
      var mapService = MapDeviceLocationService.Instance;

      var error = await QueuedTask.Run(() =>
      {
        try
        {
          mapService.ZoomOrPanToCurrentLocation(true);
        }
        catch (InvalidOperationException e)
        {
          return e.Message;
        }

        return "";
      });
      if (!string.IsNullOrEmpty(error))
        MessageBox.Show(error);
    }

    #endregion


    private SubscriptionToken _trackingToken;
    private RelayCommand _StartTrackingCmd;
    public ICommand StartTrackingCmd => _StartTrackingCmd ?? (_StartTrackingCmd = new RelayCommand(() => StartTracking()));

    private void StartTracking()
    {
      if (_trackingToken == null)
        _trackingToken = SnapshotChangedEvent.Subscribe(OnSnapshotChanged);

      NotifyPropertyChanged(nameof(CanStartTracking));
      NotifyPropertyChanged(nameof(CanStopTracking));
    }

    private RelayCommand _StopTrackingCmd;
    public ICommand StopTrackingCmd => _StopTrackingCmd ?? (_StopTrackingCmd = new RelayCommand(() => StopTracking()));

    private void StopTracking()
    {
      if (_trackingToken != null)
        SnapshotChangedEvent.Unsubscribe(_trackingToken);

      _trackingToken = null;

      // remove all the saved locations
      _locations.Clear();

      NotifyPropertyChanged(nameof(CanStartTracking));
      NotifyPropertyChanged(nameof(CanStopTracking));
    }

    public bool CanStartTracking => _trackingToken == null;
    public bool CanStopTracking => _trackingToken != null;

    private void OnSnapshotChanged(SnapshotChangedEventArgs args)
    {
      if (args == null)
        return;

      var snapshot = args.Snapshot as NMEASnapshot;
      if (snapshot == null)
        return;

      QueuedTask.Run(() =>
      {
        var pt = snapshot.GetPositionAsMapPoint();
        if (pt.IsEmpty || pt == null)
          return;

        string location = "X:" + pt.X + "; Y: " + pt.Y + ";Z " + pt.Z;
        RecordLocEvent("OnSnapshotChanged", location);

        if (LogAsFeature)
        {
          LogSnapshot(snapshot, pt);
        }
      });
    }

    private bool _LogAsFeature;
    public bool LogAsFeature
    {
      get => _LogAsFeature;
      set => SetProperty(ref _LogAsFeature, value);
    }

    public int _LogFeature;
    public int LogFeature
    {
      get => _LogFeature;
      set => SetProperty(ref _LogFeature, value);
    }

    private static List<MapPoint> _locations = new List<MapPoint>();

    private void LogSnapshot(NMEASnapshot snapshot, MapPoint pt)
    {
      if (LogFeature == LoggingPoints)
      {
        if (ptLayer == null)
          ptLayer = MapView.Active.Map.GetLayersAsFlattenedList().FirstOrDefault(l => l.Name == "TrackData_Point");

        if (ptLayer == null)
          return;

        var op = new EditOperation();
        op.Name = "Log point";

        // set up the metadata
        var atts = new Dictionary<string, object>();
        atts.Add("ESRIGNSS_POSITIONSOURCETYPE", 3); // ??
        atts.Add("ESRIGNSS_LATITUDE", snapshot.Latitude);
        atts.Add("ESRIGNSS_LONGITUDE", snapshot.Longitude);
        atts.Add("ESRIGNSS_ALTITUDE", snapshot.Altitude);
        atts.Add("ESRIGNSS_H_RMS", snapshot.HorizontalAccuracy);
        atts.Add("ESRIGNSS_V_RMS", snapshot.VerticalAccuracy);
        atts.Add("ESRIGNSS_FIXDATETIME", snapshot.DateTime);
        atts.Add("ESRIGNSS_FIXTYPE", 4); // ? rtk fixed
        atts.Add("ESRIGNSS_SPEED", snapshot.SpeedOverGround);
        atts.Add("ESRIGNSS_PDOP", snapshot.PDOP);
        atts.Add("ESRIGNSS_HDOP", snapshot.HDOP);
        atts.Add("ESRIGNSS_VDOP", snapshot.VDOP);
        atts.Add("ESRIGNSS_DIRECTION", snapshot.CourseOverGround);
        atts.Add("ESRIGNSS_STATIONID", snapshot.SatelliteVehicles.FirstOrDefault()?.Id);
        atts.Add("ESRIGNSS_NUMSATS", snapshot.NumSatelliteVehiclesInView);
        atts.Add("Shape", pt);

        op.Create(ptLayer, atts);
        op.Execute();
      }
      else
      {
        if (lineLayer == null)
          lineLayer = MapView.Active.Map.GetLayersAsFlattenedList().FirstOrDefault(l => l.Name == "TrackData_Polyline");

        if (lineLayer == null)
          return;

        _locations.Add(pt);
        if (_locations.Count == MaxPointsInPolyline)
        {
          // build a polyline from the points
          var polyline = PolylineBuilder.CreatePolyline(_locations);

          // create it
          var op = new EditOperation();
          op.Name = "Log polyline";

          op.Create(lineLayer, polyline);
          op.Execute();

          // reset the list
          _locations.Clear();
        }
      }
    }

    #region Location eventLog

    private static readonly object _locLock = new object();
    private List<string> _locEntries = new List<string>();

    public string LocEventLog
    {
      get
      {
        string contents = "";
        lock (_locLock)
        {
          contents = string.Join("\r\n", _locEntries.ToArray());
        }
        return contents;
      }
    }

    private void ClearLocEntries()
    {
      lock (_locLock)
      {
        _locEntries.Clear();
      }
      NotifyPropertyChanged(nameof(LocEventLog));
    }

    private void AddLocEntry(string entry)
    {
      lock (_locLock)
      {
        _locEntries.Add($"{entry}");
      }
      NotifyPropertyChanged(nameof(LocEventLog));
    }

    private void RecordLocEvent(string eventName, string entry)
    {
      var dateTime = DateTime.Now.ToString("G");
      AddLocEntry($"{dateTime}: {eventName} {entry}");
    }

    #endregion
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class DeviceTracking_ShowButton : Button
  {
    protected override void OnClick()
    {
      DeviceTrackingViewModel.Show();
    }
  }
}
