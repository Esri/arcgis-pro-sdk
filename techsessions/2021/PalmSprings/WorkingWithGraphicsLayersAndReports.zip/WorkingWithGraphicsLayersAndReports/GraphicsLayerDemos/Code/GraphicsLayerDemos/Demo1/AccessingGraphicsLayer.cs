﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace GraphicsLayerDemos
{
  internal class AccessingGraphicsLayer : Button
  {
    protected override void OnClick()
    {
      var map = MapView.Active.Map;      
      var allGraphicsLayers = map.GetLayersAsFlattenedList().OfType<GraphicsLayer>();
      var currentTargetGraphicsLayer = map.TargetGraphicsLayer;

      int index = allGraphicsLayers.ToList().IndexOf(currentTargetGraphicsLayer);
      index = (index == allGraphicsLayers.Count() - 1) ?  0 : ++index;
      map.TargetGraphicsLayer = allGraphicsLayers.ToList()[index];

    }
  }
}
