﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace GraphicsLayerDemos.Demo2
{
  internal class UpdateGraphics : Button
  {
    protected override void OnClick()
    {
      GraphicsLayer graphicsLayer = MapView.Active.Map.TargetGraphicsLayer;
      QueuedTask.Run(() => {
        //Get the Point graphic elements to update
        IEnumerable<GraphicElement> graphicElements = graphicsLayer.GetElementsAsFlattenedList().Where(e => e.Name.StartsWith("State Text"));
        foreach (var graphicElement in graphicElements)
        {
          //Access the CIMGraphic
          var cimTextGraphic = graphicElement.GetGraphic() as CIMTextGraphic;
          if (cimTextGraphic == null) continue;
          //Modify the text graphic's symbol (background color)
          #region Change the balloon callout color
          var textSymbol = cimTextGraphic.Symbol.Symbol as CIMTextSymbol;
          var callout = textSymbol.Callout as CIMBalloonCallout;
          var textSymbolBackgroundColor = callout.BackgroundSymbol.SymbolLayers.OfType<CIMSolidFill>().FirstOrDefault();
          textSymbolBackgroundColor.Color = ColorFactory.Instance.CreateRGBColor(255, 255, 190);
          #endregion
          //Modify the graphic's location
          cimTextGraphic.Shape = GeometryEngine.Instance.Move(cimTextGraphic.Shape, 1000000, 0) as MapPoint;
          //Apply the changes back to the graphic element
          graphicElement.SetGraphic(cimTextGraphic);
        }
      });
    }
  }
}
