﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace GraphicsLayerDemos.Demo2
{
  internal class GroupElementsTool : MapTool
  {
    public GroupElementsTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Rectangle;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      var graphicsLayer = MapView.Active.Map.TargetGraphicsLayer;
      QueuedTask.Run(() => {
        var selPoly = geometry as Polygon;
        //group some elements
        var elems = MapView.Active.SelectElements(selPoly, SelectionCombinationMethod.New);

        var group_elem = graphicsLayer.GroupElements(elems);
      });
      return base.OnSketchCompleteAsync(geometry);
    }
  }
}
