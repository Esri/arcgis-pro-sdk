﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace GraphicsLayerDemos
{
  internal class CreateGraphicsLayer : Button
  {
    protected override void OnClick()
    {
      var map = MapView.Active.Map;
      var gl_param = new GraphicsLayerCreationParams { Name = "First Graphics Layer" };

      QueuedTask.Run(() => {
        //By default will be added to the top of the TOC
        var grahicsLayer =
            LayerFactory.Instance.CreateLayer<GraphicsLayer>(gl_param, map);
        //Add to the bottom of the TOC
        //LayerFactory.Instance.CreateLayer<GraphicsLayer>(gl_param, map, LayerPosition.AddToBottom);
      });

    }
  }
}
