﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace ReportDemos
{
  internal class ReportViewerPaneViewModel : ViewStatePane
  {
    private const string _viewPaneID = "ReportDemos_ReportViewerPane";

    /// <summary>
    /// Consume the passed in CIMView. Call the base constructor to wire up the CIMView.
    /// </summary>
    public ReportViewerPaneViewModel(CIMView view)
      : base(view) { }

    /// <summary>
    /// Create a new instance of the pane.
    /// </summary>
    internal static ReportViewerPaneViewModel Create()
    {
      var view = new CIMGenericView();
      view.ViewType = _viewPaneID;
      return FrameworkApplication.Panes.Create(_viewPaneID, new object[] { view }) as ReportViewerPaneViewModel;
    }
    /// <summary>
    /// Create a new instance of the CompDetail pane.
    /// </summary>
    internal static void Create(string title, string htmlPath)
    {
      // first check if the title is already displayed
      var lstPanes = FrameworkApplication.Panes.Find(_viewPaneID);
      foreach (var pane in lstPanes)
      {
        if (pane.Caption.Equals(title))
        {
          pane?.Activate();
          return;
        }
      }
      var view = new CIMGenericView
      {
        ViewType = _viewPaneID
      };
      var vm = FrameworkApplication.Panes.Create(_viewPaneID,
                                                  new object[] { view }) as ReportViewerPaneViewModel;
      vm.HtmlSource = !string.IsNullOrEmpty(htmlPath) ? new Uri(htmlPath) : null;
      vm.Caption = title;
      return;
    }

    private Uri _HtmlSource = null;
    public Uri HtmlSource
    {
      get
      {
        return _HtmlSource;
      }
      set
      {
        SetProperty(ref _HtmlSource, value, () => HtmlSource);
      }
    }

    #region Pane Overrides

    /// <summary>
    /// Must be overridden in child classes used to persist the state of the view to the CIM.
    /// </summary>
    public override CIMView ViewState
    {
      get
      {
        _cimView.InstanceID = (int)InstanceID;
        return _cimView;
      }
    }

    /// <summary>
    /// Called when the pane is initialized.
    /// </summary>
    protected async override Task InitializeAsync()
    {
      await base.InitializeAsync();
    }

    /// <summary>
    /// Called when the pane is uninitialized.
    /// </summary>
    protected async override Task UninitializeAsync()
    {
      await base.UninitializeAsync();
    }

    #endregion Pane Overrides
  }

  /// <summary>
  /// Button implementation to create a new instance of the pane and activate it.
  /// </summary>
  internal class ReportViewerPane_OpenButton : Button
  {
    protected override void OnClick()
    {
      ReportViewerPaneViewModel.Create();
    }
  }
}
