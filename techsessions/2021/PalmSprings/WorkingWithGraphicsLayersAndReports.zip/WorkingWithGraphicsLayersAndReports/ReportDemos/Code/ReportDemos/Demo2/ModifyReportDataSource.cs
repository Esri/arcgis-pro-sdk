﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos.Demo2
{
  internal class ModifyReportDataSource : Button
  {
    protected async override void OnClick()
    {
      string stateName = "Vermont";
      await QueuedTask.Run(() => {
        var report = ReportView.Active?.Report;
        Map map = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(m => m.Name == "Counties").GetMap();
        if (map == null) return;
        FeatureLayer featueLayer = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(f => f.Name == "U.S. Counties (Generalized)");
        if (report == null) return;
        var listOfFields = new List<CIMReportField> {
           new CIMReportField{Name = "County", SortInfo = FieldSortInfo.Asc},
           new CIMReportField{Name = "State"},
           new CIMReportField{Name = "Population2000"},
           new CIMReportField{Name = "Population2019"},
           new CIMReportField{Name = "PopulationChange"},
        };

        var reportDataSource = new ReportDataSource(featueLayer, $"State = '{stateName}'", false, listOfFields);
        report.SetDataSource(reportDataSource);
        #region Change state name text element
        ReportHeader reportHeader = report.Elements.OfType<ReportSection>().FirstOrDefault().Elements.OfType<ReportHeader>().FirstOrDefault();
        if (reportHeader != null)
        {
          var geState = reportHeader.Elements.FirstOrDefault(e => e.Name == "Report Header Title Text") as GraphicElement;
          var graphic = geState.GetGraphic() as CIMParagraphTextGraphic;
          graphic.Text = $"{stateName} County Population change";
          geState.SetGraphic(graphic);
        }
        ReportFooter reportFooter = report.Elements.OfType<ReportSection>().FirstOrDefault().Elements.OfType<ReportFooter>().FirstOrDefault();
        if (reportFooter != null)
        {
          var geState = reportFooter.Elements.FirstOrDefault(e => e.Name == "Report Footer Report Totals Label") as GraphicElement;
          var graphic = geState.GetGraphic() as CIMParagraphTextGraphic;
          graphic.Text = $"{stateName} Population Totals";
          geState.SetGraphic(graphic);
        }
        #endregion
        var layoutItem = Project.Current.GetItems<LayoutProjectItem>().FirstOrDefault(l => l.Name == stateName);
        var reportLayoutSection = report.Elements.OfType<ReportLayoutPageSection>().FirstOrDefault();
        if (reportLayoutSection != null)
        {
          report.MoveReportSectionElement(reportLayoutSection, 1);
          report.ReplaceLayoutPage(layoutItem, reportLayoutSection.Name);
        }
        else
          report.AddLayoutPage(layoutItem, "layoutSection");
        report.SetName(stateName);
      });      
    }
  }
}
