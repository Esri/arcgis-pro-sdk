﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos.Demo1
{
  internal class AccessReports : Button
  {
    protected async override void OnClick()
    {
      IEnumerable<ReportProjectItem> reportsInProject = Project.Current.GetItems<ReportProjectItem>();
      Report report = await QueuedTask.Run(() => {
        Report firstReport = reportsInProject.FirstOrDefault().GetReport();
        return firstReport;
       });
      await FrameworkApplication.Panes.CreateReportPaneAsync(report);
    }
  }
}
