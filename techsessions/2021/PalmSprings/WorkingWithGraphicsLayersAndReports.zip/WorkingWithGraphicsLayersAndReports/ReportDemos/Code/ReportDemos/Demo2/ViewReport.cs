﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos.Demo2
{
  internal class ViewReport : Button
  {
    private string _location = @"C:\DevSummit\2021\Working with Graphics Layers and Reports\ReportDemos";
    protected async override void OnClick()
    {
      var report = ReportView.Active?.Report;
      if (report == null) return;
      var reportName = report.Name;
      //var folderLocation = $@"{_location}\{reportName}.pdf";
      var fileName = $"{reportName}.pdf";
      //check if PDF Exisits
      if (!System.IO.File.Exists(Path.Combine(_location, fileName)))
        await ExportReportToPDF(_location, fileName); //export it
      // show the PDF report in a Pane 
      var id = $"{reportName} County population report";
      ReportViewerPaneViewModel.Create(id, Path.Combine(_location, fileName));
    }

    private static async Task ExportReportToPDF(string folder, string fileName)
    {
      await QueuedTask.Run(() => {
        var report = ReportView.Active?.Report;
        if (report == null) return;
        //Create PDF format with appropriate settings
        var pdfFormat = new PDFFormat()
        {
          Resolution = 300,
          OutputFileName = Path.Combine(folder, fileName)
        };

        //Define Export Options
        var exportOptions = new ReportExportOptions
        {
          ExportPageOption = ExportPageOptions.ExportAllPages
        };
        var useSelection = false;
        report.ExportToPDF(report.Name, pdfFormat, exportOptions, useSelection);
      });
    }
  }
}
