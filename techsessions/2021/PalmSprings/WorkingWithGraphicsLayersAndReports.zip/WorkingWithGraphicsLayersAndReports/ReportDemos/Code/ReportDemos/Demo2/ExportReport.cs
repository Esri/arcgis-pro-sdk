﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos.Demo2
{
  internal class ExportReport : Button
  {
    protected override void OnClick()
    {
      QueuedTask.Run(() => {
        var report = ReportView.Active?.Report;
        if (report == null) return;
        //Create PDF format with appropriate settings
        var pdfFormat = new PDFFormat()
        {
          Resolution = 300,
          OutputFileName = Path.Combine(Project.Current.HomeFolderPath, $"{report.Name}.pdf")
        };

        //Define Export Options
        var exportOptions = new ReportExportOptions
        {
          ExportPageOption = ExportPageOptions.ExportAllPages
          //TotalPageNumberOverride = 12,
          //StartingPageNumberLabelOffset = 0

        };
        var useSelection = false;  //Use selection set
        //Export to pdf
        report.ExportToPDF(report.Name, pdfFormat, exportOptions, useSelection);
        //Open PDF
        System.Diagnostics.Process.Start(pdfFormat.OutputFileName);
      });
      
    }
  }
}
