﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos.Demo1
{
  internal class CreateReport : Button
  {
    protected async override void OnClick()
    {
      var report = await QueuedTask.Run(() => {
        Map map = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(m => m.Name == "Map").GetMap();
        FrameworkApplication.Panes.CreateMapPaneAsync(map);
        var featureLayerToUse = map.GetLayersAsFlattenedList().OfType<FeatureLayer>()
                                                            .FirstOrDefault(f => f.Name == "U.S. Cities");
        if (featureLayerToUse == null) return null;
        var listOfFields = new List<CIMReportField>{
        new CIMReportField{Name = "State", Group = true, SortOrder = 0, SortInfo = FieldSortInfo.Asc}, //group on common state names
        new CIMReportField{Name = "City", SortOrder = 1, SortInfo = FieldSortInfo.Asc}, //Sort on city name
        new CIMReportField{Name = "CityElevation"}
      };
        //Create the ReportDatasource using the MapMember, list of fields...
        var reportDataSource = new ReportDataSource(featureLayerToUse, $"State = 'Delaware'", false, listOfFields);
        Report newReport = ReportFactory.Instance.CreateReport("My First Report", reportDataSource);
        return newReport;
      });
      await FrameworkApplication.Panes.CreateReportPaneAsync(report);

    }
  }
}
