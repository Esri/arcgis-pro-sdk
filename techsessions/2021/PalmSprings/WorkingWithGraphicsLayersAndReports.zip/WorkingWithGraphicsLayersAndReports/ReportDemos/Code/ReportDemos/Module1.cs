﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos
{
  internal class Module1 : Module
  {
    public static CIMPolygonSymbol _polySymbol;
    private static Module1 _this = null;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current
    {
      get
      {
        return _this ?? (_this = (Module1)FrameworkApplication.FindModule("ReportDemos_Module"));
      }
    }

    protected override bool Initialize()
    {
      QueuedTask.Run(() =>
      {
        CIMSolidStroke outline = new CIMSolidStroke()
        {
          Color = ColorFactory.Instance.RedRGB,
          Width = 2
        };
        CIMSolidFill fill = new CIMSolidFill
        {
          Color = ColorFactory.Instance.CreateRGBColor(255, 0, 0, 0.1)
        };
        List<CIMSymbolLayer> symbolLayers = new List<CIMSymbolLayer>();
        symbolLayers.Add(outline);
        symbolLayers.Add(fill);
        _polySymbol =  new CIMPolygonSymbol() { SymbolLayers = symbolLayers.ToArray() };
      });
      return true;
    }
    public static Task<CIMPolygonSymbol> CreatePolygonAsync()
    {
      return QueuedTask.Run<CIMPolygonSymbol>(() =>
      {
        CIMSolidStroke outline = new CIMSolidStroke()
        {
          Color = ColorFactory.Instance.RedRGB,
          Width = 2
        };
        CIMSolidFill fill = new CIMSolidFill
        {
          Color = ColorFactory.Instance.CreateRGBColor(255, 0, 0, 0.1)
        };
        List<CIMSymbolLayer> symbolLayers = new List<CIMSymbolLayer>();
        symbolLayers.Add(outline);
        symbolLayers.Add(fill);
        return new CIMPolygonSymbol() { SymbolLayers = symbolLayers.ToArray() };
      });

    }
    public async static Task DeleteHighlights()
    {
      ReportView activeReportView = ReportView.Active;
      Report report = null;
      if (activeReportView != null)
      {
        report = activeReportView.Report;
      }
      await QueuedTask.Run(() =>
      {
        //////////////////Delete existing highlight rectangles
        var layout = Project.Current.GetItems<LayoutProjectItem>().FirstOrDefault().GetLayout();
        if (layout == null) return;
        var reportSection = report.Elements.OfType<ReportSection>().FirstOrDefault();
        var reportSectionRectangleectangle = reportSection?.Elements.OfType<GraphicElement>().FirstOrDefault(e => e.Name.StartsWith("Rectangle"));
        if (reportSectionRectangleectangle != null)
          layout.DeleteElement(reportSectionRectangleectangle);
        var reportDetails = reportSection?.Elements.OfType<ReportDetails>().FirstOrDefault();
        var reportDetailsSectionRectangle = reportDetails?.Elements.OfType<GraphicElement>().FirstOrDefault(e => e.Name.StartsWith("Rectangle"));
        if (reportDetailsSectionRectangle != null)
          layout.DeleteElement(reportDetailsSectionRectangle);
      });
    }
    public async static Task HighlightSection(ReportSectionElement reportSectionElement, bool isReportFields = false)
    {
      await QueuedTask.Run(() =>
      {        
        //////////////////Make new highlight
        if (isReportFields)
        {
          var detailsSection = reportSectionElement as ReportDetails;
          var detailsElements = detailsSection.Elements.OfType<GraphicElement>();
          foreach (var detailElement in detailsElements)
          {            
            var paragraphicTextGraphic = detailElement.GetGraphic() as CIMParagraphTextGraphic;
            if (paragraphicTextGraphic == null) continue;
            var polyShape = paragraphicTextGraphic.Shape as Polygon;            
            LayoutElementFactory.Instance.CreateRectangleGraphicElement(reportSectionElement, polyShape.Extent, _polySymbol);
          }
        }
        else
        {
          var sectionEnvelope = reportSectionElement.GetBounds();
          LayoutElementFactory.Instance.CreateRectangleGraphicElement(reportSectionElement, sectionEnvelope, _polySymbol);
        }        
      });
    }

    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

  }
}
