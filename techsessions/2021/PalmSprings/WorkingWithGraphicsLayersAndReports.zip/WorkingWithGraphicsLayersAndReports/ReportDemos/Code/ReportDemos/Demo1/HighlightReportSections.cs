﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos.Demo1
{
  internal class HighlightReportSections_ReportSection : Button
  {
    protected async override void OnClick()
    {
      #region Delete Highlights
      await Module1.DeleteHighlights();
      #endregion
      //Get the active reports
      ReportView activeReportView = ReportView.Active;      
      Report report = null;
      if (activeReportView != null)
      {
        report = activeReportView.Report;
      }
      //Get the "ReportSection"
      ReportSection mainReportSection = report.Elements.OfType<ReportSection>().FirstOrDefault();

      await Module1.HighlightSection(mainReportSection);
    }
  }

  internal class HighlightReportSections_ReportDetails : Button
  {
    protected async override void OnClick()
    {
      #region Delete Highlights
      await Module1.DeleteHighlights();
      #endregion
      ReportView activeReportView = ReportView.Active;
      Report report = null;
      if (activeReportView != null)
      {
        report = activeReportView.Report;
      }
      //Get the "ReportSection"
      ReportSection reportSection = report.Elements.OfType<ReportSection>().FirstOrDefault();
      ReportDetails reportDetails = reportSection.Elements.OfType<ReportDetails>().FirstOrDefault();
      //Highlight the details section to view
      await Module1.HighlightSection(reportDetails);
    }
  }

  internal class HighlightReportSections_ReportFields : Button
  {
    protected async override void OnClick()
    {
      #region Delete Highlights
      await Module1.DeleteHighlights();
      #endregion
      ReportView activeReportView = ReportView.Active;
      Report report = null;
      if (activeReportView != null)
      {
        report = activeReportView.Report;
      }
      //Get the "ReportSection".
      ReportSection reportSection = report.Elements.OfType<ReportSection>().FirstOrDefault();
      //Get the Details section where the fields are.
      ReportDetails reportDetails = reportSection.Elements.OfType<ReportDetails>().FirstOrDefault();
      //Get the field elements in the details section
      var reportFields = reportDetails.Elements.OfType<GraphicElement>();
      //Highlight the fields to view
      await Module1.HighlightSection(reportDetails, true);

    }
  }

}
