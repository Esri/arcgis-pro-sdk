﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Reports;

namespace ReportDemos.Demo2
{
  internal class AddField : Button
  {
    protected override void OnClick()
    {
      QueuedTask.Run(() =>
      {
        Report report = ReportView.Active?.Report;
        if (report == null) return;
        //This is the gap between two fields.
        double fieldIncrement = 0.9388875113593206276389;
        //On the QueuedTask
        //New field to add.
        var newReportField = new CIMReportField
        {
          Name = "Population",
          FieldOrder = 2,
        };
        //Get the "ReportSectionElement"                
        var mainReportSection = report.Elements.OfType<ReportSection>().FirstOrDefault();
        if (mainReportSection == null) return;

        //Get the "ReportDetails" within the ReportSectionElement. ReportDetails is where "fields" are.
        var reportDetailsSection = mainReportSection?.Elements.OfType<ReportDetails>().FirstOrDefault();
        if (reportDetailsSection == null) return;

        #region Calculate the Envelope for new field
        //Within ReportDetails find the envelope that encloses a field.
        //We get the first CIMParagraphTextGraphic in the collection so that we can add the new field next to it.                    
        var lastFieldGraphic = reportDetailsSection.Elements.FirstOrDefault((r) =>
        {
          var gr = r as GraphicElement;
          if (gr == null) return false;
          return (gr.GetGraphic() is CIMParagraphTextGraphic ? true : false);
        });
        //Get the Envelope of the last field
        var graphicBounds = lastFieldGraphic.GetBounds();

        //Min and Max values of the envelope
        var xMinOfFieldEnvelope = graphicBounds.XMin;
        var yMinOfFieldEnvelope = graphicBounds.YMin;

        var xMaxOfFieldEnvelope = graphicBounds.XMax;
        var YMaxOfFieldEnvelope = graphicBounds.YMax;
        #endregion
        //create the new Envelope to be offset from the existing field
        MapPoint newMinPoint = MapPointBuilder.CreateMapPoint(xMinOfFieldEnvelope + fieldIncrement, yMinOfFieldEnvelope);
        MapPoint newMaxPoint = MapPointBuilder.CreateMapPoint(xMaxOfFieldEnvelope + fieldIncrement, YMaxOfFieldEnvelope);
        Envelope newFieldEnvelope = EnvelopeBuilder.CreateEnvelope(newMinPoint, newMaxPoint);

        //Create field
        GraphicElement fieldGraphic = ReportElementFactory.Instance.CreateFieldValueTextElement
                                              (reportDetailsSection, newFieldEnvelope, newReportField);

        #region Field title
        Envelope envelopeOfLastField = null;
        //Field title in Page Header.				
        //Get Group Header.
        // the title needs to be in the GroupHeader section.
        var reportGroupHeader = mainReportSection?.Elements.OfType<ReportGroupHeader>().FirstOrDefault();
        #region Calculate Envelope of the Field Title
        //Get the paragraph text element (the last title)
        var lastFieldGroupHeaderGraphic = reportGroupHeader.Elements.FirstOrDefault((h) =>
        {
          var graphic = h as GraphicElement;
          if (graphic == null) return false;
          return (graphic.GetGraphic() is CIMParagraphTextGraphic ? true : false);
        });
        //Get the Envelope of the last field header
        envelopeOfLastField = lastFieldGroupHeaderGraphic?.GetBounds();
        //The ILayoutElementContainer is the "GroupHeader". Needed for the CreateRectangleParagraphGraphicElement method 

        //Min and Max values of the envelope
        var xMinOfHeaderFieldEnvelope = envelopeOfLastField.XMin;
        var yMinOfHeaderFieldEnvelope = envelopeOfLastField.YMin;

        var xMaxOfHeaderFieldEnvelope = envelopeOfLastField.XMax;
        var YMaxOfHeaderFieldEnvelope = envelopeOfLastField.YMax;
        //create the new Envelope to be offset from the existing field
        MapPoint newHeaderMinPoint = MapPointBuilder.CreateMapPoint(xMinOfHeaderFieldEnvelope + fieldIncrement, yMinOfHeaderFieldEnvelope);
        MapPoint newHeaderMaxPoint = MapPointBuilder.CreateMapPoint(xMaxOfHeaderFieldEnvelope + fieldIncrement, YMaxOfHeaderFieldEnvelope);
        #endregion
        Envelope newHeaderFieldEnvelope = EnvelopeBuilder.CreateEnvelope(newHeaderMinPoint, newHeaderMaxPoint);
        #endregion
        //Create field header title
        GraphicElement fieldHeaderGraphic = ReportElementFactory.Instance.CreateRectangleParagraphGraphicElement
                                                                (reportGroupHeader, newHeaderFieldEnvelope, newReportField.Name);
      });

    }
  }
}
