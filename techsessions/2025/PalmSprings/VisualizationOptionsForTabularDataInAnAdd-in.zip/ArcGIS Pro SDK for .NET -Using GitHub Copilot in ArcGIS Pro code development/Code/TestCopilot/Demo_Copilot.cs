﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.KnowledgeGraph;

namespace TestCopilot
{
	internal class Demo_Copilot : Button
	{
		/// <summary>
		/// Handles the button click event to perform various operations on the first feature layer in the active map.
		/// </summary>
		protected override async void OnClick()
		{
			/// <summary>
			/// Retrieves the first BasicFeatureLayer from the active map.
			/// </summary>
			var lyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<BasicFeatureLayer>().FirstOrDefault();

			/// <summary>
			/// Checks if a feature layer is found. If not, displays an error message and exits the method.
			/// </summary>
			if (lyr == null)
			{
				MessageBox.Show("No feature layer found in the map", "Error");
				return;
			}

			/// <summary>
			/// Displays the name of the found feature layer.
			/// </summary>
			MessageBox.Show($@"Layer name: {lyr.Name}");

			/// <summary>
			/// Selects features in the layer using a QueryFilter on a background thread.
			/// </summary>
			await QueuedTask.Run(() =>
			{
				lyr.Select(new QueryFilter(), SelectionCombinationMethod.New);
			});
			

			// zoom in to the selected features with a fixed duration of 0.1 minutes
			await MapView.Active.ZoomToSelectedAsync(TimeSpan.FromMinutes(0.1));

			/// <summary>
			/// Zooms in with a fixed duration of 10 seconds asynchronously.
			/// </summary>
			await MapView.Active.ZoomInFixedAsync(TimeSpan.FromSeconds(10));

			/// <summary>
			/// Zooms to the selected features asynchronously.
			/// </summary>
			await MapView.Active.ZoomToSelectedAsync();

			var layer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault();
			if (layer != null)
			{
				//await new LayerSymbolizer().SymbolizeLayer(layer);
			}

		}
	}
}
