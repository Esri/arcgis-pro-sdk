﻿	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;
	using ArcGIS.Core.CIM;
	using ArcGIS.Core.Data;
	using ArcGIS.Core.Geometry;
	using ArcGIS.Desktop.Catalog;
	using ArcGIS.Desktop.Core;
	using ArcGIS.Desktop.Editing;
	using ArcGIS.Desktop.Extensions;
	using ArcGIS.Desktop.Framework;
	using ArcGIS.Desktop.Framework.Contracts;
	using ArcGIS.Desktop.Framework.Dialogs;
	using ArcGIS.Desktop.Framework.Threading.Tasks;
	using ArcGIS.Desktop.Layouts;
	using ArcGIS.Desktop.Mapping;
	using ArcGIS.Desktop.KnowledgeGraph;

	namespace TestCopilot
	{
		internal class ButtonTest : Button
		{
		// create a method to query a feature layer based on a where clause
		private async Task<FeatureLayer> QueryFeatureLayer(string layerName, string whereClause)
		{
			// get the feature layer from the map
			var lyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == layerName);
			if (lyr == null)
			{
				MessageBox.Show("Feature layer not found in the map", "Error");
				return null;
			}
			// create a queryfilter
			var qf = new QueryFilter()
			{
				WhereClause = whereClause
			};
			// select the features based on the queryfilter
			await QueuedTask.Run(() =>
			{
				lyr.Select(qf, SelectionCombinationMethod.New);
			});
			return lyr;
		}

		protected override void OnClick()
			{
				try
				{
					// find the first BasicFeatureLayer in the map
					var lyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<BasicFeatureLayer>().FirstOrDefault();
					if (lyr == null)
					{
						MessageBox.Show("No feature layer found in the map", "Error");
						return;
					}
					QueuedTask.Run(() =>
					{
						// define a queryfilter to select all features
						var qf = new QueryFilter()
						{
							WhereClause = "1=1"
						};
						// select all features
						var oidSet = lyr.Select(qf, SelectionCombinationMethod.New);
						// zoom the mapview to the selected features
						MapView.Active.ZoomToSelected();
					});
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Error");
				}
			}
		}
	}
