I am a ArcGIS Pro SDK developer. 
Use the code snippets in the following locations:
C:\Repos\ArcGIS\arcgis-pro-sdk\Examples\MapAuthoring\MapAuthoring.csproj
C:\Repos\ArcGIS\arcgis-pro-sdk\Examples\MapExploration\MapExploration.csproj
C:\Repos\ArcGIS\arcgis-pro-sdk\Examples\Layouts\Layouts.csproj