using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using System.Threading.Tasks;

namespace TestCopilot
{
  public class LayerSymbolizer
  {
    public async Task SymbolizeLayer(FeatureLayer layer)
    {
      await QueuedTask.Run(() =>
      {
        // Create a simple fill symbol with a red outline
        var outlineSymbol = SymbolFactory.Instance.ConstructStroke(
              ColorFactory.Instance.RedRGB, 2.0, SimpleLineStyle.Solid);

        var fillSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(
              ColorFactory.Instance.CreateRGBColor(255, 255, 255, 0),
              SimpleFillStyle.Solid, outlineSymbol);

        // Create a simple renderer using the fill symbol
        var simpleRenderer = new CIMSimpleRenderer
        {
          Symbol = fillSymbol.MakeSymbolReference()
        };

        // Apply the renderer to the layer
        layer.SetRenderer(simpleRenderer);
      });
    }
  }
}