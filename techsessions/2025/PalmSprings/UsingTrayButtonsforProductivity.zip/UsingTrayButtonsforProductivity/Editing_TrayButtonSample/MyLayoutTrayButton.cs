﻿using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System.Windows.Controls;

namespace Editing_TrayButtonSample
{
  internal class MyLayoutTrayButton : LayoutTrayButton
  {
    bool gridON = false; //Assuming the grid is off to start, BUT it needs to be setup so it can turn on and off.
    protected override void Initialize()
    {
      base.Initialize();
      ButtonType = TrayButtonType.PopupToggleButton; 
    }

    protected override void Dispose(bool isDisposing)
    {
      base.Dispose(isDisposing);
    }

    // called only for TrayButtonType.ToggleButton or PopupToggleButton
    protected override void OnButtonChecked()
    {
      base.OnButtonChecked();

      gridON = !gridON;
      //// Add guides to an existing layout
      Layout lyt = LayoutView.Active.Layout;
      QueuedTask.Run(() =>
      {
        var lyt_cim = lyt.GetDefinition();
        lyt_cim.Page.ShowGuides = gridON;

        lyt.SetDefinition(lyt_cim);
      });

    }

    // only gets called first time button is loaded
    protected override void OnButtonLoaded()
    {
      base.OnButtonLoaded();
    }

    // occurs for TrayButtonType.PopupToggleButton only
    protected override void OnShowPopup()
    {
      base.OnShowPopup();
    }

    // occurs for TrayButtonType.PopupToggleButton only
    protected override void OnHidePopup()
    {
      base.OnHidePopup();
    }

    // only gets called for TrayButtonType.PopupToggleButton
    protected override ContentControl ConstructPopupContent()
    {
      // replace this with a view and return it. 
      //return null;
       return new TrayPopupView() { DataContext = this };
    }

  }
}
