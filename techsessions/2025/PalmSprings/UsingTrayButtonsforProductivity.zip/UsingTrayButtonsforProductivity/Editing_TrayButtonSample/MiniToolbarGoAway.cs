﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Core;
using System.Linq;
using System.Threading.Tasks;

namespace Editing_TrayButtonSample
{
  internal class MiniToolbarGoAway : MapTrayButton
  {
    bool isChecked;
    protected override void Initialize()
    {
      base.Initialize();
      ButtonType = TrayButtonType.ToggleButton;   
      isChecked = base.IsChecked;
      //ClickCommand = new RelayCommand(DoClick);   // need this for TrayButtonType.Button
    }

    protected override void OnButtonChecked()
    {
      base.OnButtonChecked();

      isChecked = !isChecked;

      base.SetCheckedNoCallback(isChecked == true? true : false);

      var options = ApplicationOptions.EditingOptions;
      
      options.ShowEditingToolbar = !isChecked;
      
    }

    protected override void Dispose(bool isDisposing)
    {
      base.Dispose(isDisposing);
    }

    // only gets called first time button is loaded
    protected override void OnButtonLoaded()
    {
      base.OnButtonLoaded();
    }

  }
}
