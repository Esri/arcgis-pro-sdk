﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Mapping;
using System.Linq;
using System.Threading.Tasks;

namespace Editing_TrayButtonSample
{
  internal class MyTrayButton : MapTrayButton
  {

    protected override void Initialize()
    {
      base.Initialize();
      ButtonType = TrayButtonType.Button;   // <= change this for the different button types

      ClickCommand = new RelayCommand(DoClick);   // need this for TrayButtonType.Button
    }

    private void DoClick()
    {
      ZoomToVisibleLayersAsync();
    }

    protected override void Dispose(bool isDisposing)
    {
      base.Dispose(isDisposing);
    }

    // called only for TrayButtonType.ToggleButton or PopupToggleButton
    protected override void OnButtonChecked()
    {
      base.OnButtonChecked();
    }

    // only gets called first time button is loaded
    protected override void OnButtonLoaded()
    {
      base.OnButtonLoaded();
    }

    public static Task<bool> ZoomToVisibleLayersAsync()
    {
      //Get the active map view.
      var mapView = MapView.Active;
      if (mapView == null)
        return Task.FromResult(false);

      //Zoom to all visible layers in the map.
      var visibleLayers = mapView.Map.Layers.Where(l => l.IsVisible);
      return mapView.ZoomToAsync(visibleLayers);
    }
  }

}
