﻿using AIAssistantSkillFunctionDemo.Helpers;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Assistant;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core.Assistant;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AIAssistantSkillFunctionDemo.Skills
{
	internal class LayoutExtensionClass
	{

		[AIAssistantFunction, Description(
			"Create a default layout using the current map.")]
		public static async Task<AIFunctionResult> 
			CreateLayoutWithCurrentMapAsync(
			[Description("The optional page width of the layout in inches")]
			double width = 0.0,
			[Description("The optional page height of the layout in inches")]
			double height = 0.0,
			[Description("The optional title of the layout")]
			string title = "Default Layout",
			[Description("An option to include a north arrow or not")]
			bool includeNorthArrow = true,
			[Description("An option to include a scale bar or not")]
			bool includeScaleBar = true)
		{

			var map = MapView.Active.Map;//capture the map

			//TODO: CreateLayout Skill Function implementation goes here
			var layout = await QueuedTask.Run(() =>
			{
				var layoutHlpr = new LayoutHelper();
				//Figure out the page size or use the default
				var page_size = layoutHlpr.DetermineLayoutPageSize(
					width, height, "");

				//Configure the layout based on the user choices
				var layout_info = new Layout_Info()
				{
					Map = map,
					PageSize = page_size.size,
					Title = title,
					IncludeNorthArrow = includeNorthArrow,
					IncludeScaleBar = includeScaleBar
				};
				return layoutHlpr.BuildLayout(layout_info);
			});

			//Show the newly created layout
			if (layout == null)
				return new AIFunctionError(
					"Unfortunately, layout creation failed with the inputs you provided.");

			//Show the layout = ensure we are on the GUI thread
			await FrameworkApplication.Current.Dispatcher.InvokeAsync(async () =>
			{
				await ProApp.Panes.CreateLayoutPaneAsync(layout);
			});

			return new AIFunctionResult("Layout created succesfully");
		}

		[AIAssistantFunction,
			Description(
			"Change the page size and orientation of the current active layout")]
		public static Task<AIFunctionResult> ChangeLayoutPageSizeAsync(
		[Description("The optional page orientation of the layout")] 
		string orientation = "",
		[Description("The optional page width of the layout in inches")] 
		double width = 0.0,
		[Description("The optional page height of the layout in inches")] 
		double height = 0.0)
		{
			//TODO: ChangeLayoutPageSize Skill Function implementation goes here
			var layout = LayoutView.Active.Layout;

			return QueuedTask.Run(() =>
			{
				var layoutHlpr = new LayoutHelper();

				//Identify the existing page size and orientation
				var existing_page = layout.GetPage();
				var existing_orientation = "portrait";
				if (existing_page.Width > existing_page.Height)
				{
					existing_orientation = "landscape";
				}

				//What is being requested?
				bool orientation_change_requested = 
						!string.IsNullOrEmpty(orientation);
				bool page_size_change_requested = width > 0.0 && height > 0.0;

				//Get new page details
				var page_size = layoutHlpr.DetermineLayoutPageSize(
					width, height, orientation);

				//Apply the change(s) depending on what the user asked for
				if (page_size_change_requested)
				{
					if (existing_page.Height != page_size.size.Height ||
							existing_page.Width != page_size.size.Width)
					{
						//apply the requested change
						existing_page.Height = page_size.size.Height;
						existing_page.Width = page_size.size.Width;
					}
					else
					{
						return new AIFunctionError(
							"The layout already has the requested size and/or orientation");
					}
				}
				else if (orientation_change_requested)
				{
					//We are just applying an orientation change
					if (existing_orientation.CompareTo(page_size.orientation) != 0)
					{
						//apply the requested orientation change but keep the page
						//size the same
						var height = existing_page.Height;
						existing_page.Height = existing_page.Width;
						existing_page.Width = height;
					}
					else
					{
						return new AIFunctionError(
							"The layout already has the requested size and/or orientation");
					}
				}
				else
				{
					return new AIFunctionError(
							"A page size and/or orientation change was not requested for the layout");
				}

				//Apply the change
				layout.SetPage(existing_page, true);
				return new AIFunctionResult("Layout page changed successfully");
			});
		}

		[AIAssistantFunction,
			Description("Change the page size and orientation of the current active layout")]
		public static Task<AIFunctionResult> ChangeLayoutPageSizeWithYamlAsync(
		[Description("The optional page orientation of the layout")] string orientation = "",
		[Description("The optional page width of the layout in inches")] double width = 0.0,
		[Description("The optional page height of the layout in inches")] double height = 0.0)
		{
			//To use this flavor swizzle the component category registration in the
			//Config.daml with ChangeLayoutPageSizeAsync....dont register the two
			//together because their descriptions are the same
			var layout = LayoutView.Active.Layout;

			return QueuedTask.Run(async () =>
			{
				var layoutHlpr = new LayoutHelper();

				//Identify the existing page size and orientation
				var existing_page = layout.GetPage();
				var existing_orientation = "portrait";
				if (existing_page.Width > existing_page.Height)
				{
					existing_orientation = "landscape";
				}

				//What is being requested?
				bool orientation_change_requested = !string.IsNullOrEmpty(orientation);
				bool page_size_change_requested = width > 0.0 && height > 0.0;

				//Apply the change(s) depending on what the user asked for
				if (page_size_change_requested)
				{

					//flip the requested page size to the specified orientation
					//(if one was specified)
					var page_size = layoutHlpr.CheckPageOrientation(width, height, orientation);

					//Get new page details - determine the requested layout page size change
					var standard_sizes = new List<string>()
					{
						"8.5 x 11","11 x 17", "17 x 22", "22 x 34", "34 x 44"
					};
					var list_of_sizes = string.Join(",", standard_sizes.ToArray());

					//Ensure we only apply a "standard" page size change - Invoke the prompt
					//to pick the closest one (from the list of choices) for us...
					var sel_page_size = await AIAssistant.Instance.InvokeFunctionFromYamlAsync(
						"AIAssistantSkillFunctionDemo.Prompts.SuggestPageSize.yaml",
						 Assembly.GetExecutingAssembly(),
						 new AIArguments { { "page-size", $"{page_size.wd} x {page_size.ht}" },
														 { "page-size-choices", list_of_sizes } },
						 System.Threading.CancellationToken.None);

					var dim = sel_page_size.Split("x", StringSplitOptions.RemoveEmptyEntries);
					double.TryParse(dim[0], out width);
					double.TryParse(dim[1], out height);

					//Apply the change as needed
					if (existing_page.Height != height ||
							existing_page.Width != width)
					{
						//apply the requested change
						existing_page.Height = height;
						existing_page.Width = width;
					}
					else
					{
						return new AIFunctionError(
							"The layout already has the requested size and/or orientation");
					}
				}
				else if (orientation_change_requested)
				{
					//We are just applying an orientation change
					if (existing_orientation.CompareTo(orientation) != 0)
					{
						//apply the requested orientation change but keep the page
						//size the same
						var temp = existing_page.Height;
						existing_page.Height = existing_page.Width;
						existing_page.Width = temp;
					}
					else
					{
						return new AIFunctionError(
							"The layout already has the requested size and/or orientation");
					}
				}
				else
				{
					return new AIFunctionError(
							"A page size and/or orientation change was not requested for the layout");
				}

				//Apply the change
				layout.SetPage(existing_page, true);
				return new AIFunctionResult("Layout page changed successfully");
			});
		}
	}
}
