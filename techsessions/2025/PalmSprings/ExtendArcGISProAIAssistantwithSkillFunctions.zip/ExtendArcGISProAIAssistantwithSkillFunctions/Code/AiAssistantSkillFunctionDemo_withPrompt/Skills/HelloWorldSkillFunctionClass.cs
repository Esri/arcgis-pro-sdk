﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Assistant;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core.Assistant;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIAssistantSkillFunctionDemo.Skills
{
	internal class HelloWorldSkillFunctionClass : IAISkills
	{
		#region IAISkills
		/// <summary>
		/// Gets the context json for the given AI skill function.
		/// </summary>
		/// <param name="functionName">The name of the AI skill function requesting context.</param>
		/// <returns>Json of the state of the skill function.</returns>
		string IAISkills.GetFunctionContext(string functionName) => null; // Not implemented by the engine yet.

		/// <summary>
		/// Gets the context json for the given list of AI skill functions.
		/// </summary>
		/// <param name="functionNames">The names of the AI skill functions requesting context.</param>
		/// <returns>Json of the state of the skill function.</returns>
		string IAISkills.GetFunctionContext(string[] functionNames) => null; // Not implemented by the engine yet.
		#endregion

		[SkillFunction, 
			Description("Show a hello world message with an optional text string")]
		public static AIFunctionResult HelloWorldSkillFunction(
			[Description("Optional text string to show with the Hello World message")] 
			string optionalTextString = "")
		{
			//Show a hello world message
			var msg = "Hello World";
			if (!string.IsNullOrEmpty(optionalTextString))
				msg += ": " + optionalTextString;
			MessageBox.Show(msg, "Hello World");

			return new AIFunctionResult("Hello world message shown successfully");
		}
	}
}
