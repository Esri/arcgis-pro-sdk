﻿using AIAssistantSkillFunctionDemo.Helpers;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Assistant;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core.Assistant;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIAssistantSkillFunctionDemo.Skills
{
    internal class LayoutSkillFunctionClass : IAISkills
    {
        #region IAISkills
        /// <summary>
        /// Gets the context json for the given AI skill function.
        /// </summary>
        /// <param name="functionName">The name of the AI skill function requesting context.</param>
        /// <returns>Json of the state of the skill function.</returns>
        string IAISkills.GetFunctionContext(string functionName) => null; // Not implemented by the engine yet.

        /// <summary>
        /// Gets the context json for the given list of AI skill functions.
        /// </summary>
        /// <param name="functionNames">The names of the AI skill functions requesting context.</param>
        /// <returns>Json of the state of the skill function.</returns>
        string IAISkills.GetFunctionContext(string[] functionNames) => null; // Not implemented by the engine yet.
        #endregion

        [SkillFunction, Description("Create a default layout using the current map.")]
        public static async Task<AIFunctionResult> CreateLayoutWithCurrentMapAsync(
            [Description("The optional page orientation of the layout")]
            string orientation = "",
            [Description("The optional page width of the layout in inches")]
            double width = 0.0,
            [Description("The optional page height of the layout in inches")]
            double height = 0.0,
            [Description("The optional title of the layout")]
            string title = "",
            [Description("An option to include a north arrow or not")]
            bool includeNorthArrow = true,
            [Description("An option to include a scale bar or not")]
            bool includeScaleBar = true)
        {
            //Conversions and Defaults

            //Default Title 
            if (string.IsNullOrEmpty(title))
                title = "Default Layout";

            var map = MapView.Active.Map;//capture the map

            //TODO: CreateLayout Skill Function implementation goes here
            var layout = await QueuedTask.Run(() =>
            {
                var layoutHlpr = new LayoutHelper();
                //Figure out the page size or use the default
                var page_size = layoutHlpr.DetermineLayoutPageSize(
                    width, height, orientation);

                //Configure the layout based on the user choices
                var layout_info = new Layout_Info()
                {
                    Map = map,
                    PageSize = page_size.size,
                    Title = title,
                    IncludeNorthArrow = includeNorthArrow,
                    IncludeScaleBar = includeScaleBar
                };
                return layoutHlpr.BuildLayout(layout_info);
            });

            //Show the newly created layout
            if (layout == null)
                return new AIFunctionError(
                    "Unfortunately, layout creation failed with the inputs you provided.");

            //Show the layout = ensure we are on the GUI thread
            await FrameworkApplication.Current.Dispatcher.InvokeAsync(async () =>
            {
                await ProApp.Panes.CreateLayoutPaneAsync(layout);
            });

            return new AIFunctionResult("Layout created succesfully");
        }

        [SkillFunction,
            Description("Change the page size and orientation of the current active layout")]
        public static Task<AIFunctionResult> ChangeLayoutPageSizeAsync(
        [Description("The optional page orientation of the layout")] string orientation = "",
        [Description("The optional page width of the layout in inches")] double width = 0.0,
        [Description("The optional page height of the layout in inches")] double height = 0.0)
        {
            //TODO: ChangeLayoutPageSize Skill Function implementation goes here
            var layout = LayoutView.Active.Layout;

            return QueuedTask.Run(() =>
            {
                var layoutHlpr = new LayoutHelper();

                //Identify the existing page size and orientation
                var existing_page = layout.GetPage();
                var existing_orientation = "portrait";
                if (existing_page.Width > existing_page.Height)
                {
                    existing_orientation = "landscape";
                }

                //What is being requested?
                bool orientation_change_requested = !string.IsNullOrEmpty(orientation);
                bool page_size_change_requested = width > 0.0 && height > 0.0;

                //Get new page details
                var page_size = layoutHlpr.DetermineLayoutPageSize(
                    width, height, orientation);

                //Apply the change(s) depending on what the user asked for
                if (page_size_change_requested)
                {
                    if (existing_page.Height != page_size.size.Height ||
                            existing_page.Width != page_size.size.Width)
                    {
                        //apply the requested change
                        existing_page.Height = page_size.size.Height;
                        existing_page.Width = page_size.size.Width;
                    }
                    else
                    {
                        return new AIFunctionError(
                            "The layout already has the requested size and/or orientation");
                    }
                }
                else if (orientation_change_requested)
                {
                    //We are just applying an orientation change
                    if (existing_orientation.CompareTo(page_size.orientation) != 0)
                    {
                        //apply the requested orientation change but keep the page
                        //size the same
                        var height = existing_page.Height;
                        existing_page.Height = existing_page.Width;
                        existing_page.Width = height;
                    }
                    else
                    {
                        return new AIFunctionError(
                            "The layout already has the requested size and/or orientation");
                    }
                }
                else
                {
                    return new AIFunctionError(
                            "A page size and/or orientation change was not requested for the layout");
                }

                //Apply the change
                layout.SetPage(existing_page, true);
                return new AIFunctionResult("Layout page changed successfully");
            });
        }
    }
}
