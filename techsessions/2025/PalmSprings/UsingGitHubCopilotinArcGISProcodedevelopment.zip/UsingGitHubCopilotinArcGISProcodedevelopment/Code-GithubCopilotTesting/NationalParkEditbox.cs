﻿using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Internal.Mapping.Symbology;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GithubCopilotTesting
{
  internal class NationalParkEditbox : EditBox
  {
    public NationalParkEditbox()
    {
      
    }
    protected override void OnTextChange(string text)
    {
      Module1.Current.ParkName = text;
    }
  }
}
