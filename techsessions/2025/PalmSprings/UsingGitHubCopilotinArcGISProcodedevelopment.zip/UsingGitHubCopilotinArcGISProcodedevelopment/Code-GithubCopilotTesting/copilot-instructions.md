I am a ArcGIS Pro SDK developer. 
Use the code snippets in the following locations:
C:\ArcGISPro-SDK\arcgis-pro-sdk\Examples\MapAuthoring\MapAuthoring.csproj
C:\ArcGISPro-SDK\arcgis-pro-sdk\Examples\MapExploration\MapExploration.csproj
C:\ArcGISPro-SDK\arcgis-pro-sdk\Examples\Layouts\Layouts.csproj