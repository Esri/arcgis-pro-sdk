﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GithubCopilotTesting
{
  internal class Chart : Button
  {
    protected override void OnClick()
    {
      QueuedTask.Run(() =>
      {
        var featureLayer = MapView.Active.Map.GetLayersAsFlattenedList().FirstOrDefault(l => l.Name == "NationalParks") as FeatureLayer;
        if (featureLayer == null)
        {
          return;
        }

        var layerDefinition = featureLayer.GetDefinition() as CIMFeatureLayer;
        string fieldXAxis = "Name";
        string fieldYAxis = "Visitors";

        var barChart = new CIMChart
        {
          Name = "Bar chart",
          GeneralProperties = new CIMChartGeneralProperties
          {
            Title = $"{fieldXAxis} vs. {fieldYAxis}",
            UseAutomaticTitle = false
          },
          Series = new CIMChartSeries[]
          {
              new CIMChartBarSeries
              {
                Name = "Bar chart",
                UniqueName = "Bar chart",
                Fields = new string[] { fieldXAxis, fieldYAxis },
                FillSymbolProperties = new CIMChartFillSymbolProperties
                {
                  Color = CIMColor.CreateRGBColor(38, 115, 0, 70)
                }
              }
          }
        };

        var newBarCharts = new CIMChart[] { barChart };
        var allChartsBar = (layerDefinition.Charts == null) ? newBarCharts : layerDefinition.Charts.Concat(newBarCharts);
        layerDefinition.Charts = allChartsBar.ToArray();
        featureLayer.SetDefinition(layerDefinition);
      });
    }
  }
}
