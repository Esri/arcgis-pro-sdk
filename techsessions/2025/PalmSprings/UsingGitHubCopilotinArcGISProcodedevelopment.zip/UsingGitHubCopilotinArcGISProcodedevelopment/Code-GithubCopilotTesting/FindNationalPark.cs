﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace GithubCopilotTesting
{
  internal class FindNationalPark : Button
  {
    protected override async void OnClick()
    {
      var activeMapView = MapView.Active;
      if (activeMapView == null) return;
      //Get the user input from the EditBox on the ribbon
      var nationalPark = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Module1.Current.ParkName.ToLower());
      if (!nationalPark.EndsWith("National Park", StringComparison.CurrentCultureIgnoreCase))
      {
        nationalPark += " National Park";
      }
      //Get the National Parks Feature layer from the active map
      var nationalParksLayer = activeMapView.Map?.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(lyr => lyr.Name == "USNationalParks");
      if (nationalParksLayer == null) return;
      
      // Query the nationalParksLayer for the nationalPark name and get the Feature
      await QueuedTask.Run(() =>
      {
        MapPoint parkGeometry = null;
        long? oid = null;
        var queryFilter = new QueryFilter { WhereClause = $"ParkName = '{nationalPark}'" };
        using (var rowCursor = nationalParksLayer.Search(queryFilter))
        {
          if (rowCursor.MoveNext())
          {
            var feature = rowCursor.Current as Feature;
            oid = feature.GetObjectID();
            // Zoom to the feature
            parkGeometry = feature.GetShape() as MapPoint;
          }
        }
        // Assuming _parkGeometry is defined and accessible
        if (parkGeometry != null && oid.HasValue)
        {
          //Create a buffer around the parkGeometry
          var poly = GeometryEngine.Instance.Buffer(parkGeometry, 3);
          //do we need to project the buffer polygon?
          if (!MapView.Active.Map.SpatialReference.IsEqual(poly.SpatialReference))
          {
            //project the polygon
            poly = GeometryEngine.Instance.Project(poly, MapView.Active.Map.SpatialReference);
          }
          var didItWork = activeMapView.ZoomTo(poly, new TimeSpan(0, 0, 0, 3));  
          
          MapView.Active.FlashFeature(nationalParksLayer, oid.Value);
        }
      });
    }
  }
}

