﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GithubCopilotTesting
{
  internal class CreateLayouts : Button
  {
    protected override async void OnClick()
    {
      await QueuedTask.Run(() =>
      {
        // Retrieve the LayoutProjectItem
        var layoutProjectItem = Project.Current.GetItems<LayoutProjectItem>().FirstOrDefault(item => item.Name == "Layout");
        if (layoutProjectItem == null)
          return;

        // Get the Layout from the LayoutProjectItem
        var layout = layoutProjectItem.GetLayout();
        if (layout == null)
          return;

        // Find the MapFrame element within the Layout
        var mapFrame = layout.FindElement("Map Frame") as MapFrame;
        if (mapFrame == null)
          return;

        // Get the active map view
        var activeMapView = MapView.Active;
        if (activeMapView == null)
          return;

        // Set the MapFrame's map to the active map view's map
        mapFrame.SetMap(activeMapView.Map);

        // Set the MapFrame's camera to the active map view's camera
        mapFrame.SetCamera(activeMapView.Camera);
      });
    }
  }
}
