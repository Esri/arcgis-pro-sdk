﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmbeddedUI_SketchTool
{
  internal class CutWithCircle : MapTool
  {
    public CutWithCircle()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
      ControlID = "EmbeddedUI_SketchTool_SketchToolOptions";
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      // access the connected viewmodel
      if (VM != null)
        // subscribe to propertyChanged - when a VM property changes, I want the tool to know
        VM.PropertyChanged += Vm_PropertyChanged;
      return base.OnToolActivateAsync(active);
    }

    internal SketchToolOptionsViewModel VM => this.EmbeddableControl as SketchToolOptionsViewModel;

    private void Vm_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
      // when properties on the embedded VM change, access this
      if (e.PropertyName == "RadiusValue")
      {
        Radius = VM.RadiusValue;
      }
    }
    private double Radius;
    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return QueuedTask.Run(() =>
      {
        //this returns intersecting features
        var selection = MapView.Active.SelectFeatures(geometry);
        if (selection.Count == 0)
          return false;

        var editOperation = new EditOperation();
        editOperation.Name = "Cut With Circle";
        var poly = GeometryEngine.Instance.Buffer(geometry, Radius);

        editOperation.Split(selection, poly);

        if (!editOperation.IsEmpty)
        {
          return editOperation.Execute();
        }
        return false;
      });
    }
  }
}
