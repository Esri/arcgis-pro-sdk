﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SketchTools
{
  internal class SketchTool_CutPoly_Snapping : MapTool
  {
    public SketchTool_CutPoly_Snapping()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Polygon;
      SketchOutputMode = SketchOutputMode.Map;
    }

    private bool _snappingEnabled = false;
    private List<SnapMode> _snapModes;
    protected override Task OnToolActivateAsync(bool active)
    {
      // make sure tool opts in to snapping
      UseSnapping = true;

      _snappingEnabled = Snapping.IsEnabled;
      Snapping.IsEnabled = true;

      // get existing snapModes
      _snapModes = Snapping.SnapModes;

      // make sure ONLY vertex and edges are on
      // this method modifies the state of other snap modes
      Snapping.SetSnapModes([SnapMode.Vertex, SnapMode.Edge]);

      if (Module1.LayerSnapping)
      {
        var bldLayer = MapView.Active.Map.GetLayersAsFlattenedList()
                     .First(l => l.Name == "Buildings") as FeatureLayer;
        if (bldLayer != null)
        {
          var lsm = Snapping.GetLayerSnapModes(bldLayer);
          lsm.Vertex = true;
          lsm.Edge = false;
          Snapping.SetLayerSnapModes(bldLayer, lsm);
        }
        var lineLayer = MapView.Active.Map.GetLayersAsFlattenedList()
                       .First(l => l.Name == "FacilitySiteLine") as FeatureLayer;
        if (lineLayer != null)
        {
          var lsm = Snapping.GetLayerSnapModes(lineLayer);
          lsm.Vertex = false;
          lsm.Edge = true;
          Snapping.SetLayerSnapModes(lineLayer, lsm);
        }
      }

      return base.OnToolActivateAsync(active);
    }

    protected override Task OnToolDeactivateAsync(bool hasMapViewChanged)
    {
      // restore the snap state, snap modes
      Snapping.IsEnabled = _snappingEnabled;
      Snapping.SnapModes = _snapModes;

      if (Module1.LayerSnapping)
      {
        var bldLayer = MapView.Active.Map.GetLayersAsFlattenedList()
                     .First(l => l.Name == "Buildings") as FeatureLayer;
        if (bldLayer != null)
        {
          Snapping.SetLayerSnapModes(bldLayer, true);
        }
        var lineLayer = MapView.Active.Map.GetLayersAsFlattenedList()
                               .First(l => l.Name == "FacilitySiteLine") as FeatureLayer;
        if (lineLayer != null)
        {
          Snapping.SetLayerSnapModes(lineLayer, true);
        }
      }
      return base.OnToolDeactivateAsync(hasMapViewChanged);

    }
    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      var polyLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>()
                                    .First(l => l.Name == "FacilitySite1");

      return QueuedTask.Run(() =>
      {
        // get features intersecting the sketch
        var selection = MapView.Active.SelectFeatures(geometry);

        if (polyLayer != null)
        {
          // get the features in the polygon layer only
          var polyOIDs = selection[polyLayer];

          // project sketch geometry into polygon layers spatial reference
          var projGeom = GeometryEngine.Instance.Project(geometry, polyLayer.GetSpatialReference());

          // set up the edit operation
          var editOperation = new EditOperation();
          editOperation.Name = "Cut With Circle";

          var insp = new Inspector();
          // for each poly
          foreach (var oid in polyOIDs)
          {
            // get the shape
            insp.Load(polyLayer, oid);
            var shape = insp.Shape;

            // cut it with the sketch 
            var diffGeom = GeometryEngine.Instance.Difference(shape, projGeom);

            // queue the modify operation - modifying the geometry
            editOperation.Modify(polyLayer, oid, diffGeom);
          }

          // execute the operation
          if (!editOperation.IsEmpty)
          {
            return editOperation.Execute();
          }
        }

        return false;
      });
    }
  }
}
