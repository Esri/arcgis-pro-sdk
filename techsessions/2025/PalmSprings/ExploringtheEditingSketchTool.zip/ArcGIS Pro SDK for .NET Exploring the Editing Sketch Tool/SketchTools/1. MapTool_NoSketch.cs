﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SketchTools
{
  internal class MapTool_NoSketch : MapTool
  {
    public MapTool_NoSketch()
    {
      IsSketchTool = false;
    }

    protected override void OnToolMouseDown(MapViewMouseButtonEventArgs args)
    {
      // On mouse down check if the mouse button pressed is:
      // the left mouse button to handle zoom in
      // or the right mouse button to handle zoom out
      // If it is handle the event.
      switch (args.ChangedButton)
      {
        case MouseButton.Right:
          args.Handled = true;
          break;
        case MouseButton.Left:
          args.Handled = true;
          break;
      }
    }

    protected override Task HandleMouseDownAsync(MapViewMouseButtonEventArgs e)
    {
      // Get the map coordinates from the click point and change the Camera to zoom in or out.
      return QueuedTask.Run(() =>
      {
        var mapClickPnt = MapView.Active.ClientToMap(e.ClientPoint);
        //ActiveMapView.LookAt(mapClickPnt, TimeSpan.FromSeconds(1));
        // zoom out
        if (e.ChangedButton == MouseButton.Right)
        {
          ActiveMapView.ZoomOutFixed(TimeSpan.FromSeconds(1));
        }
        // zoom in
        else if (e.ChangedButton == MouseButton.Left)
        {
          ActiveMapView.ZoomInFixed(TimeSpan.FromSeconds(1));
        }
      });
    }

  }
}
