﻿using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SketchTools
{
  internal class LayerSnappingCheckBox : CheckBox
  {
    protected override void OnClick()
    {
      Module1.LayerSnapping = this.IsChecked.Value;
    }
  }
}
