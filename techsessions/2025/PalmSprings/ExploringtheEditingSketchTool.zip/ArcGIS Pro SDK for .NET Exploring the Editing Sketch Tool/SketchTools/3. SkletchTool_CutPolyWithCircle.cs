﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core.CommonControls;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SketchTools
{
  internal class SketchTool_CutPolyWithCircle : MapTool
  {
    public SketchTool_CutPolyWithCircle()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Circle;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      var polyLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>()
                            .First(l => l.Name == "FacilitySite1");

      return QueuedTask.Run(() =>
      {
        // get features intersecting the sketch
        var selection = MapView.Active.SelectFeatures(geometry);

        if (polyLayer != null)
        {
          // get the features in the polygon layer only
          var polyOIDs = selection[polyLayer];

          // project sketch geometry into polygon layers spatial reference
          var projGeom = GeometryEngine.Instance.Project(geometry, polyLayer.GetSpatialReference());

          // set up the edit operation
          var editOperation = new EditOperation();
          editOperation.Name = "Cut With Circle";

          var insp = new Inspector();
          // for each poly
          foreach (var oid in polyOIDs)
          {
            // get the shape
            insp.Load(polyLayer, oid);
            var shape = insp.Shape;

            // cut it with the sketch 
            var diffGeom = GeometryEngine.Instance.Difference(shape, projGeom);

            // queue the modify operation - modifying the geometry
            editOperation.Modify(polyLayer, oid, diffGeom);
          }

          // execute the operation
          if (!editOperation.IsEmpty)
          {
            return editOperation.Execute();
          }
        }
        
        return false;
      });
    }
  }
}
