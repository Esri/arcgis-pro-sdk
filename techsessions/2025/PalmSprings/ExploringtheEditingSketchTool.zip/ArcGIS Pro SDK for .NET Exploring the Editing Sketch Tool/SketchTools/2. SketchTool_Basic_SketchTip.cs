﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SketchTools
{
  internal class SketchTool_Basic_SketchTip : MapTool
  {
    public SketchTool_Basic_SketchTip()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Line;
      SketchOutputMode = SketchOutputMode.Map;
      SketchTip = "click here";
    }

    protected override Task<bool> OnSketchModifiedAsync()
    {
      QueuedTask.Run(async () =>
      {
        var sketch = await GetCurrentSketchAsync();
        if (sketch is Polyline polyline)
        {
          var count = polyline.PointCount;

          SketchTip = "Vertex Count " + count.ToString();
        }
      });

      return base.OnSketchModifiedAsync();
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      SketchTip = "click here";

      return base.OnSketchCompleteAsync(geometry);
    }
  }
}
