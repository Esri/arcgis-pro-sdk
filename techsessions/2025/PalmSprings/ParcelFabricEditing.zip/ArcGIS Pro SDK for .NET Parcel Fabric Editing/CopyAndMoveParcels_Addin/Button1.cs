﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Internal.CIM;
using ArcGIS.Core.Internal.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core.Assistant.EnterpriseClient.ChatRequest.SqlWhereClauseGeneration;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static CopyParcels.CopyParcelsModule;

namespace CopyParcels
{
    internal class Button1 : Button
    {
        protected override async void OnClick()
        {
            //string sParcelTypeName = "Original";
            List<string> parcelTypes = new List<string>();
            List<long> sParcelLineOIDs = new List<long>();
            List<long> sParcelPointOIDs = new List<long>();
            MapPoint NewExtentCentroid = null;

            string errorMessage = await QueuedTask.Run(async () =>
            {
               var myParcelFabricLayer =
                  MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
              #region Guard 1: Ensure there is a parcel fabric in the map project
              // If there is no fabric in the map then bail
              if (myParcelFabricLayer == null)
                return "There is no fabric layer in the map.";
              #endregion

              if (!GetParcelPolygonFeatureLayersSelectionExt(MapView.Active,
                out Dictionary<FeatureLayer, List<long>> parcelPolygonLayerIds))
              {
                return "No parcel selection found. Please select parcel polygons and try again.";
              }

              #region Assign new 'root' centroid for all features to be copied
              // Get new map extent centroid and assign to property
              NewExtentCentroid = CopyParcelsModule.GetMapExtentCentroid(MapView.Active);
              #endregion

              foreach (var x in parcelPolygonLayerIds)
              {//just get centroid of first parcel type selection set
                var centroid = GetCentroidFromFeatures(x.Key, x.Value);
                centroid = GeometryEngine.Instance.Project(centroid,MapView.Active.Map.SpatialReference) as MapPoint;
                CopyParcelsModule.CalculateRelativeDifference(NewExtentCentroid, centroid);
                break;
              }

              SelectionSet parcelPolygonSelectionSet = SelectionSet.FromDictionary(parcelPolygonLayerIds);

                //#region Get parcel features from selected parcel polygons 
                try
                {
                  // Step 1: Create edit operation
                  var opCopyAndMoveParcels = new EditOperation
                  {
                    Name = "Copy Multiple Polygons",
                    SelectNewFeatures = false // Avoid unintended selection of newly created features
                  };

                  #region Copy Polygons
                  // Step 2: COPY POLYGONS 
                  foreach (var featlyr in parcelPolygonLayerIds)
                  {
                    var queryFilterPolygon = new ArcGIS.Core.Data.QueryFilter { ObjectIDs = featlyr.Value };
                    using (var rowCursor = featlyr.Key.Search(queryFilterPolygon))
                    {
                      while (rowCursor.MoveNext())
                      {
                        var feature = rowCursor.Current as Feature;

                      if (CopyFeatureByDeltaXY(feature, DX, DY, out Dictionary<string, object> FeatAttributes))
                        opCopyAndMoveParcels.Create(featlyr.Key, FeatAttributes);
                      }
                    }
                  }
                  #endregion

                  //get the lines and points from the selected parcels
                  var parcFeatures  = myParcelFabricLayer.GetParcelFeaturesAsync(parcelPolygonSelectionSet).Result;
                  var LineInfo = parcFeatures.Lines; // Get the line information from the parcel features object

                #region Copy Polylines
                // Step 3: COPY POLYLINES
                foreach (KeyValuePair<string, List<long>> kvp in LineInfo)
                {
                  var queryFilterLines = new ArcGIS.Core.Data.QueryFilter { ObjectIDs = kvp.Value };
                  var myLineFeatureLyrName = kvp.Key;
                  var myLineFeatureLyr = myParcelFabricLayer.GetParcelLineLayerByTypeNameAsync(myLineFeatureLyrName).Result.First();
                  using (var rowCursor = myLineFeatureLyr.Search(queryFilterLines))
                  {
                    while (rowCursor.MoveNext())
                    {
                      var feature = rowCursor.Current as Feature;
                      if (CopyFeatureByDeltaXY(feature, DX, DY, out Dictionary<string,object>FeatAttributes))
                        opCopyAndMoveParcels.Create(myLineFeatureLyr, FeatAttributes);
                    }
                  }
                }
                #endregion

                var PointInfo = parcFeatures.Points; // Get the point information from the parcel features object

                #region Copy Points
                // Step 3: COPY POINTS
                var queryFilterPoints = new ArcGIS.Core.Data.QueryFilter { ObjectIDs = PointInfo };
                var myPointFeatureLyr = myParcelFabricLayer.GetPointsLayerAsync().Result.First();
                using (var rowCursor = myPointFeatureLyr.Search(queryFilterPoints))
                {
                  while (rowCursor.MoveNext())
                  {
                    var feature = rowCursor.Current as Feature;
                    if (CopyFeatureByDeltaXY(feature, DX, DY, out Dictionary<string, object> FeatAttributes))
                      opCopyAndMoveParcels.Create(myPointFeatureLyr, FeatAttributes);
                  }
                }
                #endregion

                #region Execute Edit Operation
                // Step 5: Execute the batch edit operation
                if (!opCopyAndMoveParcels.Execute())
                {
                    System.Diagnostics.Debug.WriteLine("Failed to execute the batch edit operation.");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("All points copied with relative positions successfully.");
                }

                    #endregion
              }

              catch (Exception ex)
              {
                  return "An error occurred: " + ex.Message;
              }

              return "";
            });

            if (!string.IsNullOrEmpty(errorMessage))
            {
                ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show(errorMessage, "Error");
            }
        }
  }
}
