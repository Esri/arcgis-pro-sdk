﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CopyParcels
{
    internal class CopyParcelsModule : Module
    {
        public static double DX;
        public static double DY;

        /// <summary>
        /// Returns the centroid of the new map extent
        /// </summary>
        /// <param name="mapView"></param>
        /// <returns></returns>
        public static MapPoint GetMapExtentCentroid(MapView mapView)
        {
            if (mapView == null)
            {
                System.Diagnostics.Debug.WriteLine("Map view not found.");
            }

            var mapExtentPoints = mapView.Extent;
            MapPoint newExtentCentroid = GeometryEngine.Instance.Centroid(mapExtentPoints);

            return newExtentCentroid;
        }

        public static void CalculateRelativeDifference(MapPoint newMapExtentCentroid, MapPoint currentFeatureCentroid)
        {
            DX = newMapExtentCentroid.X - currentFeatureCentroid.X;
            DY = newMapExtentCentroid.Y - currentFeatureCentroid.Y;
        }

        internal static bool GetParcelPolygonFeatureLayersSelectionExt(MapView myActiveMapView,
            out Dictionary<FeatureLayer, List<long>> ParcelPolygonSelections)
    {
      List<FeatureLayer> featureLayer = new();
      ParcelPolygonSelections = new();

      try
      {
        var fLyrList = myActiveMapView?.Map?.GetLayersAsFlattenedList()?.OfType<FeatureLayer>()?.
          Where(l => l != null).Where(l => (l as Layer).ConnectionStatus != ConnectionStatus.Broken);

        if (fLyrList == null) return false;

        foreach (var fLyr in fLyrList)
        {
          bool isFabricLyr = fLyr.IsControlledByParcelFabricAsync(ParcelFabricType.ParcelFabric).Result;

          if (isFabricLyr && fLyr.SelectionCount > 0)
            featureLayer.Add(fLyr);
        }
      }
      catch
      { return false; }
      foreach (var lyr in featureLayer)
      {
        var fc = lyr.GetFeatureClass();
        List<long> lstOids = new();
        using (RowCursor rowCursor = lyr.GetSelection().Search())
        {
          while (rowCursor.MoveNext())
          {
            using (Row rowFeat = rowCursor.Current)
            {
              if (!ParcelPolygonSelections.ContainsKey(lyr))
                ParcelPolygonSelections.Add(lyr, lstOids);
              lstOids.Add(rowFeat.GetObjectID());
            }
          }
        }
        if (lstOids.Count > 0)
          ParcelPolygonSelections[lyr] = lstOids;
      }
      return true;
    }

        internal static bool CopyFeatureByDeltaXY(Feature feature, double deltaX, double deltaY, 
          out Dictionary<string, object> FeatAttributes)
        {
          FeatAttributes = [];
          try
          {
            var featureGeom = feature.GetShape();
            if (featureGeom != null)
            {
              var newFeatureGeom = GeometryEngine.Instance.Move(featureGeom, deltaX, deltaY);
              // Copy all original attributes from the source feature
              // Get the feature class definition to access all fields
              var fcDefinition = feature.GetTable().GetDefinition();
              foreach (var field in fcDefinition.GetFields())
              {
                // Skip system fields like ObjectID and Shape
                if (field.Name == fcDefinition.GetObjectIDField() || field.Name == fcDefinition.GetShapeField() ||
                    field.Name == fcDefinition.GetGlobalIDField())
                  continue;

                // Copy each attribute from the original feature to new feature
                FeatAttributes.Add(field.Name, feature[field.Name]);
              }
              // Add the shape field with the new geometry
              FeatAttributes.Add(fcDefinition.GetShapeField(), newFeatureGeom);
              return true;
            }
            else
              return false;
          }
          catch
          {
            return false;
          }
        }

      internal static MapPoint GetCentroidFromFeatures(FeatureLayer featLyr, IReadOnlyList<long> oids)
      {
        var queryFilter = new ArcGIS.Core.Data.QueryFilter { ObjectIDs = oids };
        GeometryBagBuilderEx geometryBagBuilder = new GeometryBagBuilderEx(featLyr.GetSpatialReference());
        using (RowCursor rowCursor = featLyr.Search(queryFilter))
        {
          while (rowCursor.MoveNext())
          {
            using (Row rowFeat = rowCursor.Current)
              geometryBagBuilder.AddGeometry((rowFeat as Feature).GetShape());
          } 
        }
        var merged = GeometryEngine.Instance.Union(geometryBagBuilder.Geometries);
        var cntr = GeometryEngine.Instance.Centroid(merged);
        return cntr;
      }

    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
        {
            //TODO - add your business logic
            //return false to ~cancel~ Application close
            return true;
        }

        #endregion Overrides

    }
}
