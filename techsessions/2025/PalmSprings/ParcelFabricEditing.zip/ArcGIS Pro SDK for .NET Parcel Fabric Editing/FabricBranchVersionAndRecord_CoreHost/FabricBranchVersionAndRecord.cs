﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Parcels;
using ArcGIS.Core.Hosting;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using Microsoft.VisualBasic;

namespace FabricBranchVersionAndRecord
{
  internal class Program
  {
    //[STAThread] must be present on the Application entry point
    [STAThread]
    static void Main(string[] args)
    {
      //Call Host.Initialize before constructing any objects from ArcGIS.Core
      Host.Initialize();

      #region Connection uri's for parcel fabric feature service
      #region user name and password
      string userName = "myusername";
      string pwd = "mypassword";
      #endregion
      Uri service = new("https://myserver.esri.com/server/rest/services/FS_DevSummit2025/FeatureServer");
      Uri portal_uri = new("https://myserver.esri.com/portal/");
      string sFabricName = "myParcelFabric";
      string sNewVersionAndRecordName = "";
      #endregion

      //Sign in to the portal
      ServiceConnectionProperties serviceConnectionProperties = new(service);

      ArcGIS.Core.SystemCore.ArcGISSignOn.Instance.SignInWithCredentials(portal_uri, 
        userName, pwd, out _, out _);

      if (serviceConnectionProperties != null)
      {
        //Connect to the feature service
        using var featService = new Geodatabase(serviceConnectionProperties);
        using (VersionManager versionManager = featService.GetVersionManager())
        {
          try
          {
            //Create a name for the new version and record
            var timeNow = RoundDown(DateTime.Now, TimeSpan.FromMinutes(30)).ToString("H:mm");
            sNewVersionAndRecordName = "MyRecord " + timeNow;

            //Confirm the version doesn't already exist
            IReadOnlyList<string> versionNameList = versionManager.GetVersionNames();
            foreach (string versionName in versionNameList)
            {
              if (versionName.ToLower() == (userName + "." + sNewVersionAndRecordName).ToLower())
                return; //version exists
            }

            //Create the version
            VersionDescription vDesc = new();
            vDesc.Description ="Dev Summit 2025";
            vDesc.AccessType = VersionAccessType.Public;
            vDesc.Name = sNewVersionAndRecordName;

            versionManager.CreateVersion(vDesc);
          }
          catch (Exception ex)
          {
            Console.WriteLine(ex.Message);
          }
        }

        //Connect to the new version
        Geodatabase connectedVersion = null;
        if (featService.IsVersioningSupported())
        {
          using (VersionManager versionManager = featService.GetVersionManager())
          using (ArcGIS.Core.Data.Version version = versionManager.GetVersion(sNewVersionAndRecordName))
          {
            connectedVersion = version.Connect();
          }
        }

        #region confirm current version
        using (VersionManager versionManager = connectedVersion.GetVersionManager())
        {
          var currentV = versionManager.GetCurrentVersion();
          var currentVName = currentV.GetName();
        }
        #endregion

        ParcelFabric myFabric = connectedVersion.OpenDataset<ParcelFabric>(sFabricName);
        var recordsFeatClass = myFabric.GetSystemTable(SystemTableType.Records);

        try
        {
          connectedVersion.ApplyEdits(() =>
          {
            using (RowBuffer rowBuffer = recordsFeatClass.CreateRowBuffer())
            {
              rowBuffer["Name"] = sNewVersionAndRecordName;
              recordsFeatClass.CreateRow(rowBuffer).Dispose();
            }
          });
        }
        catch (Exception ex)
        {
          Console.WriteLine( ex.Message);
        }
      }
    }
    static DateTime RoundDown(DateTime dt, TimeSpan d) 
    { 
      return new DateTime(dt.Ticks / d.Ticks * d.Ticks, dt.Kind); 
    }
    static DateTime RoundUp(DateTime dt, TimeSpan d)
    {
      return new DateTime((dt.Ticks + d.Ticks - 1) / d.Ticks * d.Ticks, dt.Kind);
    }

  }
}
