﻿using ActiproSoftware.Windows.Controls;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevSummit2025
{
  internal class ChangeVersionSetActiveRecord : Button
  {
    protected async override void OnClick()
    {
      //jump to the cim thread
      await QueuedTask.Run( () =>
      {
        //get time and create a new version name
        var timeNow = Module1.RoundDown(DateTime.Now, TimeSpan.FromMinutes(30)).ToString("H:mm");
        string sNewVersionAndRecord = "MyRecord " + timeNow;

        //Get the fabric layer from the active map
        var myParcelFabricLayer =
          MapView.Active?.Map?.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        
        //if there is no fabric in the map then bail
        if (myParcelFabricLayer == null)
          return; // "There is no fabric layer in the map.";

        //Use the records layer to get the geodatabase holding the parcel fabric 
        var recordsLyr = myParcelFabricLayer.GetRecordsLayerAsync().Result.First();
        var dataStore = recordsLyr.GetFeatureClass().GetDatastore();

        //Get the version manager, and default version
        var vManager = (dataStore as Geodatabase).GetVersionManager();
        var defaultV = vManager.GetDefaultVersion() as VersionBase;

        try
        { //Change version on the active map
          VersionBase targetVersion = vManager.GetVersion(sNewVersionAndRecord);
          MapView.Active.Map.ChangeVersion(defaultV, targetVersion);
        }
        catch (Exception ex) 
        {
          MessageBox.Show(ex.Message); 
        }

        //Set the active record, in this case record name is the same as the version name
        myParcelFabricLayer.SetActiveRecordAsync(sNewVersionAndRecord);

      });
    }
  }
}
