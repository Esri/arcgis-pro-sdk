﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core;
using ArcGIS.Desktop.Internal.KnowledgeGraph.FFP;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Text;
using System.Xml.Linq;

namespace AIAssistantSkillFunctionDemo.Helpers
{
	internal class Layout_Info
	{
		public Map Map { get; set; }
		public Size PageSize { get; set; }
		public string Title { get; set; }
		public bool IncludeNorthArrow { get; set; }
		public bool IncludeScaleBar { get; set; }
		public bool IncludeFootNote { get; set; }

		public CIMPage DefaultPage
		{
			get
			{
				//Construct as an ANSI A, portrait
				return new CIMPage()
				{
					Width = 8.5,
					Height = 11.0,
					StretchElements = true,
					ShowGuides = true,
					ShowRulers = true,
					Units = LinearUnit.Inches
				};
			}
		}
	}

	internal class LayoutHelper
	{

		private Dictionary<string, Size> _page_sizes = new Dictionary<string, Size>();

		private StyleProjectItem _arcgis2D = null;
		private NorthArrowStyleItem _na_style = null;
		private ScaleBarStyleItem _sb_style = null;
		private CIMTextSymbol _title_sym = null;
		private CIMTextSymbol _footnote_sym = null;

		public LayoutHelper()
		{
			Initialize();
		}

		private void Initialize()
		{
			_page_sizes.Add("A", new Size(8.5, 11.0));
			_page_sizes.Add("B", new Size(11.0, 17.0));
			_page_sizes.Add("C", new Size(17.0, 22.0));
			_page_sizes.Add("D", new Size(22.0, 34.0));
			_page_sizes.Add("E", new Size(34.0, 44.0));

			if (_arcgis2D == null)
				_arcgis2D = Project.Current.GetItems<StyleProjectItem>()
												.FirstOrDefault(item => item.Name == "ArcGIS 2D");
			if (_arcgis2D != null)
			{
				if (_na_style != null)
				{
					//Simple Filled North Arrow
					//Simple Filled North Arrow_North Arrows_7
					var na_styles = _arcgis2D.SearchNorthArrows(
													"Simple Filled North Arrow").ToList();
					var na_style = na_styles.FirstOrDefault(
						s => s.Key == "Simple Filled North Arrow_North Arrows_7");
					if (na_style == null)
					{
						if (na_styles.Count() > 0)
							na_style = na_styles.First();
						//else
						//	na_style = _arcgis2D.SearchNorthArrows("").First();
					}
					_na_style = na_style;
				}
				if (_sb_style != null)
				{
					//Alternating Scale Bar 1
					//Alternating Scale Bar 1_Imperial_8
					var sb_styles = _arcgis2D.SearchScaleBars(
										"Alternating Scale Bar 1").ToList();

					var sb_style = sb_styles.FirstOrDefault(
						s => s.Key == "Alternating Scale Bar 1_Imperial_8");
					if (sb_style == null)
					{
						if (sb_styles.Count() > 0)
							sb_style = sb_styles.First();
						//else
						//	sb_style = _arcgis2D.SearchScaleBars("").First();
					}
					_sb_style = sb_style;
				}
			}

			if (_title_sym == null)
			{
				//Tahoma bold 32pt
				_title_sym = SymbolFactory.Instance.ConstructTextSymbol(
					ColorFactory.Instance.BlackRGB, 32, "Tahoma", "Bold");
				//_title_text_sym.HorizontalAlignment = ArcGIS.Core.CIM.HorizontalAlignment.Left;
			}

			if (_footnote_sym == null)
			{
				//Tahoma regular 14pt
				var _footnote_sym = SymbolFactory.Instance.ConstructTextSymbol(
					ColorFactory.Instance.BlackRGB, 14, "Tahoma");
				//_footnote_sym.HorizontalAlignment = ArcGIS.Core.CIM.HorizontalAlignment.Left;
			}
		}

		#region Layout Page Size

		public (Size size, string orientation) DetermineLayoutPageSize(
			double width, double height, string user_specified_orientation)
		{

			//Always assume portrait
			var is_portrait = true;
			if (!string.IsNullOrEmpty(user_specified_orientation))
			{
				if (string.Compare(
					user_specified_orientation.ToLower(), "landscape") == 0)
				{
					is_portrait = false;
					if (width > 0.0001 && width < height)
					{
						//switch the orientation to be landscape
						var temp = width;
						width = height;
						height = temp;
					}
				}
			}
			else
			{
				//user did not specify a preference
				//determine from relationship between width and height
				//if a width and height were specified...
				if (width > 0.0001 && width > height)
				{
					is_portrait = false;
				}
			}

			//if we are here then we do not have a (valid) page size yet
			var result_wd = ClosestTo(width, -1.0, is_portrait);
			var result_ht = ClosestTo(-1.0, height, is_portrait);

			if (is_portrait)
			{
				//we prefer the height over the width
				return ReturnPageSize(result_ht.ansi_page_size, is_portrait);
			}
			//landscape: we prefer the width over the height
			return ReturnPageSize(result_wd.ansi_page_size, is_portrait);
		}

		private (string ansi_page_size, double delta) ClosestTo(
			double wd, double ht, bool is_portrait)
		{

			var closest_page_size = "A";//default
			var minDifference = 9999.0;

			foreach (var kvp in _page_sizes)
			{
				var difference = 0.0;
				var sz = kvp.Value;
				if (wd > ht)
				{
					//we are checking width
					difference = is_portrait ? Math.Abs(sz.Width - wd) :
																			 Math.Abs(sz.Height - wd);
				}
				else
				{
					//we are checking height
					difference = is_portrait ? Math.Abs(sz.Height - ht) :
																			 Math.Abs(sz.Width - ht);
				}

				if (minDifference > difference)
				{
					minDifference = difference;
					closest_page_size = kvp.Key;
				}
			}

			return (closest_page_size, minDifference);
		}

		private (Size page_size, string orientation) ReturnPageSize(string ansi_page_size, bool is_portrait)
		{
			if (is_portrait)
				return (_page_sizes[ansi_page_size.ToUpper()], "portrait");
			else
				return (new Size(_page_sizes[ansi_page_size.ToUpper()].Height,
								 _page_sizes[ansi_page_size.ToUpper()].Width), "landscape");
		}

		#endregion Layout Page Size

		#region Create Layout

		public Layout BuildLayout(Layout_Info layoutInfo)
		{
			//Construct the layout using the default page size - Ansi A, Portrait
			var layout = LayoutFactory.Instance.CreateLayout(layoutInfo.DefaultPage);

			var map_frame =
							EnvelopeBuilderEx.CreateEnvelope(
								1.0, 3.0, 7.5, 9.0);
			var na_frame =
				EnvelopeBuilderEx.CreateEnvelope(
					1.0, 0.7, 2.5, 2.2);
			var sb_frame =
				EnvelopeBuilderEx.CreateEnvelope(
					3.75, 1.7, 7.5, 2.2);
			//Tahoma Bold 32pt
			var title_text = new Coordinate2D(1.0, 9.75);
			//Tahoma regular 14pt
			var footnote_text = new Coordinate2D(3.15, 0.27);

			//Create the map frame - always included
			var mapFrame = ElementFactory.Instance.CreateMapFrameElement(
				layout, map_frame, layoutInfo.Map, "Map1", false);

			if (!string.IsNullOrEmpty(layoutInfo.Title))
			{
				ElementFactory.Instance.CreateTextGraphicElement(
					layout, TextType.PointText, title_text.ToMapPoint(), _title_sym,
					layoutInfo.Title, "Title Text1", false);
			}

			if (layoutInfo.IncludeNorthArrow)
			{
				var na_info = new NorthArrowInfo()
				{
					MapFrameName = mapFrame.Name,
					NorthArrowStyleItem = _na_style
				};
				var na = ElementFactory.Instance.CreateMapSurroundElement(
					layout, na_frame, na_info, "North Arrow1", false);
			}

			if (layoutInfo.IncludeScaleBar)
			{
				var sb_info = new ScaleBarInfo()
				{
					MapFrameName = mapFrame.Name,
					ScaleBarStyleItem = _sb_style
				};
				var sb = ElementFactory.Instance.CreateMapSurroundElement(
					layout, sb_frame, sb_info, "Scale Bar1", false);
			}

			if (layoutInfo.IncludeFootNote)
			{
				var today = DateTime.Now.ToString("g");
				var footnote = $"Layout generated on {today}";

				ElementFactory.Instance.CreateTextGraphicElement(
					layout, TextType.PointText, footnote_text.ToMapPoint(), _footnote_sym,
					footnote, "FootNote Text1", false);
			}

			//Apply the "actual" desired size
			var page = layoutInfo.DefaultPage;
			page.Width = layoutInfo.PageSize.Width;
			page.Height = layoutInfo.PageSize.Height;

			layout.SetPage(page, true);
			return layout;
		}

		#endregion Create Layout
	}
}
