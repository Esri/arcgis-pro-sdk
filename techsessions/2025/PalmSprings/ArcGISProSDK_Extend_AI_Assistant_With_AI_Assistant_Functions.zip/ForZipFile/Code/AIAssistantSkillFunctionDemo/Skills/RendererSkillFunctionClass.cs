﻿using ArcGIS.Core.Data;
using ArcGIS.Desktop.Core.Assistant;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core.Assistant;
using ArcGIS.Desktop.Mapping;
using System;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;


namespace AIAssistantSkillFunctionDemo.Skills
{
    internal class RendererExtensionClass
    {

        // Approval: (AutoInvoke=false)
        [AIAssistantFunction, Description("Provides suggestions for symbology to be applied to a layer.")]
        public async static Task<AIFunctionResult> SuggestRendererForLayer(
        [Description("Name of the layer.")] string layerName)
        {
            //Get the active map view.
            var mapView = MapView.Active;
            if (mapView == null)
                return new AIFunctionError("Could not suggest renderer.");

            var lyr = mapView.Map.GetLayersAsFlattenedList().Where(l => l.Name.Equals(layerName, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();

            if (lyr != null)
            {
                string fieldNames = await GetTableFields(layerName);

                // Invoke prompt for getting suggestion for renderer
                var renderer_prompt = await AIAssistant.Instance.InvokeFunctionFromYamlAsync("AIAssistantSkillFunctionDemo.Prompts.SuggestRendererPrompt.yaml", Assembly.GetExecutingAssembly(), new AIArguments { { "field_names", fieldNames } }, System.Threading.CancellationToken.None);
                return new AIFunctionResult(renderer_prompt?.ToString());
            }

            return new AIFunctionError("Could not suggest renderer.");
        }

        public async static Task<string> GetTableFields(string layerName)
        {
            try
            {
                Layer layer = MapView.Active.Map.Layers.Where(layer => layer.Name.ToLower() == layerName.ToLower()).FirstOrDefault();
                if (!(layer is FeatureLayer))
                    return null;

                string columns =String.Empty;
                await QueuedTask.Run(() =>
                {
                    FeatureLayer featureLayer = layer as FeatureLayer;
                    Table table = featureLayer.GetTable();
                    var tableDefn = table.GetDefinition();
                    var fields = tableDefn.GetFields();

                    foreach (var field in fields)
                    {
                        columns += field.Name + ", ";
                    }
                });

                return columns;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}