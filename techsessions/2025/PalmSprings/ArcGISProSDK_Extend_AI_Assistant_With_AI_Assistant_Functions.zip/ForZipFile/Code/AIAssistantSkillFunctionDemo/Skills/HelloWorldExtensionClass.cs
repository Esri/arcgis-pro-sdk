﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Assistant;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Core.Assistant;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIAssistantSkillFunctionDemo.Skills
{
	internal class HelloWorldExtensionClass
	{

		[AIAssistantFunction, 
			Description(
			"Show a hello world message with an optional text string")]
		public static AIFunctionResult HelloWorldExampleFunction(
			[Description(
			"Optional text string to show with the Hello World message")] 
			string optionalTextString = "")
		{
			//Show a hello world message
			var msg = "Hello World";
			if (!string.IsNullOrEmpty(optionalTextString))
				msg += ": " + optionalTextString;
			MessageBox.Show(msg, "Hello World");

			return new AIFunctionResult(
				"Hello world message shown successfully");
		}
	}
}
