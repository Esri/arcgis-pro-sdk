﻿using AIAssistantSkillFunctionDemo.Helpers;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Assistant;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Controls;
using System.Windows.Media.Media3D;

namespace AIAssistantSkillFunctionDemo.Ribbon
{
	internal class TestLayout : Button
	{
		protected override async void OnClick()
		{
			double width = 8.5;
			double height = 11.0;
			string orientation = "";
			string title = "USA National Parks";
			bool includeNorthArrow = true;
			bool includeScaleBar = true;

			var map = MapView.Active.Map;//capture the map

			//TODO: CreateLayout Skill Function implementation goes here
			var layout = await QueuedTask.Run(() =>
			{
				var layoutHlpr = new LayoutHelper();
				//Figure out the page size or use the default
				var page_size = layoutHlpr.DetermineLayoutPageSize(
					width, height, orientation);

				//Configure the layout based on the user choices
				var layout_info = new Layout_Info()
				{
					Map = map,
					PageSize = page_size.size,
					Title = title,
					IncludeNorthArrow = includeNorthArrow,
					IncludeScaleBar = includeScaleBar
				};
				return layoutHlpr.BuildLayout(layout_info);
			});

			//Show the newly created layout
			if (layout == null)
				return ;
			ProApp.Panes.CreateLayoutPaneAsync(layout);
		}
	}
}
