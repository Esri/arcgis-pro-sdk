﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Events;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;


namespace EditingSpy
{
  internal class SpyEventsViewModel : DockPane
  {
    private const string _dockPaneID = "EditingSpy_SpyEvents";

    protected SpyEventsViewModel()
    {
      AddEntry("Click 'Start Events' to start listening to events.");

      _spyEditEvents = true;
    }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

    private bool _listening = false;
    public bool IsListening => _listening;

    public string ButtonText => _listening ? "Stop Events" : "Start Events";


    private ICommand _clearCmd = null;
    public ICommand ClearTextCmd
    {
      get
      {
        if (_clearCmd == null)
          _clearCmd = new RelayCommand(() => ClearEntries());
        return _clearCmd;
      }
    }

    private bool _spyEditEvents;
    public bool SpyEditEvents
    {
      get => _spyEditEvents;
      set
      {
        if (_listening)
          StopListening();
        SetProperty(ref _spyEditEvents, value);
        NotifyPropertyChanged(nameof(SpySketchEvents));
      }
    }

    public bool SpySketchEvents
    {
      get => !_spyEditEvents;
      set => SpyEditEvents = !value;
    }

    #region Register / Unregister

    private bool _firstStart = true;
    private List<SubscriptionToken> _sketchEvents = new List<SubscriptionToken>();

    private Dictionary<string, List<SubscriptionToken>> _rowevents = new Dictionary<string, List<SubscriptionToken>>();
    private List<SubscriptionToken> _editEvents = new List<SubscriptionToken>();

    private ICommand _startStopCmd;
    public ICommand StartStopCmd
    {
      get
      {
        if (_startStopCmd == null)
        {
          _startStopCmd = new RelayCommand(() =>
          {
            if (_firstStart)
            {
              ClearEntries();
              _firstStart = false;
            }

            if (_listening)
            {
              StopListening();
            }
            else
            {
              StartListening();
            }
          });
        }
        return _startStopCmd;
      }
    }

    private void StartListening()
    {
      if (_listening)
        return;

      _listening = Register();
      NotifyPropertyChanged("ButtonText");
      NotifyPropertyChanged(nameof(IsListening));
    }
    private void StopListening()
    {
      if (!_listening)
        return;

      _listening = Unregister();
      NotifyPropertyChanged("ButtonText");
      NotifyPropertyChanged(nameof(IsListening));
    }

    private bool Register()
    => (_spyEditEvents) ? RegisterEditEvents() : RegisterSketchEvents();

    private bool Unregister()
      => (_spyEditEvents) ? UnregisterEditEvents() : UnregisterSketchEvents();

    private bool RegisterSketchEvents()
    {
      _sketchEvents.Add(SketchCanceledEvent.Subscribe(OnSketchCancelled));
      _sketchEvents.Add(SketchCompletedEvent.Subscribe(OnSketchCompleted));
      _sketchEvents.Add(SketchModifiedEvent.Subscribe(OnSketchModified));
      //_events.Add(SketchStartedEvent.Subscribe(OnSkecStarted));

      AddEntry("Listening Sketch Events");

      return true;
    }

    private bool UnregisterSketchEvents()
    {
      SketchCanceledEvent.Unsubscribe(_sketchEvents[0]);
      SketchCompletedEvent.Unsubscribe(_sketchEvents[1]);
      SketchModifiedEvent.Unsubscribe(_sketchEvents[2]);
      //SketchStartedEvent.Unsubscribe(_events[3]);

      _sketchEvents.Clear();

      AddEntry("Not listening");

      return false;
    }

    private bool RegisterEditEvents()
    {
      var layers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
      QueuedTask.Run(() => {
        foreach (var fl in layers)
        {
          var fc = fl.GetFeatureClass();
          var tokens = new List<SubscriptionToken>();
          //These events are fired once ~per feature~,
          //per table
          tokens.Add(RowCreatedEvent.Subscribe((rc) => RowEventHandler(rc), fc));
          tokens.Add(RowChangedEvent.Subscribe((rc) => RowEventHandler(rc), fc));
          tokens.Add(RowDeletedEvent.Subscribe((rc) => RowEventHandler(rc), fc));
          _rowevents[fl.Name] = tokens;
        }

        //This event is fired after all the edits are completed (and on
        //save, discard, undo, redo) and is fired once
        _editEvents.Add(EditStartedEvent.Subscribe((es) =>
        {
          RecordEvent("EditStartedEvent", "");
        }));

        //This event is fired once per edit execute
        //Note: This event won't fire if the edits were cancelled
        _editEvents.Add(EditCompletingEvent.Subscribe((ec) =>
        {
          RecordEvent("EditCompletingEvent", "");
          //can also cancel edit in the completing event...
          //cancels everything (that is cancealable)
          //
          //you'll need to modify the RowEventHandler() to prevent if
          //from doing the cancel or this will never get called
          if (_cancelEdit)
          {
            ec.CancelEdit($"EditCompletingEvent, edit cancelled");
            AddEntry("*** edits cancelled");
            AddEntry("---------------------------------");
          }
        }));
        //This event is fired after all the edits are completed (and on
        //save, discard, undo, redo) and is fired once
        _editEvents.Add(EditCompletedEvent.Subscribe((ec) => {
          HandleEditCompletedEvent(ec);
          return Task.FromResult(0);
        }));

      });

      AddEntry("Listening Edit Events");

      return true;
    }

    private bool UnregisterEditEvents()
    {
      //Careful here - events have to be unregistered on the same
      //thread they were registered on...hence the use of the
      //Queued Task
      QueuedTask.Run(() =>
      {
        //One kvp per layer....of which there is only one in the sample
        //out of the box but you can add others and register for events
        foreach (var kvp in _rowevents)
        {
          RowCreatedEvent.Unsubscribe(kvp.Value[0]);
          RowChangedEvent.Unsubscribe(kvp.Value[1]);
          RowDeletedEvent.Unsubscribe(kvp.Value[2]);
          kvp.Value.Clear();
        }
        _rowevents.Clear();

        // other edit events
        EditStartedEvent.Unsubscribe(_editEvents[0]);
        EditCompletingEvent.Unsubscribe(_editEvents[1]);
        EditCompletedEvent.Unsubscribe(_editEvents[2]);
        _editEvents.Clear();
      });


      AddEntry("Not listening");

      return false;
    }
    #endregion RegisterUnregister

    #region Flags

    private bool _cancelEdit;
    public bool CancelEdits
    {
      get => _cancelEdit;
      set => SetProperty(ref _cancelEdit, value);
    }

    #endregion

    #region eventLog

    private static readonly object _lock = new object();
    private List<string> _entries = new List<string>();

    public string EventLog
    {
      get
      {
        string contents = "";
        lock (_lock)
        {
          contents = string.Join("\r\n", _entries.ToArray());
        }
        return contents;
      }
    }

    private void ClearEntries()
    {
      lock (_lock)
      {
        _entries.Clear();
      }
      NotifyPropertyChanged(nameof(EventLog));
    }

    private void AddEntry(string entry)
    {
      lock (_lock)
      {
        _entries.Add($"{entry}");
      }
      NotifyPropertyChanged(nameof(EventLog));
    }

    private void RecordEvent(string eventName, string entry)
    {
      var dateTime = DateTime.Now.ToString("G");
      AddEntry($"{dateTime}: {eventName} {entry}");
    }

    private void RecordEvent(RowChangedEventArgs rc, Table table)
    {
      var eventName = $"Row{rc.EditType.ToString()}dEvent";

      var entry = $"{table.GetName()}, oid:{rc.Row.GetObjectID()}";
      RecordEvent(eventName, entry);
    }

    #endregion

    #region Sketch Events
    private void OnSketchCancelled(SketchCanceledEventArgs args)
    {
      AddEntry("SketchCancelled event");
      AddEntry("---------------------------------");
    }

    //private void OnSkecStarted(SketchStartedEventArgs args)
    //{
    //  AddEntry("---------------------------------");
    //  AddEntry("SketchStarted event");
    //}

    private void OnSketchCompleted(SketchCompletedEventArgs args)
    {
      AddEntry("SketchCompleted event");
      AddEntry("---------------------------------");
    }

    private void OnSketchModified(SketchModifiedEventArgs args)
    {
      AddEntry("SketechModified event");
      AddEntry("    " + args.SketchOperationType.ToString() + "; " + args.IsUndo.ToString());
    }
    #endregion

    #region Edit Events
    private void RowEventHandler(RowChangedEventArgs rc)
    {
      using (var table = rc.Row.GetTable())
      {

        RecordEvent(rc, table);

        rc.Row["LABEL_FIELD"] = "C";
        //Cancel flag is set.
        if (_cancelEdit)
        {
          //cancel the edit
          rc.CancelEdit($"{rc.EditType} for {table.GetName()} cancelled");
          AddEntry("*** edit cancelled");
          AddEntry("---------------------------------");
        }
      }
    }

    private void HandleEditCompletedEvent(EditCompletedEventArgs args)
    {
      RecordEvent("EditCompletedEvent", args.CompletedType.ToString());

      StringBuilder adds = new StringBuilder();
      StringBuilder mods = new StringBuilder();
      StringBuilder dels = new StringBuilder();
      adds.AppendLine("Adds");
      mods.AppendLine("Modifies");
      dels.AppendLine("Deletes");

      if (args.Creates != null)
      {
        var creates = args.Creates.ToDictionary();
        foreach (var kvp in creates)
        {
          var oids = string.Join(",", kvp.Value.Select(n => n.ToString()).ToArray());
          adds.AppendLine($" {kvp.Key.Name} {oids}");
        }
      }
      else
      {
        adds.AppendLine("  No Adds");
      }
      if (args.Modifies != null)
      {
        var modifies = args.Modifies.ToDictionary();
        foreach (var kvp in modifies)
        {
          var oids = string.Join(",", kvp.Value.Select(n => n.ToString()).ToArray());
          mods.AppendLine($" {kvp.Key.Name} {oids}");
        }
      }
      else
      {
        mods.AppendLine("  No Modifies");
      }
      if (args.Deletes != null)
      {
        var deletes = args.Deletes.ToDictionary();
        foreach (var kvp in deletes)
        {
          var oids = string.Join(",", kvp.Value.Select(n => n.ToString()).ToArray());
          dels.AppendLine($" {kvp.Key.Name} {oids}");
        }
      }
      else
      {
        dels.AppendLine("  No Deletes");
      }
      AddEntry(adds.ToString());
      AddEntry(mods.ToString());
      AddEntry(dels.ToString());
      AddEntry("---------------------------------");
    }

    #endregion
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class SpyEvents_ShowButton : Button
  {
    protected override void OnClick()
    {
      SpyEventsViewModel.Show();
    }
  }
}
