﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace EditingSpy
{
  internal sealed class BoolToVisibleConverter : IValueConverter
  {
    public BoolToVisibleConverter() { }

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (targetType != typeof(Visibility))
        throw new InvalidOperationException("The target must be of type " + nameof(Visibility));

      var invert = (parameter is bool?)
                       ? parameter as bool?
                       : parameter != null && System.Convert.ToBoolean(parameter);

      var boolValue = System.Convert.ToBoolean(value);
      if (invert == true)
        boolValue = !boolValue;
      return boolValue ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (targetType != typeof(bool))
        throw new InvalidOperationException("The target must be of type bool");

      if (value == null)
        return true;

      Visibility visiblity = (Visibility)System.Convert.ToInt32(value);

      return visiblity == Visibility.Visible ? true : false;
    }
  }
}
