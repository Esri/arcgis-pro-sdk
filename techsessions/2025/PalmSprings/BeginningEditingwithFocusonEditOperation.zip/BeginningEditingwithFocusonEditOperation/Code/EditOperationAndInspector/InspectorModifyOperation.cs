﻿using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Mapping;
using ArcGIS.Desktop.Mapping;
using System;
using System.Linq;

namespace EditOperationAndInspector
{
  internal class InspectorModifyOperation : Button
  {
    protected override void OnClick()
    {
      var polyLayer = MapView.Active.Map.GetLayersAsFlattenedList().First(l => l.Name == "FacilitySite1");
      if (polyLayer == null) return;

      QueuedTask.Run(() => {

        var inspector = new Inspector();
        //The map selection is mixed with point and poly features. 
        var selection = MapView.Active.Map.GetSelection();
        //Just get the polygon
        var oid = selection[polyLayer];
        //Load the poly and define some new attribute values
        inspector.Load(polyLayer, oid);
        inspector["FACILITYID"] = "23067.00";
        inspector["FCODE"] = "Privatized";
        inspector["DESCRIPT"] = "Alameda Resort";
        inspector["OWNTYPE"] = "Private";
        inspector["LASTUPDATE"] = DateTime.Now;
        inspector["LASTEDITOR"] = "Dev and Tech";
        //Create the edit operation  
        var editOp = new EditOperation()
        {
          Name = "Inspector with Edit Operation",
          ErrorMessage = "The operation failed somewhere",
          SelectModifiedFeatures = true,         
        };
        editOp.Modify(inspector);
        editOp.Execute();

      });
    }
  }
}
