﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Internal.CIM;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_Intro
{
  internal class EditOperationRowToken : Button
  {
    private string path = @"C:\Pro_SDK\DevSummit\2025\PalmSprings\Sessions\Beginning Editing with Focus on EditOperation";
    protected override void OnClick()
    {
      var fac_point_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                          .First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;
      if (fac_point_lyr == null)
        return;

      QueuedTask.Run(() =>
      {

        //Get an arbitrary point location to use in the edit operation
        var centerPt = MapView.Active.Extent.Center;

        // create edit operation
        var editOp = new EditOperation()
        {
          Name = "Add Attachment w/ Row Token",
          SelectNewFeatures = true
        };

        var rowtoken = editOp.Create(fac_point_lyr, centerPt);

        //Rowtoken is used as the ObjectID "placeholder"
        var attachPath = System.IO.Path.Combine(path, "Data\\Hydrant.jpg");
        editOp.AddAttachment(rowtoken, attachPath);

        //Execute the operation
        editOp.Execute();

        var new_oid = rowtoken.ObjectID ?? -1;
      });
    }
  }
}
