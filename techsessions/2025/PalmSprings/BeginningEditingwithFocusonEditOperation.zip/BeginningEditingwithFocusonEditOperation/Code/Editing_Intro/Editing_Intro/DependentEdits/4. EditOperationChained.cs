﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_Intro
{
  internal class EditOperationChained : Button
  {
    private string path = @"C:\Pro_SDK\DevSummit\2025\PalmSprings\Sessions\Beginning Editing with Focus on EditOperation";

    protected override void OnClick()
    {
      var fac_point_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                            .First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;
      if (fac_point_lyr == null)
        return;

      QueuedTask.Run(() =>
      {

        //Get an arbitrary point location to use in the edit operation
        var centerPt = MapView.Active.Extent.Center;

        // create edit operation
        var editOp = new EditOperation()
        {
          Name = "Add Attachment w/ Chained Op",
          SelectNewFeatures = true
        };

        var rowtoken = editOp.Create(fac_point_lyr, centerPt);

        //Execute the create and check status
        if (editOp.Execute())
        {
          var chained_op = editOp.CreateChainedOperation(); //chain an operation

          var attachPath = System.IO.Path.Combine(path, @"Data\Hydrant.jpg");

          chained_op.AddAttachment(fac_point_lyr, (long)rowtoken.ObjectID,
                  attachPath);
          chained_op.Execute();
        }
      });
    }
  }
}
