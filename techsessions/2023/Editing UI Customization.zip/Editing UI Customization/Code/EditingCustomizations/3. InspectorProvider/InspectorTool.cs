﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       https://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EditingCustomizations
{
  internal class InspectorTool : MapTool
  {
    private string _CrimesLayerName = "Crimes";

    private AttributeControlViewModel _attributeVM = null;
    private DelayedInvoker _invoker = new DelayedInvoker(10);
    public InspectorTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Rectangle;
      SketchOutputMode = SketchOutputMode.Map;

      // specify the ID for the embeddable control as declared in the config.daml
      ControlID = "EditingCustomizations_AttributeControl";
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      // get a reference to the view model 
      if (_attributeVM == null)
      {
        _attributeVM = this.EmbeddableControl as AttributeControlViewModel;
      }

      // populate the control with the selection
      QueuedTask.Run(() =>
      {
        // get the current selection for the active map
        var selectionInMap = ActiveMapView.Map.GetSelection();

        // get the layer from the map
        var layer = ActiveMapView.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().
                        Where(lyr => lyr.Name == _CrimesLayerName).FirstOrDefault();
        if (layer != null)
        {
          // if the point layer contains selected features
          if (selectionInMap.ToDictionary().ContainsKey(layer))
          {
            // get a list of the selected point features 
            var selectionDictionary = new Dictionary<MapMember, List<long>>();
            selectionDictionary.Add(layer as MapMember, selectionInMap.ToDictionary()[layer]);
            // and store it in the view model, this property populates the tree view
            _attributeVM.SelectedMapFeatures = selectionDictionary;

            // load the first selected point feature
            _attributeVM.AttributeInspector.Load(layer, selectionInMap[layer][0]);
          }
        }
      });

      return Task.FromResult(true);
    }

    protected override Task OnToolDeactivateAsync(bool hasMapViewChanged)
    {
      // if we have a valid view model
      if (_attributeVM != null)
      {
        // free the embeddable control resources
        _attributeVM.Cleanup();
        _attributeVM = null;
      }

      return Task.FromResult(true);
    }

    /// <summary>
    /// Occurs once the user completed the sketch and select the information for the
    /// embeddable control
    /// </summary>
    /// <param name="geometry">Sketch geometry in map coordinates.</param>
    /// <returns></returns>
    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      // select the layer in the active map
      var layer = ActiveMapView.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().
                            Where(lyr => lyr.Name == _CrimesLayerName).FirstOrDefault();
      if (layer == null)
        return Task.FromResult(true);

      // get a reference to the view model 
      if (_attributeVM == null)
      {
        _attributeVM = this.EmbeddableControl as AttributeControlViewModel;
      }

      // execute the select on the MCT
      QueuedTask.Run(() =>
      {
        // define the spatial query filter
        var spatialQuery = new SpatialQueryFilter() 
            { FilterGeometry = geometry, SpatialRelationship = SpatialRelationship.Contains };

        // gather the selection
        if (layer != null)
        {
          var pointSelection = layer.Select(spatialQuery);
          List<long> oids = pointSelection.GetObjectIDs().ToList();

          if (oids.Count == 0)
            _attributeVM.AttributeInspector.LoadSchema(layer);
          else
            _attributeVM.AttributeInspector.Load(layer, oids);

          #region Apply selection
          // set up a dictionary to store the layer and the object IDs of the selected features
          var selectionDictionary = new Dictionary<MapMember, List<long>>();
          selectionDictionary.Add(layer as MapMember, pointSelection.GetObjectIDs().ToList());

          // assign the dictionary to the view model
          _attributeVM.SelectedMapFeatures = selectionDictionary;
          #endregion
        }
      });

      return Task.FromResult(true);
    }
  }
}
