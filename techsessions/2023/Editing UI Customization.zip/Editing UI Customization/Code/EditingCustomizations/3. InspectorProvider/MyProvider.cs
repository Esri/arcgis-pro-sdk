﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       https://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using System.Collections.Generic;

namespace EditingCustomizations
{
  public class MyProvider : InspectorProvider
  {
    public override string CustomName(ArcGIS.Desktop.Editing.Attributes.Attribute attr)
    {
      if (attr.FieldName == "X_Coordinate")
        return "Location (X)";
      if (attr.FieldName == "Y_Coordinate")
        return "Location (Y)";

      return attr.FieldName;
    }
    public override bool? IsVisible(ArcGIS.Desktop.Editing.Attributes.Attribute attr)
    {
      if (attr.FieldName == "Police_District")
        return false;

      return true;
    }

    public override bool? IsEditable(ArcGIS.Desktop.Editing.Attributes.Attribute attr)
    {
      if (attr.FieldName == "ReportDate")
        return false;

      return true;
    }
    public override bool? IsHighlighted(ArcGIS.Desktop.Editing.Attributes.Attribute attr)
    {
      if (attr.FieldName == "Police_Precinct")
        return true;

      return false;
    }

    // bug in 3.1.  Make sure you override this method and return non-null otherwise you will get a crash.
    //  fixed in 3.1.3
    public override IEnumerable<Attribute> AttributesOrder(IEnumerable<Attribute> attrs)
    {
      var newList = new List<ArcGIS.Desktop.Editing.Attributes.Attribute>();
      foreach (var attr in attrs)
      {
        newList.Add(attr);
      }
      return newList;
    }

    // use BeginLoad/EndLoad if you need the entire set of attributes at once
    //  to perform any pre-processing
    // EndLoad can be used to clear any cached values
    public override void BeginLoad(IEnumerable<Attribute> attrs)
    {
      base.BeginLoad(attrs);
    }

    public override void EndLoad()
    {
      base.EndLoad();
    }
  }
}
