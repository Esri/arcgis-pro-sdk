﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       https://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using ArcGIS.Core.Data;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Linq;

namespace EditingCustomizations
{
  internal class ActivateExtension : Button
  {
    protected override void OnClick()
    {
      // get the Crimes layer
      var layer = MapView.Active?.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().
                Where(l => l.Name == "Crimes").FirstOrDefault();
      if (layer == null) return;

      //Unique quid - must match guid attribute in the DAML.
      Guid myExtension = new Guid("{E8E6C0E7-17C3-4F85-9E09-1E51F82ADFA2}");
      QueuedTask.Run(() =>
      {
        //Get the feature class of the layer
        var fc = layer.GetFeatureClass();
        // Register the extension ID (Guid) with the feature class table.
        fc.AddActivationExtension(myExtension);
      });
    }
  }

  internal class DeActivateExtension : Button
  {
    protected override void OnClick()
    {
      // get the Crimes layer
      var layer = MapView.Active?.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().
                    Where(l => l.Name == "Crimes").FirstOrDefault();
      if (layer == null) return;

      //Unique quid - must match guid attribute in the DAML.
      Guid myExtension = new Guid("{E8E6C0E7-17C3-4F85-9E09-1E51F82ADFA2}");
      QueuedTask.Run(() =>
      {
        //Get the feature class of the layer
        var fc = layer.GetFeatureClass();
        // Register the extension ID (Guid) with the feature class table.
        fc.RemoveActivationExtension(myExtension);
      });
    }
  }
}
