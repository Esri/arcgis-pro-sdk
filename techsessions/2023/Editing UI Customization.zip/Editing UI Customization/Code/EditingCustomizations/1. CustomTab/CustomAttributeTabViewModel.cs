﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       https://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using ArcGIS.Core.CIM;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace EditingCustomizations
{
  internal class CustomAttributeTabViewModel : AttributeTabEmbeddableControl
  {
    private CIMPointSymbol _ptSymbol = null;
    private IDisposable _graphic = null;


    public CustomAttributeTabViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) 
    {
      // set up the map control
      QueuedTask.Run(() =>
      {
        var _precinctLayer = MapView.Active.Map.GetLayersAsFlattenedList().
                      OfType<FeatureLayer>().
                      Where(layer => layer.Name == "Portland Precincts").FirstOrDefault();
        var extent = _precinctLayer.QueryExtent();
        var layers = new List<Layer>() { _precinctLayer };

        MapContent = MapControlContentFactory.Create(layers, extent, MapViewingMode.Map);
      });
      CurrentShape = null;
    }

    public override bool Applies(MapMember mapMember)
    {
      if (mapMember?.Name == "Crimes")
        return true;

      return false;
    }

    /// <summary>
    /// Called when attributes from one or more rows have been loaded into the Inspector
    /// </summary>
    /// <returns></returns>
    public override Task LoadFromFeaturesAsync()
    {
      // use the Inspector to obtain the record loaded
      try
      {
        var recordId = Inspector["Record_ID"].ToString();
      }
      catch (Exception ex)
      { 
      }
      QueuedTask.Run(() =>
      {
        CurrentShape = Inspector.Shape;

        AddPushPin(CurrentShape);
      });

      return Task.CompletedTask;
    }

    internal Task AddPushPin(Geometry geometry)
    {
      return QueuedTask.Run(() =>
      {
        if (_ptSymbol == null)
          _ptSymbol = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.RedRGB, 8, SimpleMarkerStyle.Pushpin);

        _graphic?.Dispose();    //Clear out the old overlay

        var mapControl = Module1.MapControl;
        if (mapControl != null)
        {
          if (geometry is MapPoint point)
            _graphic = mapControl.AddOverlay(point, _ptSymbol.MakeSymbolReference());
        }
      });
    }

    internal Task AddCurrentPushPin() => AddPushPin(CurrentShape);

    #region Properties

    public Geometry CurrentShape { get; set; }

    private MapControlContent _mapContent;
    public MapControlContent MapContent
    {
      get => _mapContent;
      set => SetProperty(ref _mapContent, value);
    }


    #endregion
  }
}
