﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       https://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using System;
using System.Windows.Controls;

namespace EditingCustomizations
{
  /// <summary>
  /// Interaction logic for CustomAttributeTabView.xaml
  /// </summary>
  public partial class CustomAttributeTabView : UserControl
  {
    public CustomAttributeTabView()
    {
      InitializeComponent();
      this.MapControl.ViewContentLoaded += MapControl_ViewContentLoaded;
      this.MapControl.ExtentChanged += MapControl_ExtentChanged;
    }

    private void MapControl_ExtentChanged(object sender, EventArgs e)
    {
      var vm = DataContext as CustomAttributeTabViewModel;
      vm?.AddCurrentPushPin();
    }

    private void MapControl_ViewContentLoaded(object sender, EventArgs e)
    {
      Module1.MapControl = this.MapControl;
    }
  }
}
