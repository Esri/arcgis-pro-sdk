﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Core.Data;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Framework.Dialogs;

namespace AsyncFine
{
  internal class TestAsync : Button
  {
    protected override  void OnClick()
    {
      try
      {
        FineGrainedMethods();
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Exception: {ex.Message}");
      }
      //MessageBox.Show("OnClick is done");
    }

    private void FineGrainedMethods()
    {
      // run the methods below under QueuedTask
      //ArcGIS.Desktop.Framework.Threading.Tasks.QueuedTask.Run(() =>
      //{
        // fine grained => call only from Queued Task
        var layers = MapView.Active.Map.FindLayers("cities").OfType<FeatureLayer>().ToList();
        var citiesLayer = layers[0] as FeatureLayer;
        QueryFilter qf = new QueryFilter()
        {
          WhereClause = "CITY_NAME = 'Washington DC'",
          SubFields = "*"
        };
        citiesLayer.Select(qf, SelectionCombinationMethod.New);
        MapView.Active.ZoomToSelected(new TimeSpan(0, 0, 3));
      //});
    }
    
  }
}
