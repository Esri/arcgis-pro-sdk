﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Core.Data;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Framework.Dialogs;

namespace AsyncCoarse
{
  internal class TestAsync : Button
  {
    protected override void OnClick()
    {
      CoarseGrainedMethods();
    }

    /// <summary>
    /// you can start with a blank map
    /// </summary>
    private void CoarseGrainedMethods()
    {
      try
      {
        //Execute a GP Tool
        // Add the await keyword
        Geoprocessing.ExecuteToolAsync("SelectLayerByAttribute_management",
             new string[] { "cities", "NEW_SELECTION",
               "CITY_NAME = 'Washington DC'" });
        // Add the await keyword
        MapView.Active.ZoomToSelectedAsync(new TimeSpan(0, 0, 5));
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Exception: {ex}");
      }
      MessageBox.Show("CoarseGrainedMethods is done");
    }

  }
}
