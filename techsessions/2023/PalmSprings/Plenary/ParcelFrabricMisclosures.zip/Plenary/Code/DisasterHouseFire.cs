﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TaxParcelPlenary
{
  internal class DisasterHouseFire : Button
  {
    protected override void OnClick()
    {
      try
      {
        // configure the required tools
        IPlugInWrapper wrapper = FrameworkApplication.GetPlugInWrapper("esri_editing_ShowAttributes");
        var command = wrapper as ICommand;

        if ((command != null) && command.CanExecute(null))
          command.Execute(null);
        
        wrapper = FrameworkApplication.GetPlugInWrapper("esri_mapping_selectByRectangleTool");
        command = wrapper as ICommand;

        if ((command != null) && command.CanExecute(null))
          command.Execute(null);
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {ex.Message}");
      }
    }
  }
}
