﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxParcelPlenary.Helper;

namespace TaxParcelPlenary.ParcelReportingTool
{
  public static class ParcelUpdates
  {
    /// <summary>
    /// Update the Misclose and Area values for the given parcel polygons and list of object Ids
    /// </summary>
    /// <param name="parcelPolygonLayersWithUpdateIds">contains parcel polygons and a list of object ids for each that need to be updated</param>
    /// <returns></returns>
    internal static async Task<EditOperation> UpdateLineAndMiscloseAreaAsync(string parcelTypeName, List<long> oidList, EditOperation editOper)
    {
      DiagnosticHelper.Start();

      var OK = editOper.Execute();
      if (OK == false)
        return null;

      if (oidList.Count() == 0)
        return editOper;

      var editOper2 = editOper.CreateChainedOperation();
        double largeParcelToleranceInSqMeters = 1011.715; //default to quarter acre in units of meters = 1011.715 sq.m
        long _largeParcelUnitCode = 109402; //acres as default
        double _sqMetersPerAreaUnit = 4046.86;//for acres as default
      var _metersPerUnit = 0.3048;
      ParcelUtils parcelUtils = new();
          var myParcelFabricLayer =
            MapView.Active?.Map?.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      var featlyr = myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(parcelTypeName).Result.FirstOrDefault();
      foreach (var oid in oidList)
            {
              ParcelEdgeCollection parcelEdgeCollection = null;
              var tol = 0.03 / _metersPerUnit; //3 cms
                                         //if (!_isPCS)
                                         //  tol = Math.Atan(tol / (6378100 / _metersPerUnit));
              try
              {
          parcelEdgeCollection = await myParcelFabricLayer.GetSequencedParcelEdgeInfoAsync(featlyr,
                    oid, null, tol,
                    ParcelLineToEdgeRelationship.BothVerticesMatchAnEdgeEnd |
                    ParcelLineToEdgeRelationship.StartVertexMatchesAnEdgeEnd |
                    ParcelLineToEdgeRelationship.EndVertexMatchesAnEdgeEnd |
                    ParcelLineToEdgeRelationship.StartVertexOnAnEdge |
                    ParcelLineToEdgeRelationship.EndVertexOnAnEdge
              );
              }
              catch
              {
                continue;
              }

              if (parcelEdgeCollection == null)
                continue;

              var startPoint = parcelEdgeCollection.Edges[0].EdgeGeometry.Points[0].Coordinate2D;
              var radiusList = new List<double>();
              var arcLengthList = new List<double>();
              var isMajorList = new List<bool>();
              var traverseCourses = new List<Coordinate3D>();
              bool canTraverseCOGO = true; //optimistic outer
              foreach (var edge in parcelEdgeCollection.Edges)
              {
                bool edgeHasCOGOConnectivity = false; //pessimistic inner
                var highestPosition = 0.0;
                foreach (var myLineInfo in edge.Lines)
                {
                  //test for COGO attributes and line type
                  bool hasCOGODirection = myLineInfo.FeatureAttributes.TryGetValue("Direction", out object direction);
                  bool hasCOGODistance = myLineInfo.FeatureAttributes.TryGetValue("Distance", out object distance);
                  bool hasCOGORadius = myLineInfo.FeatureAttributes.TryGetValue("Radius", out object radius);
                  bool hasCOGOArclength = myLineInfo.FeatureAttributes.TryGetValue("ArcLength", out object arclength);
                  bool bIsCOGOLine = hasCOGODirection && hasCOGODistance;

                  //logic to exclude unwanted lines on this edge
                  if (!myLineInfo.HasNextLineConnectivity)
                    continue;
            if (myLineInfo.EndPositionOnParcelEdge > 1.0)
                    continue;
            if (myLineInfo.EndPositionOnParcelEdge < 0.0)
                    continue;
            if (myLineInfo.StartPositionOnParcelEdge > 1.0)
                    continue;
            if (myLineInfo.StartPositionOnParcelEdge < 0.0)
                    continue;
                  //also exclude historic lines
                  bool hasRetiredByGuid = myLineInfo.FeatureAttributes.TryGetValue("RetiredByRecord", out object guid);
                  if (hasRetiredByGuid && guid != DBNull.Value)
                    continue;

                  if (!bIsCOGOLine)
                  {
                    if (hasCOGODirection && hasCOGORadius && hasCOGOArclength) //circular arc
                    {
                      edgeHasCOGOConnectivity = true;
                      var dRadius = (double)radius;
                      var dArclength = (double)arclength;
                      double dCentralAngle = dArclength / dRadius;
                      var chordDistance = 2.0 * dRadius * Math.Sin(dCentralAngle / 2.0);
                      var flip = myLineInfo.IsReversed ? Math.PI : 0.0;

                      var radiansDirection = ((double)direction * Math.PI / 180.0) + flip;
                      Coordinate3D vect = new();
                      vect.SetPolarComponents(radiansDirection, 0.0, chordDistance);
                      if (parcelUtils.ClockwiseDownStreamEdgePosition(myLineInfo) == highestPosition)
                      {//this line's start matches last line's end
                        traverseCourses.Add(vect);
                        arcLengthList.Add(dArclength);
                        if (Math.Abs(dArclength / dRadius) > Math.PI)
                          isMajorList.Add(true);
                        else
                          isMajorList.Add(false);
                        if (myLineInfo.IsReversed)
                          radiusList.Add(-dRadius); //this is for properly calcluating area sector
                        else
                          radiusList.Add(dRadius);
                      }
                    }
                    else //not a cogo circular arc, nor a cogo line
                      continue;
                  }
                  else //this is a straight cogo line
                  {
                    var flip = myLineInfo.IsReversed ? Math.PI : 0.0;
                    edgeHasCOGOConnectivity = true;
                    var radiansDirection = ((double)direction * Math.PI / 180.0) + flip;
                    Coordinate3D vect = new();
                    vect.SetPolarComponents(radiansDirection, 0.0, (double)distance);
                    if (parcelUtils.ClockwiseDownStreamEdgePosition(myLineInfo) == highestPosition)
                    {//this line's start matches last line's end
                      traverseCourses.Add(vect);
                      arcLengthList.Add(0.0);
                      radiusList.Add(0.0);
                      isMajorList.Add(false);
                    }
                  }
                  if (edgeHasCOGOConnectivity)
                  {
                    var UpstreamPos = parcelUtils.ClockwiseUpStreamEdgePosition(myLineInfo);
                    highestPosition =
                      highestPosition > UpstreamPos ? highestPosition : UpstreamPos;
                  }
                }
          if (highestPosition != 1.0)
                //means we were not able to traverse all the way to the end of this edge without a loss of COGO connection
                {
                  canTraverseCOGO = false;
                  break;
                }
              }
              if (canTraverseCOGO)
              {
                var result = COGOUtils.CompassRuleAdjust(traverseCourses, startPoint, startPoint, radiusList, arcLengthList, isMajorList,
                  out Coordinate2D miscloseVector, out double dRatio, out double calcArea);
                Dictionary<string, object> ParcelAttributes = new Dictionary<string, object>();

                ParcelAttributes.Add("MiscloseDistance", miscloseVector.Magnitude);
                ParcelAttributes.Add("MiscloseRatio", dRatio);
                if (!Double.IsNaN(calcArea))
                {
                  ParcelAttributes.Add("CalculatedArea", calcArea);
                  var AreaSqMeters = calcArea * _metersPerUnit * _metersPerUnit;
                  if (AreaSqMeters >= largeParcelToleranceInSqMeters)
                  {
                    var areaInLargeParcelUnits = AreaSqMeters / _sqMetersPerAreaUnit;// example: 1 acre = 4046.86 sq.meters
                    ParcelAttributes.Add("StatedArea", areaInLargeParcelUnits.ToString("0.00"));
                    ParcelAttributes.Add("StatedAreaUnit", _largeParcelUnitCode);
                  }
                  else
                  {
                    ParcelAttributes.Add("StatedArea", calcArea.ToString("0"));
              if (_metersPerUnit < 1.0)
                      ParcelAttributes.Add("StatedAreaUnit", 109405); //use square foot
                    else
                      ParcelAttributes.Add("StatedAreaUnit", 109404); //use square meter
                  }
                }
          editOper2.Modify(featlyr, oid, ParcelAttributes);
                ParcelAttributes.Clear();
              }
            }

      return editOper2;
    }

  }
}
