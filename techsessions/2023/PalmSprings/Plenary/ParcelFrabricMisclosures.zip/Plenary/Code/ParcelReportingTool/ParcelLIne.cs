﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using TaxParcelPlenary.Helper;

namespace TaxParcelPlenary.ParcelReportingTool
{
  /// <summary>
  /// Use this delegate to catch Property changed events in ParcelLine
  /// </summary>
  /// <param name="propertyName">name of property (column) that was changed</param>
  /// <param name="oId">object id of the changed line</param>
  /// <param name="lineGeometry">Geometry of the changed line</param>
  /// <param name="newValue">new value for the changed property</param>
  delegate void ParcelLineChangedHandler(string propertyName, long oId, Geometry lineGeometry, object newValue);

  /// <summary>
  /// Represent a parcel boundary line to be displayed in a datagrid and returned by parcel reporting
  /// </summary>
  internal class ParcelLine : PropertyChangedBase
  {
    // static event
    public static event ParcelLineChangedHandler OnPropertyChanged;

    public void InvokeOnPropertyChanged(object newValue, [CallerMemberName] string propertyName = "")
    {
      if (OnPropertyChanged != null) OnPropertyChanged(propertyName, _Oid, _Shape, newValue);
    }

    private string _Text;
    private long _Oid;
    private Geometry _Shape;
    private double _Direction;
    private double _Distance;
    private double _Radius;
    private double _ArcLength;

    public ParcelLine(string text, long oid, Geometry shape, double direction, double distance, double radius, double arcLength)
    {
      _Text = text;
      _Oid = oid;
      _Shape = shape;
      _Direction = direction;
      _Distance = distance;
      _Radius = radius;
      _ArcLength = arcLength;
    }
    public string Text
    {
      get { return _Text; }
      set { SetProperty(ref _Text, value); }
    }
    public long Oid
    {
      get { return _Oid; }
      set { SetProperty(ref _Oid, value); }
    }
    public Geometry Shape
    {
      get { return _Shape; }
      set { SetProperty(ref _Shape, value); }
    }
    public double Direction
    {
      get { return _Direction; }
      set { SetProperty(ref _Direction, value); }
    }
    public double Distance
    {
      get { return _Distance; }
      set
      {
        SetProperty(ref _Distance, value);
        NotifyPropertyChanged(nameof(DistanceDiscrepancy));
        InvokeOnPropertyChanged(value);
      }
    }
    public double Radius
    {
      get { return _Radius; }
      set { SetProperty(ref _Radius, value); }
    }
    public double ArcLength
    {
      get { return _ArcLength; }
      set { 
        SetProperty(ref _ArcLength, value);
        NotifyPropertyChanged(nameof(ArcLengthDiscrepancy));
      }
    }

    public double ShapeLength
    {
      get
      {
        var shapeLength = 0.0;
        if (Shape is Multipart multipart)
        {
          shapeLength = multipart.Length;
        }
        return shapeLength; 
      }
    }

    public double DistanceDiscrepancy
    {
      get
      {
        var discrepancy = 0.0;
        if (!double.IsNaN(Distance))
        {
          discrepancy = Math.Abs(ShapeLength - Distance);
        }
        return discrepancy;
      }
    }

    public double ArcLengthDiscrepancy
    {
      get
      {
        var discrepancy = 0.0;
        
        if (!double.IsNaN (ArcLength))
        {
          discrepancy = Math.Abs(ShapeLength - ArcLength);
        }
        return discrepancy;
      }
    }

    public double Discrepancy
    {
      get
      {
        var discrepancy = 0.0;
        if (!double.IsNaN(ArcLength)) discrepancy += ArcLength;
        if (!double.IsNaN(Distance)) discrepancy += Distance;
        discrepancy = Math.Abs(ShapeLength - discrepancy);
        return discrepancy;
      }
    }
  }
}
