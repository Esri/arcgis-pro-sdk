﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Core.UnitFormats;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Mapping;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace TaxParcelPlenary.ParcelReportingTool
{
  internal class ParcelReporting
  {
    #region Private settings

    private DisplayUnitFormat _dialogDirectionUnit = null;
    private string _datasetUnitName = "meter";
    private double _datasetMetersPerUnit = 1.0;
    private bool _isPCS = true;

    private ParcelLayer _parcelFabricLayer;
    private List<FeatureLayer> _featureLayer;
    private readonly Dictionary<FeatureLayer, List<long>> dictLyr2IdsList = new Dictionary<FeatureLayer, List<long>>();

    #endregion

    #region Static Properties

    private static SpatialReference _VectorSpatialReference;

    internal static SpatialReference VectorSpatialReference
    {
      get
      {
        return _VectorSpatialReference;
      }
      private set
      {
        _VectorSpatialReference = value;
      }
    }

    #endregion

    #region Internal Worker Methods

    /// <summary>
    /// Call to Initialize ParcelReporting
    /// </summary>
    /// <returns></returns>
    internal async Task<bool> Initialize()
    {
      return await QueuedTask.Run<bool>(() =>
      {
        _parcelFabricLayer = MapView.Active?.Map?.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        if (_parcelFabricLayer == null)
        {
          //No parcel fabric found in the map.
          throw new Exception("No parcel fabric found in this map");
        }

        _featureLayer = new List<FeatureLayer>();
        var parcelTypes = _parcelFabricLayer.GetParcelTypeNamesAsync().Result;

        foreach (var parcelType in parcelTypes)
        {
          var fLyr = _parcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(parcelType).Result.FirstOrDefault();
          if (fLyr != null)
          {
            _featureLayer.Add(fLyr);
          }
        }
        if (parcelTypes.Count == 0)
        {
          throw new Exception("No parcel types were found in this parcel fabric");
        }
        FeatureClassDefinition fcDefinition = _featureLayer[0].GetFeatureClass().GetDefinition();
        if (fcDefinition == null)
        {
          throw new Exception("Cannot open the FeatureClass definition for Parcel Type");
        }

        VectorSpatialReference = fcDefinition.GetSpatialReference();
        if (fcDefinition.GetSpatialReference()?.IsProjected ?? false)
        {
          _datasetUnitName = fcDefinition.GetSpatialReference()?.Unit.Name.ToLower().Replace("foot_us", "ft");
          _datasetMetersPerUnit = fcDefinition.GetSpatialReference().Unit.ConversionFactor;
          _isPCS = true;
        }
        else
        {
          _datasetUnitName = "meter";
          _isPCS = false;
        }
        return true;
      });
    }

    /// <summary>
    /// Get the parcel report using the “Start Point Hint” geometry (usually the click location)
    /// </summary>
    /// <param name="polygonLayer">parcel layer</param>
    /// <param name="parcelOid">parcel Object ID</param>
    /// <returns></returns>
    internal async Task<(string ParcelName, string ParcelUnits, List<string> ParcelTexts,
                          ObservableCollection<ParcelLine> ParcelLines)> GetParcelReportAsync(FeatureLayer polygonLayer, long parcelOid)
    {
      var parcUtils = new ParcelUtils();
      var parcelName = string.Empty;
      var parcelUnits = "Units: " + _datasetUnitName + ", sq " + _datasetUnitName + Environment.NewLine;
      var parcelTexts = new List<string>();
      var parcelLines = new ObservableCollection<ParcelLine>();
      var insp = new ArcGIS.Desktop.Editing.Attributes.Inspector();

      try
      {
        await QueuedTask.Run(async () =>
        {
          #region get the direction format and units from the backstage default settings
          _dialogDirectionUnit =
            DisplayUnitFormats.Instance.GetDefaultProjectUnitFormat(UnitFormatType.Direction);
          ParcelEdgeCollection parcelEdgeCollectionForTraverse = null;
          #endregion 



          try
          {
    #region Get parcel boundary lines in a clockwise order. (Pro 3.0 Parcel API)
            FeatureLayer parcelLayer = null;
            foreach (var lyr in _featureLayer)
            {
              if (!lyr.IsVisibleInView(MapView.Active))
                continue;
              parcelLayer = lyr;
              break;
            }
            insp.Load(polygonLayer, parcelOid);
            parcelName = insp["Name"] as string;
            var tangencyTolerance = 0.03 / _datasetMetersPerUnit; //3 cms
            if (!_isPCS)
              tangencyTolerance = Math.Atan(tangencyTolerance / (6378100 / _datasetMetersPerUnit));

            var HintStartPoint =
              MapPointBuilderEx.CreateMapPoint(MapView.Active.Extent.XMin,
               MapView.Active.Extent.YMin);

            #endregion

            if (Module1.InDebugCycle)
              System.Diagnostics.Trace.WriteLine(
                "Get parcel lines in clockwise order to calculate traverse.");

            parcelEdgeCollectionForTraverse = 
                await _parcelFabricLayer.GetSequencedParcelEdgeInfoAsync(
                parcelLayer,
                parcelOid, HintStartPoint, tangencyTolerance,
                ParcelLineToEdgeRelationship.BothVerticesMatchAnEdgeEnd |
                ParcelLineToEdgeRelationship.StartVertexMatchesAnEdgeEnd |
                ParcelLineToEdgeRelationship.EndVertexMatchesAnEdgeEnd |
                ParcelLineToEdgeRelationship.StartVertexOnAnEdge |
                ParcelLineToEdgeRelationship.EndVertexOnAnEdge);
          }

          #region use parcel line sequence to compute traverse and display Parcel Report

          catch (Exception ex)
          {
            var parName = string.Empty;
            if (parcelName == String.Empty || parcelName == null)
              parName = $@"Parcel: -- (oid: {parcelOid})";
            else
              parName = $@"Parcel: {parcelName}";
            parcelTexts.Add(parName);
            parcelTexts.Add("No lines found for parcel polygon.");
            throw (new Exception($@"Error getting Parcel Report: No lines found for parcel polygon. [{ex}]"));
          }
          if (parcelEdgeCollectionForTraverse == null)
          {
            throw (new Exception($@"Error getting Parcel Report: Get retrieve the Edge Collection for this parcel."));
          }
          bool isClosedloop = false;
          bool hasCogoInfo = false;
          (List<TraverseDetail> VectorCoordsAndGeometries,
           List<object> Directions,
           List<object> Distances, List<object> Radii,
           List<object> ArcLengths, List<bool> IsMajors,
           List<bool> IsReversedLines) traverse;

          #endregion
          if (!parcUtils.DisplayTraverseCalcMisclosure(
                parcelEdgeCollectionForTraverse,
                out isClosedloop, 
                out hasCogoInfo, 
                out traverse))
          {
            parcelTexts.Add("No traverse information available.");
          }

          var radiusList = new List<double>();
          foreach (var radiusObj in traverse.Radii)
          {
            double radius = 0.0;
            if (radiusObj != null)
              radius = (double)radiusObj;
            radiusList.Add(radius);
          }

          var arcLengthList = new List<double>();
          foreach (var arcLengthObj in traverse.ArcLengths)
          {
            double arcLength = 0.0;
            if (arcLengthObj != null)
              arcLength = (double)arcLengthObj;
            arcLengthList.Add(arcLength);
          }

          var isMajorList = traverse.IsMajors;
          {
            var parName = string.Empty;
            if (string.IsNullOrEmpty(parcelName))
              parName = $@"Parcel: -- (oid: {parcelOid})";
            else
              parName = $@"Parcel: {parcelName}";
            parcelTexts.Add(parName);
          }
          if (isClosedloop && hasCogoInfo)
          {
            #region line info strings for traverse
            var startPoint = parcelEdgeCollectionForTraverse.Edges[0].EdgeGeometry.Points[0].Coordinate2D;
            var traverseCourses = new List<TraverseDetail>();
            foreach (var vecGeometry in traverse.VectorCoordsAndGeometries)
              traverseCourses.Add(vecGeometry);
            var result = COGOUtils.CompassRuleAdjust(traverseCourses.Select(v => v.Coordinates).ToList(), startPoint, startPoint, radiusList, arcLengthList, isMajorList,
              out Coordinate2D miscloseVector, out double dRatio, out double cogoArea);
            parcelTexts.Add($@"Misclose ratio: 1:{dRatio:F0}");
            parcelTexts.Add($@"COGO Area: {cogoArea:F0} sq {_datasetUnitName}");
            parcelTexts.Add($@"{Module1.MisclosurePrefix}{miscloseVector.Magnitude:F2} {_datasetUnitName}");

            // Get lines in clockwise order
            //
            //parcelTexts.Add("Clockwise lines:");
            var idx = 0;
            foreach (var vecGeometry in traverseCourses)
            {
              var direction = COGOUtils.ConvertNorthAzimuthDecimalDegreesToDisplayUnit(vecGeometry.Coordinates.Azimuth * 180.0 / Math.PI, _dialogDirectionUnit);
              var description = radiusList[idx] == 0.0 ?
                            $@"  {direction}, {vecGeometry.Coordinates.Magnitude:F2}"
                          : $@"  {direction}, {vecGeometry.Coordinates.Magnitude:F2}, Radius: {radiusList[idx]:F2}, Arclength: {arcLengthList[idx]:F2}";
              parcelLines.Add(new ParcelLine(description, vecGeometry.LineObjectId, vecGeometry.LineGeometry, vecGeometry.Direction, vecGeometry.Distance, vecGeometry.Radius, vecGeometry.ArcLength));
              idx++;
            }
            #endregion
          }
          else
          {
            if (isClosedloop && !hasCogoInfo)
              parcelTexts.Add("Lines form a closed loop, but there is not enough COGO information to calculate misclose.");
            else if (!isClosedloop && hasCogoInfo)
              parcelTexts.Add("All lines found have COGO information, but they do not form a closed loop.");
            else if (!isClosedloop && !hasCogoInfo)
              parcelTexts.Add("Lines do not form a closed loop, and one or more lines are missing COGO information.");

            #region line info strings for non-traverse
            int idx = 0;
            int iLeng = (traverse.Directions).Count();
            string[] directionStr = new string[iLeng];
            string[] distanceStr = new string[iLeng];
            string[] radiusStr = new string[iLeng];
            string[] arcLengthStr = new string[iLeng];

            foreach (var dir in traverse.Directions)
            {
              if (dir != null)
              {
                var direction = (double)dir;
                var sVal = COGOUtils.ConvertNorthAzimuthDecimalDegreesToDisplayUnit(direction, _dialogDirectionUnit);
                directionStr[idx++] = sVal;
              }
              else
                directionStr[idx++] = "--";
            }
            idx = 0;
            foreach (var dist in traverse.Distances)
            {
              if (dist != null)
              {
                var distance = (double)dist;
                distanceStr[idx++] = distance.ToString("F2");
              }
              else
                distanceStr[idx++] = "--";
            }
            idx = 0;
            foreach (var rad in traverse.Radii)
            {
              if (rad != null)
              {
                var radius = (double)rad;
                radiusStr[idx++] = radius.ToString("F2");
              }
              else
                radiusStr[idx++] = "--";
            }
            idx = 0;
            foreach (var arc in traverse.ArcLengths)
            {
              if (arc != null)
              {
                var arclength = (double)arc;
                arcLengthStr[idx++] = arclength.ToString("F2");
              }
              else
                arcLengthStr[idx++] = "--";
            }

            parcelTexts.Add("Lines: ");
            idx = 0;
            foreach (string dir in directionStr)
            {
              if (radiusStr[idx] == "--" && arcLengthStr[idx] == "--")
              {
                parcelTexts.Add($@"  {dir}, {distanceStr[idx]}");
              }
              else if (radiusStr[idx] != "--" && arcLengthStr[idx] == "--")
              {
                parcelTexts.Add($@"  {dir}, Radius: {radiusStr[idx]}, {arcLengthStr[idx]}");
              }
              else if (radiusStr[idx] == "--" && arcLengthStr[idx] != "--")
              {
                parcelTexts.Add($@"  {dir}, {radiusStr[idx]}, ArcLength: {arcLengthStr[idx]}");
              }
              else if (radiusStr[idx] != "--" && arcLengthStr[idx] != "--")
              {
                parcelTexts.Add($@"  {dir}, Radius: {radiusStr[idx]}, ArcLength: {arcLengthStr[idx]}");
              }
              idx++;
            }
            #endregion

          }
        });
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(e.ToString());
      }
      return (parcelName, parcelUnits, parcelTexts, parcelLines);
    }

    #endregion

  }
}
