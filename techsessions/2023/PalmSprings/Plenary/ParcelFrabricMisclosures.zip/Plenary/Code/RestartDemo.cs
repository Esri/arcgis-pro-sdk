﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using TaxParcelPlenary.Helper;

namespace TaxParcelPlenary
{
  internal class RestartDemo : Button
  {
    protected override async void OnClick()
    {
      try
      {
        #region CAMA settings

        //// close the CAMA table view as the active view
        //var camaTable = MapView.Active.Map.GetStandaloneTablesAsFlattenedList().OfType<StandaloneTable>().Where(fl => fl.Name.Equals("Changes to CAMA")).FirstOrDefault();
        //if (camaTable == null) return;
        //QueuedTask.Run(() =>
        //{
        //  camaTable.GetTable().DeleteRows(new QueryFilter());
        //});
        //Module1.ChangeConditionState("state_CamaPostReady", false);
        //Module1.ChangeConditionState("state_AddToCAMA", false);
        //Module1.ChangeConditionState("state_DisasterOverlay", false);
        //// close table panes
        //var lstMapMembers = new List<MapMember>
        //{
        //  camaTable
        //};
        //foreach (var mapMember in lstMapMembers)
        //  Module1.CloseTablePane(mapMember);

        #endregion

        // discard all edits
        _ = Project.Current.DiscardEditsAsync();

        // activate the TAX (parcel) table view as the active view
        var taxTable = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(Module1.TaxParcelPolygonLayerName)).FirstOrDefault();
        if (taxTable == null) return;
        await QueuedTask.Run(() => taxTable.ClearSelection());

        // reset the caption to the default table name
        var iTaxTablePane = Module1.OpenAndActivateTablePane(taxTable);
        if (iTaxTablePane == null || iTaxTablePane as ITablePaneEx == null) return;
          (iTaxTablePane as ITablePaneEx).Caption = taxTable.Name;

        // run on UI thread
        await Task.Delay(new TimeSpan(0, 0, 3)).ContinueWith(o =>
        {
          System.Windows.Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
          {
            ResetTableView((iTaxTablePane as ITablePaneEx).TableView);            
            // toggle the debug mode
            Module1.Restart();
          });
        });

        //// activate the TAX Line (parcel boundaries) table view as the active view
        //var taxLineTable = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(Module1.TaxParcelLineLayerName)).FirstOrDefault();
        //if (taxLineTable == null) return;

        //// reset the caption to the default table name
        //var iTaxLineTablePane = Module1.OpenAndActivateTablePane(taxLineTable);
        //if (iTaxLineTablePane == null || iTaxLineTablePane as ITablePaneEx == null) return;
        //(iTaxLineTablePane as ITablePaneEx).Caption = taxLineTable.Name;

        //// run on UI thread
        //await Task.Delay(new TimeSpan(0, 0, 3)).ContinueWith(o =>
        //{
        //  System.Windows.Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
        //  {
        //    ResetTableView((iTaxLineTablePane as ITablePaneEx).TableView);

        //  });
        //});
      }
      catch (Exception ex)
      {
        throw new Exception($@"Error: {ex.Message}");
      }
    }

    /// <summary>
    /// Reset the table views
    /// </summary>
    /// <param name="tableView">table View</param>
    private static async void ResetTableView(TableView tableView)
    {
      if (tableView == null || tableView.IsReady == false)
      {
        DiagnosticHelper.WriteLine(tableView == null ? "Active TableView is null" : "Active TableView is not ready");
        return;
      }
      // set visible and hidden columns
      tableView.ShowAllFields();

      // clear and reset frozen fields
      await tableView.ClearAllFrozenFieldsAsync();

      await tableView.SetViewMode(TableViewMode.eAllRecords);
      tableView.SetZoomLevel(100);
    }
  }
}
