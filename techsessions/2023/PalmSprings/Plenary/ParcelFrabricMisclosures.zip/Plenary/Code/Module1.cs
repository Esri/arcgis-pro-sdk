﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Mapping;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Threading;

namespace TaxParcelPlenary
{
  internal class Module1 : Module
  {
    internal static List<string> RegisteredFeatureLayers = new();
    internal static readonly string TaxParcelPolygonLayerName = "Tax";
    internal static readonly string TaxParcelLineLayerName = "Tax_Lines";
    internal static readonly string MisclosurePrefix = "Misclose distance: ";
    internal static readonly double MisclosureMinDistance = 0.10;
    internal static readonly double DistanceDiscrepanyAlert = 0.10; // change cell color for discrepancy to red if discrepany is more
    internal static readonly List<string> TaxTableHiddenFields = new() { "Shape", "CreatedByRecord", "RetiredByRecord", "CalculatedArea", "IsSeed", "created_user", "created_date", 
      "last_edited_user", "last_edited_date", "Shape_Length", "Shape_Area", "GlobalID","VALIDATIONSTATUS"};
    internal static readonly List<string> TaxTableFrozenFields = new() { "Name" };
    internal static readonly List<string> TaxLineTableHiddenFields = new() { "Shape", "CreatedByRecord", "RetiredByRecord", "ParentLineID", "Radius2", "COGOType", "IsCOGOGround", "Rotation", "Scale", "DirectionAccuracy", "DistanceAccuracy", "created_user", "created_date", "last_edited_user", "last_edited_date", "GlobalID", "VALIDATIONSTATUS", "LabelPosition" };
    internal static readonly List<string> TaxLineTableFrozenFields = new() { "OBJECTID" };
    internal static readonly string MisclosedTaxParcelTableCaption = "Tax Parcels";
    internal static readonly string TaxLinesTableCaption = "Boundary Lines";
    internal static IReadOnlyList<long> SampleTaxParceelOids = new List<long>() { 13543 };  //  13543, 13544 
    internal static readonly string PlatOnOffLayerName = "Plat Scans";
    internal static readonly Dictionary<string, int> TaxLineSignificantDigits = new Dictionary<string, int>() { { "Distance", 2 }, { "Direction", 2 }, { "Radius", 2 }, { "ArcLength", 2 }, { "Shape_Length", 2 } };
    internal static readonly Dictionary<string, int> TaxSignificantDigits = new Dictionary<string, int>() { { "StatedArea", 0 }, { "CalculatedArea", 0 }, { "MiscloseRatio", 0 }, { "MiscloseDistance", 2 }, { "Shape_Area", 0 } };

    private static Module1 _this = null;
    
    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("TaxParcelPlenary_Module");

    protected override bool Initialize()
    {
      InDebugCycle = false;
      // subscribe to events to determine if a feature class needs the custom attribute tab
      ActiveMapViewChangedEvent.Subscribe(OnActiveMapViewChanged);
      // subscribe to map view initialized in order to add required table views
      MapViewInitializedEvent.Subscribe(new Action<MapViewEventArgs>((mapViewEventArgs) =>
      {
        var map = mapViewEventArgs.MapView?.Map;
        if (map != null)
        {
          var showTableView4MapMembers = new List<MapMember>();
          var featLayers = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().ToList();
          foreach (var featLayer in featLayers)
          {
            if (featLayer.Name.Equals (Module1.TaxParcelPolygonLayerName))
              showTableView4MapMembers.Add(featLayer);
          }
          // We can only open the table views we need after the mapview has been initialized
          if (showTableView4MapMembers.Count > 0)
          {
            Task.Delay(new TimeSpan(0, 0, 3)).ContinueWith(o =>
            {
              System.Windows.Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
              {
                foreach (var showTableView in showTableView4MapMembers)
                  OpenAndActivateTablePane(showTableView);
              });
            });
          }
        }
      }));
      return base.Initialize();
    }

    /// <summary>
    /// A new MapView is incoming
    /// </summary>
    /// <param name="args"></param>
    private static void OnActiveMapViewChanged(ActiveMapViewChangedEventArgs args)
    {
      Map incomingMap = args?.IncomingView?.Map;
      if (incomingMap == null) return;
      // process each layer to see if the layer needs the custom attribute tab
      var featLayers = incomingMap.GetLayersAsFlattenedList().OfType<FeatureLayer>().ToList();
      foreach (var featLayer in featLayers)
      {
        RegisterFeatureClassGuidAsync(featLayer);
      }
    }

    #region Register Guid with Feature Class to add Custom Tab to Edit Attributes Dockpane

    /// <summary>
    /// Register Feature Class with GUID defined in config.daml categories
    /// </summary>
    /// <param name="featureLayer"></param>
    internal static async void RegisterFeatureClassGuidAsync(FeatureLayer featureLayer)
    {
      await QueuedTask.Run(() =>
      {
        //note: These methods must be called on the Main CIM Thread. Use QueuedTask.Run.
        var fc = featureLayer.GetFeatureClass();
        if (fc == null) return;
        var fcName = fc.GetName();
        if (!fcName.Equals(Module1.TaxParcelPolygonLayerName)) return;

        var fcDefintion = fc.GetDefinition();
        if (fcDefintion == null) return;

        // remember the registration
        if (!RegisteredFeatureLayers.Contains(fcName))
        {
          RegisteredFeatureLayers.Add(fcName);

          // This Guid defines the "Custom Tab" in the config.daml
          Guid extension = new("{92d93d89-b4e8-4fce-895f-676f85d1a09d}");
          fc.AddActivationExtension(extension);
        }
      });
    }

    #endregion Register Guid with Feature Class to support Custom Tab to Edit Attributes Dockpane

    #region Demo Functions

    internal static bool InDebugCycle { get; private set; }

    internal static void Restart()
    {
      InDebugCycle = !InDebugCycle;
    }

    #endregion

    #region Utility Functions

    /// <summary>
    /// utility function to open and activate the TablePane for a given MapMember
    /// </summary>
    /// <param name="mapMember">table to have the table view activated</param>
    internal static ITablePane OpenAndActivateTablePane(MapMember mapMember)
    {
      try
      {
        // check the open panes to see if it's open but just needs activating
        IEnumerable<ITablePane> tablePanes = FrameworkApplication.Panes.OfType<ITablePane>();
        foreach (var tablePane in tablePanes)
        {
          if (tablePane.MapMember != mapMember) continue;
          var pane = tablePane as Pane;
          pane?.Activate();
          return pane as ITablePane;
        }
        // it's not currently open... so open it
        if (FrameworkApplication.Panes.CanOpenTablePane(mapMember))
        {
          return FrameworkApplication.Panes.OpenTablePane(mapMember);
        }
        return null;
      }
      catch (Exception ex)
      {
        throw new Exception($@"Error in OpenAndActivateMap: {ex.Message}");
      }
    }

    /// <summary>
    /// utility function to find the TablePane for a given MapMember
    /// </summary>
    /// <param name="mapMember">table to have the table view activated</param>
    internal static ITablePane GetTablePaneForMapMember(MapMember mapMember)
    {
      try
      {
        // check the open panes to see if it's open but just needs activating
        IEnumerable<ITablePane> tablePanes = FrameworkApplication.Panes.OfType<ITablePane>();
        foreach (var tablePane in tablePanes)
        {
          if (tablePane.MapMember != mapMember) continue;
          var pane = tablePane as Pane;
          pane?.Activate();
          return pane as ITablePane;
        }
        // it's not currently open... so open it
        if (FrameworkApplication.Panes.CanOpenTablePane(mapMember))
        {
          return FrameworkApplication.Panes.OpenTablePane(mapMember);
        }
        return null;
      }
      catch (Exception ex)
      {
        throw new Exception($@"Error in OpenAndActivateMap: {ex.Message}");
      }
    }

    internal static void CloseTablePane(MapMember mapMember)
    {
      // check the open panes to see if it's open but just needs activating
      IEnumerable<ITablePane> tablePanes = FrameworkApplication.Panes.OfType<ITablePane>();
      foreach (var tablePane in tablePanes)
      {
        if (tablePane.MapMember != mapMember) continue;
        var pane = tablePane as Pane;
        pane?.Close();
      }
    }

    internal static void ChangeConditionState (string condition, bool state)
    {
      if (state)
      {
        // set state to true => activate it
        if (!FrameworkApplication.State.Contains(condition))
        {
          FrameworkApplication.State.Activate(condition); //activates the state
        }
      }
      else
      {
        // set state to false => deactivate it
        if (FrameworkApplication.State.Contains(condition))
        {
          FrameworkApplication.State.Deactivate(condition); //activates the state
        }
      }
    }

    #endregion

    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

  }
}
