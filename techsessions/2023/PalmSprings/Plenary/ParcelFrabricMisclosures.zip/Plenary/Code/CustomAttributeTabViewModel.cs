﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Mapping;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Threading;
using System.Xml.Linq;
using TaxParcelPlenary.Helper;
using TaxParcelPlenary.ParcelReportingTool;

namespace TaxParcelPlenary
{
  internal class CustomAttributeTabViewModel : AttributeTabEmbeddableControl
  {
    private FeatureLayer _parcelLineFeatureLayer = null;
    private FeatureLayer _parcelPolygonFeatureLayer = null;
    private long _parcelObjectId = -1;
    private Geometry _parcelGeometry = null;

    private static ParcelReporting _ParcelReporting;
    private static System.IDisposable _overlayObject = null;
    private CIMSymbolReference _symbolReferenceLine;
    private bool _taxTableViewSynced = false;
    private bool _taxLineTableViewInitilized = false;

    private ObservableCollection<ParcelLine> _ParcelLines;
    private (string ParcelName,
      string ParcelUnits,
      List<string> ParcelTexts,
      ObservableCollection<ParcelLine> ParcelLines) _ParcelReportResult;



    public CustomAttributeTabViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) 
    {
      var flowDocument = new FlowDocument();
      var run = new Run("No Parcel has been selected");
      run.Foreground = System.Windows.Media.Brushes.Red;
      flowDocument.Blocks.Add(new Paragraph(run));
      ParcelStatus = System.Windows.Markup.XamlWriter.Save(flowDocument);
      PlatOnOff = "Show Plat";
    }

    /// <summary>
    /// Called when any parcel line property has been updated
    /// </summary>
    /// <param name="propertyName">Name of property that was update</param>
    /// <param name="oId">object id of line that was updated</param>
    /// <param name="lineGeometry">geometry of line that was changed</param>
    /// <param name="newValue">New value for the updated property</param>
    private void ParcelLine_OnPropertyChanged(string propertyName, long oId, Geometry lineGeometry, object newValue)
    {
      DiagnosticHelper.Start();
      if (_parcelLineFeatureLayer == null)
      {
        System.Diagnostics.Trace.WriteLine($@"Error: no line feature layer: {propertyName} new value: {newValue}");
        _parcelLineFeatureLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where((r) => r.Name.Equals(Module1.TaxParcelLineLayerName)).FirstOrDefault();
if (_parcelLineFeatureLayer == null)
        return;
      }
      try
      {
        var changeInspector = new Inspector();
        QueuedTask.Run(async () =>
        {
          changeInspector.Load(_parcelLineFeatureLayer, oId);
          //get geometry of the line
          var shapeFldName = _parcelLineFeatureLayer.GetFeatureClass().GetDefinition().GetShapeField();
          var lineGeometry = changeInspector[shapeFldName] as Geometry;
          var thinBufferPolygon = GeometryEngine.Instance.Buffer(lineGeometry, 1.0) as Polygon;
          var centroid = GeometryEngine.Instance.Centroid(thinBufferPolygon);
          var searchGeometry = GeometryEngine.Instance.Buffer(centroid, 1.0) as Polygon;
          //search geometry is a 1 foot circle midway along the line

          // define the spatial query filter
          var spatialQuery = new SpatialQueryFilter()
          {
            FilterGeometry = searchGeometry,
            SpatialRelationship = SpatialRelationship.Intersects
          };

          var fc = _parcelPolygonFeatureLayer.GetFeatureClass();
          List<long> lstOids = new();
          spatialQuery.WhereClause = _parcelPolygonFeatureLayer.DefinitionQuery;
          using (RowCursor rowCursor = fc.Search(spatialQuery))
          {
            while (rowCursor.MoveNext())
            {
              using (Row rowFeat = rowCursor.Current)
              {
                lstOids.Add(rowFeat.GetObjectID());
              }
            }
          }

          var editOper = new EditOperation()
          {
            Name = $@"Change value for {_parcelLineFeatureLayer.Name}.{propertyName}",
            SelectModifiedFeatures = false
          };
          changeInspector[propertyName] = newValue;
          editOper.Modify(changeInspector);

          // update the misclose data and area for all adjoining parcels
          var editOper2 = await ParcelUpdates.UpdateLineAndMiscloseAreaAsync("Tax", 
                                                                        lstOids, editOper);
          var result = false;
          if (editOper2 != null)
            result = editOper2.Execute();
          if (result != true || editOper.IsSucceeded != true)
            throw new Exception($@"Update failed: {editOper.ErrorMessage}");

          _ = Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, (Action)(async () =>
          {
            _ParcelReportResult = await _ParcelReporting.GetParcelReportAsync(_parcelPolygonFeatureLayer, _parcelObjectId);

            ParcelStatus = ParcelStatus = System.Windows.Markup.XamlWriter.Save(GetFlowDocFromParcelText(_ParcelReportResult.ParcelTexts));
            ParcelLines = _ParcelReportResult.ParcelLines;

          }));
        });
      }
      catch (Exception ex)
      {
        ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($@"Unable to update {_parcelLineFeatureLayer.Name}: [{ex}]");
      }
    }

    #region AttributeTabEmbeddableContent overrides

    /// <summary>
    /// Does this control (and it's parent tab) apply to this MapMember.  Default is false. 
    /// </summary>
    /// <param name="mapMember"></param>
    /// <returns>
    /// If the return value is false, a custom tab containing this control will not be displayed 
    /// when a row from Mapmember is highlighted in the attributes treeview. 
    /// </returns>
    public override bool Applies(MapMember mapMember)
    {
      #region Applies method-override. Custom tab pattern. New in Pro API at 3.1.
      DiagnosticHelper.Start();

      var confirmLayerApplies = true;
      _parcelPolygonFeatureLayer = mapMember as FeatureLayer;
      if (_parcelPolygonFeatureLayer == null) return false;
      #endregion
      if (Module1.InDebugCycle)
      {
        System.Diagnostics.Trace.WriteLine(
          "Custom tab pattern - new at 3.1");
      }

      //Confirm selected feature is in a parcel fabric layer...
      confirmLayerApplies = 
        _parcelPolygonFeatureLayer.Name.Equals(
          Module1.TaxParcelPolygonLayerName);

      // initialize our custom tab
      if (confirmLayerApplies)
      {
        try
        {
          if (MapView.Active?.Map == null)
          {
            // the Map has not been initialized
            ActiveMapViewChangedEvent.Subscribe((args) =>
            {
              {
                Map incomingMap = args?.IncomingView?.Map;
                if (incomingMap == null) return;
                if (_ParcelReporting == null)
                {
                  _ParcelReporting = new ParcelReporting();
                  _ = _ParcelReporting.Initialize();
                  _parcelLineFeatureLayer = incomingMap.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where((r) => r.Name.Equals(Module1.TaxParcelLineLayerName)).FirstOrDefault();
                }
              }
            });
          }
          else
          {
            if (_ParcelReporting == null)
            {
              _ParcelReporting = new ParcelReporting();
              _ = _ParcelReporting.Initialize();
              _parcelLineFeatureLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where((r) => r.Name.Equals(Module1.TaxParcelLineLayerName)).FirstOrDefault();
            }
          }
        }
        catch (Exception ex)
        {
          ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show(ex.ToString());
          confirmLayerApplies = false;
          _ParcelReporting = null;
        }
      }
      
      return confirmLayerApplies;
    }

    /// <summary>
    /// Is the parent tab default.  Default is false.
    /// </summary>
    public override bool IsDefault => false;

    /// <summary>
    /// Does this control (and it's parent tab) support selection of multiple rows in the Attribute treeview.
    /// Default is false.
    /// </summary>
    public override bool SupportsMultiples => base.SupportsMultiples;

    /// <summary>
    /// Called when attributes from one or more rows have been loaded into the Inspector
    /// </summary>
    /// <returns></returns>
    public async override Task LoadFromFeaturesAsync()
    {
      try
      {
        DiagnosticHelper.Start();

        ParcelLine.OnPropertyChanged -= ParcelLine_OnPropertyChanged;

        // Inspector of the base class is already loaded with the current selected record
        var inspector = this.Inspector;
        if (_parcelPolygonFeatureLayer == null || inspector?.MapMember == null) return;
        if (inspector.MapMember != _parcelPolygonFeatureLayer)
        {
          DiagnosticHelper.WriteLine($@"Inspect MapMember: {inspector.MapMember.Name} vs. Applies(MapMember): {_parcelPolygonFeatureLayer.Name}");
          return;
        }
        _parcelObjectId = inspector.ObjectID;
        if (_parcelObjectId < 0)
        {
          if (inspector.OIDSet.Count > 0)
            _parcelObjectId = inspector.OIDSet[0];
          if (_parcelObjectId < 0)
          {
            return;
          }
        }
        var geometryInspector = new Inspector();
        _parcelGeometry = await QueuedTask.Run<Geometry>(() =>
        {
          geometryInspector.Load(_parcelPolygonFeatureLayer, _parcelObjectId);
          Geometry geom = geometryInspector?.Shape?.Clone();
          if (geom != null)
          {
            var polyLine = geom as Polyline;
            if (polyLine != null)
            {
              geom = polyLine.Points[0];
            }
            //MapView.Active.ZoomTo(geom.Extent.Expand(1.5, 1.5, true));
          }
          return geom;
        });
        _ParcelReportResult = await _ParcelReporting.GetParcelReportAsync(_parcelPolygonFeatureLayer, _parcelObjectId);

        ParcelStatus = System.Windows.Markup.XamlWriter.Save(GetFlowDocFromParcelText (_ParcelReportResult.ParcelTexts));
        ParcelLines = _ParcelReportResult.ParcelLines;

        ParcelLine.OnPropertyChanged += ParcelLine_OnPropertyChanged;
      }
      catch (Exception ex)
      {
        System.Diagnostics.Trace.WriteLine($@"Exception in LoadFromFeatureAsync: {ex}");
      }
    }

    #endregion

    #region MVVM Properties and ICommands

    public ICommand ZoomToParcelCmd
    {
      get
      {
        return new RelayCommand(() =>
        {
          if (MapView.Active == null) return;
          if (_parcelGeometry!= null)
          {
            MapView.Active.ZoomToAsync(_parcelGeometry.Extent.Expand(1.5, 1.5, true));
          }
        }, true);
      }
    }

    public System.Windows.Media.ImageSource ZoomToParcelImage
    {
      get { return System.Windows.Application.Current.Resources["SelectionZoomToSelected16"] as System.Windows.Media.ImageSource; }
    }

    public ICommand ShowTableViewCmd => new RelayCommand(() =>
    {
      if (MapView.Active == null) return;
      if (_parcelGeometry != null)
      {
        DiagnosticHelper.Start();

        _taxTableViewSynced = !_taxTableViewSynced;
        _taxLineTableViewInitilized = false;

        // activate the TAX (parcel) table view as the active view
        var taxTable = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(Module1.TaxParcelPolygonLayerName)).FirstOrDefault();
        if (taxTable == null) return;

        // override the default title of the TablePane
        var iTaxTablePane = Module1.OpenAndActivateTablePane(taxTable);
        if (iTaxTablePane == null || iTaxTablePane as ITablePaneEx == null) return;
        (iTaxTablePane as ITablePaneEx).Caption = _taxTableViewSynced ? Module1.MisclosedTaxParcelTableCaption : taxTable.Name;

        // run on UI thread
        _ = Task.Delay(new TimeSpan(0, 0, 3)).ContinueWith(o =>
        {
          Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
          {
            if (_taxTableViewSynced)
              ShowCustomTableView((iTaxTablePane as ITablePaneEx).TableView, Module1.TaxTableHiddenFields, Module1.TaxTableFrozenFields, TableViewMode.eSelectedRecords);
            else
              ShowDefaultTableView((iTaxTablePane as ITablePaneEx).TableView);
          });
        });
      }
    }, true);

    public System.Windows.Media.ImageSource ShowTableViewImage
    {
      get { return System.Windows.Application.Current.Resources["TableRelatedData16"] as System.Windows.Media.ImageSource; }
    }

    private string _ParcelStatus;

    public string ParcelStatus
    {
      get { return _ParcelStatus; }
      set
      {
        SetProperty(ref _ParcelStatus, value);
      }
    }

    private bool _PlatIsChecked;

    public bool PlatIsChecked
    {
      get { return _PlatIsChecked; }
      set
      {
        SetProperty(ref _PlatIsChecked, value);
        _ = ShowHidePlatAsync(_PlatIsChecked);
      }
    }

    private string _PlatOnOff;

    public string PlatOnOff
    {
      get { return _PlatOnOff; }
      set
      {
        SetProperty(ref _PlatOnOff, value);
      }
    }

    private bool _LabelsIsChecked = true;

    public bool LabelsIsChecked
    {
      get { return _LabelsIsChecked; }
      set
      {
        SetProperty(ref _LabelsIsChecked, value);
        _ = ShowHideLabelsAsync(_LabelsIsChecked);
      }
    }

    public ObservableCollection<ParcelLine> ParcelLines
    {
      get { return _ParcelLines; }
      set
      {
        SetProperty(ref _ParcelLines, value);
      }
    }

    private ParcelLine _ParcelLineSelected;

    public ParcelLine ParcelLineSelected
    {
      get { return _ParcelLineSelected; }
      set
      {
        SetProperty(ref _ParcelLineSelected, value);
        if (MapView.Active != null)
        {
          if (_ParcelLineSelected == null)
          {
            if (_overlayObject != null)
            {
              _overlayObject.Dispose();
              _overlayObject = null;
            }
          }
          else
          {
            var geometry = _ParcelLineSelected.Shape;
            if (geometry != null)
            {
              // Add Overlay showing the parcel boundary
              if (_symbolReferenceLine == null)
              {
                // Construct line symbol
                var symbolLine = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.RedRGB, 2.0);
                _symbolReferenceLine = symbolLine.MakeSymbolReference();
              }
              QueuedTask.Run(() =>
              {
                if (_overlayObject != null)
                {
                  MapView.Active.UpdateOverlay(_overlayObject, geometry, _symbolReferenceLine);
                }
                else
                {
                  _overlayObject = MapView.Active.AddOverlay(geometry, _symbolReferenceLine);
                }
              });
              // ActivateTaxLineTableView(_ParcelLineSelected.Oid);             
            }
          }
        }
      }
    }

    public ICommand ParcelLineDoubleClick => new RelayCommand(() =>
    {
      var geometry = _ParcelLineSelected.Shape;
      if (geometry != null)
      {
        QueuedTask.Run(() =>
        {
          var diagonal = Math.Sqrt((geometry.Extent.Width * geometry.Extent.Width) + (geometry.Extent.Height * geometry.Extent.Height));
          if (diagonal > 20.0)
            MapView.Active.ZoomTo(geometry.Extent.Expand(0.9, 0.9, true));
          else
            MapView.Active.ZoomTo(geometry.Extent.Expand(20.0, 20.0, false));

        });
      }
    });

    #endregion

    #region Utilities

    private void ActivateTaxLineTableView(long lineOid)
    {
      if (_parcelGeometry != null && _taxTableViewSynced)
      {
        DiagnosticHelper.Start();

        // activate the exploreTool        
        var command = FrameworkApplication.GetPlugInWrapper("esri_mapping_exploreTool") as ICommand;
        if (command.CanExecute(null))
          command.Execute(null);

        // activate the TaxLine table view 
        var taxLineTable = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(Module1.TaxParcelLineLayerName)).FirstOrDefault();
        if (taxLineTable == null) return;

        // override the default title of the TablePane
        var iTaxLineTablePane = Module1.OpenAndActivateTablePane(taxLineTable);
        if (iTaxLineTablePane == null || iTaxLineTablePane as ITablePaneEx == null) return;
        (iTaxLineTablePane as ITablePaneEx).Caption = _taxTableViewSynced ? Module1.TaxLinesTableCaption : taxLineTable.Name;
        var tableView = (iTaxLineTablePane as ITablePaneEx).TableView;

        if (!_taxLineTableViewInitilized)
        {
          _taxLineTableViewInitilized = true;

          _ = Task.Delay(new TimeSpan(0, 0, 2)).ContinueWith(o =>
          {
            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
            {
              ShowCustomTableView(tableView, Module1.TaxLineTableHiddenFields, Module1.TaxLineTableFrozenFields, TableViewMode.eAllRecords);
            });
          });
          _ = Task.Delay(new TimeSpan(0, 0, 4)).ContinueWith(o =>
          {
            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
            {
              tableView.ClearHighlighted();
              tableView.Highlight(new List<long>() { lineOid }, true);
              QueuedTask.Run(() => tableView.BringIntoView(tableView.GetRowIndex(lineOid, false)));
              QueuedTask.Run(() => tableView.BringIntoView(tableView.GetRowIndex(lineOid, false)));
            });
          });

        }
        else
        {
          tableView.ClearHighlighted();
          tableView.Highlight(new List<long>() { lineOid }, true);
          QueuedTask.Run(() => tableView.BringIntoView(tableView.GetRowIndex(lineOid, false)));
        }
      }
    }

    private static FlowDocument GetFlowDocFromParcelText (List <string> parcelTexts)
    {
      var flowDocument = new FlowDocument();
      Paragraph paragraph = null;
      for (int i = 0;i < parcelTexts.Count; i++)
      {
        Run run = null;
        var line = parcelTexts[i];
        if (i == (parcelTexts.Count-1) && line.Length > Module1.MisclosurePrefix.Length)
        {
          // process misclosure
          var theValue = line.Substring(Module1.MisclosurePrefix.Length);
          var idxEnd = theValue.IndexOf(' ');
          if (idxEnd > 0) theValue = theValue.Substring(0, idxEnd);
          if (double.TryParse(theValue, out double miscloseVectorMagnitude))
          {
            run = new Run(line)
            {
              Foreground = miscloseVectorMagnitude > Module1.MisclosureMinDistance ?
                           System.Windows.Media.Brushes.Red : System.Windows.Media.Brushes.Green
            };
          }
          else
          {
            run = new Run($@"Unable to parse '{line}'.")
            {
              Foreground = System.Windows.Media.Brushes.Red
            };
          }
          run.FontWeight = FontWeights.Bold;
        }
        else
          run = new Run($@"{line}{Environment.NewLine}");
        run.FontSize = 14;
        if (paragraph == null)
          paragraph = new Paragraph(run);
        else 
          paragraph.Inlines.Add(run);
      }
      if (paragraph!= null) 
        flowDocument.Blocks.Add(paragraph);
      return flowDocument;
    }

    private static async Task ShowHidePlatAsync (bool doShow)
    {
      if (MapView.Active == null) return;
      DiagnosticHelper.Start();

      try
      {
        // First make the Plat layer visible / hidden
        var platLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<GroupLayer>().Where(gl => gl.Name.Equals(Module1.PlatOnOffLayerName)).FirstOrDefault();
        if (platLayer == null) return;

        await QueuedTask.Run(() =>
        {
          platLayer.SetVisibility(doShow);
        });
      }
      catch (Exception ex)
      {
        ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($@"Error: {ex.Message}");
      }
    }

    private static async Task ShowHideLabelsAsync(bool doShow)
    {
      if (MapView.Active == null) return;
      DiagnosticHelper.Start();

      try
      {
        // Show/hide taxLines labeling 
        var taxLineLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(Module1.TaxParcelLineLayerName)).FirstOrDefault();
        if (taxLineLayer == null) return;

        await QueuedTask.Run(() =>
        {
          taxLineLayer.SetLabelVisibility(doShow);
        });
      }
      catch (Exception ex)
      {
        ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($@"Error: {ex.Message}");
      }
    }

    /// <summary>
    /// Show custom TableView
    /// </summary>
    /// <param name="tableView"></param>
    /// <param name="lstHiddenFields"></param>
    /// <param name="lstFrozenFields"></param>
    /// <param name="showSelectedRecordsOnly"></param>
    private static async void ShowCustomTableView(TableView tableView, 
      List<string> lstHiddenFields, 
      List<string> lstFrozenFields, 
      TableViewMode showSelectedRecordsOnly)
    {
      DiagnosticHelper.Start();

      // change the camaTableView as well
      if (tableView == null || tableView.IsReady == false)
      {
        DiagnosticHelper.WriteLine(tableView == null ? "Active TableView is null" : "Active TableView is not ready");
        return;
      }
      // set visible and hidden fields
      //
      tableView.ShowAllFields();

      await tableView.ClearAllFrozenFieldsAsync();
      
      if (Module1.InDebugCycle)
      {
        System.Diagnostics.Trace.WriteLine("TableView class. Pro 3.1 API");
      }

      // Hide fields that I am not interested in:
      tableView.SetHiddenFields(lstHiddenFields);
      // Freeze fields to keep them in view - "Name"
      await tableView.SetFrozenFieldsAsync(lstFrozenFields);
      // Set ViewMode to show only selected features
      await tableView.SetViewMode(showSelectedRecordsOnly);
      // magnify the table view text by 120%
      tableView.SetZoomLevel(120);
    }

    /// <summary>
    /// Reset TableView to its defaults
    /// </summary>
    /// <param name="tableView">table View</param>
    private static async void ShowDefaultTableView(TableView tableView)
    {
      // change the camaTableView as well
      if (tableView == null || tableView.IsReady == false)
      {
        DiagnosticHelper.WriteLine(tableView == null ? "Active TableView is null" : "Active TableView is not ready");
        return;
      }
      // set visible and hidden columns
      tableView.ShowAllFields();

      // clear and reset frozen fields
      await tableView.ClearAllFrozenFieldsAsync();

      await tableView.SetViewMode(TableViewMode.eAllRecords);
      tableView.SetZoomLevel(100);
    }

    #endregion

  }
}
