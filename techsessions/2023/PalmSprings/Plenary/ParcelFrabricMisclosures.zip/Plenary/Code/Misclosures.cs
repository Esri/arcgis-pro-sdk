﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using TaxParcelPlenary.Helper;

namespace TaxParcelPlenary
{
  internal class Misclosures : Button
  {
    protected override async void OnClick()
    {
      try
      {
        if (MapView.Active == null) return;

        // configure the required tools
        IPlugInWrapper wrapper = FrameworkApplication.GetPlugInWrapper("esri_editing_ShowAttributes");
        var command = wrapper as ICommand;

        if ((command != null) && command.CanExecute(null))
          command.Execute(null);
        
        wrapper = FrameworkApplication.GetPlugInWrapper("esri_mapping_selectByRectangleTool");
        command = wrapper as ICommand;

        if ((command != null) && command.CanExecute(null))
          command.Execute(null);

        // Set the Tax_Lines as the selectable layer and select the sample Oid
        var taxLine = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(Module1.TaxParcelLineLayerName)).FirstOrDefault();
        if (taxLine == null) return;

        // set dislay number formats 
        SetNumbericFormats(taxLine, Module1.TaxLineSignificantDigits);

        // activate the Tax table view as the active view
        var taxTable = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(Module1.TaxParcelPolygonLayerName)).FirstOrDefault();
        if (taxTable == null) return;

        // set dislay number formats 
        SetNumbericFormats(taxTable, Module1.TaxSignificantDigits);

        await QueuedTask.Run(() =>
        {
          // clear 'selectable' for all BasicFeatureLayers
          // only Tax layer is selectable
          var allLayers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<BasicFeatureLayer>();
          foreach (var layer in allLayers) 
            layer.SetSelectable(false);
          taxLine.ClearSelection();
          taxTable.SetSelectable(true);
          taxTable.Select(new QueryFilter() { ObjectIDs = Module1.SampleTaxParceelOids });
          MapView.Active.ZoomToSelected();
          MapView.Active.ZoomOutFixed();
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {ex.Message}");
      }
    }

    private async void SetNumbericFormats(FeatureLayer featureLayer, Dictionary<string, int> taxLineSignificantDigits)
    {
      await QueuedTask.Run(() =>
      {
        // setup default display formats
        var fieldDescriptions = featureLayer.GetFieldDescriptions();
        foreach (var fieldDescription in fieldDescriptions)
        {
          if (fieldDescription.NumberFormat != null
              && fieldDescription.NumberFormat is CIMNumericFormat numericFormat)
          {
            if (taxLineSignificantDigits.ContainsKey(fieldDescription.Name))
            {
              numericFormat.RoundingValue = taxLineSignificantDigits[fieldDescription.Name];
            }
          }
        }
        featureLayer.SetFieldDescriptions(fieldDescriptions);
      });
    }
  }
}
