﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using TaxParcelPlenary.Helper;

namespace TaxParcelPlenary
{
  internal class CAMAShowPosted : Button
  {
    protected override void OnClick()
    {
      try
      {
        var tableName = "Changes to CAMA";

        // activate the CAMA table view as the active view
        var camaTable = MapView.Active.Map.GetStandaloneTablesAsFlattenedList().OfType<StandaloneTable>().Where(fl => fl.Name.Equals(tableName)).FirstOrDefault();
        if (camaTable == null) return;
        // set the query defintion to show posted data only
        SetCamaDefinitionQuery(camaTable, "posted = 1", "Posted records only");

        // run on UI thread
        var iTablePane = Module1.OpenAndActivateTablePane(camaTable);
        if (iTablePane == null) return;
        // override the default title of the TablePane to show Queued status
        var tablePaneEx = iTablePane as ITablePaneEx;
        if (tablePaneEx != null)
          tablePaneEx.Caption = $@"Posted to CAMA";

        _ = Task.Delay(new TimeSpan(0, 0, 4)).ContinueWith(o =>
        {
          System.Windows.Application.Current.Dispatcher.BeginInvoke(() =>
          {
            PrepareTableView(TableView.Active);
          });
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {ex.Message}");
      }
    }

    /// <summary>
    /// Update the query defintion for the given standalone table using the given whereclause and description
    /// </summary>
    /// <param name="standaloneTable">table for which to update the expression</param>
    /// <param name="whereClause"></param>
    /// <param name="description"></param>
    private static async void SetCamaDefinitionQuery(StandaloneTable standaloneTable, string whereClause, string description)
    {
      await QueuedTask.Run(() =>
      {
        // change the definition query
        standaloneTable.RemoveAllDefinitionQueries();
        standaloneTable.InsertDefinitionQuery(new DefinitionQuery() { Name = description, WhereClause = whereClause }, true);
      });
    }

    /// <summary>
    /// Update the tableview to only show the posted CAMA records
    /// </summary>
    /// <param name="tableView">Cama table View</param>
    private static async void PrepareTableView(TableView tableView)
    {
      // change the camaTableView as well
      if (tableView == null || tableView.IsReady == false)
      {
        DiagnosticHelper.WriteLine(tableView == null ? "Active TableView is null" : "Active TableView is not ready");
        return;
      }
      // set visible and hidden columns
      // show all fields PostedDate and PostedBy Columns
      tableView.ShowAllFields();

      // clear and reset frozen fields
      var frozenFields = tableView.GetFrozenFields();
      if (!frozenFields.Contains("TypeOfChange"))
      {
        await tableView.ClearAllFrozenFieldsAsync();
        await tableView.SetFrozenFieldsAsync(new List<string> { "ObjectId", "ParcelNo", "TypeOfChange", "DateSubmitted" });
      }
      await tableView.SetViewMode(TableViewMode.eAllRecords);
      tableView.SetZoomLevel(125);
    }
  }
}
