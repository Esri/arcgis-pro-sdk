﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using Version = ArcGIS.Core.Data.Version;

namespace ParcelFabricSDK
{
  public class SDKUtilities
  {
    public static async Task<Dictionary<string, Version>> CreateChangeEditVersion(ParcelLayer parcelLayer)
    {
      // unique timestamp to append to version name
      int unixTimestamp = (int)(DateTime.Now.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
      string versionName = $"SDK_{unixTimestamp}";

      Geodatabase geodatabase = null;
      Dictionary<string, Version> versionDict = new Dictionary<string, Version>();

      var parcelFabricContainer = await parcelLayer.GetRecordsLayerAsync();
      FeatureLayer recordsFeatureLayer = parcelLayer.Layers[0] as FeatureLayer;
      await QueuedTask.Run(() =>
      {
        using (Table table = recordsFeatureLayer.GetTable())
        {
          Datastore datastore = table.GetDatastore();
          geodatabase = datastore as Geodatabase;

          if (geodatabase.IsVersioningSupported())
          {
            using(VersionManager versionManager = geodatabase.GetVersionManager())
            {
              try
              {
                var currentVersion = versionManager.GetCurrentVersion();
                VersionDescription versionDescription = new VersionDescription(versionName, "Created by SDK", VersionAccessType.Public);
                versionManager.CreateVersion(versionDescription);
                Version newVersion = versionManager.GetVersion(versionName);

                versionDict.Add("fromVersion", currentVersion);
                versionDict.Add("toVersion", newVersion);
              }
              catch(Exception ex)
              {
                MessageBox.Show(ex.Message);
              }
            }

          }
        }
      });
      return versionDict;
    }
  }
}
