﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class Merge3 : Button
  {
    protected async override void OnClick()
    {
      //jump to the cim thread
      string errorMessage = await QueuedTask.Run( () =>
      {
        //Simple check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a feature layer in the table of contents.";
        // get the feature layer that's selected in the table of contents
        var featLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        //get the templates
        var map = ArcGIS.Desktop.Mapping.MapView.Active.Map;
        if (map == null)
          return "";
        var layers = MapView.Active.Map.GetLayersAsFlattenedList();
        var lotFeatLayer= MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "Lot");
        var lotTemplate = lotFeatLayer.GetTemplate("Parcel") as ArcGIS.Desktop.Editing.Templates.EditingRowTemplate;
        var opMerge3 = new EditOperation()
        {
          Name = "Merge 3",
          ProgressMessage = "Merging parcels...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };
        opMerge3.Merge(lotTemplate, featLyr, featLyr.GetSelection().GetObjectIDs());
        if (!opMerge3.Execute())
          return opMerge3.ErrorMessage;
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Merge Parcels");
    }
  }
}
