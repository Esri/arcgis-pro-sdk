﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class CreateNewRecord : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      //if there is no fabric in the map then bail
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Create Parcel Fabric Record");
        return;
      }
      string sNewRecord = Microsoft.VisualBasic.Interaction.InputBox("New Record Name:", "Create Parcel Fabric Record", "MyRecordName");
      if (sNewRecord.Trim().Length == 0)
        return;

      //check to make sure there is no record by this name.
      var x = await myParcelFabricLayer.GetRecordAsync(sNewRecord);
      if (x != null)
      { 
        MessageBox.Show("Record with this name already exists.", "Create Parcel Fabric Record");
        return;      
      }

      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        Dictionary<string, object> RecordAttributes = new Dictionary<string, object>();
        try
        {
          var recordsLayer = await myParcelFabricLayer.GetRecordsLayerAsync();
          var editOper = new EditOperation()
          {
            Name = "Create Parcel Fabric Record",
            ProgressMessage = "Create Parcel Fabric Record...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = false,
            SelectModifiedFeatures = false
          };
          RecordAttributes.Add("Name", sNewRecord);
          editOper.Create(recordsLayer.FirstOrDefault(), RecordAttributes);
          if (!editOper.Execute())
            return editOper.ErrorMessage;
          await myParcelFabricLayer.SetActiveRecordAsync(sNewRecord);
          return "";
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Create Parcel Fabric Record");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Create Parcel Fabric Record");

      var EdOp = new EditOperation();

//EdOp.BuildParcelsByExtent
//EdOp.BuildParcelsByRecord
//EdOp.ChangeParcelType
//EdOp.CopyLineFeaturesToParcelType
//EdOp.CopyParcelLinesToParcelType
//EdOp.CreateParcelSeedsByRecord
//EdOp.DeleteParcels
//EdOp.DuplicateParcels
//EdOp.RetireFeaturesToRecord
//EdOp.SetParcelHistoryCurrent
//EdOp.SetParcelHistoryRetired
//EdOp.ShrinkParcelsToSeeds






    }
  }
}
