﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class SetParcelsHistoric : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        System.Windows.MessageBox.Show("There is no parcel layer in the map.", "Set Parcels Historic");
        return;
      }
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        try
        {
          FeatureLayer destPolygonL = null;
          //test to make sure the layer is a parcel type, is non-historic, and has a selection
          bool bFound = false;
          var ParcelTypesEnum = await myParcelFabricLayer.GetParcelTypeNamesAsync();
          foreach (FeatureLayer mapFeatLyr in 
            MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>())
          { 
            foreach (string ParcelType in ParcelTypesEnum)
            {
              var layerEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(ParcelType);
              foreach (FeatureLayer flyr in layerEnum)
              {
                if (flyr == mapFeatLyr)
                {
                  bFound = mapFeatLyr.SelectionCount > 0;
                  destPolygonL = mapFeatLyr;
                  break;
                }
              }
              if (bFound) break;
            }
            if (bFound) break;
          }
          if (!bFound)
            return "Please select parcels to set as historic.";
          var theActiveRecord = myParcelFabricLayer.GetActiveRecord();
          if (theActiveRecord == null)
            return "There is no Active Record. Please set the active record and try again.";

          var ids = new List<long>(destPolygonL.GetSelection().GetObjectIDs());
          //can do multi layer selection but using single per code above
          //var kvp00 = new KeyValuePair<MapMember, List<long>>(destPolygonL, ids);
          //var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp00 };
          var sourceParcFeats = new Dictionary<MapMember, List<long>>();
          sourceParcFeats.Add(destPolygonL, ids);

          var editOper = new EditOperation()
          {
            Name = "Set Parcels Historic",
            ProgressMessage = "Set Parcels Historic...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          var peToken = 
            editOper.SetParcelHistoryRetired(myParcelFabricLayer, SelectionSet.FromDictionary(sourceParcFeats), 
              theActiveRecord);
          if (!editOper.Execute())
            return editOper.ErrorMessage;
          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (var kvp in FeatSetCreated.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name + 
                " features created." + Environment.NewLine;
            }
          }
          if (FeatSetModified != null)
          {
            foreach (var kvp in FeatSetModified.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + 
                " features modified." + Environment.NewLine;
            }
          }
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Set Parcels Historic");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Set Parcels Historic");
    }
  }
}
