﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class DeleteParcels : Button
  {
    protected async override void OnClick()
    {
      string errorMessage = await QueuedTask.Run( () =>
      {
        try
        {
          // check for selected layer
          if (MapView.Active.GetSelectedLayers().Count == 0)
            return "Please select a source feature layer in the table of contents.";
          //first get the feature layer that's selected in the table of contents
          var theParcelFeatLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();
          if (theParcelFeatLyr == null)
            return "Please select a source feature layer in the table of contents.";
          var ids = new List<long>(theParcelFeatLyr.GetSelection().GetObjectIDs());
          if (ids.Count == 0)
            return "";
          var editOper = new EditOperation()
          {
            Name = "Delete Parcels",
            ProgressMessage = "Delete Parcels...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = false,
            SelectModifiedFeatures = false
          };
          editOper.DeleteParcels(theParcelFeatLyr, ids);
          if (!editOper.Execute())
            return editOper.ErrorMessage;
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Delete Parcels");
    }
  }
}
