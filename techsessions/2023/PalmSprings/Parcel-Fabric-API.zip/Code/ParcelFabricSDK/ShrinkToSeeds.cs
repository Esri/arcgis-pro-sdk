﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class ShrinkToSeeds : Button
  {
    protected async override void OnClick()
    {
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        var myParcelFabricLayer = 
          MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        if (myParcelFabricLayer == null)
          return "Please add a parcel fabric to the map.";
        try
        {
          FeatureLayer parcelPolygonLyr = null;
          //find the first layer that is a polygon parcel type, is non-historic, and has a selection
          bool bFound = false;
          var ParcelTypesEnum = await myParcelFabricLayer.GetParcelTypeNamesAsync();
          foreach (FeatureLayer mapFeatLyr in 
            MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>())
          {
            foreach (string ParcelType in ParcelTypesEnum)
            {
              var layerEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(ParcelType);
              foreach (FeatureLayer flyr in layerEnum)
              {
                if (flyr == mapFeatLyr)
                {
                  bFound = mapFeatLyr.SelectionCount > 0;
                  parcelPolygonLyr = mapFeatLyr;
                  break;
                }
              }
              if (bFound) break;
            }
            if (bFound) break;
          }
          if (!bFound)
            return "Please select parcels to shrink to seeds.";
          var editOper = new EditOperation()
          {
            Name = "Shrink Parcels To Seeds",
            ProgressMessage = "Shrink Parcels To Seeds...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          var ids = new List<long>(parcelPolygonLyr.GetSelection().GetObjectIDs());
          //var kvp00 = new KeyValuePair<MapMember, List<long>>(parcelPolygonLyr, ids);
          //var sourceParcelFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp00 };
          var sourceParcFeats = new Dictionary<MapMember, List<long>>();
          sourceParcFeats.Add(parcelPolygonLyr, ids);
          var MyParcelEditToken = 
            editOper.ShrinkParcelsToSeeds(myParcelFabricLayer, SelectionSet.FromDictionary(sourceParcFeats));
          if (!editOper.Execute())
            return editOper.ErrorMessage;

          var editOperation2 = editOper.CreateChainedOperation();
          Dictionary<string, object> ParcelAttributes = new Dictionary<string, object>();
          var FeatSetModified = MyParcelEditToken.ModifiedFeatures;
          if (FeatSetModified != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetModified.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                var dictInspParcelFeat = kvp.Key.Inspect(oid).ToDictionary(a => a.FieldName, a => a.CurrentValue);
                ParcelAttributes.Add("Name", "Seed for: " + dictInspParcelFeat["Name"]);
                editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + 
              " features modified." + Environment.NewLine;
            }
          }
          if (!editOperation2.Execute())
            return editOperation2.ErrorMessage;
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Shrink Parcels To Seeds");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Shrink Parcels To Seeds");
    }
  }
}
