﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class CopyLineFeatsToParcelType : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Copy Line Features To Parcel Type");
        return;
      }
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a target parcel polygon layer in the table of contents.";

        //first get the feature layer that's selected in the table of contents
        var destPolygonL = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        try
        {
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";
          string ParcelTypeName = await GetParcelTypeNameFromFeatureLayer(myParcelFabricLayer,
            destPolygonL, GeometryType.Polygon);
          if (String.IsNullOrEmpty(ParcelTypeName))
            return "Please select a target parcel polygon layer in the table of contents.";
          var srcFeatLyr = 
            MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name.Contains("Lines SP") && l.IsVisible);
          if (srcFeatLyr == null)
            return "Source layer with string Lines SP* not found in the table of contents.";
          //now get the line layer for this parcel type
          var destLineLyrEnum = 
            await myParcelFabricLayer.GetParcelLineLayerByTypeNameAsync(ParcelTypeName);
          if (destLineLyrEnum.Count() == 0) //make sure there is one in the map
            return "No line layer found.";

          var destLineL = destLineLyrEnum.FirstOrDefault();
          if (destLineL == null || destPolygonL == null)
            return "";
          var editOper = new EditOperation()
          {
            Name = "Copy Line Features To Parcel Type",
            ProgressMessage = "Copy Line Features To Parcel Type...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          var ids = new List<long>((srcFeatLyr as FeatureLayer).GetSelection().GetObjectIDs());
          if (ids.Count == 0)
            return "No selected lines were found. Please select line features and try again.";
          ParcelEditToken peToken = editOper.CopyLineFeaturesToParcelType(srcFeatLyr, ids, 
            destLineL, destPolygonL);

          if(!editOper.Execute())
            return editOper.ErrorMessage;

          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (var kvp in FeatSetCreated.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name + 
                " features created." + Environment.NewLine;
            }
          }
          if (FeatSetModified != null)
          {
            foreach (var kvp in FeatSetModified.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + 
                " features modified." + Environment.NewLine;
            }
          }
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage,"Copy Line Features To Parcel Type");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult,"Copy Line Features To Parcel Type");
    }
    private async Task<string> GetParcelTypeNameFromFeatureLayer(ParcelLayer myParcelFabricLayer, FeatureLayer featLayer, GeometryType geomType)
    {
      if (featLayer == null) //nothing to do return empty string
        return String.Empty;
      IEnumerable<string> parcelTypeNames = await myParcelFabricLayer.GetParcelTypeNamesAsync();
      foreach (string parcelTypeName in parcelTypeNames)
      {
        if (geomType == GeometryType.Polygon)
        {
          var polygonLyrParcelTypeEnum = 
            await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
          polygonLyrParcelTypeEnum = 
            await myParcelFabricLayer.GetHistoricParcelPolygonLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
        if (geomType == GeometryType.Polyline)
        {
          var lineLyrParcelTypeEnum = 
            await myParcelFabricLayer.GetParcelLineLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
          lineLyrParcelTypeEnum = 
            await myParcelFabricLayer.GetHistoricParcelLineLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
      }
      return String.Empty;
    }
  }
}
