﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class CopyParcelLinesToParcelType : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Copy Parcel Lines To");
        return;
      }
      // check for selected layer
      if (MapView.Active.GetSelectedLayers().Count == 0)
      {
        MessageBox.Show("Please select a source parcel polygon feature layer in the table of contents.", 
          "Copy Parcel Lines To");
        return;
      }
      string sTargetParcelType = Microsoft.VisualBasic.Interaction.InputBox("Target Parcel Type:", 
        "Copy Parcel Lines To", "Tax");
      if (sTargetParcelType.Trim().Length == 0)
        return;
      // get the feature layer that's selected in the table of contents
      var srcParcelFeatLyr = MapView.Active.GetSelectedLayers().FirstOrDefault() as FeatureLayer;
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        try
        {
          var destLineLEnum = 
            await myParcelFabricLayer.GetParcelLineLayerByTypeNameAsync(sTargetParcelType);
          if (destLineLEnum.Count() == 0)
            return "No destination parcel line layer found.";
          var destLineL = destLineLEnum.FirstOrDefault();
          var destPolygonLEnum = 
            await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(sTargetParcelType);
          if (destPolygonLEnum.Count() == 0)
            return "No destination parcel layer found.";
          var destPolygonL = destPolygonLEnum.FirstOrDefault();

          if (destLineL == null || destPolygonL == null)
            return "";
          var ids = new List<long>(srcParcelFeatLyr.GetSelection().GetObjectIDs());
          if (ids.Count == 0)
            return "No selected parcels found. Please select parcels and try again.";
          //var kvp00 = new KeyValuePair<MapMember, List<long>>(srcParcelFeatLyr, ids);
          //var sourceParcelFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp00 };
          var sourceParcFeats = new Dictionary<MapMember, List<long>>();
          sourceParcFeats.Add(srcParcelFeatLyr, ids);

          var editOper = new EditOperation()
          {
            Name = "Copy Lines To Parcel Type",
            ProgressMessage = "Copy Lines To Parcel Type ...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          ParcelEditToken peToken = 
            editOper.CopyParcelLinesToParcelType(myParcelFabricLayer, SelectionSet.FromDictionary(sourceParcFeats),
              destLineL, destPolygonL, true,true,true);

          

          var createdIDsSelectionSet = peToken.CreatedFeatures;
          if (!editOper.Execute())
            return editOper.ErrorMessage;
          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (var kvp in FeatSetCreated.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + 
                kvp.Key.Name + " features created." +
                  Environment.NewLine;
            }
          }
          if (FeatSetModified != null)
          {
            foreach (var kvp in FeatSetModified.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + 
                kvp.Key.Name + " features modified." +
                  Environment.NewLine;
            }
          }
        }
        catch (Exception ex)
        { 
          return ex.Message; 
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Copy Parcel Lines To");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Copy Parcel Lines To");
    }
  }
}