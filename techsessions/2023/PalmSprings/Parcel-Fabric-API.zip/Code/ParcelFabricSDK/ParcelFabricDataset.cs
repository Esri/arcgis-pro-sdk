﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Parcels;
using ArcGIS.Core.Data.Topology;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class ParcelFabricDataset : Button
  {
    private bool CheckSignOn()
    {
      var portal = ArcGISPortalManager.Current.GetActivePortal();
      if (portal == null)
      {
        return false;
      }

      if (!portal.IsSignedOn())
      {
        portal.SignIn();
      }
      if (!portal.IsSignedOn())
      {
        return false;
      }
      return true;
    }

    private bool IsFeatureClass;
    protected async override void OnClick()
    {
      string sPath = GetBrowsedPath();

      if (sPath.Trim() == "")
        return;

      string dsName = System.IO.Path.GetFileName(sPath);
      string sPathDir = System.IO.Path.GetDirectoryName(sPath);

      bool isSDE = false;
      bool isFile = false;
      bool isService = false;

      if (sPathDir.StartsWith("http")) // might be better to look at the browse item type -> portal 
      {
        isService = true;
        sPathDir = sPathDir.Replace(@"\", @"/").Replace(@":/", @"://");
      }
      else if (IsFeatureClass)
      {
        var sde = ".sde";
        var gdb = ".gdb";
        var ext = System.IO.Path.GetExtension(sPathDir);

        if (ext != sde && ext != gdb)
          sPathDir = System.IO.Path.GetDirectoryName(sPathDir); // remove the FDS path

        ext = System.IO.Path.GetExtension(sPathDir);

        if (ext == sde)
          isSDE = true;
        else if (ext == gdb)
          isFile = true;
      }
      if (!isSDE && !isFile && !isService)
      {
        MessageBox.Show("Unknown database.");
        return;
      }

      var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
        MessageBox.Show("Please add a parcel fabric to the map.");

      await QueuedTask.Run(() =>
      {
        if (isService && !CheckSignOn()) // TODO...not needed?
          return;

        ParcelFabric parcelFabric = null;

        var uri = new Uri(sPathDir);

        //DatabaseConnectionFile connectionFile = new DatabaseConnectionFile(uri); // test code to see what the connection is
        //DatabaseConnectionProperties connectionProperties = DatabaseClient.GetDatabaseConnectionProperties(connectionFile);

        using (Geodatabase projectWorkspace = isService ? new Geodatabase(new ServiceConnectionProperties(uri)) :
                                              isSDE ? new Geodatabase(new DatabaseConnectionFile(uri)) :
                                                          new Geodatabase(new FileGeodatabaseConnectionPath(uri)))
        {
          try
          {
            using (Table browsedDataset = projectWorkspace.OpenDataset<Table>(dsName))
            {
              parcelFabric = GetParcelFabricFromTable(browsedDataset);
              if (parcelFabric == null)
              {
                MessageBox.Show("Selected dataset is not part of a parcel fabric.");
                return;
              }
              var sFabDSName = parcelFabric.GetName();
              //FeatureDataset xx = projectWorkspace.OpenDataset<FeatureDataset>("Fabric");
              ParcelFabric yy = projectWorkspace.OpenDataset<ParcelFabric>(sFabDSName); //renton6k


            }
          }
          catch (Exception ex)
          {

            MessageBox.Show(ex.Message + Environment.NewLine + "Dataset not found.");
            return;
          }
        }

        var pfDefinition = parcelFabric.GetDefinition();


        string msg = "";
        try
        {
          var x = parcelFabric.GetSystemTable(SystemTableType.Records);
          var y = x.Type;

          msg = "Parcel Fabric Schema Version: " + pfDefinition.GetSchemaVersion() + "\n\n";
          msg += parcelFabric.GetSystemTable(SystemTableType.Records).GetName() + "\n";
          //msg += parcelFabric.GetSystemTable(SystemTableType.DirtyAreas).GetName() + "\n";
          //msg += parcelFabric.GetSystemTable(SystemTableType.PointErrors).GetName() + "\n";
          //msg += parcelFabric.GetSystemTable(SystemTableType.LineErrors).GetName() + "\n";
          //msg += parcelFabric.GetSystemTable(SystemTableType.PolygonErrors).GetName() + "\n";
          msg += parcelFabric.GetSystemTable(SystemTableType.Points).GetName() + "\n";
          msg += parcelFabric.GetSystemTable(SystemTableType.Connections).GetName() + "\n";
          if (parcelFabric.IsSystemTableSupported(SystemTableType.AdjustmentPoints))
            msg += parcelFabric.GetSystemTable(SystemTableType.AdjustmentPoints).GetName() + "\n";
          if (parcelFabric.IsSystemTableSupported(SystemTableType.AdjustmentLines))
            msg += parcelFabric.GetSystemTable(SystemTableType.AdjustmentLines).GetName() + "\n";
          if (parcelFabric.IsSystemTableSupported(SystemTableType.AdjustmentVectors))
            msg += parcelFabric.GetSystemTable(SystemTableType.AdjustmentVectors).GetName() + "\n";
          msg += parcelFabric.GetParcelTopology().GetName() + "\n\n";

          msg += "Topology Enabled: " + pfDefinition.GetTopologyEnabled().ToString() + "\n";

          msg += "\nTypes\n\n";
          var typeInfo = parcelFabric.GetParcelTypeInfo();
          foreach (var info in typeInfo)
            msg += "N:" + info.Name + ", A:" + info.IsAdministration.ToString() + "\n  L:" + info.LineFeatureTable.GetName() + "\n  P:" + info.PolygonFeatureTable.GetName() + "\n\n";

          Topology topoDS = parcelFabric.GetParcelTopology();
          //topoDS.BuildGraph()
        }
        catch
        {
          msg += "Failed to get a property from parcel fabric object.\n";
        }

        try
        {
          msg += "\n";
          parcelFabric = myParcelFabricLayer.GetParcelFabric();
          if (parcelFabric == null)
            msg += "Parcel Fabric -> null";
          else
            msg += "Got a Parcel Fabric from the layer in the map: " + parcelFabric.GetName();
        }
        catch
        {
          msg += "Failed to get parcel fabric from layer.\n";
        }

        MessageBox.Show("Parcel Fabric info\n\n" + msg);
      });
    }

    public static ParcelFabric GetParcelFabricFromTable(Table table)
    {
      ParcelFabric parcelFabric = null;
      if (table.IsControllerDatasetSupported())
      {
        // Tables can belong to multiple controller datasets, but at most one of them will be a parcel fabric

        IReadOnlyList<Dataset> controllerDatasets = table.GetControllerDatasets();
        foreach (Dataset controllerDataset in controllerDatasets)
        {
          if (controllerDataset is ParcelFabric)
          {
            parcelFabric = controllerDataset as ParcelFabric;
          }
          else
          {
            controllerDataset.Dispose();
          }
        }
      }
      return parcelFabric;
    }

    //public static Topology GetTopologyFromTable(Table table)
    //{
    //  Topology topology = null;

    //  if (table.IsControllerDatasetSupported())
    //  {
    //    // Tables can belong to multiple controller datasets, but at most one of them will be a topology

    //    IReadOnlyList<Dataset> controllerDatasets = table.GetControllerDatasets();
    //    foreach (Dataset controllerDataset in controllerDatasets)
    //    {
    //      if (controllerDataset is Topology)
    //      {
    //        topology = controllerDataset as Topology;
    //      }
    //      else
    //      {
    //        controllerDataset.Dispose();
    //      }
    //    }
    //  }

    //  return topology;
    //}


    private string GetBrowsedPath()
    {
      IsFeatureClass = false;
      BrowseProjectFilter bf = new BrowseProjectFilter(ItemFilters.FeatureClasses_All);

      //Display the filter in an Open Item dialog
      OpenItemDialog aBrowseForFolder = new OpenItemDialog
      {
        Title = "Select A Parcel Fabric Feature Class",
        //InitialLocation = folderPath,
        MultiSelect = false,
        BrowseFilter = bf
      };
      bool? ok = aBrowseForFolder.ShowDialog();
      if (ok == true)
      {
        var myItems = aBrowseForFolder?.Items;
        var firstItem = myItems?.FirstOrDefault();
        if (firstItem == null)
          return "";


        if (firstItem.Type.Contains("Enterprise Geodatabase Parcel Fabric"))
          return "";

        IsFeatureClass = firstItem.Type.Contains("Feature Class");

        return firstItem.Path;
      }
      else return "";

    }

  }
}
