﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class Merge2 : Button
  {
    protected async override void OnClick()
    {
      string sTargetParcelType = Microsoft.VisualBasic.Interaction.InputBox("Target Parcel Type:",
        "Merge To Parcel Type", "Tax");
      if (sTargetParcelType.Trim().Length == 0)
        return;
      //jump to the cim thread
      string errorMessage = await QueuedTask.Run( async () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a feature layer in the table of contents";
        //first get the feature layer that's selected in the table of contents
        var featSrcLyr= MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        if (featSrcLyr.SelectionCount == 0)
          return "There is no selection on the source layer.";
        var myParcelFabricLayer = 
          MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        if (myParcelFabricLayer == null)
          return "Please add a parcel layer to the map.";
        try
        {
          var typeNamesEnum = 
            await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(sTargetParcelType);
          if (typeNamesEnum.Count() == 0)
            return "Target parcel type " + sTargetParcelType + " not found. Please try again.";         
          var featTargetLyr = typeNamesEnum.FirstOrDefault();
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";
          var opMerge2 = new EditOperation()
          {
            Name = "Merge2",
            ProgressMessage = "Merging parcels...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          opMerge2.Merge(featTargetLyr, featSrcLyr, featSrcLyr.GetSelection().GetObjectIDs());
          if (!opMerge2.Execute())
            return opMerge2.ErrorMessage;
        }
        catch (Exception ex)
        {
          return ex.Message;  
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Merge Parcels");
      //When active record is set, and merging into the same parcel type, the original parcels are set historic with RetiredByRecord GUID field
      //When active record is set, the new merged parcel will be tagged with the Active record.
    }
  }
}
