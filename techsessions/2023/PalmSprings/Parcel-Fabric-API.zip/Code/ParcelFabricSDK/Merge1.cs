﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class Merge1 : Button
  {
    protected async override void OnClick()
    {
      // check for selected layer
      if (MapView.Active.GetSelectedLayers().Count == 0)
      {
        MessageBox.Show("Please select a feature layer in the table of contents", "Merge");
        return;
      }
      //jump to the cim thread
      string errorMessage = await QueuedTask.Run( () =>
      {
        //first get the feature layer that's selected in the table of contents
        var featLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        var opMerge1 = new EditOperation()
        {
          Name = "Merge1",
          ProgressMessage = "Merging parcels...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };
        opMerge1.Merge(featLyr, featLyr.GetSelection().GetObjectIDs());
        if (!opMerge1.Execute())
          return opMerge1.ErrorMessage;
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Merge Parcels");
    }
  }
}