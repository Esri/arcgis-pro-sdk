﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcelFabricSDK
{
  internal class NavigateParcelElements : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer =
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        System.Windows.MessageBox.Show("There is no parcel layer in the map.", "Set Parcels Historic");
        return;
      }

      //var pointOfBeginning = MapPointBuilderEx.CreateMapPoint(3129866.761, 13793829.98);


      var pointOfBeginning = MapPointBuilderEx.CreateMapPoint(7502550.00, 447570.00);


            string sReportResult = "";
      string errorMessage = await QueuedTask.Run(async () =>
      {
        try
        {
          long myParceloid = -1;
          FeatureLayer MyPolygonLyr = null;

          //test to make sure the layer is a parcel type, is non-historic, and has a selection
          bool bFound = false;

          var ParcelTypesEnum = await myParcelFabricLayer.GetParcelTypeNamesAsync();

          foreach (FeatureLayer mapFeatLyr in
                  MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>())
          {
            foreach (string ParcelType in ParcelTypesEnum)
            {
              var layerEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(ParcelType);
              foreach (FeatureLayer flyr in layerEnum)
              {
                if (flyr == mapFeatLyr)
                {
                  bFound = mapFeatLyr.SelectionCount > 0;
                  if (bFound)
                    myParceloid = mapFeatLyr.GetSelection()?.GetObjectIDs().FirstOrDefault() ?? -1;
                  MyPolygonLyr = mapFeatLyr;
                  break;
                }
              }
              if (bFound)
                break;
            }
            if (bFound)
              break;
          }

          if (!bFound)
            return "Please select parcels to show their lines.";

          //ParcelEdgeCollection parcelEdgeCollection =
          //  await myParcelFabricLayer.GetSequencedParcelEdgeInfoAsync(destPolygonL, oid, null);

          ParcelEdgeCollection parcelEdgeCollection =
            await myParcelFabricLayer.GetSequencedParcelEdgeInfoAsync(MyPolygonLyr, 
              myParceloid, pointOfBeginning, 0.1, ParcelLineToEdgeRelationship.All);


          if (parcelEdgeCollection == null)
            return "Null response (BAD)";

          sReportResult += "Points:" + ListToString(parcelEdgeCollection.Points) + "\n\n";

          foreach (var edge in parcelEdgeCollection.Edges)
          {
            sReportResult += "Edge: " + edge.EdgeID.ToString() + " Geometry: ";
            sReportResult += edge.EdgeGeometry == null ? "NULL\n\n" : edge.EdgeGeometry.Length.ToString("F2") + " Length\n\n";
            foreach (var line in edge.Lines)
            {
              sReportResult += "*Line-OID:" + line.ObjectID;
              sReportResult += "\nFromPnt:" + ListToString(line.FromPointObjectID);
              sReportResult += " ToPnt:" + ListToString(line.ToPointObjectID);
              sReportResult += "\nRecord:" + line.RecordGUID.ToString();
              sReportResult += "\nEdge IDs:" + ListToString(line.EdgeID);
              sReportResult += "\nRelation:" + line.EdgeRelationship.ToString();
              sReportResult += "\nReversed:" + line.IsReversed;
              sReportResult += " Closing:" + line.IsClosing;
              sReportResult += " NextCon:" + line.HasNextLineConnectivity;
              sReportResult += " PrevCon:" + line.HasPreviousLineConnectivity;
              sReportResult += "\nStart:" + line.StartPositionOnParcelEdge.ToString("F2");
              sReportResult += " End:" + line.EndPositionOnParcelEdge.ToString("F2");
              sReportResult += "\nAttributes:" + (line.FeatureAttributes == null ? "NULL" : line.FeatureAttributes.Count.ToString());
              sReportResult += "\nGeometry:" + (line.FeatureGeometry == null ? "NULL" : line.FeatureGeometry.Length.ToString("F2") + " Length");
              sReportResult += "\n\n";
            }
          }
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });

      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Parcel Lines");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Parcel Lines");
    }

    private static string ListToString<T>(IReadOnlyList<T> ids)
    {
      string ret = "";
      foreach (var id in ids)
      {
        if (ret.Count() > 0)
          ret += ",";
        ret += id;
      }
      return ret;
    }

  }
}
