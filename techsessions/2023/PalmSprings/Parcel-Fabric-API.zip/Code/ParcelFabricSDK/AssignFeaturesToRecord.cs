﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class AssignFeaturesToRecord : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer =
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
        MessageBox.Show("Please select a parcel fabric layer in the table of contents.","Assign Features To Record");
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        //check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a source feature layer in the table of contents.";
        //get the feature layer that's selected in the table of contents
        var srcFeatLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        bool bIsControlledByFabric = await srcFeatLyr.IsControlledByParcelFabricAsync(ParcelFabricType.ParcelFabric);
        if (!bIsControlledByFabric)
          return "Please select a parcel fabric layer in the table of contents.";
        try
        {
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";
          //TODO add selection from other layers
          var ids = new List<long>(srcFeatLyr.GetSelection().GetObjectIDs());
          //var kvp00 = new KeyValuePair<MapMember, List<long>>(srcFeatLyr, ids);
          //var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp00 };
          // ------- get the selected parcels ---------
          var sourceParcFeats = new Dictionary<MapMember, List<long>>();
          sourceParcFeats.Add(srcFeatLyr, ids);

          var editOper = new EditOperation()
          {
            Name = "Assign Features to Record",
            ProgressMessage = "Assign Features to Record...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          ParcelEditToken peToken = 
            editOper.AssignFeaturesToRecord(myParcelFabricLayer, SelectionSet.FromDictionary(sourceParcFeats), pRec);
          if (!editOper.Execute())
            return editOper.ErrorMessage;

          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (var kvp in FeatSetCreated.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name + 
                " features created." + Environment.NewLine;
            }
          }
          if (FeatSetModified != null)
          {
            foreach (var kvp in FeatSetModified.ToDictionary())
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + 
                " features modified." + Environment.NewLine;
            }
          }
        }
        catch (Exception ex)
        {
          errorMessage= ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Assign Features To Record");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Assign Features To Record");
    }
  }
}
