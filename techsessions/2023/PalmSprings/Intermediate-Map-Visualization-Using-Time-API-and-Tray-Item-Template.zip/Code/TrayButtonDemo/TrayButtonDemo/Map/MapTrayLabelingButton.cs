﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace TrayButtonDemo.Map
{
    internal class MapTrayLabelingButtonOn : MapTrayButton
    {
        /// <summary>
        /// Invoked after construction, and after all DAML settings have been loaded. 
        /// Use this to perform initialization such as setting ButtonType.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();

            // set the button type
            //  change for different button types
            ButtonType = TrayButtonType.Button;

            // ClickCommand is used for TrayButtonType.Button only
            ClickCommand = new RelayCommand(DoClick);
        }

    #region TrayButtonType.Button
    private void DoClick()
    {
      // do something when the tray button is clicked
      var featLayers = MapView.Active.Map.GetLayersAsFlattenedList()
                    .OfType<FeatureLayer>().ToList();
      if (featLayers.Count == 0)
        return;//nothing to do
      QueuedTask.Run(() =>
      {
        foreach (var featlayer in featLayers)
        {
          featlayer.SetLabelVisibility(true);
        }
      });

    }
    #endregion
    /// <summary>
    /// Override to perform some button initialization.  This is called the first time the botton is loaded.
    /// </summary>
    protected override void OnButtonLoaded()
        {
            base.OnButtonLoaded();
        }

    

  }
  internal class MapTrayLabelingButtonOff : MapTrayButton
  {
    /// <summary>
    /// Invoked after construction, and after all DAML settings have been loaded. 
    /// Use this to perform initialization such as setting ButtonType.
    /// </summary>
    protected override void Initialize()
    {
      base.Initialize();

      // set the button type
      //  change for different button types
      ButtonType = TrayButtonType.Button;

      // ClickCommand is used for TrayButtonType.Button only
      ClickCommand = new RelayCommand(DoClick);
    }

    #region TrayButtonType.Button
    private void DoClick()
    {
      // do something when the tray button is clicked
      var featLayers = MapView.Active.Map.GetLayersAsFlattenedList()
                    .OfType<FeatureLayer>().ToList();
      if (featLayers.Count == 0)
        return;//nothing to do
      QueuedTask.Run(() =>
      {
        foreach (var featlayer in featLayers)
        {
          featlayer.SetLabelVisibility(false);
        }
      });

    }
    #endregion
    /// <summary>
    /// Override to perform some button initialization.  This is called the first time the botton is loaded.
    /// </summary>
    protected override void OnButtonLoaded()
    {
      base.OnButtonLoaded();
    }

    

  }
}
