﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TrayButtonDemo.Map
{
  /// <summary>
  /// Interaction logic for MapTrayLabelingPopupView.xaml
  /// </summary>
  public partial class MapTrayLabelingPopupView : UserControl
  {
    public MapTrayLabelingPopupView()
    {
      InitializeComponent();
    }
    #region Event Handlers
    //Event handlers to control auto close behavior of tray button 
    private void PopupOpened(object sender, EventArgs e)
    {
      var vm = (DataContext as MapTrayLabelingPopupViewModel);
      vm.CanPopupAutoClose = false;
    }

    private void PopupClosed(object sender, EventArgs e)
    {
      var vm = (DataContext as MapTrayLabelingPopupViewModel);
      vm.CanPopupAutoClose = true;
    }
    #endregion
  }
}
