﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Internal.CIM;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TrayButtonDemo
{
  internal class Module1 : Module
  {
    private static Module1 _this = null;
    internal static Dictionary<string, List<string>> AvailableFontsStylesMapping = new Dictionary<string, List<string>>();
    internal ObservableCollection<string> _availableFonts = new ObservableCollection<string>();
    internal ObservableCollection<string> _availableFontStyles = new ObservableCollection<string>();
    //internal static readonly string DefaultFontName = "Arial Black";
    //internal static readonly string DefaultFontStyle = "Regular";
    //internal static readonly double DefaultSize = 12.0;
    //internal static readonly CIMColor DefaultColor = ColorFactory.Instance.BlackRGB;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("TrayButtonDemo_Module");


    public ObservableCollection<string> AvailableFontNames => _availableFonts;

    public ObservableCollection<string> AvailableFontStyles => _availableFontStyles;

    #region Overrides

    protected override bool Initialize()
    {
      QueuedTask.Run( () => {
        var fonts = SymbolFactory.Instance.GetAvailableFonts();
        foreach (var font in fonts)
        {
          _availableFonts.Add(font.fontName);
          if (AvailableFontsStylesMapping.ContainsKey(font.fontName))
          {
            AvailableFontsStylesMapping[font.fontName].AddRange(font.fontStyles);
          }
          else
            AvailableFontsStylesMapping.Add(font.fontName, font.fontStyles);
        }
        
        //var availableStyles = AvailableFontsStylesMapping["Arial Black"]; //default
        //foreach (var style in availableStyles)
        //  _availableFontStyles.Add(style);
      });
      return true;
    }
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

  }
}
