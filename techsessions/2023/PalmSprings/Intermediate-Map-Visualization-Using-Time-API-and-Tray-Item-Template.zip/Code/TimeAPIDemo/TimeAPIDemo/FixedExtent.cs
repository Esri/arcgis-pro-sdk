﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeAPIDemo
{
  internal class FixedExtent : Button
  {
    protected override void OnClick()
    {

      var beforeMudSlideImge = MapView.Active.Map.GetLayersAsFlattenedList().OfType<RasterLayer>().FirstOrDefault(l => l.Name.Contains("Before"));
      var AfterMudSlideImge = MapView.Active.Map.GetLayersAsFlattenedList().OfType<RasterLayer>().FirstOrDefault(l => l.Name.Contains("After"));

      if (beforeMudSlideImge == null || AfterMudSlideImge == null) return;

      QueuedTask.Run(() =>
      {
        //Configure TimeParameter object for beforeMudslide layer
        var tParamsBefore = new TimeParameters();
        tParamsBefore.TimeRange = new TimeRange();

        tParamsBefore.TimeRange.Start = new DateTime(2021, 11, 24);
        tParamsBefore.TimeRange.End = new DateTime(2021, 11, 25);
        //Testing the validity of the time filter
        if (beforeMudSlideImge.CanSetTime(tParamsBefore))
        {
          beforeMudSlideImge.SetTime(tParamsBefore); //apply the filter
        }

        //Configure TimeParameter object for afterMudslide layer
        var tParamsAfter = new TimeParameters();
        tParamsAfter.TimeRange = new TimeRange();

        tParamsAfter.TimeRange.Start = new DateTime(2021, 11, 26);
        tParamsAfter.TimeRange.End = new DateTime(2021, 11, 27);

        //Testing the validity of the time filter
        if (AfterMudSlideImge.CanSetTime(tParamsAfter))
        {
          AfterMudSlideImge.SetTime(tParamsAfter); //apply the filter
        }

        //Configure the time slider
        //Specify the step interval for visualization
        var delta = new TimeDelta(1, TimeUnit.Days);
        //Create time range
        var startTime = new DateTime(2021, 11, 24);
        var timeRange = new TimeRange(startTime, delta);

        timeRange.ExcludeStart = false;
        timeRange.ExcludeEnd = false;
        //Apply the time range to the map view
        MapView.Active.Time = timeRange;
      });
    }
  }
}
