﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeAPIDemo
{
  internal class ConfigureTemporalPropertiesOnLayers : Button
  {
    protected override void OnClick()
    {
      if (MapView.Active == null) return;
      QueuedTask.Run( () => {
        var layers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureSceneLayer>();
        foreach (var layer in layers) {
          //is layer time aware?
          if (!layer.IsTimeSupported()) break;
          
          //Configure TimeParameter object
          var tParams = new TimeParameters();
          
          //Attribute field to use - With date info 
          tParams.StartTimeFieldName = "ConstructionDate";                    

          //Testing the validity of the time filter
          if (layer.CanSetTime(tParams))
          {
            layer.SetTime(tParams); //apply the filter
          }

          #region Show feature cumulatively
          var layerDefn = layer.GetDefinition() as CIMIndexedSceneLayer;
          if (layerDefn != null)
          {
            var timeDefn = layerDefn.TimeDisplayDefinition;
            if (timeDefn != null)
            {
              timeDefn.Cumulative = true;
              layerDefn.TimeDisplayDefinition = timeDefn;
              layer.SetDefinition(layerDefn);
            }
          }
          #endregion
        }
       
      });
    }
  }
}
