﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeAPIDemo
{
  internal class SetMapViewTimeExtent : Button
  {
    protected override void OnClick()
    {
      QueuedTask.Run(() => {
        #region Configure Time Slider
        //Specify the step interval for visualization
        var delta = new TimeDelta(100, TimeUnit.Years);
        //Create time range
        var startTime = new DateTime(1601, 01, 01);
        var timeRange = new TimeRange(startTime, delta);
        timeRange.ExcludeStart = false;
        timeRange.ExcludeEnd = false;
        //Apply the time range to the map view
        MapView.Active.Time = timeRange;
        #endregion
      });
    }
  }
}