﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.UnitFormats;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoordinateGeometrySDK
{
  internal class ConvertDirectionFormat : Button
  {
    protected async override void OnClick()
    {
      string directionFormatString = "Quadrant Bearing";
      //Run on MCT
      await QueuedTask.Run(() =>
      {
        //get the direction format and units from the backstage default settings
        var inputDirectionUnit =
          DisplayUnitFormats.Instance.GetDefaultProjectUnitFormat(UnitFormatType.Direction);
        directionFormatString = inputDirectionUnit.DisplayName;
        //=====================================================
        //Get an entered string value for a direction
        //=====================================================
        var sDirectionInBackstageFormat = 
          Microsoft.VisualBasic.Interaction.InputBox
            ("Direction in " + directionFormatString + ":", "Convert", "n10-59-59e");
        
        if (sDirectionInBackstageFormat.Trim() == "")
          return;

        var DirectionInNorthAzimuth = ConvertToNorthAzimuthDecimalDegrees(inputDirectionUnit, sDirectionInBackstageFormat);
        //=====================================================
        MessageBox.Show("Write this value to the direction field:\n" + DirectionInNorthAzimuth.ToString("0.0000000"),
          "Converted Direction");
      });
    }

    private double ConvertToNorthAzimuthDecimalDegrees(DisplayUnitFormat incomingUnitFormat, 
      string InDirectionString)
    {
      var DirectionConv = DirectionUnitFormatConversion.Instance;
      var dirTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar; //default to polar
      
      var directionUnitFormat = incomingUnitFormat.UnitFormat as CIMDirectionFormat;

      //Set the direction type on the converter from the incoming Direction format's type
      if (directionUnitFormat.DirectionType == ArcGIS.Core.CIM.DirectionType.NorthAzimuth)
        dirTypeIn = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth;
      else if (directionUnitFormat.DirectionType == ArcGIS.Core.CIM.DirectionType.SouthAzimuth)
        dirTypeIn = ArcGIS.Core.SystemCore.DirectionType.SouthAzimuth;
      else if (directionUnitFormat.DirectionType == ArcGIS.Core.CIM.DirectionType.Polar)
        dirTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar;
      else if (directionUnitFormat.DirectionType == ArcGIS.Core.CIM.DirectionType.QuadrantBearing)
        dirTypeIn = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing;

      //Set the direction unit on the converter from the incoming Direction format's unit
      var dirUnitIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians;
      if (directionUnitFormat.Units == ArcGIS.Core.CIM.DirectionUnits.DegreesMinutesSeconds)
        dirUnitIn = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds;
      else if (directionUnitFormat.Units == ArcGIS.Core.CIM.DirectionUnits.DecimalDegrees)
        dirUnitIn = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees;
      else if (directionUnitFormat.Units == ArcGIS.Core.CIM.DirectionUnits.Gradians)
        dirUnitIn = ArcGIS.Core.SystemCore.DirectionUnits.Gradians;
      else if (directionUnitFormat.Units == ArcGIS.Core.CIM.DirectionUnits.Gons) //same as gradians
        dirUnitIn = ArcGIS.Core.SystemCore.DirectionUnits.Gons;

      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = dirTypeIn,
        DirectionUnitsIn = dirUnitIn,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return DirectionConv.ConvertToDouble(InDirectionString, ConvDef);
    }
  }
}
