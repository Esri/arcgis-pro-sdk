﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoordinateGeometrySDK
{
  internal class CreateOffsetsAtBends : Button
  {
    protected async override void OnClick()
    {
      // methods need to run on MCT
      await QueuedTask.Run(() =>
      {
        var layers = MapView.Active.Map.GetLayersAsFlattenedList();
        var lineFeatLyr = layers.FirstOrDefault(l => l.Name.Contains("Connect") && l is FeatureLayer && l.IsVisible);

        if (lineFeatLyr == null)
        {
          System.Windows.MessageBox.Show("Source layer with name 'Connect' not found in the table of contents", "Create Offsets at Bends");
          return;
        }

        SpatialReference sr = MapView.Active.Map.SpatialReference;

        var ids = new List<long>((lineFeatLyr as FeatureLayer).GetSelection().GetObjectIDs());
        var fcDefinition = (lineFeatLyr as FeatureLayer).GetFeatureClass().GetDefinition();

        if (!fcDefinition.IsCOGOEnabled())
        {
          MessageBox.Show("Please select a single feature from a COGO Enabled Feature class");
          return;
        }

        //=====================================================
        //User Entry Values
        //=====================================================

        //string sOffsetRatioParameter = Microsoft.VisualBasic.Interaction.InputBox("Ratio:", "Create offsets at bends", "200");
        //if (!Double.TryParse(sOffsetRatioParameter, out double oRP))
        //  return;
        string sOffsetRatioParameter = "200";
        if (!Double.TryParse(sOffsetRatioParameter, out double oRP))
          return;
        //=====================================================

        //var minO = 0.1; //feet
        //var maxO = 5.0; //feet
        
        var minO = 0.05/0.3048; //feet
        var maxO = 2.0/0.3048; //feet

        var pQuery = new QueryFilter();
        pQuery.ObjectIDs = ids;
        FeatureClass cogoFClass = (lineFeatLyr as FeatureLayer).GetFeatureClass();
        ICollection<Segment> segments = new List<Segment>();
        Dictionary<string, object> COGOAttributes = new Dictionary<string, object>();

        var editOper = new EditOperation()
        {
          Name = "Create offsets at bends",
          ProgressMessage = "Create Offsets at bends...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
        };

        using (RowCursor rowCursor = cogoFClass.Search(pQuery, false))
        {
          while (rowCursor.MoveNext())
          {
            using (Row row = rowCursor.Current)
            {
              Polyline thePolyline = (row as Feature).GetShape() as Polyline;
              if (thePolyline == null)
                continue;

              int numPoints = thePolyline.PointCount;
              if (numPoints <= 2)
                continue;
              //startPoint = thePolyline.Points[0];
              //endPoint = thePolyline.Points[numPoints - 1];
              thePolyline.GetAllSegments(ref segments);
              var segList = segments.ToList();
              for (int i = 0; i < segList.Count - 1; i++)
              {
                var pointA = segList[i].StartCoordinate;
                var pointB = segList[i].EndCoordinate;
                var pointC = segList[i + 1].EndCoordinate;

                //straight line ac
                var lineACVec = new Coordinate3D(pointC.X - pointA.X, pointC.Y - pointA.Y, 0);
                var lineACUnitVec = new Coordinate3D();//unit vector
                lineACUnitVec.SetPolarComponents(lineACVec.Azimuth, 0, 1.0);
                //====
                //straight line ab
                var lineABVec = new Coordinate3D(pointB.X - pointA.X, pointB.Y - pointA.Y, 0);
                var lineABUnitVec = new Coordinate3D();//unit vector
                lineABUnitVec.SetPolarComponents(lineABVec.Azimuth, 0, 1.0);
                //====
                //straight line bc
                var lineBCVec = new Coordinate3D(pointC.X - pointB.X, pointC.Y - pointB.Y, 0);
                var lineBCUnitVec = new Coordinate3D();//unit vector
                lineBCUnitVec.SetPolarComponents(lineBCVec.Azimuth, 0, 1.0);
                //====

                var dotProd = lineACUnitVec.DotProduct(lineABUnitVec);
                var angBAC = Math.Acos(dotProd);

                var mB = Math.Sin(angBAC) * lineABVec.Magnitude;
                var mA = Math.Cos(angBAC) * lineABVec.Magnitude;

                dotProd = lineACUnitVec.DotProduct(lineBCUnitVec);
                var angBCA = Math.Acos(dotProd);
                var mC = Math.Cos(angBCA) * lineBCVec.Magnitude;

                var R = (mC < mA) ? mC / mB : mA / mB;
                bool iAmABend = (R <= oRP && mB >= minO) || mB >= maxO;

                if (iAmABend)
                {
                  //Calculate point m (drop perpendicular)
                  Coordinate3D pVec1 = new Coordinate3D(pointA.X, pointA.Y, 0);
                  Coordinate3D pVec2 = new Coordinate3D();
                  pVec2.SetPolarComponents(lineACVec.Azimuth, 0, mA);
                  Coordinate2D pointM = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
                  var offsetSegment = LineBuilderEx.CreateLineSegment(pointB, pointM);
                  Polyline offsetLine = PolylineBuilderEx.CreatePolyline(offsetSegment);
                  COGOAttributes.Add("direction", PolarRadiansToNorthAzimuthDecimalDegrees(offsetSegment.Angle));
                  COGOAttributes.Add("distance", offsetSegment.Length);
                  editOper.Create(lineFeatLyr as FeatureLayer, offsetLine, COGOAttributes);
                  COGOAttributes.Clear(); //this is OK. CreateEx makes a clone / copy of the attributes, prior to editOper.Execute();
                }
              }
            }
          }
        }
        editOper.Execute();
      });
    }

    private double PolarRadiansToNorthAzimuthDecimalDegrees(double InPolarRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InPolarRadians, ConvDef);
    }
  }
}