﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CoordinateGeometrySDK
{
  internal class SpiralTangentAtGivenLength : Button
  {
    protected async override void OnClick()
    {
      // methods need to run on MCT
      await QueuedTask.Run( () =>
      {
      var layers = MapView.Active.Map.GetLayersAsFlattenedList();
      var lineFeatLyr = layers.FirstOrDefault(l => l.Name.Contains("Connect") && l is FeatureLayer && l.IsVisible);

      if (lineFeatLyr == null)
      {
        System.Windows.MessageBox.Show("Source layer with name 'Connect' not found in the table of contents", "Create Spiral with Tangent and Offset");
        return;
      }

      SpatialReference sr = MapView.Active.Map.SpatialReference;

      if ((lineFeatLyr as FeatureLayer).SelectionCount != 1)
      {
        MessageBox.Show("Please select a single Spiral from a COGO Enabled Feature class");
        return;
      }

      var ids = new List<long>((lineFeatLyr as FeatureLayer).GetSelection().GetObjectIDs());
      var fcDefinition = (lineFeatLyr as FeatureLayer).GetFeatureClass().GetDefinition();

      if (!fcDefinition.IsCOGOEnabled())
      {
        MessageBox.Show("Please select a single Spiral from a COGO Enabled Feature class");
        return;
      }

      //=====================================================
      //User Entry Values
      //=====================================================
      double dOffset1 = -100;
      double dOffset2 = 100;

      string sDistanceAlong = Microsoft.VisualBasic.Interaction.InputBox("Distance Along:", "Station And Offset", "300");
      if (!Double.TryParse(sDistanceAlong, out double queryArcLength))
        return;
      //=====================================================

      var pQuery = new QueryFilter();
      pQuery.ObjectIDs = ids;
      FeatureClass cogoFClass = (lineFeatLyr as FeatureLayer).GetFeatureClass();
      int iStartRadius = fcDefinition.FindField("radius");
      int iEndRadius = fcDefinition.FindField("radius2");
      int iArcLength = fcDefinition.FindField("arclength");
      int iDirection = fcDefinition.FindField("direction");

      bool bNULLCOGOFAIL = false;
      MapPoint startPoint = null;
      MapPoint endPoint = null;

      double tangentDirection = 0; //QuadrantBearingDMSToPolarRadians("n14-19-33w");

      double ChordDirectionNAzDecDegs = 0;
      double startRadius = 0, endRadius = 0, arcLength = 0;

      using (RowCursor rowCursor = cogoFClass.Search(pQuery, false))
      {
        while (rowCursor.MoveNext())
        {
          using (Row row = rowCursor.Current)
          {
            Polyline spiralPolyline = (row as Feature).GetShape() as Polyline;
            if (spiralPolyline == null)
              return;

            int numPoints = spiralPolyline.PointCount;
            startPoint = spiralPolyline.Points[0];
            endPoint = spiralPolyline.Points[numPoints-1];

            if (row[iStartRadius] == null || row[iEndRadius] == null || row[iArcLength] == null)
            {
              bNULLCOGOFAIL = true;
              break;
            }

            startRadius = Convert.ToDouble(row[iStartRadius]);

            if (startRadius == 0)
              startRadius = double.PositiveInfinity;
            endRadius = Convert.ToDouble(row[iEndRadius]);

            if (endRadius == 0)
              endRadius = double.PositiveInfinity;
            arcLength = Convert.ToDouble(row[iArcLength]);

            if (row[iDirection]!=null)
              ChordDirectionNAzDecDegs = Convert.ToDouble(row[iDirection]);

          }
        }
      }

      if (bNULLCOGOFAIL)
      {
        MessageBox.Show("Selected line is missing COGO attributes");
        return;
      }

        //create a local copy of the spiral
        //Spiral Chord Direction to Tangent Direction 

        //get the geometry chord direction from the selected spiral's end points.
        Coordinate3D p1 = new Coordinate3D(startPoint);
        Coordinate3D p2= new Coordinate3D(endPoint);

        Coordinate3D chordVec = new Coordinate3D(p2.X - p1.X, p2.Y - p1.Y, 0);
        double geomChordAz = chordVec.Azimuth * 180/Math.PI;

        tangentDirection = GetSpiralTangentDirectionFromChord(geomChordAz, startRadius, endRadius, arcLength, sr);
        tangentDirection = NAzDecimalDegToPolarRadians(tangentDirection);

        MapPoint pointOnPath;
        double radiusCalculated, tangentDirectionCalculated, lengthCalculated, angleCalculated;
        string sRadiusCalculatedComputed, sTangentDirectionComputed, sLengthAlongComputed, sDeltaAngleComputed;

        //if (!QuerySpiralParametersByArclength1(queryArcLength, startPoint, tangentDirection, startRadius, endRadius, arcLength, sr, out pointOnPath,
        //  out radiusCalculated, out tangentDirectionCalculated, out lengthCalculated, out angleCalculated))
        //  return;


        if (!QuerySpiralParametersByArclength2(queryArcLength, startPoint, tangentDirection, startRadius, endRadius, arcLength, sr, out pointOnPath,
               out radiusCalculated, out tangentDirectionCalculated, out lengthCalculated, out angleCalculated))
          return;


        sRadiusCalculatedComputed = radiusCalculated.ToString("0.00");
        sTangentDirectionComputed = PolarRadiansToQuadBearingDMS(tangentDirectionCalculated);
        sLengthAlongComputed = lengthCalculated.ToString("0.00");
        sDeltaAngleComputed = AngleInRadiansToDMS(angleCalculated).ToString();

        List<Coordinate2D> CoordinateList = new List<Coordinate2D>();

        double tangentDirectionNAzRadians = PolarRadiansToNorthAzimuthDecimalDegrees(tangentDirectionCalculated) * Math.PI / 180;
        Coordinate2D coordAtTangentOnPath = new Coordinate2D(pointOnPath);
        Coordinate3D pVec1 = new Coordinate3D(pointOnPath.X, pointOnPath.Y, 0);
        Coordinate3D pVec2 = new Coordinate3D();
        pVec2.SetPolarComponents(tangentDirectionNAzRadians, 0, 200);
        Coordinate2D coordEndTangent = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));

        CoordinateList.Add(coordAtTangentOnPath);
        CoordinateList.Add(coordEndTangent);
        Polyline TangentLine = PolylineBuilderEx.CreatePolyline(CoordinateList, sr);

        //Compute offset 1 and create orthogonal offset line
        CoordinateList.Clear();
        double d90Degrees = Math.PI / 2;
        if (dOffset1 < 0)
          d90Degrees = d90Degrees * -1;

        double dOffsetDirection1 = (tangentDirectionNAzRadians + d90Degrees);

        pVec2.SetEmpty();
        pVec2.SetPolarComponents(dOffsetDirection1, 0, Math.Abs(dOffset1));
        Coordinate2D coordEndOffset = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
        CoordinateList.Add(coordAtTangentOnPath);
        CoordinateList.Add(coordEndOffset);
        Polyline Offset1 = PolylineBuilderEx.CreatePolyline(CoordinateList, sr);

        //Compute offset 2 and create orthogonal offset line
        CoordinateList.Clear();
        d90Degrees = Math.PI / 2;
        if (dOffset2 < 0)
          d90Degrees = d90Degrees * -1;

        double dOffsetDirection2 = (tangentDirectionNAzRadians + d90Degrees);

        pVec2.SetEmpty();
        pVec2.SetPolarComponents(dOffsetDirection2, 0, Math.Abs(dOffset2));
        coordEndOffset = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
        CoordinateList.Add(coordAtTangentOnPath);
        CoordinateList.Add(coordEndOffset);
        Polyline Offset2 = PolylineBuilderEx.CreatePolyline(CoordinateList, sr);

        Dictionary<string, object> COGOAttributes = new Dictionary<string, object>();

        if (TangentLine != null)
        {
          var editOper = new EditOperation()
          {
            Name = "Create Spiral with Tangent and Offsets",
            ProgressMessage = "Create Spiral with Tangent and Offsets...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = false,
          };

          COGOAttributes.Add("direction", NAzRadiansToNorthAzimuthDecimalDegrees(tangentDirectionNAzRadians));
          editOper.Create((lineFeatLyr as FeatureLayer), TangentLine, COGOAttributes);
          COGOAttributes.Clear(); //this is OK. CreateEx makes a clone / copy of the attributes, prior to editOper.Execute();

          COGOAttributes.Add("direction", NAzRadiansToNorthAzimuthDecimalDegrees(dOffsetDirection1));
          editOper.Create((lineFeatLyr as FeatureLayer), Offset1, COGOAttributes);
          COGOAttributes.Clear();//this is OK. CreateEx makes a clone / copy of the attributes, prior to editOper.Execute();

          COGOAttributes.Add("direction", NAzRadiansToNorthAzimuthDecimalDegrees(dOffsetDirection2));
          editOper.Create((lineFeatLyr as FeatureLayer), Offset2, COGOAttributes);
          COGOAttributes.Clear();//this is OK. CreateEx makes a clone / copy of the attributes, prior to editOper.Execute();

          editOper.Execute();
        }

      });

    }

    private bool QuerySpiralParametersByArclength2(double queryLength, MapPoint constructorStartPoint, double constructorTangentDirection,
              double constructorStartRadius, double constructorEndRadius, double constructorArcLength, SpatialReference spatRef,
       out MapPoint tangentPointOnPath, out double radiusCalculated, out double tangentDirectionCalculated, out double lengthCalculated,
       out double deltaAngleCalculated)
    {//Returns a point on a constructed spiral that is at the given distance along that constructed spiral.
     //Returns the following at this station: tangent point, tangent direction, radius, delta angle

      ArcOrientation orientation = ArcOrientation.ArcClockwise;
      if (constructorStartRadius < 0 || constructorEndRadius < 0)
        orientation = ArcOrientation.ArcCounterClockwise;

      ClothoidCreateMethod createMethod = ClothoidCreateMethod.ByLength;
      CurveDensifyMethod densifyMethod = CurveDensifyMethod.ByLength;

      double densifyParameter = constructorArcLength / 5000; //densification has an upper limit of 5000 vertices

      Polyline mySpiral = PolylineBuilderEx.CreatePolyline(constructorStartPoint, constructorTangentDirection, constructorStartRadius,
            Math.Abs(constructorEndRadius), orientation, createMethod, constructorArcLength, densifyMethod, densifyParameter, spatRef);

      int numPoints = mySpiral.PointCount; //this has an upper limit with small densify parameter methods. 5000 points

      if (queryLength > constructorArcLength)
        queryLength = constructorArcLength;

      int idxOfClosestQueryPoint = Convert.ToInt32(Math.Floor(queryLength / constructorArcLength * numPoints)) - 1;

      if (idxOfClosestQueryPoint < 0)
        idxOfClosestQueryPoint = 0;

      MapPoint queryPointAtArcLength = mySpiral.Points[idxOfClosestQueryPoint]; //query point at arclength query distance

      double radius01_Calculated, tangentDirection01_Calculated, length01_Calculated, deltaAngle01_Calculated;
      MapPoint tangentPointOnPath01=null, tangentPointOnPath02=null;

      PolylineBuilderEx.QueryClothoidParameters(queryPointAtArcLength, constructorStartPoint, constructorTangentDirection,
                    Math.Abs(constructorStartRadius), Math.Abs(constructorEndRadius), orientation, createMethod, constructorArcLength,
        out tangentPointOnPath01, out radius01_Calculated, out tangentDirection01_Calculated, out length01_Calculated, out deltaAngle01_Calculated, spatRef);

      //test out arc length of this first densification point against our requested arc length
      double smallArcLength = 0;
      if (length01_Calculated < queryLength) //should always be the case, unless they're exactly equal
        smallArcLength = queryLength - length01_Calculated;

      if (smallArcLength > 0 && ((numPoints-1) != idxOfClosestQueryPoint))
      {
        queryPointAtArcLength = mySpiral.Points[idxOfClosestQueryPoint + 1];

        PolylineBuilderEx.QueryClothoidParameters(queryPointAtArcLength, constructorStartPoint, constructorTangentDirection,
                Math.Abs(constructorStartRadius), Math.Abs(constructorEndRadius), orientation, createMethod, constructorArcLength,
            out tangentPointOnPath02, out radiusCalculated, out tangentDirectionCalculated, out lengthCalculated, out deltaAngleCalculated, spatRef);

        //go smallArcLength distance from tangentPointOnPath01 in the direction tangentDirection01_Calculated
        Coordinate3D TangPt01 = new Coordinate3D(tangentPointOnPath01);
        Coordinate3D TangPt02 = new Coordinate3D();
        TangPt02.SetPolarComponents(PolarRadiansToNorthAzimuthDecimalDegrees(tangentDirection01_Calculated) * Math.PI/180, 0, smallArcLength);
        MapPoint queryPointRefined = TangPt01.AddCoordinate3D(TangPt02).ToMapPoint(spatRef);

        double SmallSpiralArcLength = (lengthCalculated - queryLength) + smallArcLength;
        
        //construct and query the small refined spiral between the 2 densification points
        PolylineBuilderEx.QueryClothoidParameters(queryPointRefined, tangentPointOnPath01, tangentDirection01_Calculated,
                Math.Abs(radius01_Calculated), Math.Abs(radiusCalculated), orientation, createMethod, SmallSpiralArcLength,
            out tangentPointOnPath, out radiusCalculated, out tangentDirectionCalculated, out lengthCalculated, out deltaAngleCalculated, spatRef);

        //test the computed tangentPointOnPath against the refined query point

        double xDiff = (queryPointRefined.X - tangentPointOnPath.X);
        double yDiff = (queryPointRefined.Y - tangentPointOnPath.Y);
        double dDist = Math.Sqrt(((xDiff * xDiff) + (yDiff * yDiff)));

        //NOTE: input tangent point on path is updated on out parameter

        PolylineBuilderEx.QueryClothoidParameters(tangentPointOnPath, constructorStartPoint, constructorTangentDirection,
                      Math.Abs(constructorStartRadius), Math.Abs(constructorEndRadius), orientation, createMethod, constructorArcLength,
            out tangentPointOnPath, out radiusCalculated, out tangentDirectionCalculated, out lengthCalculated, out deltaAngleCalculated, spatRef);

      }
      else
      {
        radiusCalculated = radius01_Calculated;
        tangentDirectionCalculated = tangentDirection01_Calculated;
        lengthCalculated = length01_Calculated;
        deltaAngleCalculated = deltaAngle01_Calculated;
        tangentPointOnPath = tangentPointOnPath01;
      }
     return true;
    }

    private bool QuerySpiralParametersByArclength1(double queryLength, MapPoint constructorStartPoint, double constructorTangentDirection,
              double constructorStartRadius, double constructorEndRadius, double constructorArcLength, SpatialReference spatRef,
       out MapPoint tangentPointOnPath, out double radiusCalculated, out double tangentDirectionCalculated, out double lengthCalculated, 
       out double deltaAngleCalculated)
     
    {//Returns a point on a constructed spiral that is at the given distance along that constructed spiral.
     //Returns the following at this station: tangent point, tangent direction, radius, delta angle


      //reference book: "Spiral Curves"
      //Jim Crume P.L.S.
      //page 32: Points on a Spiral Curve

      //---------------------------------------------------------------------------------------------------------------------
      //NOTE: this formula is for the case of one Radius at infinity. Use QuerySpiralParametersByArclength2 function
      // for both radii at non-infinity.
      //----------------------------------------------------------------------------------------------------------------------

      //spiral delta 
      //R=5729.57795/D
      //R = End radius of main simple curve
      //D = Degree of curvature of main curve
      //Ls = Length of spiral
      //a = Rate of change per 100 feet [maybe that can be unit agnostic if all others like radius are in same unit?]
      // a = (D * 100)/Ls

      //D =5729.57795/R

      ArcOrientation orientation = ArcOrientation.ArcClockwise;
      if (constructorStartRadius < 0 || constructorEndRadius < 0)
        orientation = ArcOrientation.ArcCounterClockwise;

      ClothoidCreateMethod createMethod = ClothoidCreateMethod.ByLength;


      //TODO: currently set up to start at infinity and go to end radius. Can also be computed in the other direction


      double spiral_D = 5729.57795 / Math.Abs(constructorEndRadius);
      double spiral_a = (spiral_D * 100) / constructorArcLength;

      //Point on a spiral curve
      double a_squared = Math.Pow(spiral_a, 2);
      double lsi_5th_power = Math.Pow((queryLength / 100), 5);
      double spiral_C = queryLength - (0.00034 * a_squared * lsi_5th_power);

      double deflection = (spiral_a * Math.Pow(queryLength, 2)) / 60000;
      double distAlongTangentFromStart = spiral_C * Math.Cos(deflection * Math.PI / 180);
      double deflectionOffsetFromTangent = spiral_C * Math.Sin(deflection * Math.PI / 180);

      double nAzRadianstangentDir = PolarRadiansToNorthAzimuthDecimalDegrees(constructorTangentDirection) * Math.PI / 180;

      Coordinate3D pVec1 = new Coordinate3D(constructorStartPoint.X, constructorStartPoint.Y, 0);
      Coordinate3D pVec2 = new Coordinate3D();
      pVec2.SetPolarComponents(nAzRadianstangentDir, 0, distAlongTangentFromStart);
      Coordinate2D coord2 = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));

      //if orientation is to the left then subtract 90° for offset
      //if orientation is to the right then add 90° for offset

      double d90Degrees = Math.PI / 2;
      if (orientation == ArcOrientation.ArcCounterClockwise)
        d90Degrees = d90Degrees * -1;

      Coordinate3D pVec3 = new Coordinate3D(coord2.X, coord2.Y, 0);
      Coordinate3D pVec4 = new Coordinate3D();
      pVec4.SetPolarComponents(nAzRadianstangentDir + d90Degrees, 0, deflectionOffsetFromTangent);
      Coordinate2D coord3 = new Coordinate2D(pVec3.AddCoordinate3D(pVec4));

      MapPoint computedTangentPointOnPath = MapPointBuilderEx.CreateMapPoint(coord3.X, coord3.Y);


      PolylineBuilderEx.QueryClothoidParameters(computedTangentPointOnPath, constructorStartPoint, constructorTangentDirection, 
                    Math.Abs(constructorStartRadius), Math.Abs(constructorEndRadius), orientation, createMethod, constructorArcLength,
        out tangentPointOnPath, out radiusCalculated, out tangentDirectionCalculated, out lengthCalculated, out deltaAngleCalculated, spatRef);

      return true;

    }

    private double GetSpiralTangentDirectionFromChord(double InChordDirectionNAzDecDegs, double startRadius,
        double endRadius, double arcLength, SpatialReference spatRef)
    {
      ArcOrientation orientation = ArcOrientation.ArcClockwise;
      if (startRadius < 0 || endRadius < 0)
        orientation = ArcOrientation.ArcCounterClockwise;

      ClothoidCreateMethod createMethod = ClothoidCreateMethod.ByLength;
      CurveDensifyMethod densifyMethod = CurveDensifyMethod.ByLength;
      double densifyParameter = arcLength / 5000; //densification has an upper limit of 5000 vertices

      MapPoint startPoint = MapPointBuilderEx.CreateMapPoint(0, 0);

      double inPolarRadiansChord = NAzDecimalDegToPolarRadians(InChordDirectionNAzDecDegs);

      Coordinate3D inChordVec = new Coordinate3D();
      inChordVec.SetPolarComponents(InChordDirectionNAzDecDegs * Math.PI / 180, 0, 1);

      Polyline mySpiral = PolylineBuilderEx.CreatePolyline(startPoint, inPolarRadiansChord, Math.Abs(startRadius),
      Math.Abs(endRadius), orientation, createMethod, arcLength, densifyMethod, densifyParameter, spatRef);

      Coordinate3D computedChord = new Coordinate3D();
      int numPoints = mySpiral.PointCount;
      computedChord.SetComponents(mySpiral.Points[numPoints - 1].X, mySpiral.Points[numPoints - 1].Y, 0);
      double computedChordDirection = computedChord.Azimuth;

      Coordinate3D computedChordVector = new Coordinate3D();
      computedChordVector.SetPolarComponents(computedChordDirection, 0, 1);

      double dDotProd = inChordVec.DotProduct(computedChordVector);
      double dAngle = Math.Acos(dDotProd) * 180 / Math.PI; // in degrees

      double tangentDirection = computedChordVector.Azimuth * 180 / Math.PI; //initialize the tangent as the same as chord, then correct it

      if (orientation == ArcOrientation.ArcClockwise)
        tangentDirection -= 2 * dAngle;
      else
        tangentDirection += 2 * dAngle;

      tangentDirection = NAzRadiansToNorthAzimuthDecimalDegrees(tangentDirection * Math.PI / 180); //this for cases of >360° or negative values

      return tangentDirection; //comes out as decimal degrees NAz

    }
    private double QuadrantBearingDMSToPolarDecimalDegrees(string InQuadBearingDMS)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InQuadBearingDMS, ConvDef);
    }

    private double QuadrantBearingDMSToPolarRadians(string InQuadBearingDMS)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };
      return AngConv.ConvertToDouble(InQuadBearingDMS, ConvDef);
    }

    private double AngleInDMSToRadians(string InAngleinDMS)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };
      return AngConv.ConvertToDouble(InAngleinDMS, ConvDef);
    }

    private string AngleInRadiansToDMS(double InAngleInRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds
      };
      return AngConv.ConvertToString(InAngleInRadians, 0, ConvDef);
    }

    private double PolarRadiansToNorthAzimuthDecimalDegrees(double InPolarRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InPolarRadians, ConvDef);
    }

    private double NAzDecimalDegToPolarRadians(double InNAzDecimalDegrees)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };
      return AngConv.ConvertToDouble(InNAzDecimalDegrees, ConvDef);
    }

    private double NAzRadiansToNorthAzimuthDecimalDegrees(double InNAzRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InNAzRadians, ConvDef);
    }

    private string NAzRadiansToQuadBearingDMS(double InNAzRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds
      };
      return AngConv.ConvertToString(InNAzRadians,0, ConvDef);
    }

    private string PolarRadiansToQuadBearingDMS(double InNAzRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds
      };
      return AngConv.ConvertToString(InNAzRadians, 0, ConvDef);
    }

  }


}

