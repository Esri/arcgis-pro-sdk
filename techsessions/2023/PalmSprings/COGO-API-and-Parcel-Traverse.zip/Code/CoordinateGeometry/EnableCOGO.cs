﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace CoordinateGeometrySDK
{
  internal class EnableCOGO : Button
  {
    protected async override void OnClick()
    {

      string sReportResult = "";
      string errorMessage = await QueuedTask.Run(async () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a line layer in the table of contents.";

        //first get the feature layer that's selected in the table of contents
        var lineLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();

        var fcDefinition = lineLyr.GetFeatureClass()?.GetDefinition();
        if (fcDefinition == null)
          return "Could not get the feature class.";
        if (fcDefinition.GetShapeType() != GeometryType.Polyline)
          return "Please select a line layer in the table of contents.";

        bool bIsCOGOEnabled = fcDefinition.IsCOGOEnabled();

        if (bIsCOGOEnabled)
          return "This line layer is already COGO Enabled.";

        var LineFC = lineLyr.GetFeatureClass();
        var sPathToGDB = LineFC.GetDatastore().GetConnectionString().Replace("DATABASE=", "");
        var pFDS = LineFC.GetFeatureDataset();
        var sPathToLineFC = "";
        if (pFDS == null)
          sPathToLineFC = sPathToLineFC = Path.Combine(sPathToGDB, LineFC.GetName());
        else
          sPathToLineFC = Path.Combine(sPathToGDB, pFDS.GetName(), LineFC.GetName());

        try
        {
          await EnableCOGOAsync(sPathToLineFC);
          //Remove and then re-add layer
          //remove layer
          var map = MapView.Active.Map;
          map.RemoveLayer(lineLyr);

          var featureClassUri = new Uri(sPathToLineFC);
          //Define the Feature Layer's parameters.
          var layerParams = new FeatureLayerCreationParams(featureClassUri)
          {
            //Set visibility
            IsVisible = true,
          };
          var createdLayer = LayerFactory.Instance.CreateLayer<FeatureLayer>(layerParams, MapView.Active.Map);
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "COGO Enable Line Features");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "COGO Enable Line Features");
    }

    protected async Task EnableCOGOAsync(string LineFCPath)
    {
      var progDlg = new ProgressDialog("Enable COGO for line feature class", "Cancel", 100, true);
      progDlg.Show();

      //GP Enable COGO
      GPExecuteToolFlags flags = GPExecuteToolFlags.Default | GPExecuteToolFlags.GPThread;
      var progSrc = new CancelableProgressorSource(progDlg);
      var parameters = Geoprocessing.MakeValueArray(LineFCPath);
      await Geoprocessing.ExecuteToolAsync("management.EnableCOGO", parameters,
          null, progSrc.Progressor, flags);

      progDlg.Hide();
    }
  }
}
