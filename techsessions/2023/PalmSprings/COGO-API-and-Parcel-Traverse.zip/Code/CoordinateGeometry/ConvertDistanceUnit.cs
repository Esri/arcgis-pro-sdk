﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.UnitFormats;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoordinateGeometrySDK
{
  internal class ConvertDistanceUnit : Button
  {
    protected async override void OnClick()
    {
      string distanceUnitString = "meters";

      // check for selected layer
      if (MapView.Active.GetSelectedLayers().Count == 0)
      {
        MessageBox.Show("Please select a line layer in the table of contents.",  "Converted Distance");
        return;
      }
      //first get the feature layer that's selected in the table of contents
      var MyFeatureLayer = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
      //get the feature class definition object

      double metersPerUnitDataEntry = 1.0;
      double metersPerUnitTargetDataset = 1.0;

      //Run on MCT
      await QueuedTask.Run(() =>
      {
        var fcDefinition = MyFeatureLayer?.GetFeatureClass()?.GetDefinition();
        if (fcDefinition == null)
          return;
        //get the metric unit conversion from the dataset
        if (fcDefinition.GetSpatialReference().IsProjected)
          metersPerUnitTargetDataset = fcDefinition.GetSpatialReference().Unit.ConversionFactor;

        //get the distance unit from the backstage default settings
        var inputDialogDistanceUnit =
          DisplayUnitFormats.Instance.GetDefaultProjectUnitFormat(UnitFormatType.Distance);
        distanceUnitString = inputDialogDistanceUnit.DisplayName;

        //get the metric unit conversion from the backstage
        metersPerUnitDataEntry = inputDialogDistanceUnit.MeasurementUnit.ConversionFactor;

      });
      //=====================================================
      //Get an entered distance value
      //=====================================================
      string sDistanceInBackstageUnits = 
        Microsoft.VisualBasic.Interaction.InputBox("Distance in " + distanceUnitString + ":", "Convert", "300");

      if (sDistanceInBackstageUnits.Trim() == "")
        return;

      if (!Double.TryParse(sDistanceInBackstageUnits, out double enteredDistance))
        return;

      var enteredDistanceInMeters = enteredDistance * metersPerUnitDataEntry;
      var convertedDistance = enteredDistanceInMeters / metersPerUnitTargetDataset;

      MessageBox.Show("Write this value to the distance field:\n" + convertedDistance.ToString("0.000"),
        "Converted Distance");
      //=====================================================

    }
  }
}
