﻿using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAndGeometryControl
{
  internal class TableViewHideColumnsButton : Button
  {
    private bool _ShowCustomization = false;

    protected override void OnClick()
    {
      _ShowCustomization = !_ShowCustomization;
      try
      {
        var paneDetail = Module1.GetTablePaneReady(Module1.TaxParcelPolygonLayerName);
        var tableView = TableView.Active;
        if (_ShowCustomization)
        {
          // set visible and hidden columns
          // hide PostedDate and Posted Columns
          tableView.ShowAllFields();
          tableView.SetHiddenFields(new List<string>() { 
            "Shape", "CreatedByRecord", "RetiredByRecord", "CalculatedArea",
            "StatedAreaUnit", "StatedArea",  "TMK", "Parcel", "Zone", "Section", "Plat",
            "IsSeed", "created_user", "created_date", "last_edited_user", "last_edited_date",
            "Shape_Area", "GlobalID","VALIDATIONSTATUS"});
        }
        else
        {
          tableView.ShowAllFields();
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {this} {ex}");
      }
    }
  }
}
