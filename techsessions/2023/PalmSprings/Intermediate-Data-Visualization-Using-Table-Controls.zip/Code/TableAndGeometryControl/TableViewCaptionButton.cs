﻿using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAndGeometryControl
{
  internal class TableViewCaptionButton : Button
  {
    private bool _ShowCustomization = false;

    protected override void OnClick()
    {
      _ShowCustomization = !_ShowCustomization;
      try
      {
        var paneDetail = Module1.GetTablePaneReady(Module1.TaxParcelPolygonLayerName);
        // set the TableView's Caption using the ITableViewEx interface
        paneDetail.iTablePaneEx.Caption = _ShowCustomization ?
                                        $@"{Module1.TaxParcelPolygonLayerName} Parcels"
                                        : Module1.TaxParcelPolygonLayerName;
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {this} {ex}");
      }
    }
  }
}
