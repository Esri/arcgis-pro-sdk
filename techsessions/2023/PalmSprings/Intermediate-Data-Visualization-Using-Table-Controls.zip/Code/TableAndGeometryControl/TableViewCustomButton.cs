﻿using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TableAndGeometryControl.Helper;

namespace TableAndGeometryControl
{
  internal class TableViewCustomButton : Button
  {

    private bool _ShowCustomization = false;

    protected override void OnClick()
    {
      _ShowCustomization = !_ShowCustomization;
      try
      {
        var paneDetail = Module1.GetTablePaneReady(Module1.TaxParcelPolygonLayerName);
        // customize the TableView / or set it back to default
        // and set the TableView's Caption using the ITableViewEx interface
        if (_ShowCustomization)
        {
          paneDetail.iTablePaneEx.Caption = $@"{Module1.TaxParcelPolygonLayerName} Parcels";
          PrepareTableView(TableView.Active);
        }
        else
        {
          paneDetail.iTablePaneEx.Caption = Module1.TaxParcelPolygonLayerName;
          Module1.ResetTableView(TableView.Active);
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {this} {ex}");
      }
    }

    /// <summary>
    /// Shows the CAMA queue, only the non-posted CAMA records: where Posted = 0
    /// </summary>
    /// <param name="tableView">Cama table View</param>
    private static async void PrepareTableView(TableView tableView)
    {
      // change the camaTableView as well
      if (tableView == null || tableView.IsReady == false)
      {
        DiagnosticHelper.WriteLine(tableView == null ? "Active TableView is null" : "Active TableView is not ready");
        return;
      }
      // set visible and hidden columns
      // hide PostedDate and Posted Columns
      tableView.ShowAllFields();
      tableView.SetHiddenFields(new List<string> () { "Shape", "CreatedByRecord", "RetiredByRecord", "CalculatedArea", 
        "StatedAreaUnit", "StatedArea",  "TMK", "Parcel", "Zone", "Section", "Plat", 
        "IsSeed", "created_user", "created_date", "last_edited_user", "last_edited_date", 
        "Shape_Area", "GlobalID","VALIDATIONSTATUS"});

      // clear and reset frozen fields
      var frozenFields = tableView.GetFrozenFields();
      if (!frozenFields.Contains("Name"))
      {
        await tableView.ClearAllFrozenFieldsAsync();
        await tableView.SetFrozenFieldsAsync(new List<string> { "ObjectId", "Name" });
      }
      await tableView.SetViewMode(TableViewMode.eAllRecords);
      tableView.SetZoomLevel(150);
    }
  }
}
