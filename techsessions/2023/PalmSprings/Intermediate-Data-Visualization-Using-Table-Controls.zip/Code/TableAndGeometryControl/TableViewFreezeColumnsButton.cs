﻿using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAndGeometryControl
{
  internal class TableViewFreezeColumnsButton : Button
  {
    private bool _ShowCustomization = false;

    protected override async void OnClick()
    {
      _ShowCustomization = !_ShowCustomization;
      try
      {
        var paneDetail = Module1.GetTablePaneReady(Module1.TaxParcelPolygonLayerName);
        var tableView = TableView.Active;
        if (_ShowCustomization)
        {
          // clear and reset frozen fields
          var frozenFields = tableView.GetFrozenFields();
          if (!frozenFields.Contains("Name"))
          {
            await tableView.ClearAllFrozenFieldsAsync();
            await tableView.SetFrozenFieldsAsync(new List<string> { "ObjectId", "Name" });
          }
        }
        else
        {
          await tableView.ClearAllFrozenFieldsAsync();
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {this} {ex}");
      }
    }
  }
}
