﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAndGeometryControl
{
  class IdentifyTool : MapTool
  {
    /// <summary>
    ///  Constructor
    /// </summary>
    public IdentifyTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
    }

    /// <summary>
    ///  On sketch completion find the intersecting feature and show it in the
    ///  TableControl
    /// </summary>
    /// <param name="geometry"></param>
    /// <returns></returns>
    protected override async Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      if (Module1.SelectedMapMember is BasicFeatureLayer layer)
      {
        // create a new spatial filter
        //  to find features intersecting the sketch geometry
        var filter = new SpatialQueryFilter
        {
          FilterGeometry = geometry,
          SpatialRelationship = SpatialRelationship.Intersects
        };

        long oid = -1;
        await QueuedTask.Run(() =>
        {
          // search the layer using the filter
          //   finding the first objectId
          using var cursor = layer.Search(filter);
          if (cursor.MoveNext())
          {
            using var row = cursor.Current;
            oid = row.GetObjectID();
          }
        });

        // if an objectID was found
        if (oid == -1) return false;

        // find the dockpane viewmodel
        // call MoveTo
        if (FrameworkApplication.DockPaneManager.Find("TableAndGeometryControl_TableControlDockpane") is TableControlDockpaneViewModel vm)
        {
          vm.MoveToAsync(oid);
        }
      }
      return true;
    }

  }
}
