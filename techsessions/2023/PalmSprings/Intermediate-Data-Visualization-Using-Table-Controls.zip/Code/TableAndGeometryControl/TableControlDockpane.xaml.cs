﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace TableAndGeometryControl
{
  /// <summary>
  /// Interaction logic for TableControlDockpaneView.xaml
  /// </summary>
  public partial class TableControlDockpaneView : UserControl
  {
    public static readonly DependencyProperty BoundDataContextProperty = DependencyProperty.Register(
    "BoundDataContext",
    typeof(object),
    typeof(TableControlDockpaneView),
    new PropertyMetadata(null, OnBoundDataContextChanged));

    private static void OnBoundDataContextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      // e.NewValue is your new DataContext
      // d is your UserControl
      // set the TableControl property in the ViewModel
      var vm = (e.NewValue) as TableControlDockpaneViewModel;
      if (vm != null)
      {
        vm.MyTableControl = (d as TableControlDockpaneView).tableControl;
      }
    }

    public TableControlDockpaneView()
    {
      InitializeComponent();

      this.SetBinding(BoundDataContextProperty, new Binding());
    }
  }
}
