﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using TableAndGeometryControl.Helper;

namespace TableAndGeometryControl
{
  internal class Module1 : Module
  {
    internal static readonly List<string> TaxTableHiddenFields = new() {
            "Shape", "CreatedByRecord", "RetiredByRecord", "CalculatedArea",
            "StatedAreaUnit", "StatedArea",  "TMK", "Parcel", "Zone", "Section", "Plat",
            "IsSeed", "created_user", "created_date", "last_edited_user", "last_edited_date",
            "Shape_Area", "GlobalID", "VALIDATIONSTATUS", "MiscloseRatio", "MiscloseDistance", "Island"};
    internal static readonly List<string> TaxTableFrozenFields = new() { "ObjectId", "Name" };

    internal static readonly string TaxParcelPolygonLayerName = "Tax";
    internal static MapMember SelectedMapMember = null;

    private static Module1 _this = null;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("TableAndGeometryControl_Module");

    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

    #region Utility Functions

    /// <summary>
    /// Called to get a TablePane ready for customization.  Use any Feature Layer Name as input.
    /// </summary>
    /// <param name="featureLayerName"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    internal static (ITablePane iTablePane, ITablePaneEx iTablePaneEx) GetTablePaneReady(string featureLayerName)
    {
      try
      {        // work on the tax table
        var taxTable = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(featureLayerName)).FirstOrDefault();
        if (taxTable == null)
        {
          throw new Exception ($@"Unable to find Feature class in for map member {Module1.TaxParcelPolygonLayerName} in the Table of Content");
        }
        // open / activate the tax table pane
        var iTablePane = Module1.OpenAndActivateTablePane(taxTable);
        if (iTablePane == null)
        {
          throw new Exception($@"Unable to get TablePane for feature layer {Module1.TaxParcelPolygonLayerName}");
        }
        var iTablePaneEx = iTablePane as ITablePaneEx;
        if (iTablePaneEx == null)
        {
          throw new Exception($@"Unable to get TablePaneEx for feature layer {Module1.TaxParcelPolygonLayerName}");
        }
        return (iTablePane, iTablePaneEx);
      }
      catch (Exception ex)
      {
        throw new Exception($@"Error in {DiagnosticHelper.CurrentMethodName()}: {ex.Message}");
      }
    }

    /// <summary>
    /// utility function to open and activate the TablePane for a given MapMember
    /// </summary>
    /// <param name="mapMember">table to have the table view activated</param>
    internal static ITablePane OpenAndActivateTablePane(MapMember mapMember)
    {
      try
      {
        // check the open panes to see if it's open but just needs activating
        IEnumerable<ITablePane> tablePanes = FrameworkApplication.Panes.OfType<ITablePane>();
        foreach (var tablePane in tablePanes)
        {
          if (tablePane.MapMember != mapMember) continue;
          var pane = tablePane as Pane;
          pane?.Activate();
          return pane as ITablePane;
        }
        // it's not currently open... so open it
        if (FrameworkApplication.Panes.CanOpenTablePane(mapMember))
        {
          return FrameworkApplication.Panes.OpenTablePane(mapMember);
        }
        return null;
      }
      catch (Exception ex)
      {
        throw new Exception($@"Error in {DiagnosticHelper.CurrentMethodName()}: {ex.Message}");
      }
    }


    /// <summary>
    /// Reset the table views
    /// </summary>
    /// <param name="tableView">table View</param>
    internal static async void ResetTableView(TableView tableView)
    {
      if (tableView == null || tableView.IsReady == false)
      {
        DiagnosticHelper.WriteLine(tableView == null ? "Active TableView is null" : "Active TableView is not ready");
        return;
      }
      // set visible and hidden columns
      // clear and reset frozen fields
      await tableView.ClearAllFrozenFieldsAsync();

      await tableView.SetFrozenFieldsAsync(new List<string> { });

      tableView.ShowAllFields();

      await tableView.SetViewMode(TableViewMode.eAllRecords);
      tableView.SetZoomLevel(100);
    }

    #endregion
  }
}
