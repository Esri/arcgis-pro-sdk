﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Events;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Controls;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Threading;
using TableAndGeometryControl.Helper;

namespace TableAndGeometryControl
{
  internal class TableControlDockpaneViewModel : DockPane
  {
    private const string _dockPaneID = "TableAndGeometryControl_TableControlDockpane";
    private bool _isFiltered = false;
    private bool _isViewModeSelected = false;
    private Item _selectedItem;
    private TableControlContent _tableContent;
    private TableControl _MyTableControl;

    protected TableControlDockpaneViewModel() 
    {
      ProjectWindowSelectedItemsChangedEvent.Subscribe(OnProjectWindowSelectedItem);
      TOCSelectionChangedEvent.Subscribe((mapViewEventArgs) =>
      {
        var selectedLayer = mapViewEventArgs.MapView.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        if (selectedLayer != null)
        {
          // create the content
          var tableContent = TableControlContentFactory.Create(selectedLayer);

          // assign it
          if (tableContent != null)
          {
            this.TableContent = tableContent;
            Module1.SelectedMapMember= selectedLayer;
          }

        }
      });
    }

    /// <summary>
    /// Allows to add the selection (if it's a table or feature class) to the TableControl
    /// </summary>
    /// <param name="args"></param>
    private void OnProjectWindowSelectedItem(ProjectWindowSelectedItemsChangedEventArgs args)
    {
      if (args.IProjectWindow.SelectionCount > 0)
      {
        Module1.SelectedMapMember = null;

        // get the first selected item from the Map TOC
        _selectedItem = args.IProjectWindow.SelectedItems.First();

        // check if it's supported by the TableControl
        if (!TableControlContentFactory.IsItemSupported(_selectedItem))
          return;

        // create the content and initialize the TableContent Property
        var tableContent = TableControlContentFactory.Create(_selectedItem);

        // assign it
        if (tableContent != null)
        {
          this.TableContent = tableContent;
        }
      }
    }

    internal async void MoveToAsync(long oid)
    {
      if (oid == -1 || MyTableControl == null) return;
      await QueuedTask.Run(async () =>
      {
        // get the row index from the oid
        var rowIndex = MyTableControl.GetRowIndex(oid, false);
        if (rowIndex != -1)
        {
          // scroll to it
          await MyTableControl.BringIntoView(rowIndex);
          // clear any existing selection
          MyTableControl.ClearSelection();

          // toggle selection state of the row (ie select it)
          MyTableControl.ToggleRowSelection();
        }
      });
    }

    #region Commands

    public ICommand CmdAddToMap => new RelayCommand(() =>
    {
      var map = MapView.Active?.Map;
      if (map == null)
        return;

      QueuedTask.Run(() =>
      {
        // test if the selected Catalog item can create a layer
        if (LayerFactory.Instance.CanCreateLayerFrom(_selectedItem))
        {
          var creationParams = new LayerCreationParams(_selectedItem);
          Module1.SelectedMapMember = LayerFactory.Instance.CreateLayer<FeatureLayer>(creationParams, map);
        }
        // test if the selected Catalog item can create a table
        else if (StandaloneTableFactory.Instance.CanCreateStandaloneTableFrom(_selectedItem))
        {
          var creationParams = new StandaloneTableCreationParams(_selectedItem);
          Module1.SelectedMapMember = StandaloneTableFactory.Instance.CreateStandaloneTable(creationParams, map);
        }
        else
        {
          Module1.SelectedMapMember = null;
        }
      });

    }, _selectedItem != null);

    public ICommand CmdFilterTableControl => new RelayCommand(async () =>
    {
      if (MyTableControl == null) return;
      DiagnosticHelper.Start();

      // update the look and feel of the TableControl
      _isFiltered = !_isFiltered;
      if (_isFiltered)
      {
        // set visible and hidden columns
        MyTableControl.ShowAllFields();
        // set visible and hidden columns
        // Hide fields that i am not interested in:
        MyTableControl.SetHiddenFields(Module1.TaxTableHiddenFields);
        // Freeze fields to keep them in view - "Name"
        await MyTableControl.SetFrozenFieldsAsync(Module1.TaxTableFrozenFields);
        //// Set ViewMode to show just selected records
        //await TableControl.SetViewMode(showSelectedRecordsOnly);
        // magnify the table view by factor of 1.2
        MyTableControl.SetZoomLevel(120);
      }
      else
      {
        // clear and reset frozen fields
        await MyTableControl.ClearAllFrozenFieldsAsync();
        await MyTableControl.SetFrozenFieldsAsync(new List<string>() { });
        // set visible and hidden columns
        MyTableControl.ShowAllFields();
        await MyTableControl.SetViewMode(TableViewMode.eAllRecords);

        MyTableControl.SetZoomLevel(100);
      }

    }, true);

    public ICommand CmdViewModeTableControl => new RelayCommand(async () =>
    {
      if (MyTableControl == null) return;
      DiagnosticHelper.Start();

      // update the look and feel of the TableControl
      _isViewModeSelected = !_isViewModeSelected;
      if (_isViewModeSelected)
      {
        // Set ViewMode to show just selected records
        await MyTableControl.SetViewMode(TableViewMode.eSelectedRecords);
      }
      else
      {
        // clear selected only viewmode
        await MyTableControl.SetViewMode(TableViewMode.eAllRecords);

        MyTableControl.SetZoomLevel(100);
      }

    }, true);

    public ICommand CmdZoomToSelectedTableControl => new RelayCommand(() =>
    {
      if (MyTableControl == null) return;
      DiagnosticHelper.Start();

      // zoom to selected record on the map
      MyTableControl.ZoomToSelected();

    }, true);

    #endregion

    #region Command Images

    public System.Windows.Media.ImageSource CmdFilterTableControlImage
    {
      get => System.Windows.Application.Current.Resources["TableRelatedData16"] as System.Windows.Media.ImageSource;
    }
    public System.Windows.Media.ImageSource CmdViewModeTableControlImage
    {
      get => System.Windows.Application.Current.Resources["TableReselectHighlighted16"] as System.Windows.Media.ImageSource;
    }
    public System.Windows.Media.ImageSource CmdZoomToSelectedTableControlImage
    {
      get => System.Windows.Application.Current.Resources["ZoomToSelectedItems16"] as System.Windows.Media.ImageSource;
    }
    public System.Windows.Media.ImageSource CmdCustomSortImage
    {
      get => System.Windows.Application.Current.Resources["TableSort32"] as System.Windows.Media.ImageSource;
    }
    public System.Windows.Media.ImageSource CmdExportImage
    {
      get => System.Windows.Application.Current.Resources["ExportTable32"] as System.Windows.Media.ImageSource;
    }
    public System.Windows.Media.ImageSource CmdFindImage
    {
      get => System.Windows.Application.Current.Resources["Search_Find32"] as System.Windows.Media.ImageSource;
    }
    #endregion

    #region Properties

    public TableControlContent TableContent
    {
      get => _tableContent;
      set => SetProperty(ref _tableContent, value);
    }

    public TableControl MyTableControl
    {
      get => _MyTableControl;
      set => SetProperty(ref _MyTableControl, value);
    }

    #endregion

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class TableControlDockpane_ShowButton : Button
  {
    protected override void OnClick()
    {
      TableControlDockpaneViewModel.Show();
    }
  }
}
