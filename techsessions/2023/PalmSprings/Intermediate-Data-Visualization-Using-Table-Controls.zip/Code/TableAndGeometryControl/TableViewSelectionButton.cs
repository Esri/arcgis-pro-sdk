﻿using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableAndGeometryControl
{
  internal class TableViewSelectionButton : Button
  {
    private bool _ShowCustomization = false;

    protected override async void OnClick()
    {
      _ShowCustomization = !_ShowCustomization;
      try
      {
        var paneDetail = Module1.GetTablePaneReady(Module1.TaxParcelPolygonLayerName);
        await (TableView.Active).SetViewMode(_ShowCustomization ? 
                      TableViewMode.eSelectedRecords : TableViewMode.eAllRecords);
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error: {this} {ex}");
      }
    }
  }
}
