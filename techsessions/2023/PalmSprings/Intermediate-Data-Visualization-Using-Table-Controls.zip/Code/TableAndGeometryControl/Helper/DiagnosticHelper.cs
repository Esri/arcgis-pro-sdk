﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace TableAndGeometryControl.Helper
{
  internal static class DiagnosticHelper
  {
    internal static string CurrentMethodName([CallerMemberName] string caller = null) => caller;

    internal static void Start ([CallerMemberName] string caller = null) => System.Diagnostics.Trace.WriteLine ($@"Called: {caller}");

    internal static void WriteLine (string line) => System.Diagnostics.Trace.WriteLine (line);
  }
}
