﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Hosting;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PointPolygonOverlay
{
  internal class Program
  {

    private static string _arcgisProPath = "";
    //[STAThread] must be present on the Application entry point
    [STAThread]
    static void Main(string[] args)
    {
      // Perform CoreHost task: point over polygon
      try
      {
        // Get path of the ArcGIS Pro installation from registry
        // Pro has to be installed to run any CoreHost app
        _arcgisProPath = GetInstallDirAndVersionFromReg().path;
        if (string.IsNullOrEmpty(_arcgisProPath)) throw new InvalidOperationException("ArcGIS Pro is not installed.");

        // Resolve ArcGIS Pro assemblies, this allows us to run the 
        // Corehost app from any path.
        AppDomain currentDomain = AppDomain.CurrentDomain;
        currentDomain.AssemblyResolve += new ResolveEventHandler(ResolveProAssemblyPath);

        PerformPointOverpolygon(args);
      }
      catch (Exception e)
      {
        Console.WriteLine($@"Error: {e.ToString()}");
        return;
      }
    }

    /// <summary>
    /// Initilize the CoreHost environment then check the parameters
    /// then Overlay points over polygons and store the result in an 
    /// output FeatureClass
    /// </summary>
    /// <param name="args"></param>
    private static void PerformPointOverpolygon(string[] args)
    {
      // Call Host.Initialize before constructing any objects from ArcGIS.Core
      try
      {
        Host.Initialize();
      }
      catch (Exception e)
      {
        // Error (missing installation, no license, 64 bit mismatch, etc.)
        throw new Exception($@"Corehost Initialization failed: {e.Message}");
      }
      // check input parameters
      if (args.Length < 4)
      {
        var usage = @"Usage: PointPolygonOverlay geoDatabasePath pointFeatureClassName polygonFeatureClassName resultPointFeatureClassName";
        Console.WriteLine(usage);
        Console.WriteLine(@" PointPolygonOverlay tries to find the polygon 'under' the point or if no polygon is found tries to find the nearest polygon");
        Console.WriteLine(@" Where: geoDatabasePath is the geodatabase that contains the point, polygon and result point feature classes.");
        Console.WriteLine(@"        pointFeatureClassName is the feature class containing the points that we try to match with a polygon");
        Console.WriteLine(@"        polygonFeatureClassName is the feature class containing the polygons");
        Console.WriteLine(@"        resultPointFeatureClassName contains the results of the overlay (or nearest polygon) operation");
        throw new ArgumentException($@"Command line argument(s) missing: {usage}");
      }
      string geodatabasePath = args[0];
      string pointFeatureClassName = args[1];
      string polygonFeatureClassName = args[2];
      string resultPointFeatureClassName = args[3];
      try
      {
        using var gdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(geodatabasePath, UriKind.Absolute)));
        gdb.ApplyEdits(() =>
        {
          using var pointFeatureClass = gdb.OpenDataset<FeatureClass>(pointFeatureClassName);
          using var polygonFeatureClass = gdb.OpenDataset<FeatureClass>(polygonFeatureClassName);
          using var resultPointFeatureClass = gdb.OpenDataset<FeatureClass>(resultPointFeatureClassName);
          // process all points
          // add queryfilter to select SystemLinkId null records only
          var qf = new QueryFilter() { WhereClause = "SystemLinkID = null" };
          // for testing use all of them
          using var pointCursor = pointFeatureClass.Search(null, false);
          while (pointCursor.MoveNext())
          {
            // retrieve the first feature
            using var pointFeat = pointCursor.Current as Feature;
            // first we try the overlay
            var spatialQuery = new SpatialQueryFilter()
            {
              FilterGeometry = pointFeat.GetShape(),
              SpatialRelationship = SpatialRelationship.Intersects
            };
            using var polygonCursor = polygonFeatureClass.Search(spatialQuery);
            if (polygonCursor.MoveNext())
            {
              // found a polygon for this point
              // retrieve the polygon feature
              using var polygonFeat = polygonCursor.Current as Feature;
              // add the result  and save the result object id as the system link id
              var resultFeat = AddResult(pointFeat, polygonFeat, resultPointFeatureClass);
              pointFeat["SystemLinkID"] = resultFeat.GetObjectID();
              pointFeat.Store();
              continue;
            }
            // expand the point's envelope
            double bufferSize = 100;
            var pnt = pointFeat.GetShape() as MapPoint;
            var extent = EnvelopeBuilderEx.CreateEnvelope(pnt.X - bufferSize, pnt.Y - bufferSize, pnt.X + bufferSize, pnt.Y + bufferSize, pnt.SpatialReference);
            // try this 10 times then we give up
            Dictionary<string, object> nearestPolygon = null;
            for (int i = 0; i < 10; i++)
            {
              extent = extent.Expand(bufferSize, bufferSize, false);
              var sq = new SpatialQueryFilter()
              {
                FilterGeometry = extent,
                SpatialRelationship = SpatialRelationship.Contains
              };
              using var largePolygonCursor = polygonFeatureClass.Search(sq, false);
              var shortestDistance = double.MaxValue;
              while (largePolygonCursor.MoveNext())
              {
                using var polygonFeat = largePolygonCursor.Current as Feature;
                var dist = GeometryEngine.Instance.Distance(pointFeat.GetShape(), polygonFeat.GetShape());
                if (dist < shortestDistance)
                {
                  nearestPolygon = new Dictionary<string, object>
                {
                  { "Location", GetString(polygonFeat, "Location") },
                  { "ParcelID", GetString(polygonFeat, "ParcelID") }
                };
                  shortestDistance = dist;
                }
              }
              if (nearestPolygon != null)
              {
                // add the result  and save the result object id as the system link id
                var resultFeat = AddResult(pointFeat, nearestPolygon, resultPointFeatureClass);
                pointFeat["SystemLinkID"] = resultFeat.GetObjectID();
                pointFeat.Store();
                break;
              }
            }
            if (nearestPolygon == null)
            {
              Console.WriteLine($@"Can't find a polygon for oid: [{pointFeat.GetObjectID()}] address: [{pointFeat["Address"]}]");
            }
          }
        });
      }
      catch (Exception ex) 
      {
        throw new Exception($@"Error while processing points: {ex.ToString()}");
      }
    }

    /// <summary>
    /// Add the result using a point feature and polygon feature
    /// </summary>
    /// <param name="pointFeat"></param>
    /// <param name="polygonFeat"></param>
    /// <param name="resultPointFeatureClass"></param>
    /// <returns>newly added feature</returns>
    private static Feature AddResult(Feature pointFeat, 
      Feature polygonFeat, 
      FeatureClass resultPointFeatureClass)
    {
      var newRowBuffer = resultPointFeatureClass.CreateRowBuffer();
      var point = pointFeat.GetShape().Clone() as MapPoint;
      newRowBuffer["Shape"] = MapPointBuilderEx.CreateMapPoint(point.X, point.Y, 0, pointFeat.GetShape().SpatialReference);
      newRowBuffer["Location"] = GetString(polygonFeat, "Location");
      newRowBuffer["ParcelID"] = GetString(polygonFeat, "ParcelID");
      newRowBuffer["Address"] = GetString(pointFeat, "Address");
      newRowBuffer["TimeStamp"] = DateTime.Now;
      return resultPointFeatureClass.CreateRow(newRowBuffer);
    }

    /// <summary>
    /// Add the result using a point feature and polygon feature
    /// </summary>
    /// <param name="pointFeat"></param>
    /// <param name="polygonFeat"></param>
    /// <param name="resultPointFeatureClass"></param>
    /// <returns>newly added feature</returns>
    private static Feature AddResult(Feature pointFeat,
      Dictionary<string, object> polygonFeat,
      FeatureClass resultPointFeatureClass)
    {
      var newRowBuffer = resultPointFeatureClass.CreateRowBuffer();
      var point = pointFeat.GetShape().Clone() as MapPoint;
      newRowBuffer["Shape"] = MapPointBuilderEx.CreateMapPoint(point.X, point.Y, 0, pointFeat.GetShape().SpatialReference);
      newRowBuffer["Location"] = polygonFeat["Location"];
      newRowBuffer["ParcelID"] = polygonFeat["ParcelID"];
      newRowBuffer["Address"] = GetString(pointFeat, "Address");
      newRowBuffer["TimeStamp"] = DateTime.Now;
      return resultPointFeatureClass.CreateRow(newRowBuffer);
    }

    private static string GetString (Feature feature, string columnName)
    {
      if (feature[columnName] == DBNull.Value) { return string.Empty; }
      return feature[columnName].ToString();
    }

    /// <summary>
    /// Resolves the ArcGIS Pro Assembly Path.  Called when loading of an assembly fails.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    /// <returns>programmatically loaded assembly in the pro /bin path</returns>
    static Assembly ResolveProAssemblyPath(object sender, ResolveEventArgs args)
    {
      string assemblyPath = Path.Combine(_arcgisProPath, "bin", new AssemblyName(args.Name).Name + ".dll");
      if (!File.Exists(assemblyPath)) return null;
      Assembly assembly = Assembly.LoadFrom(assemblyPath);
      return assembly;
    }

    /// <summary>
    /// Gets the ArcGIS Pro install location, major version, and build number from the registry.
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception">InvalidOperationException</exception>
    internal static (string path, string version, string buildNo) GetInstallDirAndVersionFromReg()
    {
      string regKeyName = "ArcGISPro";
      string regPath = $@"SOFTWARE\ESRI\{regKeyName}";

      string err1 = $@"Install location of ArcGIS Pro cannot be found. Please check your registry for HKLM\{regPath}\InstallDir";
      string err2 = $@"Version of ArcGIS Pro cannot be determined. Please check your registry for HKLM\{regPath}\Version";
      string err3 = $@"Build Number of ArcGIS Pro cannot be determined. Please check your registry for HKLM\{regPath}\BuildNumber";
      string path;
      string version;
      string buildNo;
      try
      {
        RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
        RegistryKey esriKey = localKey.OpenSubKey(regPath);

        if (esriKey == null)
        {
          localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.CurrentUser, RegistryView.Registry64);
          esriKey = localKey.OpenSubKey(regPath);
        }
        if (esriKey == null)
        {
          //this is an error
          throw new System.InvalidOperationException(err1);
        }
        path = esriKey.GetValue("InstallDir") as string;
        if (path == null || path == string.Empty)
          //this is an error
          throw new InvalidOperationException(err1);

        version = esriKey.GetValue("Version") as string;
        if (version == null || version == string.Empty)
          //this is an error
          throw new InvalidOperationException(err2);

        buildNo = esriKey.GetValue("BuildNumber") as string;
        if (buildNo == null || buildNo == string.Empty)
          //this is an error
          throw new InvalidOperationException(err3);
      }
      catch (InvalidOperationException ie)
      {
        //this is ours
        throw ie;
      }
      catch (Exception ex)
      {
        throw new Exception(err1, ex);
      }
      return (path, version, buildNo);
    }
  }
}
