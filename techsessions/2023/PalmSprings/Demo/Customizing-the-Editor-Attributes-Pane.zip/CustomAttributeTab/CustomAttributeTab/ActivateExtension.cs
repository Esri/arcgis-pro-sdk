﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributeTab
{
    internal class ActivateExtension : Button
    {
    protected override void OnClick()
    {
      //Gets the building footprint layer
      var featureLayer = MapView.Active?.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().
        Where(g => g.ShapeType == esriGeometryType.esriGeometryPolygon && g.Name == "SanDiegoDowntownFootprint").FirstOrDefault();
      if (featureLayer == null) return;
      //Unique quid - must match guid attribute in the DAML.
      Guid myExtension = new Guid("{f019fd26-4824-45d8-9788-2a0746973b31}");
      QueuedTask.Run(() =>
      {        
            //Get the feature class of the layer
            var fc = featureLayer.GetFeatureClass();
            // Register the extension ID (Guid) with the feature class table.
            fc.AddActivationExtension(myExtension);
      });
    }
  }
}
