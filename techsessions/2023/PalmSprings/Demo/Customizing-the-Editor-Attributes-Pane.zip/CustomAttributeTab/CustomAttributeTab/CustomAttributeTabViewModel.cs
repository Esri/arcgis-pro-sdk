﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Internal.CIM;
using ArcGIS.Core.Internal.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;


namespace CustomAttributeTab
{
  internal class CustomAttributeTabViewModel : ArcGIS.Desktop.Editing.Attributes.AttributeTabEmbeddableControl
  {
    #region Private members
    private FeatureLayer _sanDiegoFootprintsLayer = null;
    private Map _sanDiegoScene;
    private FeatureLayer _sanDiegoMultiPatchLayer = null;
    private Pane _sanDiegoScenePane = null;
    private CIMBasicFeatureLayer _sanDiegoFootprintLyrDfn;
    private CIMFeatureTable _sanDiegoFootprintTable;
    private string _displayField;
    #endregion
    public CustomAttributeTabViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) {
      if (MapView.Active == null) return;
      var sanDiegoProjectItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(m => m.Name == "San Diego Scene");
      if (sanDiegoProjectItem == null) return;    
      
      Module1.CustomTabVM = this;
      QueuedTask.Run(() => {
        _sanDiegoScene = sanDiegoProjectItem.GetMap();
        //Set the MapControl's content to display the San Diego Scene.
        MapContent = MapControlContentFactory.Create(_sanDiegoScene, _sanDiegoScene.GetDefaultExtent(), MapViewingMode.SceneLocal);       
      });
    }

    /// <summary>
    /// Does this control (and it's parent tab) apply to this MapMember.  Default is false. 
    /// </summary>
    /// <param name="mapMember"></param>
    /// <returns>
    /// If the return value is false, a custom tab containing this control will not be displayed when a row from Mapmember
    /// is highlighted in the attributes treeview. 
    /// </returns>
    public override bool Applies(MapMember mapMember)
    {
      _sanDiegoFootprintsLayer = mapMember as FeatureLayer;
      bool isPolygonMM = false;
      QueuedTask.Run(() =>
      {
        if (_sanDiegoFootprintsLayer != null)
        {
          if (_sanDiegoFootprintsLayer.ShapeType == esriGeometryType.esriGeometryPolygon && _sanDiegoFootprintsLayer.Name == "SanDiegoDowntownFootprint")
            isPolygonMM = true;         
        }
      });
      return isPolygonMM;
    }
    /// <summary>
    /// Is the parent tab default.  Default is false.
    /// </summary>
    public override bool IsDefault => false;
    /// <summary>
    /// Does this control (and it's parent tab) support selection of multiple rows in the Attribute treeview.  Default is false.
    /// </summary>
    public override bool SupportsMultiples => base.SupportsMultiples;
    private long _oid;
    /// <summary>
    /// Called when attributes from one or more rows have been loaded into the Inspector
    /// </summary>
    /// <returns></returns>
    public async override Task LoadFromFeaturesAsync()
    {
      if (Inspector == null) return;

      await QueuedTask.Run(() =>
      {
        // get the CIM definition from the layer
        _sanDiegoFootprintLyrDfn = _sanDiegoFootprintsLayer.GetDefinition() as ArcGIS.Core.CIM.CIMBasicFeatureLayer;
        // get source table underlying the layer
        _sanDiegoFootprintTable = _sanDiegoFootprintLyrDfn.FeatureTable;
        //Get the display field of the selected feature/row
        _displayField = _sanDiegoFootprintTable.DisplayField;

        //Binding for the FeatureName property
        FeatureName = Inspector[_displayField].ToString();

        //Populate the Map Control with a bookmark view of the selected feature
        var bookmark = _sanDiegoScene.GetBookmarks().FirstOrDefault(b => b.Name == FeatureName);
        var bmkDefn = bookmark.GetDefinition();
        var bmkCIMViewCamera = bmkDefn.Camera;
        MapControlCamera = new Camera(bmkCIMViewCamera.X, 
                                      bmkCIMViewCamera.Y, 
                                      bmkCIMViewCamera.Z, 
                                      bmkCIMViewCamera.Pitch, 
                                      bmkCIMViewCamera.Heading, 
                                      _sanDiegoScene.SpatialReference, 
                                      CameraViewpoint.LookFrom);               
      });
    }
    #region Property bindings
    /// <summary>
    /// Text to be displayed in the Custom tab. In this example, the NAME field of the selected feature will be displayed.
    /// </summary>
    private string _featureName;
    public string FeatureName
    {
      get => _featureName;
      set
      {
        SetProperty(ref _featureName, value, () => FeatureName);
      }
    }

    private string _coordX;
    public string CoordinateX
    {
      get=> _coordX;
      set => SetProperty(ref _coordX, value, () => CoordinateX);  
    }

    private string _coordY;
    public string CoordinateY
    {
      get => _coordY;
      set => SetProperty(ref _coordY, value, () => CoordinateY);
    }

    private MapControlContent _mapContent;
    public MapControlContent MapContent
    {
      get => _mapContent;
      set => SetProperty(ref _mapContent, value, () => MapContent);
    }

    private Camera _mapControlCamera;
    public Camera MapControlCamera
    {
      get => _mapControlCamera;
      set => SetProperty(ref _mapControlCamera, value);
    }

    private ArcGIS.Core.Geometry.Envelope _extent;
    public ArcGIS.Core.Geometry.Envelope Extent
    {
      get => _extent;
      set => SetProperty(ref _extent, value, () => Extent);
    }

    private MapControl _theMapControl;
    public MapControl TheMapControl
    {
      get => _theMapControl;
      set => SetProperty(ref _theMapControl, value, () => TheMapControl); 
    }


    private ICommand _flashFeatures = null;
    public ICommand FlashFeatures
    {
      get
      {
        //_flashFeatures = new RelayCommand(() => FlashFeatures(), () => true);
        return _flashFeatures;
      }
    }


    #endregion
    #region Utility Methods
    private void LabelFeature(string fieldName, string featureName, ArcGIS.Core.Geometry.Geometry geometry, CIMTextSymbol textSymbol)
    {
      var lyrDefn = _sanDiegoFootprintsLayer.GetDefinition() as CIMFeatureLayer;
      //Get the label classes - we need the first one
      var listLabelClasses = lyrDefn.LabelClasses.ToList();
      var theLabelClass = listLabelClasses.FirstOrDefault();
      //Set the label classes' symbol to the custom text symbol
      //Refer to the ProSnippets-TextSymbols wiki page for help with creating custom text symbols.
      //Example: var textSymbol = await CreateTextSymbolWithHaloAsync();
      theLabelClass.TextSymbol.Symbol = textSymbol;
      theLabelClass.WhereClause = $"{fieldName} = '{featureName}'";
      lyrDefn.LabelClasses = listLabelClasses.ToArray(); //Set the labelClasses back
      _sanDiegoFootprintsLayer.SetDefinition(lyrDefn); //set the layer's definition
                                           //set the label's visiblity
      _sanDiegoFootprintsLayer.SetLabelVisibility(true);
    }
    private IDisposable _graphic = null;

    private CIMPointSymbol _starSymbol = null;

    internal static Task<CIMPointSymbol> CreatePointSymbolAsync()
    {
      return QueuedTask.Run(() =>
      {
        return SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.RedRGB, 14, SimpleMarkerStyle.Star);
      });
    }
    private static Task<CIMTextSymbol> CreateSimpleLineCalloutAsync()
    {
      return QueuedTask.Run<CIMTextSymbol>(() => {
        //create a text symbol
        var textSymbol = SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 10, "Verdana", "Regular");
        //Create a line call out
        var lineCalloutSymbol = new CIMSimpleLineCallout();
        //Get a line symbol
        var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.BlackRGB, 1, SimpleLineStyle.DashDotDot);
        //assign the line symbol to the callout
        lineCalloutSymbol.LineSymbol = lineSymbol;
        //Offset for the text
        textSymbol.OffsetX = 10;
        textSymbol.OffsetY = 10;
        //Assign the callout to the text symbol
        textSymbol.Callout = lineCalloutSymbol;
        return textSymbol;
      });
    }
    #endregion

  }
}
