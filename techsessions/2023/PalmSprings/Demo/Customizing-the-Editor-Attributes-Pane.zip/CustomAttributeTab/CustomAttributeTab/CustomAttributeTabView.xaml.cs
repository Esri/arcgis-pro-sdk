﻿using ArcGIS.Desktop.Mapping.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace CustomAttributeTab
{
  /// <summary>
  /// Interaction logic for CustomAttributeTabView.xaml
  /// </summary>
  public partial class CustomAttributeTabView : UserControl
  {
    //internal CustomAttributeTabViewModel tabVM = null;
    internal static MapControl MapControlOnTab = null;
    public CustomAttributeTabView()
    {
      InitializeComponent();
      if (Module1.CustomTabVM != null)
      {
        Module1.CustomTabVM.TheMapControl = this.MapControl;  //Link MapControl variable to this map control

      }
    }
  }
}
