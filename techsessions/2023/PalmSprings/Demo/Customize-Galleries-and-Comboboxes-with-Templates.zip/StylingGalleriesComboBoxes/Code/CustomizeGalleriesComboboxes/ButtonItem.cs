﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.

using ArcGIS.Desktop.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;

namespace CustomizeGalleriesComboboxes
{
  // class to be loaded into gallery/combobox
  public class ButtonItem
  {
    public ButtonItem(string id)
    {
      CommandID = id;

      var plugin = FrameworkApplication.GetPlugInWrapper(id);
      if (plugin == null) return;

      PlugInWrapper = plugin;
      Name = plugin.Caption;
      Tooltip = plugin.Tooltip;
      if (plugin.SmallImage is ImageSource)
        Icon16 = (ImageSource)plugin.SmallImage;
      else
        Icon16 = plugin.SmallImage;
      if (plugin.LargeImage is ImageSource)
        Icon32 = (ImageSource)plugin.LargeImage;
      else
        Icon32 = plugin.LargeImage;
    }

    public string Name { get; private set; }
    public string Tooltip { get; private set; }
    public object Icon16 { get; private set; }
    public object Icon32 { get; private set; }
    public string CommandID { get; private set; }
    public IPlugInWrapper PlugInWrapper { get; private set; }
    internal void Execute()
    {
      if (PlugInWrapper.IsRelevant)
      {
        ((ICommand)PlugInWrapper).Execute(null);
      }
    }

  }
}
