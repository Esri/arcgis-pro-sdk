﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Topology;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TopologyAddin
{
  public class TopologyOperations
  {

    #region private members

    private AlertService _alertService;
    // topology name
    private string _topologyDatasetName = "Cadastre_Topology";

    // feature layer for traversal
    private string _featureLayerName = "TaxParcel";

    #endregion

    // Ctor
    public TopologyOperations()
    {
      _alertService = new AlertService();
    }

    private async Task<Topology> OpenTopologyAsync()
    {
      Topology topology = null;
      await QueuedTask.Run<Topology>(async () =>
      {
        Geodatabase geodatabase = await GetGeodatabaseFromTOCAsync();
        topology = geodatabase?.OpenDataset<Topology>(_topologyDatasetName);

        return topology;
      });
      return topology;
    }

    public async Task<string> ReadTopologyMetadataAsync()
    {
      StringBuilder sb = new StringBuilder();
      await QueuedTask.Run(async () =>
     {
       using (Topology topology = await OpenTopologyAsync())
       using (TopologyDefinition topologyDefinition = topology.GetDefinition())
       {
         // Get general metadata
         string topologyName = topologyDefinition.GetName();
         double culsterTolerances = topologyDefinition.GetClusterTolerance();
         double zCulsterTolerance = topologyDefinition.GetZClusterTolerance(); // if topology supports the z height
         sb.AppendLine($"Name: {topologyName} \nDefault Cluster tolerance: {culsterTolerances} \nZ Cluster tolerance: {zCulsterTolerance}");

         // Get topology rules 
         IReadOnlyList<TopologyRule> rules = topologyDefinition.GetRules();
         sb.AppendLine($"Number of Rules: {rules.Count}");

         // Iterate topology rules
         foreach (TopologyRule rule in rules)
         {
           TopologyRuleType ruleType = rule.RuleType;
           string ruleOriginClass = rule.OriginClass;
           string ruleDestinationClass = rule.DestinationClass;
           Subtype ruleOriginSubtype = rule.OriginSubtype;
           Subtype ruleDestinationSubtype = rule.DestinationSubtype;
           int ruleId = rule.ID;

           sb.AppendLine($"\t RuleID: {ruleId}, Rule type: {ruleType}, Origin class: {ruleOriginClass}, Destination class: {ruleDestinationClass}");
         }

         // Get feature classes participated in the topology   
         IReadOnlyList<string> participatedFeatureClassNames = topologyDefinition.GetFeatureClassNames();
         sb.AppendLine($"Feature classes: {participatedFeatureClassNames.Count }");

         // Iterate feature classes participated in the topology
         foreach (string featureClassName in participatedFeatureClassNames)
         {
           sb.AppendLine($"\t {featureClassName}");
         }
       }
     });

      return sb.ToString();
    }

    public async Task<string> ValidateTopologyAsync()
    {
      StringBuilder sb = new StringBuilder();
      await QueuedTask.Run(async () =>
      {
        using (Topology topology = await OpenTopologyAsync())
        {
          // Topology state before validation
          TopologyState topologyStateBeforeValidation = topology.GetState();
          sb.AppendLine($"Topology state before validation: {topologyStateBeforeValidation}");

          // Validation description
          ValidationDescription validationDescription = new ValidationDescription(topology.GetExtent());

          // Validate topology
          ValidationResult validationResult = topology.ValidateInEditOperation(validationDescription);

          // Topology state after validation
          TopologyState topologyStateAfterValidation = topology.GetState();

          // Check if dirty area exists after validation
          if (validationResult.AffectedArea.IsEmpty)
          {
            sb.AppendLine($"Topology state after validation:{topologyStateAfterValidation}");
            sb.AppendLine($"Topology has not been edited to create dirty areas");
            return;
          }
          else
          {
            sb.AppendLine($"Topology state after validation:{topologyStateAfterValidation}");
          }
        }
      });

      return sb.ToString();
    }



    public async Task<string> GetAllErrorAndExceptionsAsync()
    {
      StringBuilder sb = new StringBuilder();
      await QueuedTask.Run(async () =>
      {
        using (Topology topology = await OpenTopologyAsync())
        {
          // Get a  topology rule
          TopologyRule topologyRule = await GetTopologyRuleAsync();

          // Create an error description object associated with the topology rule
          ErrorDescription errorDescription = new ErrorDescription(topology.GetExtent())
          {
            TopologyRule = topologyRule,
            ErrorType = ErrorType.ErrorAndException
          };

          // Fetch all error and exceptions 
          IReadOnlyList<TopologyError> errorAndExceptions = topology.GetErrors(errorDescription);

          sb.AppendLine($"Total error and exceptions: {errorAndExceptions.Count}");

          // Iterate over errors/exceptions
          foreach (TopologyError errorAndException in errorAndExceptions)
          {
            sb.AppendLine($"Rule type: {errorAndException.RuleType}, Rule Id:{errorAndException.RuleID}, IsException:{errorAndException.IsException}");
          }
        }
      });

      return sb.ToString();
    }

    public async Task<string> MarkErrorAsExceptionAsync()
    {
      StringBuilder sb = new StringBuilder();
      await QueuedTask.Run(async () =>
     {
       using (Topology topology = await OpenTopologyAsync())
       {
         // Get a  topology rule
         TopologyRule topologyRule = await GetTopologyRuleAsync();

         // Create an error description object associated with the topology rule
         ErrorDescription errorDescription = new ErrorDescription(topology.GetExtent())
         {
           TopologyRule = topologyRule,
           ErrorType = ErrorType.ErrorAndException
         };

         sb.AppendLine("Errors and Exceptions before 'Mark as Exception'");

         // Fetch all error and exceptions before errors mark as exception 
         IReadOnlyList<TopologyError> allErrorsAndExceptions = topology.GetErrors(errorDescription);

         int errorAndExeptionsCount = allErrorsAndExceptions.Count;
         int exceptionsCount = allErrorsAndExceptions.Where(error => error.IsException == true).ToList().Count;
         int errorsCount = errorAndExeptionsCount - exceptionsCount;
         sb.AppendLine($"Total error and exceptions: {errorAndExeptionsCount}");
         sb.AppendLine($"Exceptions: {exceptionsCount}");
         sb.AppendLine($"Errors: {errorsCount}");

         // Mark errors as exception
         foreach (TopologyError error in allErrorsAndExceptions)
         {
           topology.MarkAsExceptionInEditOperation(error);
         }

         sb.AppendLine("Errors and Exceptions after 'Mark as Exception'");

         // Fetch all error and exceptions after errors mark as exception 
         IReadOnlyList<TopologyError> allErrorsAndExceptionsAfterMarkedAsException = topology.GetErrors(errorDescription);

         int errorAndExeptionsCountAfterMarkedAsException = allErrorsAndExceptionsAfterMarkedAsException.Count;
         int exceptionsCountAfterMarkedAsException = allErrorsAndExceptionsAfterMarkedAsException.Where(error => error.IsException == true).ToList().Count;
         int errorsCountAfterMarkedAsException = errorAndExeptionsCountAfterMarkedAsException - exceptionsCountAfterMarkedAsException;
         sb.AppendLine($"Total error and exceptions: {errorAndExeptionsCountAfterMarkedAsException}");
         sb.AppendLine($"Exceptions: {exceptionsCountAfterMarkedAsException}");
         sb.AppendLine($"Errors: {errorsCountAfterMarkedAsException}");
       }
     });

      return sb.ToString();
    }

    public async Task<string> UnmarkErrorAsExceptionAsync()
    {
      StringBuilder sb = new StringBuilder();

      await QueuedTask.Run(async () =>
      {
        using (Topology topology = await OpenTopologyAsync())
        {
          // Get a  topology rule
          TopologyRule topologyRule = await GetTopologyRuleAsync();

          // Create an error description object associated with the topology rule
          ErrorDescription errorDescription = new ErrorDescription(topology.GetExtent())
          {
            TopologyRule = topologyRule,
            ErrorType = ErrorType.ErrorAndException
          };

          sb.AppendLine($"Error and exceptions before 'Unmark as Exception'");

          // Fetch all error and exceptions before errors unmark as exception 
          IReadOnlyList<TopologyError> allErrorsAndExceptionsBeforeUnmarkAsException = topology.GetErrors(errorDescription);

          int errorAndExeptionsCount = allErrorsAndExceptionsBeforeUnmarkAsException.Count;
          int exceptionsCount = allErrorsAndExceptionsBeforeUnmarkAsException.Where(error => error.IsException == true).ToList().Count;
          int errorsCount = errorAndExeptionsCount - exceptionsCount;
          sb.AppendLine($"Total error and exceptions: {errorAndExeptionsCount}");
          sb.AppendLine($"Exceptions: {exceptionsCount}");
          sb.AppendLine($"Errors: {errorsCount}");

          // Unmark errors as exception
          foreach (TopologyError error in allErrorsAndExceptionsBeforeUnmarkAsException)
          {
            topology.UnmarkAsExceptionInEditOperation(error);
          }

          sb.AppendLine($"Error and exceptions after 'Unmark as Exception'");

          // Fetch all error and exceptions before errors unmark as exception 
          IReadOnlyList<TopologyError> allErrorsAndExceptionsAfterUnMarkAsException = topology.GetErrors(errorDescription);

          int errorAndExeptionsCountAfterUnmarkAsException = allErrorsAndExceptionsAfterUnMarkAsException.Count;
          int exceptionsCountAfterUnmarkAsException = allErrorsAndExceptionsAfterUnMarkAsException.Where(error => error.IsException == true).ToList().Count;
          int errorsCountAfterUnmarkedAsException = errorAndExeptionsCountAfterUnmarkAsException - exceptionsCountAfterUnmarkAsException;
          sb.AppendLine($"Total error and exceptions: {errorAndExeptionsCountAfterUnmarkAsException }");
          sb.AppendLine($"Exceptions: { exceptionsCountAfterUnmarkAsException}");
          sb.AppendLine($"Errors: {errorsCountAfterUnmarkedAsException}");
        }
      });

      return sb.ToString();
    }

    public async Task TraverseTopologyGraphEdgesAsync()
    {
      await QueuedTask.Run(async () =>
     {
       using (Topology topology = await OpenTopologyAsync())
       {
         //Build a topology graph using the topology extent and pass the graph as an input for the callback method
         topology.BuildGraph(topology.GetExtent(), ExploreTopologyGraphEdgesAsync);
       }
     });
    }
    private async void ExploreTopologyGraphEdgesAsync(TopologyGraph topologyGraph)
    {
      StringBuilder sb = new StringBuilder();
      await QueuedTask.Run(async () =>
      {
        try
        {
          // Get selected feature to explore the topology graph
          using (Feature selectedFeature = await GetSelectedFeatureAsync())
          {
            if (selectedFeature is null) return;
            sb.AppendLine($"Feature OID:{selectedFeature.GetObjectID()}");

            // Get topology edges corresponding to the feature 
            IReadOnlyList<TopologyEdge> edges = topologyGraph.GetEdges(selectedFeature);
            sb.AppendLine($"Edges corresponding the feature: {edges.Count}");

            int edgeCounter = 1;
            //Iterate through the edges
            foreach (TopologyEdge edge in edges)
            {
              // Topology node at the from point of the edge
              TopologyNode fromNode = edge.GetFromNode();

              // Get parents that spawn the from node
              List<long> fromNodeParents = fromNode.GetParentFeatures().Select(f => f.ObjectID).ToList();
              string fromNodeParentsAsString = string.Join(", ", fromNodeParents);

              // Topology node at the to point of the edge
              TopologyNode toNode = edge.GetToNode();

              // Get parents that spawn the to node
              List<long> toNodeParents = toNode.GetParentFeatures().Select(f => f.ObjectID).ToList();
              var toNodeParentsAsString = string.Join(", ", toNodeParents);

              sb.AppendLine($"Parents of the node at the FROM point of the edge {edgeCounter}: {fromNodeParentsAsString}");
              sb.AppendLine($"Parents of the node at the TO point of the edge {edgeCounter}: {toNodeParentsAsString }");

              // Get left parents that shares the edge
              IReadOnlyList<FeatureInfo> leftParentFeaturesBoundByEdge = edge.GetLeftParentFeatures(true);
              if (leftParentFeaturesBoundByEdge.Count > 0)
              {
                string featureClassName = leftParentFeaturesBoundByEdge[0].FeatureClassName;

                List<long> leftParentFeaturesNotBoundByEdgeOids = leftParentFeaturesBoundByEdge.Select(f => f.ObjectID).ToList();
                string leftParentFeaturesNotBoundByEdgeOidsAsString = string.Join(", ", leftParentFeaturesNotBoundByEdgeOids);
                sb.AppendLine($"Left parent features cover the edge {edgeCounter} in {featureClassName}: {leftParentFeaturesNotBoundByEdgeOidsAsString}");

                // Iterate parent features - Bounus
                foreach (FeatureInfo featureInfo in leftParentFeaturesBoundByEdge)
                {
                  string fcName = featureInfo.FeatureClassName;
                  long featureObjecID = featureInfo.ObjectID;
                  using (Feature feature1 = featureInfo.GetFeature())
                  {
                    // Manipulate feature
                  }
                }
              }

              // Get right parents that shares the edge
              IReadOnlyList<FeatureInfo> rightParentFeaturesBoundByEdge = edge.GetRightParentFeatures(true);
              if (rightParentFeaturesBoundByEdge.Count > 0)
              {
                string featureClassName = rightParentFeaturesBoundByEdge[0].FeatureClassName;
                List<long> rightParentFeaturesNotBoundByEdgeOids = rightParentFeaturesBoundByEdge.Select(f => f.ObjectID).ToList();
                string rightParentFeaturesNotBoundByEdgeOidsAsString = string.Join(", ", rightParentFeaturesNotBoundByEdgeOids);
                sb.AppendLine($"Right parent features cover the edge {edgeCounter} in {featureClassName}: {rightParentFeaturesNotBoundByEdgeOidsAsString}");
              }

              edgeCounter++;
            }
          }
        }
        catch (Exception ex)
        {
          _alertService.AlertMessage(ex.Message);
        }
      });

      _alertService.AlertMessage(sb.ToString());
    }

    public async Task TraverseTopologyGraphNodeAsync()
    {
      await QueuedTask.Run(async () =>
      {
        using (Topology topology = await OpenTopologyAsync())
        {
          //Build a topology graph using the topology extent and pass the graph as an input for the callback method
          topology.BuildGraph(topology.GetExtent(), ExploreTopologyGraphNodesAsync);
        }
      });
    }

    private async void ExploreTopologyGraphNodesAsync(TopologyGraph topologyGraph)
    {
      StringBuilder sb = new StringBuilder();
      await QueuedTask.Run(async () =>
      {
        try
        {
          // Get selected feature to explore the topology graph
          using (Feature selectedFeature = await GetSelectedFeatureAsync())
          {
            if (selectedFeature is null) return;
            sb.AppendLine($"Feature OID: {selectedFeature.GetObjectID()}");

            // Get nodes corresponding to the feature 
            IReadOnlyList<TopologyNode> nodes = topologyGraph.GetNodes(selectedFeature);
            sb.AppendLine($"Nodes corresponding to the feature: {nodes.Count}");


            int nodeCounter = 1;

            // Iterate over nodes
            foreach (TopologyNode node in nodes)
            {
              // Get edges coincident with the node in clockwise direction; GetEdges(false) for counter clockwise
              IReadOnlyList<TopologyEdge> edgesClockwise = node.GetEdges(true);

              sb.AppendLine($"Edges coincident with node {nodeCounter} : {edgesClockwise.Count} ");
              int edgeClockwiseCounter = 1;

              // Iterate over the coincident edges
              foreach (TopologyEdge edgeClockWise in edgesClockwise)
              {
                // Get left parents that covers the edge
                IReadOnlyList<FeatureInfo> leftParentFeaturesFromClockwiseEdge = edgeClockWise.GetLeftParentFeatures();
                List<long> leftParentOids = leftParentFeaturesFromClockwiseEdge.Select(f => f.ObjectID).ToList();
                string leftParentOidsAsString = string.Join(" , ", leftParentOids);

                // Get left parents that covers the edge
                IReadOnlyList<FeatureInfo> rightParentFeaturesFromClockwiseEdge = edgeClockWise.GetRightParentFeatures();
                List<long> rightParentOids = rightParentFeaturesFromClockwiseEdge.Select(f => f.ObjectID).ToList();
                string rightParentOidsAsString = string.Join(" , ", rightParentOids);

                sb.AppendLine($"Edge {edgeClockwiseCounter}");
                sb.AppendLine($"\t Left parents' OID {leftParentOidsAsString} Right parents' OID; {rightParentOidsAsString}");

                edgeClockwiseCounter++;
              }

              nodeCounter++;
            }
          }
        }
        catch (Exception ex)
        {
          _alertService.AlertMessage(ex.Message);
        }
      });

      _alertService.AlertMessage(sb.ToString());
    }

    public async Task<string> FindClosestElement(MapPoint mapPoint, double searchRadius = 10.0)
    {
      StringBuilder sb = new StringBuilder();
      TopologyElement element = null;

      await QueuedTask.Run(async () =>
      {
         using (Topology topology = await OpenTopologyAsync())
         {
           //Build a topology graph using the default extent of map view
           topology.BuildGraph(MapView.Active.Map.GetDefaultExtent(), (topologyGraph) =>
           {

             //Find the closest element to the location/map point within the search radius
             element = topologyGraph.FindClosestElement<TopologyElement>(mapPoint, searchRadius);

             // Check if elemet is node 
             if (element is TopologyNode node)
             {
               // Get parents that spawn the node
               IReadOnlyList<FeatureInfo> parentFeatures = node.GetParentFeatures();
               sb.AppendLine("ElementType: Node");
               sb.AppendLine("ParentFeatures:");

               //
               foreach (FeatureInfo featureInfo in parentFeatures)
               {
                 long featureOId = featureInfo.GetFeature().GetObjectID();
                 string featureClassName = featureInfo.FeatureClassName;
                 using (Feature feature = featureInfo.GetFeature())
                 {
                   //
                 }
                 sb.AppendLine($"\t {featureClassName}-{featureOId}");
               }
             }

             // Check if element is edge
             if (element is TopologyEdge edge)
             {
               sb.AppendLine("ElementType: Edge");

               // Fetch left parents covers the edge
               IReadOnlyList<FeatureInfo> leftParents = edge.GetLeftParentFeatures();
               sb.AppendLine("LeftParents:");

               //Iterate over left parent features
               foreach (FeatureInfo leftParent in leftParents)
               {
                 long leftParentFeatureOId = leftParent.ObjectID;
                 string featureClassName = leftParent.FeatureClassName;
                 sb.AppendLine($"\t {featureClassName} -{leftParentFeatureOId}");
               }

               // Fetch left parents covers the edge
               IReadOnlyList<FeatureInfo> rightParents = edge.GetRightParentFeatures();
               sb.AppendLine("RightParents:");

               // Iterate over right parent features
               foreach (FeatureInfo rightParent in rightParents)
               {
                 long rightParentFeatureOId = rightParent.GetFeature().GetObjectID();
                 string featureClassName = rightParent.FeatureClassName;
                 sb.AppendLine($"\t {featureClassName} -{rightParentFeatureOId}");
               }
             }

           });
         }
       });

      return sb.ToString();
    }


    #region private helper methods
    private Task<TopologyRule> GetTopologyRuleAsync()
    {
      return QueuedTask.Run<TopologyRule>(async () =>
      {
        // Open a topology;
        Topology topology = await OpenTopologyAsync();

        // Get a topology rule of type 'PointProperlyInsideAra'
        TopologyRule topologyRule = topology.GetDefinition().GetRules().FirstOrDefault(rule => rule.RuleType == TopologyRuleType.PointProperlyInsideArea);

        return topologyRule;
      });
    }

    private async Task<Geodatabase> GetGeodatabaseFromTOCAsync()
    {
      return await QueuedTask.Run<Geodatabase>(async () =>
      {
        // Get feature layer from map contents 
        FeatureLayer featureLayer = await GetFeatureLayerFromTOCAsync();
        if (featureLayer == null) return null;

        // Get geodatabase from the feature layer
        Geodatabase geodatabase = featureLayer?.GetFeatureClass().GetDatastore() as Geodatabase;
        return geodatabase;

      });
    }

    private async Task<Feature> GetSelectedFeatureAsync()
    {
      return await QueuedTask.Run<Feature>(async () =>
      {
        try
        {
          Geodatabase geodatabase = await GetGeodatabaseFromTOCAsync();
          FeatureLayer featureLayer = await GetFeatureLayerFromTOCAsync();
          Selection selectedFeaturesFromMap = featureLayer?.GetSelection();

          // Get the selected feature from the map
          if (selectedFeaturesFromMap.GetCount() < 1)
          {
            _alertService.AlertMessage("Feature is not selected");
            return null;
          }

          RowCursor rowCursor = selectedFeaturesFromMap.Search();

          if (rowCursor.MoveNext())
          {
            return rowCursor.Current as Feature;
          }
        }
        catch (Exception ex)
        {
          _alertService.AlertMessage(ex.Message);
        }
        return null;
      });
    }

    private async Task<FeatureLayer> GetFeatureLayerFromTOCAsync()
    {
      return await QueuedTask.Run<FeatureLayer>(() =>
      {
        // Get a feature layer from the map view
        FeatureLayer featureLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(layer => layer.Name == _featureLayerName);
        return featureLayer;
      });
    }

    #endregion
  }

}
