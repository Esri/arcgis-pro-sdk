﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace TopologyAddin
{
  public class AlertService
  {
    public void AlertMessage(string message)
    {
      MessageBox.Show(message, "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
    }
  }
}
