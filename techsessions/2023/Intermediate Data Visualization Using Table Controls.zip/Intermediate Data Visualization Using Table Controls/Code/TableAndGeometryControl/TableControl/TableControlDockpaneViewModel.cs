﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       https://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using ArcGIS.Desktop.Core.Events;
using ArcGIS.Desktop.Editing.Controls;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;

namespace TableAndGeometryControl
{
  internal class TableControlDockpaneViewModel : DockPane
  {
    private const string _dockPaneID = "TableAndGeometryControl_TableControlDockpane";

    protected TableControlDockpaneViewModel() 
    {
      ProjectWindowSelectedItemsChangedEvent.Subscribe(OnProjectWindowSelectedItem);
      TOCSelectionChangedEvent.Subscribe((mapViewEventArgs) =>
      {
        var selectedLayer = mapViewEventArgs.MapView.GetSelectedLayers().
                                  OfType<FeatureLayer>().FirstOrDefault();
        if (selectedLayer != null)
        {
          // create the content
          var tableContent = TableControlContentFactory.Create(selectedLayer);

          // assign it
          if (tableContent != null)
          {
            this.TableContent = tableContent;
          }
        }
      });
    }

    /// <summary>
    /// Allows to add the selection (if it's a table or feature class) to the TableControl
    /// </summary>
    /// <param name="args"></param>
    private void OnProjectWindowSelectedItem(ProjectWindowSelectedItemsChangedEventArgs args)
    {
      if (args.IProjectWindow.SelectionCount > 0)
      {
        //Module1.SelectedMapMember = null;

        // get the first selected item
        var selectedItem = args.IProjectWindow.SelectedItems.First();

        // check if it's supported by the TableControl
        if (!TableControlContentFactory.IsItemSupported(selectedItem))
          return;

        // create the content
        var tableContent = TableControlContentFactory.Create(selectedItem);

        // assign it
        if (tableContent != null)
        {
          this.TableContent = tableContent;
        }
      }
    }

    private TableControlContent _tableContent;
    public TableControlContent TableContent
    {
      get => _tableContent;
      set => SetProperty(ref _tableContent, value);
    }

    private TableControl _MyTableControl;
    public TableControl MyTableControl
    {
      get => _MyTableControl;
      set => SetProperty(ref _MyTableControl, value);
    }

    #region Commands

    private bool _isFiltered = false;
    public ICommand CmdHideFieldsTableControl => new RelayCommand(() =>
    {
      if (MyTableControl == null) return;

      // update the look and feel of the TableControl
      _isFiltered = !_isFiltered;
      if (_isFiltered)
      {
        MyTableControl.ShowAllFields();
        // Hide fields that i am not interested in:
        MyTableControl.SetHiddenFields(new List<string>() {
            "Shape", "Address", "Neighborhood",
            "Police_Precinct", "Police_District",  
            "X_Coordinate", "Y_Coordinate", "Offense_Type"});
      }
      else
      {
        MyTableControl.ShowAllFields();
      }

    }, true);

    public ICommand CmdMoveToTableControl => new RelayCommand(async () =>
    {
      if (MyTableControl == null) return;

      await QueuedTask.Run(() =>
      {
        var oid = 267;
        var rowIdx = MyTableControl.GetRowIndex(oid, false);
        MyTableControl.BringIntoView(rowIdx);

        var rowIndexes = new List<long>() { rowIdx, rowIdx + 1 };
        MyTableControl.Select(rowIndexes, false);

        MapView.Active.ZoomToSelected();
      });
    }, true);

    public ICommand CmdViewModeTableControl => new RelayCommand(async () =>
    {
      if (MyTableControl == null) return;

      // update the look and feel of the TableControl
      var viewMode = MyTableControl.ViewMode;
      if (viewMode == TableViewMode.eAllRecords)
      {
        // Set ViewMode to show just selected records
        await MyTableControl.SetViewMode(TableViewMode.eSelectedRecords);
      }
      else
      {
        // clear selected only viewmode
        await MyTableControl.SetViewMode(TableViewMode.eAllRecords);
      }

    }, true);

    #endregion


    public System.Windows.Media.ImageSource CmdHideFieldsTableControlImage
    {
      get => System.Windows.Application.Current.Resources["TableHideField16"] as System.Windows.Media.ImageSource;
    }

    public System.Windows.Media.ImageSource CmdMoveToTableControlImage
    {
      get => System.Windows.Application.Current.Resources["AttributesWindow16"] as System.Windows.Media.ImageSource;
    }
   
    public System.Windows.Media.ImageSource CmdViewModeTableControlImage
    {
      get => System.Windows.Application.Current.Resources["TableReselectHighlighted16"] as System.Windows.Media.ImageSource;
    }


    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class TableControlDockpane_ShowButton : Button
  {
    protected override void OnClick()
    {
      TableControlDockpaneViewModel.Show();
    }
  }
}
