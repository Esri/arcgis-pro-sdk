﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Controls;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using static System.Net.Mime.MediaTypeNames;

namespace DataVisualization.TableControlButtons
{
  internal class TableControlDockpaneViewModel : DockPane
  {
    private const string _dockPaneID = "DataVisualization_TableControlButtons_TableControlDockpane";
    public TableControl SummarizeTableControl = null;
    protected TableControlDockpaneViewModel() { }

    protected override async void OnShow(bool isVisible)
    {
      if (isVisible == false) return;
      var mapView = MapView.Active;
      if (mapView == null) return;
      try
      {
        var featureLayer = mapView.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault();
        if (!TableControlContentFactory.IsMapMemberSupported(featureLayer))
          return;
        await QueuedTask.Run(() =>
        {
          _objectIdPavedMax = Module1.GetRowIDForStatistic("sum_Length_KILOMETERS", "Majority_carte_velo = 'Piste cyclable ou partagee'");
          _objectIdUnpavedMax = Module1.GetRowIDForStatistic("sum_Length_KILOMETERS", "Majority_carte_velo = 'Reseau vert'");
        });
        // create the content to display in the table control
        var tableContent = TableControlContentFactory.Create(featureLayer);

        if (tableContent != null)
        {
          //bind the table control content to the UI
          this.MyTableControlContent = tableContent;
        }

      }
      catch (Exception)
      {

        throw;
      }
    }
    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

    /// <summary>
    /// Text shown near the top of the DockPane.
    /// </summary>
    private string _heading = "Toulouse Bike Path Summary";
    public string Heading
    {
      get => _heading;
      set => SetProperty(ref _heading, value);
    }
    private TableControlContent _tableContent;
    private long _objectIdPavedMax;
    private long _objectIdUnpavedMax;

    public TableControlContent MyTableControlContent
    {
      get => _tableContent;
      set => SetProperty(ref _tableContent, value);
    }


    private ImageSource _imgTownshipStats;
    public ImageSource ImgTownshipStats
    {
      get
      {
        if (_imgTownshipStats == null)
          _imgTownshipStats = new BitmapImage(new Uri(
              "pack://application:,,,/DataVisualization;component/Images/stats-lines.png", UriKind.Absolute));
        return _imgTownshipStats;
      }
    }
    private ImageSource _imgPaved;
    public ImageSource ImgPaved
    {
      get
      {
        if (_imgPaved == null)
          _imgPaved = new BitmapImage(new Uri(
              "pack://application:,,,/DataVisualization;component/Images/Bicycle-icon.png", UriKind.Absolute));
        return _imgPaved;
      }
    }

    private ImageSource _imgUnpaved;
    public ImageSource ImgUnpaved
    {
      get
      {
        if (_imgUnpaved == null)
          _imgUnpaved = new BitmapImage(new Uri(
              "pack://application:,,,/DataVisualization;component/Images/Bicycle-icon.png", UriKind.Absolute));
        return _imgUnpaved;
      }
    }

    public ImageSource ImgClearSelection
    {
      get
      {
        return FrameworkApplication.Current.Resources["SelectionClearSelected32"] as ImageSource;
      }
    }
    public ICommand CmdHideFields
    {
      get
      {
        return new RelayCommand(() => {
          if (SummarizeTableControl == null) return;
          List<string> fieldsToHide = new List<string>
          {
            "OBJECTID",
            "Shape",
            "geo_point_2d",
            "code_insee",
            "libcom",
            "code_fantoir",
            "Shape_Area",
            "Shape_Length",
            "Polyline_Count",
            "Minority_carte_velo",
            "Minority_carte_velo_Percent",
            "Majority_carte_velo_Percent",
            "Join_ID",
            "ColorCode"
          };
          //Hide the unnecessary fields
          SummarizeTableControl.SetHiddenFields(fieldsToHide);
        });
      }
    }
    public ICommand CmdPavedPath
    {
      get
      {
        return new RelayCommand(() =>
        {
          if (SummarizeTableControl == null)
            return;
          //SummarizeTableControl.SetViewMode(TableViewMode.eAllRecords);
          _ = SelectRowAsync(SummarizeTableControl, _objectIdPavedMax);
          SummarizeTableControl.SetViewMode(TableViewMode.eSelectedRecords);
        });
      }
    }

    public ICommand CmdClearSelection
    {
      get
      {
        return new RelayCommand(() =>
        {
          if (SummarizeTableControl == null)
            return;
          SummarizeTableControl.ClearSelection();
          SummarizeTableControl.SetViewMode(TableViewMode.eAllRecords);
        });
      }
    }


    public ICommand CmdUnPavedPath
    {
      get
      {
        return new RelayCommand(() =>
        {
          if (SummarizeTableControl == null)
            return;
          //SummarizeTableControl.SetViewMode(TableViewMode.eAllRecords);
          _ = SelectRowAsync(SummarizeTableControl, _objectIdUnpavedMax);
          SummarizeTableControl.SetViewMode(TableViewMode.eSelectedRecords);
        });
      }
    }
    private async Task SelectRowAsync(TableControl tableControl, long objectID)
    {
      await QueuedTask.Run(() => {

        if ((tableControl as TableControl).CanSelect)
        {
          (tableControl as TableControl)?.Select(objectID, true);
        }
      });

    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class TableControlDockpane_ShowButton : Button
  {
    protected override void OnClick()
    {
      TableControlDockpaneViewModel.Show();
    }
  }
}
