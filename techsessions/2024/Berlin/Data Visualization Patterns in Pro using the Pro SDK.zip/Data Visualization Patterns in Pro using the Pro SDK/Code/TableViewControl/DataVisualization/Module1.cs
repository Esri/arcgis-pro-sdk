﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DataVisualization
{
  internal class Module1 : Module
  {
    private static Module1 _this = null;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("DataVisualization_Module");
    internal static CIMMapTableView MyTableView = null;
    internal static ITablePaneEx MyTablePane = null;
    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides
    /// <summary>
    /// Calculates the max value of a field in a feature class. Must run on the MCT
    /// </summary>
    /// <param name="fieldName"></param>
    /// <param name="whereClause"></param>
    /// <returns></returns>
    internal static long GetRowIDForStatistic(string fieldName, string whereClause)
    {
      long oID = 0;
      try
      {
        using (Geodatabase geodatabase = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(Project.Current.DefaultGeodatabasePath))))
        {
          IReadOnlyList<FeatureClassDefinition> fcList = geodatabase.GetDefinitions<FeatureClassDefinition>();
          var toulouseSummaryFCDefn = fcList.Where(f => f.GetName() == "ToulouseTownships_SummarizeWithin").FirstOrDefault();
          if (toulouseSummaryFCDefn != null)
          {
            //Get the feature class
            using (var resultFC = geodatabase.OpenDataset<FeatureClass>($"{toulouseSummaryFCDefn.GetName()}"))
            {
              // Get fields
              Field field = toulouseSummaryFCDefn.GetFields().First(x => x.Name.Equals(fieldName));

              // Create StatisticsDescriptions
              StatisticsDescription statisticsDescription = new StatisticsDescription(field, new List<StatisticsFunction> { StatisticsFunction.Max });

              // Create TableStatisticsDescription
              TableStatisticsDescription tableStatisticsDescription = new TableStatisticsDescription(new List<StatisticsDescription>() {
              statisticsDescription
              });
              tableStatisticsDescription.QueryFilter = new QueryFilter { WhereClause = whereClause };
              // Calculate Statistics
              IReadOnlyList<TableStatisticsResult> tableStatisticsResults = resultFC.CalculateStatistics(tableStatisticsDescription);

              foreach (TableStatisticsResult tableStatisticsResult in tableStatisticsResults)
              {
                // Get the statistics results for the field
                StatisticsResult statistics = tableStatisticsResult.StatisticsResults[0];

                QueryFilter queryFilter = new QueryFilter { WhereClause = $"{fieldName} = {statistics.Max}" };
                var rowCursor = resultFC.Search(queryFilter);
                while (rowCursor.MoveNext())
                {
                  oID = rowCursor.Current.GetObjectID();
                }
              }
            }
          }
          return oID;

        }
      }
      catch (Exception ex)
      {

        return 0;
      }
    }
  }
}
