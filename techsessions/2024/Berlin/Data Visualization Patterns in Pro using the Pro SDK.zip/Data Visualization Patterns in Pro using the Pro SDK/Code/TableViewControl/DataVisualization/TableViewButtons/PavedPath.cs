﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataVisualization.TableViewButtons
{
  internal class PavedPath : Button
  {
    protected async override void OnClick()
    {
      TableView activeTableView = TableView.Active;
      if (activeTableView == null) return;
      await QueuedTask.Run(() => {
        //Using Statistics functions in ArcGIS.Core.Data API
        var objectIdPavedMax = Module1.GetRowIDForStatistic("sum_Length_KILOMETERS", "Majority_carte_velo = 'Piste cyclable ou partagee'");
        if (activeTableView.CanSelect)
        {
          activeTableView.Select(objectIdPavedMax, true);
          activeTableView.SetViewMode(TableViewMode.eSelectedRecords);
        }
      });
    }
  }
}
