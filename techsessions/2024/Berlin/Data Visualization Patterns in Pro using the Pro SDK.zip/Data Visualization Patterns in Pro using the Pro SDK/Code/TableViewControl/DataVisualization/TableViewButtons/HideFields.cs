﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataVisualization.TableViewButtons
{
    internal class HideFields : Button
    {
        protected override void OnClick()
        {
            TableView activeTableView = TableView.Active;
            if (activeTableView == null) return;
            //Hide rows
            List<string> fieldsToHide = new List<string>
          {
            "OBJECTID",
            "Shape",
            "geo_point_2d",
            "code_insee",
            "libcom",
            "code_fantoir",
            "Shape_Area",
            "Shape_Length",
            "Polyline_Count",
            "Minority_carte_velo",
            "Minority_carte_velo_Percent",
            "Majority_carte_velo_Percent",
            "Join_ID",
            "CyclePathType",
            "ColorCode"
          };
            activeTableView.SetHiddenFields(fieldsToHide);
        }
    }
}
