﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataVisualization.TableViewButtons
{
    internal class OpenTableView : Button
    {
        protected override void OnClick()
        {
            if (MapView.Active == null) return;
            //get the feature layer - which is a map member
            var featureLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault();

            //You must be on the UI thread to call this function.
            TableView myTableView;
            if (FrameworkApplication.Panes.CanOpenTablePane(featureLayer))
            {
                Module1.MyTablePane = FrameworkApplication.Panes.OpenTablePane(featureLayer) as ITablePaneEx;
                myTableView = Module1.MyTablePane.TableView;
                //Do something with the TableView
            }
        }
    }
}
