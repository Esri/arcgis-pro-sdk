﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateLineOfSight
{
  internal class StartDemo : Button
  {
    protected override void OnClick()
    {
      var map = MapView.Active.Map;
      QueuedTask.Run(() =>
      {
        var qf = new QueryFilter()
        {
          ObjectIDs = new List<long>() { 93, 128, 110, 95 }
        };
        var bldgs = map.GetLayersAsFlattenedList().OfType<FeatureLayer>()
                         .First(fl => fl.Name == "bldgfootprint3d");
        bldgs.Select(qf);

        //Draw pins
        var LOS = map.GetLayersAsFlattenedList().OfType<GroupLayer>()
                   .First(gl => gl.Name == "LoS");
        LOS.SetVisibility(true);
      });
    }
  }
}
