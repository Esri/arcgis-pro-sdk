﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Analyst3D;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;


namespace Datasets_3D
{
  internal class LasDatasetDockPaneViewModel : DockPane
  {
    private const string _dockPaneID = "Datasets_3D_LasDatasetDockPane";

    private static readonly object _lockObject = new object();
    protected LasDatasetDockPaneViewModel()
    {
      BindingOperations.EnableCollectionSynchronization(LASLayersInMap, _lockObject);
    }

    protected override void OnShow(bool isVisible)
    {
      if (isVisible)
      {
        var map = MapView.Active?.Map;

        // Get the LAS layers in the map
        BuildLasLayerCollection(map);
        UpdateMessages();
        SelectFirstLayer();
      }
      base.OnShow(isVisible);
    }

    #region Public
    /// <summary>
    /// Gets the class codes that are checked in the UI
    /// </summary>
    /// <returns></returns>
    public List<int> GetLasClassCodesChecked()
    {
      var classCodes = new List<int>();
      foreach (var item in UniqueClassCodesInLayer)
      {
        if (item.IsChecked)
          classCodes.Add(item.ClassCode);
      }
      return classCodes;
    }

    /// <summary>
    /// Gets the return types that are checked in the UI
    /// </summary>
    /// <returns></returns>
    public List<LasReturnType> GetLasReturnTypesChecked()
    {
      var returns = new List<LasReturnType>();
      foreach (var item in AllReturnValues)
      {
        if (item.IsChecked)
          returns.Add(item.LasReturnType);
      }
      return returns;
    }

    /// <summary>
    /// Is the Key Points checked in the UI
    /// </summary>
    public bool IsKeyPointChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Key Points");
        return flag?.IsChecked ?? false;
      }
    }

    /// <summary>
    /// Is the Overlap Points checked in the UI
    /// </summary>
    public bool IsOverlapPointsChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Overlap Points");
        return flag?.IsChecked ?? false;
      }
    }

    /// <summary>
    /// Is the Synthetic Points checked in the UI
    /// </summary>
    public bool IsSyntheticPointsChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Synthetic Points");
        return flag?.IsChecked ?? false;
      }
    }

    /// <summary>
    /// Is the Withheld Points checked in the UI
    /// </summary>
    public bool IsWithheldPointsChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Withheld Points");
        return flag?.IsChecked ?? false;
      }
    }

    public bool IsNotFlaggedChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Not Flagged");
        return flag?.IsChecked ?? false;
      }
    }

    #endregion

    #region Binding properties

    private Visibility _displayLASLayerExistsMessage = Visibility.Hidden;
    public Visibility DisplayLASLayerExistsMessage
    {
      get => _displayLASLayerExistsMessage;
      set => SetProperty(ref _displayLASLayerExistsMessage, value);
    }

    private Visibility _displayNoLasLayerMessage = Visibility.Hidden;
    public Visibility DisplayNoLasLayerMessage
    {
      get => _displayNoLasLayerMessage;
      set => SetProperty(ref _displayNoLasLayerMessage, value);
    }

    /// <summary>
    /// Text shown near the top of the DockPane.
    /// </summary>
    private string _heading = "LAS Filter";
    public string Heading
    {
      get => _heading;
      set => SetProperty(ref _heading, value);
    }

    private List<LasDatasetLayer> _lasLayersInMap = new List<LasDatasetLayer>();
    public List<LasDatasetLayer> LASLayersInMap
    {
      get => _lasLayersInMap;
      set => SetProperty(ref _lasLayersInMap, value);
    }

    private LasDatasetLayer _selectedLASLayer;
    public LasDatasetLayer SelectedLASLayer
    {
      get => _selectedLASLayer;
      set
      {
        SetProperty(ref _selectedLASLayer, value);
        _ = UpdateFilterSettingsAsync(SelectedLASLayer);
      }
    }

    private List<CustomLASFilterDisplayItem> _uniqueClassCodesInLayer = new List<CustomLASFilterDisplayItem>();
    public List<CustomLASFilterDisplayItem> UniqueClassCodesInLayer
    {
      get => _uniqueClassCodesInLayer;
      set => SetProperty(ref _uniqueClassCodesInLayer, value);
    }

    private CustomLASFilterDisplayItem _selectedClassCodes;
    public CustomLASFilterDisplayItem SelectedClassCodes
    {
      get => _selectedClassCodes;
      set => SetProperty(ref _selectedClassCodes, value);
    }

    private List<CustomLASFilterDisplayItem> _allReturnValues = new List<CustomLASFilterDisplayItem>();
    public List<CustomLASFilterDisplayItem> AllReturnValues
    {
      get => _allReturnValues;
      set => SetProperty(ref _allReturnValues, value);
    }

    private CustomLASFilterDisplayItem _selectedReturnValues;
    public CustomLASFilterDisplayItem SelectedReturnValues
    {
      get => _selectedReturnValues;
      set => SetProperty(ref _selectedReturnValues, value);
    }

    private List<CustomLASFilterDisplayItem> _allClassificationFlags = new List<CustomLASFilterDisplayItem>();
    public List<CustomLASFilterDisplayItem> AllClassificationFlags
    {
      get => _allClassificationFlags;
      set => SetProperty(ref _allClassificationFlags, value);
    }

    private CustomLASFilterDisplayItem _selectedClassificationFlags;
    public CustomLASFilterDisplayItem SelectedClassificationFlags
    {
      get => _selectedClassificationFlags;
      set => SetProperty(ref _selectedClassificationFlags, value);
    }

    public ImageSource DisplayFilterImage => Application.Current.Resources["DisplayManualTiePoints32"] as ImageSource;
    //public ImageSource RetrievePointsImage => Application.Current.Resources["LidarSession32"] as ImageSource;

    #endregion

    #region Utility members

    /// <summary>
    /// Called when the map member properties change, when a new LAS layer is selected. 
    /// </summary>
    /// <param name="lasLayer"></param>
    /// <remarks>This method reads the LAS layer, gathers the values for Classification Codes, return value and classification flags and updates the UI</remarks>
    /// <returns></returns>
    private async Task UpdateFilterSettingsAsync(LasDatasetLayer lasLayer)
    {
      if (lasLayer == null)
        return;

      DisplayLASLayerExistsMessage = Visibility.Visible;
      DisplayNoLasLayerMessage = Visibility.Hidden;

      var classCodes = new List<CustomLASFilterDisplayItem>();
      var returnsVals = new List<CustomLASFilterDisplayItem>();
      var classificationFlags = new List<CustomLASFilterDisplayItem>();

      await QueuedTask.Run(() =>
      {
        // get the display filter from the layer
        var displayFilter = lasLayer.GetDisplayFilter();

        var displayClassCodes = displayFilter.ClassCodes; //the filter values for class codes in the layer
        var displayReturns = displayFilter.Returns; //the filter values for return values in the layer

        using (var lasDataset = lasLayer.GetLasDataset())
        {
          foreach (var cc in lasDataset.GetUniqueClassCodes()) //Get the unique class codes in the layer
          {
            //When the displayClassCodes is empty, all the class codes are displayed - this is a little idiosyncrasy of the CIM.
            bool isCCDisplayed = displayClassCodes.Count == 0 ? true : displayClassCodes.Contains(cc); //Is the class code applied in the filter?
            classCodes.Add(new CustomLASFilterDisplayItem(cc, isCCDisplayed));
          }

          foreach (var rv in lasDataset.GetUniqueReturns())
          {
            //When the displayReturns is empty, all the return values are displayed - this is a little idiosyncrasy of the CIM.
            bool isRVDisplayed = displayReturns.Count == 0 ? true : displayReturns.Contains(rv);
            returnsVals.Add(new CustomLASFilterDisplayItem(rv, isRVDisplayed));
          }
        }

        classificationFlags.Add(new CustomLASFilterDisplayItem("Not Flagged", displayFilter.NotFlagged));
        classificationFlags.Add(new CustomLASFilterDisplayItem("Key Points", displayFilter.KeyPoints));
        classificationFlags.Add(new CustomLASFilterDisplayItem("Synthetic Points", displayFilter.SyntheticPoints));
        classificationFlags.Add(new CustomLASFilterDisplayItem("Withheld Points", displayFilter.WithheldPoints));
      });

      UniqueClassCodesInLayer = classCodes;
      AllReturnValues = returnsVals;
      AllClassificationFlags = classificationFlags;
    }
    #endregion

    #region Commands

    public RelayCommand CmdApplyDisplayFilter
    {
      get
      {
        return new RelayCommand(() => ApplyDisplayFilter(), true);
      }
    }
    /// <summary>
    /// Applies the display filter to the selected LAS layer
    /// </summary>
    private void ApplyDisplayFilter()
    {
      QueuedTask.Run(() =>
      {
        if (SelectedLASLayer != null)
        {
          LasPointDisplayFilter lasPointDisplayFilter = new LasPointDisplayFilter();
          lasPointDisplayFilter.Returns = GetLasReturnTypesChecked();
          lasPointDisplayFilter.ClassCodes = GetLasClassCodesChecked();
          lasPointDisplayFilter.KeyPoints = IsKeyPointChecked;
          lasPointDisplayFilter.SyntheticPoints = IsSyntheticPointsChecked;
          lasPointDisplayFilter.OverlapPoints = IsOverlapPointsChecked;
          lasPointDisplayFilter.WithheldPoints = IsWithheldPointsChecked;
          lasPointDisplayFilter.NotFlagged = IsNotFlaggedChecked;
          SelectedLASLayer.SetDisplayFilter(lasPointDisplayFilter);
        }
      });
    }

    //public RelayCommand CmdRetrievePoints
    //{
    //  get
    //  {
    //    return new RelayCommand(() => ActivateRetrievePointsTool(), true);
    //  }
    //}

    //private void ActivateRetrievePointsTool()
    //  => FrameworkApplication.SetCurrentToolAsync("LASDatasetAPISamples_RetrievePointsUsingFilterTool");

    #endregion

    #region Private
    private void UpdateMessages()
    {
      var layerCount = LASLayersInMap.Count;
      DisplayNoLasLayerMessage = (layerCount == 0) ? Visibility.Visible : Visibility.Hidden;
      DisplayLASLayerExistsMessage = (layerCount == 0) ? Visibility.Hidden : Visibility.Visible;
    }

    private void SelectFirstLayer()
    {
      if (LASLayersInMap.Count > 0)
        SelectedLASLayer = LASLayersInMap.FirstOrDefault();
    }

    private void BuildLasLayerCollection(Map map)
    {
      var lasLayers = new List<LasDatasetLayer>();
      if (map != null)
        lasLayers = map.GetLayersAsFlattenedList().OfType<LasDatasetLayer>().ToList();

      LASLayersInMap = lasLayers;
    }
    #endregion
    
    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class LasDatasetDockPane_ShowButton : Button
  {
    protected override void OnClick()
    {
      LasDatasetDockPaneViewModel.Show();
    }
  }
}
