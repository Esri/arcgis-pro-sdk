﻿using ArcGIS.Core.Data.Analyst3D;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;


namespace Datasets_3D
{
  internal class LasSearchInfoViewModel : EmbeddableControl
  {
    private LasDatasetLayer _lasLayer;
    public LasSearchInfoViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) 
    {
      _lasLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<LasDatasetLayer>().FirstOrDefault();
      GetFilterSettingsAsync();
    }

    internal void Search(LasDatasetLayer lasLayer, Polygon polygon)
    {
      QueuedTask.Run(() =>
      {
        LasPointFilter lasPointFilter = new LasPointFilter();
        lasPointFilter.FilterGeometry = polygon;

        var datasetPtCount = 0;
        using (var lasDataset = lasLayer.GetLasDataset())
        {
          using (var datasetPtCursor = lasDataset.SearchPoints(lasPointFilter))
          {
            while (datasetPtCursor.MoveNext())
            {
              datasetPtCount++;
            }
          }
        }

        var layerPtCount = 0;
        using (var layerPtCursor = lasLayer.SearchPoints(lasPointFilter))
        {
          while (layerPtCursor.MoveNext())
          {
            layerPtCount++;
          }
        }

        DatasetPointCount = datasetPtCount;
        LayerPointCount = layerPtCount;

      });
    }


    #region Bindable
    private long _layerPointCount;
    public long LayerPointCount
    {
      get => _layerPointCount;
      set => SetProperty(ref _layerPointCount, value);
    }
    private long _datasetPointCount;
    public long DatasetPointCount
    {
      get => _datasetPointCount;
      set => SetProperty(ref _datasetPointCount, value);
    }

    private List<CustomLASFilterDisplayItem> _uniqueClassCodesInLayer = new List<CustomLASFilterDisplayItem>();
    public List<CustomLASFilterDisplayItem> UniqueClassCodesInLayer
    {
      get => _uniqueClassCodesInLayer;
      set => SetProperty(ref _uniqueClassCodesInLayer, value);
    }

    private CustomLASFilterDisplayItem _selectedClassCodes;
    public CustomLASFilterDisplayItem SelectedClassCodes
    {
      get => _selectedClassCodes;
      set => SetProperty(ref _selectedClassCodes, value);
    }

    private List<CustomLASFilterDisplayItem> _allReturnValues = new List<CustomLASFilterDisplayItem>();
    public List<CustomLASFilterDisplayItem> AllReturnValues
    {
      get => _allReturnValues;
      set => SetProperty(ref _allReturnValues, value);
    }

    private CustomLASFilterDisplayItem _selectedReturnValues;
    public CustomLASFilterDisplayItem SelectedReturnValues
    {
      get => _selectedReturnValues;
      set => SetProperty(ref _selectedReturnValues, value);
    }

    private List<CustomLASFilterDisplayItem> _allClassificationFlags = new List<CustomLASFilterDisplayItem>();
    public List<CustomLASFilterDisplayItem> AllClassificationFlags
    {
      get => _allClassificationFlags;
      set => SetProperty(ref _allClassificationFlags, value);
    }

    private CustomLASFilterDisplayItem _selectedClassificationFlags;
    public CustomLASFilterDisplayItem SelectedClassificationFlags
    {
      get => _selectedClassificationFlags;
      set => SetProperty(ref _selectedClassificationFlags, value);
    }

    public ImageSource DisplayFilterImage => Application.Current.Resources["DisplayManualTiePoints32"] as ImageSource;
    //public ImageSource RetrievePointsImage => Application.Current.Resources["LidarSession32"] as ImageSource;

    #endregion


    #region Utility members

    /// <summary>
    /// Called when the map member properties change, when a new LAS layer is selected. 
    /// </summary>
    /// <param name="lasLayer"></param>
    /// <remarks>This method reads the LAS layer, gathers the values for Classification Codes, return value and classification flags and updates the UI</remarks>
    /// <returns></returns>
    private async Task GetFilterSettingsAsync()
    {
      if (_lasLayer == null)
        return;

      var classCodes = new List<CustomLASFilterDisplayItem>();
      var returnsVals = new List<CustomLASFilterDisplayItem>();
      var classificationFlags = new List<CustomLASFilterDisplayItem>();

      await QueuedTask.Run(() =>
      {
        // get the display filter from the layer
        var displayFilter = _lasLayer.GetDisplayFilter();

        var displayClassCodes = displayFilter.ClassCodes; //the filter values for class codes in the layer
        var displayReturns = displayFilter.Returns; //the filter values for return values in the layer

        using (var lasDataset = _lasLayer.GetLasDataset())
        {
          foreach (var cc in lasDataset.GetUniqueClassCodes()) //Get the unique class codes in the layer
          {
            //When the displayClassCodes is empty, all the class codes are displayed - this is a little idiosyncrasy of the CIM.
            bool isCCDisplayed = displayClassCodes.Count == 0 ? true : displayClassCodes.Contains(cc); //Is the class code applied in the filter?
            classCodes.Add(new CustomLASFilterDisplayItem(cc, isCCDisplayed));
          }

          foreach (var rv in lasDataset.GetUniqueReturns())
          {
            //When the displayReturns is empty, all the return values are displayed - this is a little idiosyncrasy of the CIM.
            bool isRVDisplayed = displayReturns.Count == 0 ? true : displayReturns.Contains(rv);
            returnsVals.Add(new CustomLASFilterDisplayItem(rv, isRVDisplayed));
          }
        }

        classificationFlags.Add(new CustomLASFilterDisplayItem("Not Flagged", displayFilter.NotFlagged));
        classificationFlags.Add(new CustomLASFilterDisplayItem("Key Points", displayFilter.KeyPoints));
        classificationFlags.Add(new CustomLASFilterDisplayItem("Synthetic Points", displayFilter.SyntheticPoints));
        classificationFlags.Add(new CustomLASFilterDisplayItem("Withheld Points", displayFilter.WithheldPoints));
      });

      UniqueClassCodesInLayer = classCodes;
      AllReturnValues = returnsVals;
      AllClassificationFlags = classificationFlags;
    }
    #endregion

    #region Commands

    public RelayCommand CmdApplyDisplayFilter
    {
      get
      {
        return new RelayCommand(() => ApplyDisplayFilter(), true);
      }
    }
    /// <summary>
    /// Applies the display filter to the selected LAS layer
    /// </summary>
    private void ApplyDisplayFilter()
    {
      QueuedTask.Run(() =>
      {
        if (_lasLayer != null)
        {
          LasPointDisplayFilter lasPointDisplayFilter = new LasPointDisplayFilter();
          lasPointDisplayFilter.Returns = GetLasReturnTypesChecked();
          lasPointDisplayFilter.ClassCodes = GetLasClassCodesChecked();
          lasPointDisplayFilter.KeyPoints = IsKeyPointChecked;
          lasPointDisplayFilter.SyntheticPoints = IsSyntheticPointsChecked;
          lasPointDisplayFilter.OverlapPoints = IsOverlapPointsChecked;
          lasPointDisplayFilter.WithheldPoints = IsWithheldPointsChecked;
          lasPointDisplayFilter.NotFlagged = IsNotFlaggedChecked;

          _lasLayer.SetDisplayFilter(lasPointDisplayFilter);
        }
      });
    }

    #endregion


    #region Dsiplay Filter UI

    /// <summary>
    /// Gets the class codes that are checked in the UI
    /// </summary>
    /// <returns></returns>
    public List<int> GetLasClassCodesChecked()
    {
      var classCodes = new List<int>();
      foreach (var item in UniqueClassCodesInLayer)
      {
        if (item.IsChecked)
          classCodes.Add(item.ClassCode);
      }
      return classCodes;
    }

    /// <summary>
    /// Gets the return types that are checked in the UI
    /// </summary>
    /// <returns></returns>
    public List<LasReturnType> GetLasReturnTypesChecked()
    {
      var returns = new List<LasReturnType>();
      foreach (var item in AllReturnValues)
      {
        if (item.IsChecked)
          returns.Add(item.LasReturnType);
      }
      return returns;
    }

    /// <summary>
    /// Is the Key Points checked in the UI
    /// </summary>
    public bool IsKeyPointChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Key Points");
        return flag?.IsChecked ?? false;
      }
    }

    /// <summary>
    /// Is the Overlap Points checked in the UI
    /// </summary>
    public bool IsOverlapPointsChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Overlap Points");
        return flag?.IsChecked ?? false;
      }
    }

    /// <summary>
    /// Is the Synthetic Points checked in the UI
    /// </summary>
    public bool IsSyntheticPointsChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Synthetic Points");
        return flag?.IsChecked ?? false;
      }
    }

    /// <summary>
    /// Is the Withheld Points checked in the UI
    /// </summary>
    public bool IsWithheldPointsChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Withheld Points");
        return flag?.IsChecked ?? false;
      }
    }

    public bool IsNotFlaggedChecked
    {
      get
      {
        var flag = AllClassificationFlags.FirstOrDefault(item => item.Name == "Not Flagged");
        return flag?.IsChecked ?? false;
      }
    }

    #endregion
  }
}
