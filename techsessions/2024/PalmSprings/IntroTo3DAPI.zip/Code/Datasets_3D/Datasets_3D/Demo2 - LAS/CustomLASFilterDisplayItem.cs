﻿using ArcGIS.Core.Data.Analyst3D;
using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datasets_3D
{
  /// <summary>
  /// Enum to represent the type of custom item to be added to the Combo boxes for Class Codes, return value and Classification flags of the LAS Dataset.
  /// </summary>
  public enum CustomItemType
  {
    ClassCode, ReturnType, Flags
  }

  /// <summary>
  /// Represents the custom item to be displayed in the combo box for Classification Codes, Return Values and Classification Flags of the LAS Dataset.
  /// </summary>
  public class CustomLASFilterDisplayItem : PropertyChangedBase
  {
    /// <summary>
    /// Constructor for Classification Code Custom item for combo box
    /// </summary>
    /// <param name="classCode"></param>
    /// <param name="isChecked"></param>
    public CustomLASFilterDisplayItem(int classCode = 1, bool isChecked = false)
    {
      if (classCode < 23)
        Name = classCode + " - " + _classificationCodeMeaning[classCode];
      if (classCode >= 23 && classCode <= 63)
        Name = classCode + " - " + "Reserved";
      if (classCode >= 64 && classCode <= 255)
        Name = classCode + " - " + "User defined";
      _classCode = classCode;

      ItemType = CustomItemType.ClassCode;
      IsChecked = isChecked;
    }

    /// <summary>
    /// Constructor for Return Type Custom item for combo box
    /// </summary>
    /// <param name="lasReturnType"></param>
    /// <param name="isChecked"></param>
    public CustomLASFilterDisplayItem(LasReturnType lasReturnType, bool isChecked)
    {
      if (_returnTypeMeaning.ContainsKey(lasReturnType))
        Name = _returnTypeMeaning[lasReturnType];
      else
        Name = "Single";
      _lasReturnType = lasReturnType;

      ItemType = CustomItemType.ReturnType;
      IsChecked = isChecked;
    }

    /// <summary>
    /// Constructor for Classification Flag Custom item for combo box
    /// </summary>
    /// <param name="flag"></param>
    /// <param name="isChecked"></param>
    public CustomLASFilterDisplayItem(string flag, bool isChecked)
    {
      Name = flag;
      _flag = flag;
      ItemType = CustomItemType.Flags;
      IsChecked = isChecked;
    }

    private int _classCode;
    public int ClassCode
    {
      get => _classCode;
      set => SetProperty(ref _classCode, value);
    }

    private LasReturnType _lasReturnType;
    public LasReturnType LasReturnType
    {
      get => _lasReturnType;
      set => SetProperty(ref _lasReturnType, value);
    }

    private string _flag;
    public string Flag
    {
      get => _flag;
      set => SetProperty(ref _flag, value);
    }

    private string _name;
    public string Name
    {
      get => _name;
      set => SetProperty(ref _name, value);
    }

    private bool _isChecked;
    public bool IsChecked
    {
      get => _isChecked;
      set => SetProperty(ref _isChecked, value);
    }

    private CustomItemType _itemType;
    public CustomItemType ItemType
    {
      get => _itemType;
      set => SetProperty(ref _itemType, value);
    }

    private static Dictionary<int, string> _classificationCodeMeaning = new Dictionary<int, string>
    {
        {0, "Created, Never classified"},
        {1, "Unassigned"},
        {2, "Ground"},
        {3, "Low Vegetation"},
        {4, "Medium Vegetation"},
        {5, "High Vegetation"},
        {6, "Building"},
        {7, "Low Point"},
        {8, "Model Key-Point"},
        {9, "Water"},
        {10, "Rail"},
        {11, "Road Surface"},
        {12, "Reserved"},
        {13, "Wire - Guard (Shield)"},
        {14, "Wire - Conductor (Phase)"},
        {15, "Transmission Tower"},
        {16, "Wire-Structure Connector (Insulator)"},
        {17, "Bridge Deck"},
        {18, "High Noise"},
        {19, "Reserved"},
        {20, "Ignored Ground"},
        {21, "Snow"},
        {22, "Temporal Exclusion"}
    };

    private static Dictionary<LasReturnType, string> _returnTypeMeaning = new Dictionary<LasReturnType, string>
    {
      {LasReturnType.Return1, "1"},
      {LasReturnType.Return2, "2"},
      {LasReturnType.Return3, "3"},
      {LasReturnType.Return4, "4"},
      {LasReturnType.Return5, "5"},
      {LasReturnType.Return6, "6"},
      {LasReturnType.Return7, "7"},
      {LasReturnType.Return8, "8"},
      {LasReturnType.Return9, "9"},
      {LasReturnType.Return10, "10"},
      {LasReturnType.Return11, "11"},
      {LasReturnType.Return12, "12"},
      {LasReturnType.Return13, "13"},
      {LasReturnType.Return14, "14"},
      {LasReturnType.Return15, "15"},
      {LasReturnType.ReturnFirstOfMany, "First of Many"},
      {LasReturnType.ReturnLastOfMany, "Last of Many"},
      {LasReturnType.ReturnLast, "Last"},
      {LasReturnType.ReturnSingle, "Single"},
    };
  }
}
