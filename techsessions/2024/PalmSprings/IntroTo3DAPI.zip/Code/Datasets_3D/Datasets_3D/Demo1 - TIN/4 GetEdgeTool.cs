﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Datasets_3D
{
  internal class GetEdgeTool : MapTool
  {
    public GetEdgeTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return QueuedTask.Run(() =>
      {
        var mapPoint = geometry as MapPoint;
        var tinLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TinLayer>().FirstOrDefault();
        if (tinLayer == null)
          return false;

        #region overlays and symbols
        Module1.Current.ClearOverlays();

        var magenta = ColorFactory.Instance.CreateRGBColor(255, 0, 255);

        var ptSymbol = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.RedRGB, 8);
        var edgeSymbol = SymbolFactory.Instance.ConstructLineSymbol(magenta, 2);
        var nextEdgeSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.BlueRGB, 2);
        var prevEdgeSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.GreenRGB, 2);
        var leftTriSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreenRGB, SimpleFillStyle.Horizontal);
        var rightTriSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreenRGB, SimpleFillStyle.Vertical);
        #endregion


        var tinDataset = tinLayer.GetTinDataset();

        var edge = tinDataset.GetNearestEdge(mapPoint);
        if (edge != null)
        {
          Module1.Current.AddOverlay(MapView.Active, edge.ToPolyline(), edgeSymbol.MakeSymbolReference());

          var nodes = edge.Nodes;
          var nextEdge = edge.GetNextEdgeInTriangle();
          var prevEdge = edge.GetPreviousEdgeInTriangle();
          var leftTriangle = edge.LeftTriangle;
          var rightTriangle = edge.RightTriangle;

          Module1.Current.AddOverlay(MapView.Active, nodes[0].ToMapPoint(), ptSymbol.MakeSymbolReference());
          Module1.Current.AddOverlay(MapView.Active, nodes[1].ToMapPoint(), ptSymbol.MakeSymbolReference());

          if (nextEdge != null)
            Module1.Current.AddOverlay(MapView.Active, nextEdge.ToPolyline(), nextEdgeSymbol.MakeSymbolReference());
          if (prevEdge != null)
            Module1.Current.AddOverlay(MapView.Active, prevEdge.ToPolyline(), prevEdgeSymbol.MakeSymbolReference());

          if (leftTriangle != null)
            Module1.Current.AddOverlay(MapView.Active, leftTriangle.ToPolygon(), leftTriSymbol.MakeSymbolReference());
          if (rightTriangle != null)
            Module1.Current.AddOverlay(MapView.Active, rightTriangle.ToPolygon(), rightTriSymbol.MakeSymbolReference());
        }

        return true;
      });
    }
  }
}
