﻿using ActiproSoftware.Windows.Shapes;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Analyst3D;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace Datasets_3D
{
  internal class TinSearchInfoViewModel : EmbeddableControl
  {
    private TinDataset _tinDataset;

    public TinSearchInfoViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) { }

    internal void Search(TinLayer tinLayer, Envelope envelope)
    {
      QueuedTask.Run(() =>
      {

        _tinDataset = tinLayer.GetTinDataset();

        //
        // all triangles within envelope
        // 
        var triFilter_all = new TinTriangleFilter();
        triFilter_all.FilterEnvelope = envelope;
        triFilter_all.FilterType = TinFilterType.All;   // default
        triFilter_all.DataElementsOnly = false;         // default
        TriangleCount_All = CountTriangles(triFilter_all);

        SymbolizeTriangles(triFilter_all);

        // 
        //  all INSIDE triangles within envelope  (DataElementsOnly = true = INSIDE)
        // 
        var insideTriFilter_all = new TinTriangleFilter();
        insideTriFilter_all.FilterEnvelope = envelope;
        insideTriFilter_all.FilterType = TinFilterType.All;   // default
        insideTriFilter_all.DataElementsOnly = true;
        InsideTriangleCount_All = CountTriangles(insideTriFilter_all);


        // 
        //  all triangles inside TIN within envelope (FilterType = InsideTin)
        // 
        var triFilter_insideTin = new TinTriangleFilter();
        triFilter_insideTin.FilterEnvelope = envelope;
        triFilter_insideTin.FilterType = TinFilterType.InsideTin;
        triFilter_insideTin.DataElementsOnly = false;     // default
        TriangleCount_InsideTin = CountTriangles(triFilter_insideTin);

        // 
        //  all INSIDE triangles inside TIN within envelope  (FilterType = InsideTin; DataElementsOnly = true = INSIDE)
        // 
        var insideTriFilter_insideTin = new TinTriangleFilter();
        insideTriFilter_insideTin.FilterEnvelope = envelope;
        insideTriFilter_insideTin.FilterType = TinFilterType.InsideTin;
        insideTriFilter_insideTin.DataElementsOnly = true;     // default
        InsideTriangleCount_InsideTin = CountTriangles(insideTriFilter_insideTin);


        // 
        //  all triangles inside TIN data area within envelope (FilterType = InsideDataArea)
        //      InsideDataArea = elements are "INSIDE"
        // 
        var triFilter_insideDataArea = new TinTriangleFilter();
        triFilter_insideDataArea.FilterEnvelope = envelope;
        triFilter_insideDataArea.FilterType = TinFilterType.InsideDataArea;
        TriangleCount_InsideDataArea = CountTriangles(triFilter_insideDataArea);
      });
    }

    #region Counts
    private int _triangleCount_all;
    public int TriangleCount_All
    {
      get => _triangleCount_all;
      set => SetProperty(ref _triangleCount_all, value);
    }

    private int _insideTriangleCount_All;
    public int InsideTriangleCount_All
    {
      get => _insideTriangleCount_All;
      set => SetProperty(ref _insideTriangleCount_All, value);
    }

    private int _triangleCount_InsideTin;
    public int TriangleCount_InsideTin
    {
      get => _triangleCount_InsideTin;
      set => SetProperty(ref _triangleCount_InsideTin, value);
    }

    private int _insideTriangleCount_InsideTin;
    public int InsideTriangleCount_InsideTin
    {
      get => _insideTriangleCount_InsideTin;
      set => SetProperty(ref _insideTriangleCount_InsideTin, value);
    }
    private int _triangleCount_InsideDataArea;
    public int TriangleCount_InsideDataArea
    {
      get => _triangleCount_InsideDataArea;
      set => SetProperty(ref _triangleCount_InsideDataArea, value);
    }

    internal void ClearCounts()
    {
      TriangleCount_All = 0;
      InsideTriangleCount_All = 0;
      TriangleCount_InsideTin = 0;
      InsideTriangleCount_InsideTin = 0;
      TriangleCount_InsideDataArea = 0;
    }
    #endregion

    internal int CountTriangles(TinTriangleFilter filter)
    {
      var count = 0;
      using (var triangleCursor = _tinDataset.SearchTriangles(filter))
      {
        while (triangleCursor.MoveNext())
        {
          using (ArcGIS.Core.Data.Analyst3D.TinTriangle triangle = triangleCursor.Current)
          {
            count++;
          }
        }
      }

      return count;
    }

    internal void SymbolizeTriangles(TinTriangleFilter filter)
    {
      var insideTriSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreenRGB, SimpleFillStyle.Horizontal);
      var outsideTriSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.BlueRGB, SimpleFillStyle.Vertical);
      var outsideTINTriSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.RedRGB, SimpleFillStyle.Vertical);

      Module1.Current.ClearOverlays();

      using (var triangleCursor = _tinDataset.SearchTriangles(filter))
      {
        while (triangleCursor.MoveNext())
        {
          using (ArcGIS.Core.Data.Analyst3D.TinTriangle triangle = triangleCursor.Current)
          {
            if (triangle.IsInsideDataArea)
            {
              Module1.Current.AddOverlay(MapView.Active, triangle.ToPolygon(), insideTriSymbol.MakeSymbolReference());
            }
            else
            {
              if (triangle.Index == 183)
                Module1.Current.AddOverlay(MapView.Active, triangle.ToPolygon(), outsideTINTriSymbol.MakeSymbolReference());
              else
                Module1.Current.AddOverlay(MapView.Active, triangle.ToPolygon(), outsideTriSymbol.MakeSymbolReference());
            }
          }
        }
      }
    }
  }
}