﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datasets_3D
{
  internal class GetDataExtent : Button
  {
    internal List<IDisposable> overlays = new List<IDisposable>();
    protected override async void OnClick()
    {
      var layer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TinLayer>().FirstOrDefault();
      if (layer == null)
        return;

      await QueuedTask.Run(() =>
      {
        #region Overlays and symbols
        foreach (var overlay in overlays)
        {
          overlay.Dispose();
        }
        overlays.Clear();

        // define symbols
        var dataExtentOutline = SymbolFactory.Instance.ConstructStroke(ColorFactory.Instance.BlackRGB, 2, SimpleLineStyle.Solid);
        var dataExtentSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.BlackRGB, SimpleFillStyle.Null, dataExtentOutline);
        #endregion



        var tinDataset = layer.GetTinDataset();

        // data extent
        var dataExtent = tinDataset.GetDataArea();
        MapView.Active.AddOverlay(dataExtent, dataExtentSymbol.MakeSymbolReference());
      });
    }
  }
}
