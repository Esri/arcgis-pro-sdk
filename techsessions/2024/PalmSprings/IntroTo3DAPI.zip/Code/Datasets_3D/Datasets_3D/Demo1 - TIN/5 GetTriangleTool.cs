﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datasets_3D
{
  internal class GetTriangleTool : MapTool
  {


    public GetTriangleTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    // tinDataset.GetTriangleNeighborhood

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return QueuedTask.Run(() =>
      {
        var mapPoint = geometry as MapPoint;
        var tinLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TinLayer>().FirstOrDefault();
        if (tinLayer == null)
          return false;

        #region overlays and symbols
        Module1.Current.ClearOverlays();

        var ptSymbol = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.RedRGB, 8);
        var edgeSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.BlueRGB, 2);
        var triSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreenRGB, SimpleFillStyle.Horizontal);
        var adjTriSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreenRGB, SimpleFillStyle.Vertical);
        #endregion


        var tinDataset = tinLayer.GetTinDataset();

        var triangle = tinDataset.GetTriangleByPoint(mapPoint);
        if (triangle != null)
        {
          Module1.Current.AddOverlay(MapView.Active, triangle.ToPolygon(), triSymbol.MakeSymbolReference());

          var centroid = triangle.GetCentroid();
          var circle = triangle.GetCircumCircle();
          var adjTriangles = triangle.GetAdjacentTriangles();

          if (centroid != null)
            Module1.Current.AddOverlay(MapView.Active, centroid, ptSymbol.MakeSymbolReference());
          if (circle != null)
          {
            var polyline = PolylineBuilderEx.CreatePolyline(circle);
            Module1.Current.AddOverlay(MapView.Active, polyline, edgeSymbol.MakeSymbolReference());
          }

          foreach (var t in adjTriangles)
            Module1.Current.AddOverlay(MapView.Active, t.ToPolygon(), adjTriSymbol.MakeSymbolReference());
        }

        return true;
      });
    }
  }
}
