﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datasets_3D
{
  internal class GetSuperNodes : Button
  {
    internal List<IDisposable> overlays = new List<IDisposable>();
    protected override async void OnClick()
    {
      var layer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TinLayer>().FirstOrDefault();
      if (layer == null)
        return;

      await QueuedTask.Run(() =>
      {
        #region overlays and symbols
        foreach (var overlay in overlays)
        {
          overlay.Dispose();
        }
        overlays.Clear();

        // define symbols
        var superNodeSymbol = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.GreenRGB, 8);

        var superNodeExtentOutline = SymbolFactory.Instance.ConstructStroke(ColorFactory.Instance.RedRGB, 2, SimpleLineStyle.Solid);
        var superNodeExtentSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.RedRGB, SimpleFillStyle.Null, superNodeExtentOutline);
        #endregion



        var tinDataset = layer.GetTinDataset();


        // super node extent
        var superNodeExtent = tinDataset.GetSuperNodeExtent();
        var superNodePoly = PolygonBuilderEx.CreatePolygon(superNodeExtent);
        MapView.Active.AddOverlay(superNodePoly, superNodeExtentSymbol.MakeSymbolReference());

        // search for the super nodes
        var filter = new ArcGIS.Core.Data.Analyst3D.TinNodeFilter();
        filter.FilterType = ArcGIS.Core.Data.Analyst3D.TinFilterType.All;     // default
        filter.DataElementsOnly = false;   
        filter.FilterEnvelope = superNodeExtent;
        filter.SuperNode = true;

        var nodecursor = tinDataset.SearchNodes(filter);
        while (nodecursor.MoveNext())
        {
          using (var node = nodecursor.Current)
          {
            overlays.Add(MapView.Active.AddOverlay(node.ToMapPoint(), superNodeSymbol.MakeSymbolReference()));
          }
        }   // 4

      });
    }
  }
}
