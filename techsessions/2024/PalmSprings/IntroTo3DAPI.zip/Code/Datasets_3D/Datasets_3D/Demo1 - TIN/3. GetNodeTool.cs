﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Analyst3D;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datasets_3D
{
  internal class GetNodeTool : MapTool
  {
    public GetNodeTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return QueuedTask.Run(() =>
        {
          var mapPoint = geometry as MapPoint;
          var tinLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TinLayer>().FirstOrDefault();
          if (tinLayer == null)
            return false;

          #region overlays and symbols

          Module1.Current.ClearOverlays();

          var magenta = ColorFactory.Instance.CreateRGBColor(255, 0, 255);
          var ptSymbol = SymbolFactory.Instance.ConstructPointSymbol(magenta, 8);
          var adjPtSymbol = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.BlueRGB, 8);
          var edgeSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.RedRGB, 2);
          var triSymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.GreenRGB, SimpleFillStyle.Horizontal);
          #endregion



          var tinDataset = tinLayer.GetTinDataset();

          var node = tinDataset.GetNearestNode(mapPoint);
          if (node != null)
          {
            // add to overlay
            Module1.Current.AddOverlay(MapView.Active, node.ToMapPoint(), ptSymbol.MakeSymbolReference());

            // find adjacent nodes, incident edges, incident triangles
            var adjNodes = node.GetAdjacentNodes();
            var edges = node.GetIncidentEdges();
            var triangles = node.GetIncidentTriangles();

            foreach (var n in adjNodes)
              Module1.Current.AddOverlay(MapView.Active, n.ToMapPoint(), adjPtSymbol.MakeSymbolReference());
            
            foreach (var e in edges)
              Module1.Current.AddOverlay(MapView.Active, e.ToPolyline(), edgeSymbol.MakeSymbolReference());
            
            foreach (var t in triangles)
              Module1.Current.AddOverlay(MapView.Active, t.ToPolygon(), triSymbol.MakeSymbolReference());
          }

          return true;
        });
    }
  }
}
