﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Mapping;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyst3DLayers
{
  internal class RenderTinLayer : Button
  {
    protected override void OnClick()
    {
      var tinLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TinLayer>().FirstOrDefault();
      if (tinLayer == null) return;
      
      QueuedTask.Run( () =>
      {
        #region Display nodes of a TIN using a TinNodeRendererDefinition
        var nodeSymbol = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.RedRGB, 2.0);
        // Step 1: Create the TinRendererDefinition
        var nodeRendererDef = new TinNodeRendererDefinition()
        { 
         Description = "Simple Node Renderer",
         SymbolTemplate = nodeSymbol.MakeSymbolReference()
        };
        if (tinLayer.CanCreateRenderer(nodeRendererDef))
        {
          //Step 2: Create the renderer
          var renderer = tinLayer.CreateRenderer(nodeRendererDef) as CIMTinNodeRenderer;
          renderer.Symbol.Symbol.SetRealWorldUnits(false); //Display symbol with screen size
          renderer.Symbol.Symbol.SetSize(2.0); //Set size
          if (tinLayer.CanSetRenderer(renderer, SurfaceRendererTarget.Points))
            //Step 3: Set the renderer
            tinLayer.SetRenderer(renderer, SurfaceRendererTarget.Points);
        }
        #endregion
      });
    }
    internal static CIMColorRamp GetColorRamp(string colorRampName = "Spectrum By Wavelength-Full Bright")
    {
      StyleProjectItem style =
        Project.Current.GetItems<StyleProjectItem>().FirstOrDefault(s => s.Name == "ArcGIS Colors");
      if (style == null) return null;
      //var colorRampList = style.SearchColorRamps("Heat Map 4 - Semitransparent");
      var colorRampList = style.SearchColorRamps(colorRampName);
      if (colorRampList == null || colorRampList.Count == 0) return null;
      return colorRampList[0].ColorRamp;
    }
  }
}
