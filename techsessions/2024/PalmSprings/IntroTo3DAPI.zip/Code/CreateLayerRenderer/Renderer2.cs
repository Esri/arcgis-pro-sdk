﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyst3DLayers
{
  internal class Renderer2 : Button
  {
    protected override void OnClick()
    {
      var map = MapView.Active?.Map;
      if (map == null) return;
      QueuedTask.Run( () => {
        #region Renderer 1: Display nodes of a TIN using a TinNodeRendererDefinition
        var nodeSymbol = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.RedRGB, 2.0);
        var nodeRendererDef = new TinNodeRendererDefinition(){
          Description = "Simple Node Renderer",
          SymbolTemplate = nodeSymbol.MakeSymbolReference()
        };
        #endregion
        #region Renderer 2: Display contours of a TIN using a TinContourRendererDefinition
        var indexContourLineSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.RedRGB, 1.7);
        var regularContourLineSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.BlackRGB, 1);
        var contourRendererDefn = new TinContourRendererDefinition
                   (regularContourLineSymbol.MakeSymbolReference(), 
                   "Symbol Label: Regular Contour", 
                   "Symbol Description: Regular Contour",
                    indexContourLineSymbol.MakeSymbolReference(), 
                    "Index Label: Index Contour", 
                    "Index Description: Index Contour");
        contourRendererDefn.ContourInterval = 10;
        contourRendererDefn.ContourFactor = 10;
        contourRendererDefn.ReferenceHeight = 7;
        #endregion
        #region Renderer 3: Display surfaces of a TIN using a TinFaceClassBreaksRendererDefinition
        var tinFaceClassBreaksRendererDefinition = 
              new TinFaceClassBreaksRendererDefinition(TerrainDrawCursorType.FaceElevation);
        tinFaceClassBreaksRendererDefinition.ClassificationMethod = ClassificationMethod.StandardDeviation;
        tinFaceClassBreaksRendererDefinition.DeviationInterval = StandardDeviationInterval.OneQuarter;
        tinFaceClassBreaksRendererDefinition.ColorRamp = GetColorRamp();
        #endregion

        //Create a dictionary of renderer definitions
        var rendererDefinitions = new Dictionary<SurfaceRendererTarget, TinRendererDefinition>();
        //Add the 3 renderer definitions to the dictionary
        rendererDefinitions.Add(SurfaceRendererTarget.Points, nodeRendererDef);
        rendererDefinitions.Add(SurfaceRendererTarget.Contours, contourRendererDefn);
        rendererDefinitions.Add(SurfaceRendererTarget.Surface, tinFaceClassBreaksRendererDefinition);

        //Create the TinLayerCreationParams objects
        //Defining the name, visibility and the renderer definitions
        var tinUri = new Uri($@"{Project.Current.HomeFolderPath}\Palisades");
        var tinLayerParams = new TinLayerCreationParams(tinUri)
        {
          Name = "Palisades",
          IsVisible = true,
          RendererDefinitions = rendererDefinitions //Adding the 3 renderer definitions
        };
        //Create the TinLayer pre-configured with the renderer definitions
        var tinLayer = LayerFactory.Instance.
                CreateLayer<TinLayer>(tinLayerParams, map);
      });
    }

    internal static CIMColorRamp GetColorRamp(string colorRampName = "Spectrum By Wavelength-Full Bright")
    {
      StyleProjectItem style =
        Project.Current.GetItems<StyleProjectItem>().FirstOrDefault(s => s.Name == "ArcGIS Colors");
      if (style == null) return null;
      //var colorRampList = style.SearchColorRamps("Heat Map 4 - Semitransparent");
      var colorRampList = style.SearchColorRamps(colorRampName);
      if (colorRampList == null || colorRampList.Count == 0) return null;
      return colorRampList[0].ColorRamp;
    }
  }
}
