﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyst3DLayers
{
  internal class GetRenderers : Button
  {
    protected override void OnClick()
    {
      var tinLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TinLayer>().FirstOrDefault();
      if (tinLayer == null) return;
      QueuedTask.Run( () => {
        //Gets the renderers for the TIN layer as a list
        IReadOnlyList<CIMTinRenderer> tinRenderers = tinLayer.GetRenderers();
        var rendererCount = tinRenderers.Count;

        // get the renderers as a dictionary
        Dictionary<SurfaceRendererTarget, CIMTinRenderer> rendererDict
                           = tinLayer.GetRenderersAsDictionary();
        CIMTinRenderer surfaceRenderer;
        
        // iterate through dictionary and get the surface renderer
        if (rendererDict.ContainsKey(SurfaceRendererTarget.Surface))
          surfaceRenderer = rendererDict[SurfaceRendererTarget.Surface];
      });
     

    }
  }
}
