﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyst3DLayers
{
  internal class CreateLasDatasetLayer : Button
  {
    protected override void OnClick()
    {
      var lasDatasetUri = new Uri($@"{Project.Current.HomeFolderPath}\Netherlands.zlas");
      //Create a LasDataset Parameter object
      //with the values for the new layer
      var lasParams = new LasDatasetLayerCreationParams(lasDatasetUri)
      {
        Name = "Netherlands",
        IsVisible = true
      };

      QueuedTask.Run( () =>
      {
        LasDatasetLayer lasDatasetLayer = null;
        //Check if the layer can be created
        // with the given parameters
        if (LayerFactory.Instance.CanCreateLayer<LasDatasetLayer>(lasParams, MapView.Active.Map))
          {
          //Create the layer passing in the parameters  
          //Templated type is LasDatasetLayer
          lasDatasetLayer = LayerFactory.Instance.
              CreateLayer<LasDatasetLayer>(lasParams, MapView.Active.Map);
          }
      });
    }
  }
}
