﻿using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Desktop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Resources;

namespace POITracking.Models
{
  public class SuspectInfo
  {
    public SuspectInfo(KnowledgeGraphEntityValue suspect, long numberOfCalls = 0)
    {
      Init(suspect);
      this.Id = (long)suspect["objectid"];
      this.FullName = (string)suspect["FULL_NAME"];
      this.City = (string)suspect["CITY"];
      this.Address = (string)suspect["ADDRESS"];
      this.PhoneNumber = (string)suspect["PHONE_NUMBER"];
      ForceOverwriteOfImages = Module1.Current.ForceOverwriteOfImages;
      if (numberOfCalls > 0)
        NumberTimesCalled = numberOfCalls;
    }

    public SuspectInfo()
    {
    }

    public string FullName { get; set; }
    public string PhoneNumber { get; set; }
    public string Name
    {
      get
      {
        var parts = FullName.Split(',');
        if (parts.Length > 1)
        {
          var subParts = parts[^1].Split(' ', StringSplitOptions.RemoveEmptyEntries);
          return subParts[0];
        }
        return FullName;
      }
    }
    public long Id { get; set; }
    public string SubHeader
    {
      get
      {
        return PhoneNumber;
        // return $@"{Dob}, {Height}, {Weight}";
      }
    }
    public string Address { get; set; }
    public string City { get; set; }
    public string Weight { get; set; }
    public string Height { get; set; }
    public string Dob { get; set; }

    internal bool ForceOverwriteOfImages { get; set; }

    public long NumberTimesCalled { get; set; }

    public string SuspectDetails
    {
      get
      {
        return $"{Name} ({City}), " +
               $"cell: {PhoneNumber} called {NumberTimesCalled} times";
      }
    }

    public string ImageSource
    {
      get
      {
        var img_name = FullName.ToLower().Replace(" ", "_");
        return PackUriForResource($@"{img_name}.png").AbsoluteUri;
        //return $@"C:\Data\POI\{Id}new.png";
      }
    }

    public string LocalImageSource
    {
      get
      {
				var img_name = FullName.ToLower().Replace(" ", "_");
				var localImagePath = System.IO.Path.Combine(CoreModule.CurrentProject.DefaultGeodatabasePath, $@"{img_name}.png");
        if (!System.IO.File.Exists(localImagePath) || this.ForceOverwriteOfImages)
        {
					BitmapImage bmp = new();
					bmp.BeginInit();
          bmp.StreamSource = ImageStream;
					bmp.EndInit();
					BitmapEncoder encoder = new PngBitmapEncoder();
					encoder.Frames.Add(BitmapFrame.Create(bmp));
					using var fileStream = new System.IO.FileStream(localImagePath, System.IO.FileMode.Create);
					encoder.Save(fileStream);
          this.ForceOverwriteOfImages = false;
        }
				return localImagePath;
      }
    }

    #region ImageStream

    public System.IO.Stream ImageStream
    {
      get
      {
        var img_name = FullName.ToLower().Replace(" ", "_");
        StreamResourceInfo sri = Application.GetResourceStream(new Uri($@"pack://application:,,,/POITracking;Component/Images/{img_name}.png"));
        return sri.Stream;
      }
    }
    private ImageSource GetImage(string imageName)
    {
      StreamResourceInfo sri = Application.GetResourceStream(
        new Uri($@"pack://application:,,,/POITracking;Component/Images/{imageName}"));
      BitmapImage bmp = new BitmapImage();
      bmp.BeginInit();
      bmp.StreamSource = sri.Stream;
      bmp.EndInit();
      return bmp;
    }
    public static Uri PackUriForResource(string resourceName, string folderName = "Images")
    {
      string asm = System.IO.Path.GetFileNameWithoutExtension(
          System.Reflection.Assembly.GetExecutingAssembly().Location);
      string uriString = folderName.Length > 0
          ? string.Format("pack://application:,,,/{0};component/{1}/{2}", asm, folderName, resourceName)
          : string.Format("pack://application:,,,/{0};component/{1}", asm, resourceName);
      return new Uri(uriString, UriKind.Absolute);
    }

    #endregion ImageStream

    public static SuspectInfo GetSuspectInfoByFullName(string name)
    {
      return SuspectInfoList.FirstOrDefault(s => s.FullName == name);
    }

    public static SuspectInfo GetSuspectInfoByName(string name)
    {
      return SuspectInfoList.FirstOrDefault(s => s.Name == name);
    }

    private void Init(KnowledgeGraphEntityValue suspect)
    {
      var name = (string)suspect["FULL_NAME"];

      var ssi = SuspectInfoList.FirstOrDefault(ssi => ssi.FullName == name);
      if (ssi == null)
      {
        ssi = new SuspectInfo()
        {
          Height = "5'06",
          Weight = "155",
          Dob = "3/10/1998"
        };
      }
      this.Height = ssi.Height;
      this.Weight = ssi.Weight;
      this.Dob = ssi.Dob;
    }


    public static List<SuspectInfo> _SuspectInfoList = new List<SuspectInfo>();
    private static List<SuspectInfo> SuspectInfoList
    {
      get
      {
        if (_SuspectInfoList.Count > 0) return _SuspectInfoList;
        //v6
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Ty Fitzpatrick", Height = "5'10", Weight = "195", Dob = "9/20/1986" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Amy Clarke", Height = "5'05", Weight = "135", Dob = "12/21/1993" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Tim Murphy", Height = "6'01", Weight = "225", Dob = "3/10/1979" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Charlie McCloud", Height = "5'09", Weight = "200", Dob = "7/28/1968" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Wolfgang Kaiser", Height = "6'02", Weight = "195", Dob = "9/20/1956" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Jim Miller", Height = "5'08", Weight = "180", Dob = "2/23/2001" });
        //v7
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Robert Johnson", Height = "5'10", Weight = "195", Dob = "9/20/1986" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Michael Wilson", Height = "5'05", Weight = "135", Dob = "12/21/1993" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Dan Brown", Height = "6'01", Weight = "225", Dob = "3/10/1979" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "James Davis", Height = "5'09", Weight = "200", Dob = "7/28/1968" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "William Thompson", Height = "6'02", Weight = "195", Dob = "9/20/1956" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "James Miller", Height = "5'08", Weight = "195", Dob = "9/20/1956" });
        //Females
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Emma Clarke", Height = "5'05", Weight = "135", Dob = "06/21/1998" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Olivia Smith", Height = "5'02", Weight = "115", Dob = "09/21/1983" });
        _SuspectInfoList.Add(new SuspectInfo { FullName = "Mia Anderson", Height = "5'03", Weight = "155", Dob = "12/21/1989" });

        return _SuspectInfoList;
      }
    }

  }
}
