﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Internal.Mapping.Ribbon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace POITracking.Reporting
{
  [DataContract]
  internal class SetPage
	{
		[DataMember(Name = "Name")]
		public string Name { get; set; }
		[DataMember(Name = "LayoutName")]
		public string LayoutName { get; set; }
		[DataMember(Name = "MapFrameName")]
		public string MapFrameName { get; set; }
		[DataMember(Name = "Width")]
		internal double Width { get; set; }
		[DataMember(Name = "Height")]
		internal double Height { get; set; }
		[DataMember(Name = "LinearUnit")]
		internal LinearUnit LinearUnit { get; set; }

		// computed fields:

		internal double OffsetFromPageMiddle = 7 / 8.0;
		internal double OffsetImageBoxWidth = 7 / 16.0;

		internal double MarginLayout => 0.35;

		internal double XCenterOffset => 1.25;
		// layout: 0,0 is bottom left corner of layout

		// Title
		internal double TitleXll => MarginLayout + XCenterOffset + 0.5;
		internal double TitleYll => Height-TitleHeight;
		internal double TitleHeight => MarginLayout * 2;
		internal double TitleWidth => Width - MarginLayout * 2 - XCenterOffset;
		// Pics
		internal double PicsHeight => 0.5;
		internal double PicsWidth => 1.5;
		internal double PicsXll => Width/2.0 - 1.5 * PicsWidth;
		internal double PicsYll => TitleYll - PicsHeight-(MarginLayout/2);
		internal double PicsXur => Width - MarginLayout;
		internal double PicsYur => PicsYll + PicsHeight;
		internal double PicsLabelHeight => 0.8;
		// Map
		internal double MapXll => MarginLayout;
		internal double MapYll => MapYur - MapHeight;
		internal double MapXur => Width - MarginLayout;
		internal double MapYur => 9.35;
		internal double MapHeight => 3.5;
		internal double MapWidth => Width - MarginLayout;
		// Link Chart
		internal double LinkChartHeight => MapYll - (2*MarginLayout);
		internal double LinkChartWidth => 5.0 - MarginLayout;
		internal double LinkChartXll => MarginLayout;
		internal double LinkChartYll => MapYll - MarginLayout - LinkChartHeight;
		internal double LinkChartXur => LinkChartXll + LinkChartWidth;
    internal double LinkChartYur => LinkChartYll + LinkChartHeight;

    // Table
    internal double TableHeight => MapYll - (3 * MarginLayout) - LegendHeight;
		internal double TableWidth => LegendWidth;
		internal double TableXll => Width - MarginLayout - TableWidth;
		internal double TableYll => MapYll - MarginLayout - TableHeight;
		internal double TableYur => TableYll + TableHeight;
		internal double TableXur => TableXll + TableWidth;

		// Legend
		internal double LegendXll => Width - MarginLayout - LegendWidth;
		internal double LegendYll => MarginLayout;
    internal double LegendXur => LegendXll + LegendWidth;
    internal double LegendYur => LegendYll + LegendHeight;
    internal double LegendHeight => 2.5;
		internal double LegendWidth => 3.0 - MarginLayout;

		// Service Layer Credits
		internal double ServiceLyrCredsXll => MarginLayout;
		internal double ServiceLyrCredsYll => -MarginLayout;
	}

	[DataContract]
  internal class SetPages
  {
    [DataMember(Name = "SetPageList")]
    internal IList<SetPage> SetPageList { get; set; }

    internal SetPages()
    {
      SetPageList = new List<SetPage>
      {
        new() { Name = "Legal - Portrait", MapFrameName = "Sample Map Frame", LayoutName = "Person of Interest", Width = 8.3, Height = 11.7, LinearUnit = LinearUnit.Inches },
        new() { Name = "Legal - Portrait", MapFrameName = "Sample Map Frame", LayoutName = "Person of Interest", Width = 8.5, Height = 14, LinearUnit = LinearUnit.Inches }
      };

    }
    
  }
}
