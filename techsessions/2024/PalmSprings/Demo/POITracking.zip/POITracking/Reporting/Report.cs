﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Internal.Geometry;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Reports;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using POITracking.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace POITracking.Reporting
{
  internal class Report
  {
    internal static async void RunReport ()
    {
      if (MapView.Active == null)
      {
        MessageBox.Show("No map view is active");
        return;
      }

      var currentCamera = MapView.Active?.Camera;
      try
      {
        // take first first map in the project
        var mapProjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.MapType == MapType.Map);

        
        var linkChartProjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.MapType == MapType.LinkChart);

        var mapName = mapProjItem.Name;
        //var linkChartName = linkChartProjItem.Name;
        var setPages = new SetPages();
        var pageLayout = setPages.SetPageList[0];

        var theLayout = await QueuedTask.Run<Layout>(() =>
        {
          //Set up a page
          CIMPage newPage = new()
					{
            //required
            Width = pageLayout.Width,
            Height = pageLayout.Height,
            Units = pageLayout.LinearUnit
          };
          Layout layout = LayoutFactory.Instance.CreateLayout(newPage);
          layout.SetName(pageLayout.LayoutName);

          //Title: dynamic text: <dyn type="page" property="name"/>
          var dt = DateTime.Now.ToString("MM/dd/yyyy");
					var title = $@"Call Analysis for: '{Module1.Current.PersonOfInterest.FullName}', {dt}";
					Coordinate2D llTitle = new(pageLayout.TitleXll, pageLayout.TitleYll);
					var pointGeometry = MapPointBuilderEx.CreateMapPoint(llTitle);
					var titleGraphics = ElementFactory.Instance.CreateTextGraphicElement(layout, TextType.PointText, pointGeometry, null) as TextElement;
					titleGraphics.SetTextProperties(new TextProperties(title, "Arial", 16, "Bold"));

            //Baseball card row

            List<SuspectInfo> suspects = new List<SuspectInfo>();// [];
          suspects.Add(Module1.Current.PersonOfInterest);
          suspects.Add(Module1.Current.SuspectCalled);
          AddSuspectsToLayout(suspects, layout, pageLayout);
          

					//Add Map Frame
					Coordinate2D llMap = new(pageLayout.MapXll, pageLayout.MapYll);
          Coordinate2D urMAP = new(pageLayout.MapXur, pageLayout.MapYur);
          Envelope envMap = EnvelopeBuilderEx.CreateEnvelope(llMap, urMAP);

          //Reference map, create Map Frame and add to layout
          MapProjectItem mapPrjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals(mapName) && item.MapType == MapType.Map);
          Map theMap = mapPrjItem.GetMap();
          MapFrame mfElm = ElementFactory.Instance.CreateMapFrameElement(layout, envMap, theMap);
          mfElm.SetName(pageLayout.MapFrameName);
          if (currentCamera != null)
            mfElm.SetCamera(currentCamera);

          /*
          //Add knowledge graph link chart
          var llKg = new Coordinate2D(pageLayout.LinkChartXll, pageLayout.LinkChartYll);
          var urKg = new Coordinate2D(pageLayout.LinkChartXur, pageLayout.LinkChartYur);
          var envKg = EnvelopeBuilder.CreateEnvelope(llKg, urKg);

          //Reference link chart, create Map Frame and add to layout
          MapProjectItem linkChartPrjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals(linkChartName) && item.MapType == MapType.LinkChart);
          Map theLinkChart = linkChartPrjItem.GetMap();
          MapFrame linkChartMf = ElementFactory.Instance.CreateMapFrameElement(layout, envKg, theLinkChart);
          // zoom out a bit
          var newCamera = linkChartMf.Camera;
          newCamera.Scale *= 1.2;
          linkChartMf.SetCamera(newCamera);
          */


          //Scale bar
          Coordinate2D llScalebar = new(pageLayout.MapXll + pageLayout.MarginLayout, 
            pageLayout.MapYll + pageLayout.MarginLayout);
          var scaleBarGeometry = MapPointBuilderEx.CreateMapPoint(llScalebar);
          //Create Scale Bar
          ScaleBarInfo sbInfo = new()
          {
            MapFrameName = mfElm.Name
          };
          var sbElm = ElementFactory.Instance.CreateMapSurroundElement(layout, scaleBarGeometry, sbInfo) as ScaleBar;

          //NorthArrow
          Coordinate2D llNorthArrow = new(pageLayout.MapWidth-pageLayout.MarginLayout,
            pageLayout.MapYll + 1.25 * pageLayout.MarginLayout);
          var northArrowGeometry = MapPointBuilderEx.CreateMapPoint(llNorthArrow);
          NorthArrowInfo sbInfoNorthArrow = new()
					{
            MapFrameName = mfElm.Name
          };
          var northArrow = ElementFactory.Instance.CreateMapSurroundElement(layout, northArrowGeometry, sbInfoNorthArrow) as NorthArrow;
          northArrow.SetAnchor(Anchor.CenterPoint);
          northArrow.SetLockedAspectRatio(true);
          northArrow.SetWidth(1.1 * northArrow.GetWidth());

            // Table 1
            //AddTableToLayout(layout, theMap, mfElm, "Call Locations", pageLayout, ["PhoneOwner", "DateAndTime"]);
            string[] cols = { "PhoneOwner", "DateAndTime" };
            AddTableToLayout(layout, theMap, mfElm, "Call Locations", pageLayout, cols);


            // legend
            Coordinate2D llLegend = new(pageLayout.LegendXll, pageLayout.LegendYll);
          Coordinate2D urLegend = new(pageLayout.LegendXur, pageLayout.LegendYur);
          System.Diagnostics.Debug.WriteLine(mfElm);
          var legendInfo = new LegendInfo
          {
            MapFrameName = mfElm.Name
          };
          var legend = ElementFactory.Instance.CreateMapSurroundElement(layout, EnvelopeBuilderEx.CreateEnvelope(llLegend, urLegend), legendInfo) as Legend;

          // Service layer credits
          var servLyrCred = @"<dyn type=""layout"" name=""Sample Map4"" property=""serviceLayerCredits""/>";
          Coordinate2D llServLyrCred = new(pageLayout.ServiceLyrCredsXll, pageLayout.ServiceLyrCredsYll);
          var pntGeom = MapPointBuilderEx.CreateMapPoint(llServLyrCred);
          var slcElement = ElementFactory.Instance.CreateTextGraphicElement(layout, TextType.PointText, pntGeom, null) as TextElement;
          var txtProps = new TextProperties(servLyrCred, "Arial", 8, "Regular");
          slcElement.SetTextProperties(txtProps);
          return layout;
        });

        //CREATE, OPEN LAYOUT VIEW (must be in the GUI thread)
        ILayoutPane layoutPane = await LayoutFrameworkExtender.CreateLayoutPaneAsync(ProApp.Panes, theLayout);
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error in create layout: {ex}");
      }
    }

		private static void AddSuspectsToLayout(List<SuspectInfo> suspects, Layout layout, SetPage pageLayout)
		{
      var xOffset = 0.0;
      double picXOffset = -1;
      var middle = pageLayout.Width * 0.5;

      foreach (var suspect in suspects)
      {
        if (picXOffset <= 0)
        {
          picXOffset = middle - pageLayout.OffsetFromPageMiddle - pageLayout.OffsetImageBoxWidth;
        }
        else
        {
          picXOffset = middle + pageLayout.OffsetFromPageMiddle;
        }
        Coordinate2D llPic = new(picXOffset+0.15, pageLayout.PicsYll);
        Coordinate2D urPic = new(picXOffset + 0.25 + pageLayout.OffsetImageBoxWidth, pageLayout.PicsYur);
        //Coordinate2D llPic = new(pageLayout.XllPics+xOffset, pageLayout.YllPics);
        //Coordinate2D urPic = new(pageLayout.XurPics + xOffset, pageLayout.YurPics);
        Envelope envPic = EnvelopeBuilderEx.CreateEnvelope(llPic, urPic);
        var imagePath = suspect.LocalImageSource;
        var picGraphic = ElementFactory.Instance.CreatePictureGraphicElement(layout, envPic, imagePath);
        CIMGraphic picGra = picGraphic.GetGraphic();
        CIMPictureGraphic cimPicGra = picGra as CIMPictureGraphic;
				cimPicGra.Frame.BorderSymbol = new CIMSymbolReference
				{
					Symbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.GreyRGB, 1.0, SimpleLineStyle.Solid)
				};
				//Update the element
				picGraphic.SetGraphic(picGra);

        var nl = Environment.NewLine;
        var poi = $@"{suspect.Name}{nl}{suspect.PhoneNumber}{nl}{suspect.City}{nl}{suspect.Dob}";
        Coordinate2D llPiclabel = new(picXOffset, pageLayout.PicsYll - pageLayout.PicsLabelHeight);
        //Coordinate2D llPiclabel = new(pageLayout.XllPics + xOffset, pageLayout.YllPics - pageLayout.HeightPics - 0.2 + pageLayout.MarginLayout / 2);
        var piclabelGeometry = MapPointBuilderEx.CreateMapPoint(llPiclabel);
        var titlePics = ElementFactory.Instance.CreateTextGraphicElement(layout, TextType.PointText, piclabelGeometry, null) as TextElement;
        titlePics.SetTextProperties(new TextProperties(poi, "Arial", 12, "Regular"));
        if (xOffset > 0)
          xOffset += 1.25;
        else
        {
					xOffset += 1.25;
					var phoneIcon = "BusinessAnalystPhone32";
          var img = GetImagepathForResourceImage(phoneIcon);
          var shrinkage = 0.3; // inches
          
          llPic = new(middle - (3/16) + 0.25, pageLayout.PicsYll + shrinkage - 0.2);
          //llPic = new(pageLayout.XllPics + xOffset + shrinkage, pageLayout.YllPics+ shrinkage);
          urPic = new(middle + (3/16) + 0.25, pageLayout.PicsYur - shrinkage - 0.2);
          //urPic = new(pageLayout.XurPics + xOffset - shrinkage, pageLayout.YurPics - shrinkage);
          envPic = EnvelopeBuilderEx.CreateEnvelope(llPic, urPic);
					var phoneGraphic = ElementFactory.Instance.CreatePictureGraphicElement(
            layout, envPic, img, "PhonePictureFrame");
					xOffset += 1.25;
				}
      }
		}

    private static string GetImagepathForResourceImage (string resourceImageName)
    {
			var localImagePath = System.IO.Path.Combine(CoreModule.CurrentProject.DefaultGeodatabasePath, $@"{resourceImageName}.png");
			if (!System.IO.File.Exists(localImagePath))
			{
        var imgSrc = System.Windows.Application.Current.Resources[resourceImageName] as DrawingImage;
				using var fileStream = new System.IO.FileStream(localImagePath, System.IO.FileMode.Create);
				BitmapEncoder encoder = new PngBitmapEncoder();
				//encoder.Frames.Add(BitmapFrame.Create(image));
				encoder.Frames.Add(BitmapFrame.Create(ToBitmapSource(imgSrc)));
				encoder.Save(fileStream);
			}
			return localImagePath;
		}

		public static BitmapSource ToBitmapSource(DrawingImage source)
		{
			DrawingVisual drawingVisual = new();
			DrawingContext drawingContext = drawingVisual.RenderOpen();
			drawingContext.DrawImage(source, new System.Windows.Rect(new System.Windows.Point(0, 0), new System.Windows.Size(source.Width, source.Height)));
			drawingContext.Close();

			RenderTargetBitmap bmp = new((int)source.Width, (int)source.Height, 96, 96, PixelFormats.Pbgra32);
			bmp.Render(drawingVisual);
			return bmp;
		}

		private static void  AddTableToLayout(Layout layout, Map theMap, MapFrame mfElm, 
      string layerName, SetPage setPage, string[] fields)
    {
      var lyrs = theMap.FindLayers(layerName, true);
      if (lyrs.Count > 0)
      {
        Layer lyr = lyrs[0];
        Coordinate2D llTab1 = new(setPage.TableXll, setPage.TableYll);
        Coordinate2D urTab1 = new(setPage.TableXur, setPage.TableYur);
        var tableFrameInfo = new TableFrameInfo()
        {
          MapFrameName = mfElm.Name,
          MapMemberUri = lyr.URI,
          FieldNames = fields
        };
        var theTable = ElementFactory.Instance.CreateMapSurroundElement(layout, EnvelopeBuilderEx.CreateEnvelope(llTab1, urTab1), tableFrameInfo) as TableFrame;
        var def = theTable.GetDefinition() as CIMTableFrame;
        def.FittingStrategy = TableFrameFittingStrategy.AdjustColumnsAndSize;
        def.FillingStrategy = TableFrameFillingStrategy.ShowAllRows;
        theTable.SetDefinition(def);
      }
    }
  }
}
