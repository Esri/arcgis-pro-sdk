﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using POITracking.AnalysisUI;
using POITracking.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;


namespace POITracking
{
  internal class Module1 : Module
  {
    private static Module1 _this = null;

    internal static string KG_URL =
@"--- Phone Calls for Dev Summit/KnowledgeGraphServer ---";
    
    internal static string Default_Project = 
      @"..\Developer Summit 2024\Developer Summit 2024.aprx";

    public static readonly string LinkChartName = "Common Phone Calls";
    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("POITracking_Module");

    //public string ReportPeriod { get; set; } = "2021-01-31 all day";

    #region Query Results

    public string CallLocationFC = "CallLocations";
    public string CallLocationFLayer = "Call Locations";
    public string IncidentLocationFC = "IncidentLocations";
    public string IncidentLocationFLayer = "Incident Locations";

    internal bool KeepProTabs = false;//for debug
    internal bool ForceOverwriteOfImages = true;

    private static readonly object _lock = new object();
    internal ObservableCollection<SuspectInfo> _all_suspects =
        new ObservableCollection<SuspectInfo>();
    internal ObservableCollection<SuspectInfo> _suspects_called =
        new ObservableCollection<SuspectInfo>();
    internal ObservableCollection<CallLocation> _calls_made_w_location =
        new ObservableCollection<CallLocation>();
    internal ObservableCollection<IncidentLocation> _incidents =
        new ObservableCollection<IncidentLocation>();

    public SuspectInfo PersonOfInterest { get; set; }

		public SuspectInfo SuspectCalled { get; set; }

		public static object CollectionLock => _lock;

    public ObservableCollection<SuspectInfo> Suspects => _all_suspects;

    public ObservableCollection<SuspectInfo> SuspectsCalled => _suspects_called;

    public ObservableCollection<CallLocation> CallLocations => _calls_made_w_location;

    public ObservableCollection<IncidentLocation> Incidents => _incidents;

    #endregion

    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

  }
}