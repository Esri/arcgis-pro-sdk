﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using POITracking.Helpers;
using POITracking.Models;
using POITracking.UI;
using System;
using System.Collections.Generic;
using System.Linq;

namespace POITracking
{
  internal class RunAnalysisQueries
  {
    public static void RunQuery1_ForSuspectList(StartPageViewModel startPage)
    {
      var qry = @"MATCH (s:Suspects) RETURN s ORDER BY s.FULL_NAME";

      QueuedTask.Run(async () =>
      {
        var kg_connect = new KnowledgeGraphConnectionProperties(
                             new Uri(Module1.KG_URL));

        var suspects = new List<SuspectInfo>();

        using (var knowledgeGraph = new KnowledgeGraph(kg_connect))
        {
          var graphQuery1 = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };
          using (var kgRowCursor = knowledgeGraph.SubmitQuery(graphQuery1))
          {
            while (await kgRowCursor.WaitForRowsAsync())
            {
              while (kgRowCursor.MoveNext())
              {
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  var suspect = graphRow[0] as KnowledgeGraphEntityValue;
                  suspects.Add(new SuspectInfo(suspect));
                  #endregion
                }
              }
            }
          }
          lock (Module1.CollectionLock)
          {
            Module1.Current.Suspects.Clear();
            var ty_suspect = suspects.FirstOrDefault(s => s.FullName == "Ty Fitzpatrick");
            var rob_suspect = suspects.FirstOrDefault(s => s.FullName == "Robert Johnson");
            foreach (var suspect in suspects)
            {
              if (ty_suspect != null)
              {
                if (suspect.Id == ty_suspect.Id)
                  continue;
              }
              if (rob_suspect != null)
              {
                if (suspect.Id == rob_suspect.Id)
                  continue;
              }
              Module1.Current.Suspects.Add(suspect);
            }
            if (ty_suspect != null)
              Module1.Current.Suspects.Insert(1, ty_suspect);
            if (rob_suspect != null)
              Module1.Current.Suspects.Insert(1, rob_suspect);
          }
          startPage.PersonOfInterest = Module1.Current.Suspects[0];
        }
      });
    }

    public static void RunQuery2_CalledBySuspect(SuspectInfo poi)
    {
      var qry = @"WITH " + 
                @" datetime(""2024-01-01T01:00:00.00-07:00"") AS min," +
                @" datetime(""2024-12-31T01:00:00.00-07:00"") AS max " +
                @"MATCH (poi:PhoneNumber)-[:MADE_CALL|RECEIVED_CALL]-(phoneCall:PhoneCall)-" +
                @"[:MADE_CALL|RECEIVED_CALL]-(associate:PhoneNumber), (associates:Suspects) " +
                @" WHERE " +
                @" phoneCall.START_DATE > min AND " +
                @" phoneCall.END_DATE < max AND " +
                $@" poi.FULL_NAME = ""{poi.FullName}"" AND " +
                @" associate.FULL_NAME = associates.FULL_NAME " +
                @" RETURN distinct associate, count(associate.FULL_NAME) as NumberTimesCalled";

      QueuedTask.Run(async () =>
      {
        var suspects_called = new List<SuspectInfo>();

        using (var knowledgeGraph = InitKnowledgeGraph())
        {
          var graphQuery2 = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };

          using (var kgRowCursor = knowledgeGraph.SubmitQuery(graphQuery2))
          {
            while (await kgRowCursor.WaitForRowsAsync())
            {
              while (kgRowCursor.MoveNext())
              {
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  var associate = graphRow[0] as KnowledgeGraphEntityValue;
                  var number_of_calls = (long)graphRow[1];

                  var suspect_info = new SuspectInfo(associate, number_of_calls);
                  suspects_called.Add(suspect_info);

                  #endregion
                }
              }
            }
          }
          lock (Module1.CollectionLock)
          {
            Module1.Current.SuspectsCalled.Clear();
            foreach (var suspect in suspects_called)
              Module1.Current.SuspectsCalled.Add(suspect);
          }
        }

      });

    }

    public static void RunQuery3_CommonCallsForLinkChart(SuspectInfo poi, SuspectInfo poi_called)
    {
      var qry = @"MATCH " +
                @"  (poi:PhoneNumber)-[r1:MADE_CALL|RECEIVED_CALL]->(c1:PhoneCall)<-" +
                @"[r2:MADE_CALL|RECEIVED_CALL]-(poi2:PhoneNumber)-[r3:MADE_CALL|RECEIVED_CALL]->(c2:PhoneCall)<-" +
                @"[r4:MADE_CALL|RECEIVED_CALL]-(poi_called:PhoneNumber) " +
                $@"WHERE poi.FULL_NAME = ""{poi.FullName}"" AND" +
                $@" poi_called.FULL_NAME = ""{poi_called.FullName}"" AND" +
                @"  poi.globalid <> poi2.globalid AND" +
                @"  poi2.globalid <> poi_called.globalid " +
                @"RETURN poi, r1, c1, r2, poi2, r3, c2, r4, poi_called";

      QueuedTask.Run(async () =>
      {
        var call_locations = new List<CallLocation>();

        using (var knowledgeGraph = InitKnowledgeGraph())
        {
          var graphQuery3 = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };

          var id_set = new Dictionary<string, List<long>>();

          using (var kgRowCursor = knowledgeGraph.SubmitQuery(graphQuery3))
          {
            while (await kgRowCursor.WaitForRowsAsync())
            {
              while (kgRowCursor.MoveNext())
              {
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row
                  //poi, r1, c1, r2, poi2, r3, c2, r4, poi_called

                  //var poi = graphRow[0] as KnowledgeGraphEntityValue;
                  //var r1 = graphRow[1] as KnowledgeGraphRelationshipValue;
                  //var c1 = graphRow[2] as KnowledgeGraphEntityValue;
                  //var r2 = graphRow[3] as KnowledgeGraphRelationshipValue;
                  //var poi2 = graphRow[4] as KnowledgeGraphEntityValue;
                  //var r3 = graphRow[5] as KnowledgeGraphRelationshipValue;
                  //var c2 = graphRow[6] as KnowledgeGraphEntityValue;
                  //var r4 = graphRow[7] as KnowledgeGraphRelationshipValue;
                  //var poi_called = graphRow[8] as KnowledgeGraphEntityValue;

                  /*
                  var cnt_val = (int)graphRow.GetCount();
                  for(int v = 0; v < cnt_val; v++)
                  {
                    var obj_val = graphRow[v] as KnowledgeGraphNamedObjectValue;
                    var type_name = obj_val.GetTypeName();
                    var oid = (long)obj_val.GetObjectID();
                    if (!id_set.ContainsKey(type_name))
                    {
                      id_set[type_name] = new List<long>();
                    }
                    if (!id_set[type_name].Contains(oid))
                      id_set[type_name].Add(oid);
                  }
                  */
                  #endregion
                }
              }
            }
          }

          /*
          Map linkChartMap = null;
          var mapPanes = FrameworkApplication.Panes.OfType<IMapPane>().ToList();
          foreach(var mapPane in mapPanes)
          {
            if (mapPane.MapView.IsLinkChartView && mapPane.Caption == Module1.LinkChartName)
            {
              linkChartMap = mapPane.MapView.Map;
              break;
            }
          }
          //try and get the first available...
          if (linkChartMap == null)
          {
            var mapPane = mapPanes.FirstOrDefault(mp => mp.MapView.IsLinkChartView);
            linkChartMap = mapPane?.MapView?.Map;
          }

          var idSet = KnowledgeGraphLayerIDSet.FromDictionary(knowledgeGraph, id_set);
          if (linkChartMap == null)
          {
            //create new
            var linkChart = MapFactory.Instance.CreateLinkChart(
              Module1.LinkChartName, knowledgeGraph, idSet, "");
            FrameworkApplication.Panes.CreateMapPaneAsync(linkChart);
          }
          else
          {
            //append
            linkChartMap.AppendToLinkChart(idSet);
          }

          */

          //LayerHelper.ResetLayer(Module1.Current.CallLocationFLayer);

          //lock (Module1.CollectionLock)
          //{
          //  Module1.Current.CallLocations.Clear();
          //  foreach (var call_location in call_locations)
          //  {
          //    if (Module1.Current.CallLocations.Any(
          //      cl => cl.CallID == call_location.CallID))
          //      continue;
          //    Module1.Current.CallLocations.Add(call_location);
          //  }
          //}
          //foreach (var call_location in Module1.Current.CallLocations)
          //  LayerHelper.AddLocationToMap(
          //      Module1.Current.CallLocationFLayer, call_location);
        }
      });
    }

    public static void RunQuery4_CallsWithLocation(SuspectInfo poi)
    {
      var qry = @"WITH " +
                @"  datetime(""2024-01-01T01:00:00.00-07:00"") AS min, " +
                @"  datetime(""2024-12-31T01:00:00.00-07:00"") AS max " +
                @"MATCH " +
                @"  (poi:PhoneNumber)-[:MADE_CALL|RECEIVED_CALL]-(phoneCall:PhoneCall)" +
                @"-[:MADE_CALL|RECEIVED_CALL]-(associate:PhoneNumber)-[:HasLocation]-(ploc:PhoneNumberLocation)," +
                @"(suspect:Suspects) " +
                @"WHERE phoneCall.START_DATE > min AND phoneCall.END_DATE < max " +
                $@" AND poi.FULL_NAME = ""{poi.FullName}"" AND " +
                @"  associate.FULL_NAME = suspect.FULL_NAME " +
                @"RETURN distinct associate as SuspectCalled, ploc as PhoneLocation, phoneCall as CallDetails";

      QueuedTask.Run(async () =>
      {
        var call_locations = new List<CallLocation>();

        using (var knowledgeGraph = InitKnowledgeGraph())
        {
          var graphQuery4 = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };
          
          using (var kgRowCursor = knowledgeGraph.SubmitQuery(graphQuery4))
          {
            while (await kgRowCursor.WaitForRowsAsync())
            {
              while (kgRowCursor.MoveNext())
              {
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  var associate = graphRow[0] as KnowledgeGraphEntityValue;
                  var phone_loc = graphRow[1] as KnowledgeGraphEntityValue;
                  var call_details = graphRow[2] as KnowledgeGraphEntityValue;

                  var call_location = new CallLocation(
                    associate, phone_loc, call_details);

                  call_locations.Add(call_location);

                  #endregion
                }
              }
            }
          }

          LayerHelper.ResetLayer(Module1.Current.CallLocationFLayer);

          lock (Module1.CollectionLock)
          {
            Module1.Current.CallLocations.Clear();
            foreach (var call_location in call_locations)
            {
              if (Module1.Current.CallLocations.Any(
                cl => cl.CallID == call_location.CallID))
                continue;
              Module1.Current.CallLocations.Add(call_location);
            }
          }
          foreach(var call_location in Module1.Current.CallLocations)
            LayerHelper.AddLocationToMap(
                Module1.Current.CallLocationFLayer, call_location);
        }
      });
    }

    public static void RunQuery5_CallsWithIncidents(SuspectInfo poi)
    {
      var qry = @"WITH " +
                @"  datetime(""2024-01-01T01:00:00.00-07:00"") AS min, " +
                @"  datetime(""2024-12-31T01:00:00.00-07:00"") AS max " +
                @"MATCH " +
                @"  (poi:PhoneNumber)-[:MADE_CALL|RECEIVED_CALL]-(phoneCall:PhoneCall)" +
                @"-[:MADE_CALL|RECEIVED_CALL]-(associate:PhoneNumber)-[:HasLocation]-(ploc:PhoneNumberLocation)," +
                @"(suspect:Suspects), (incident:Incidents) " +
                @"WHERE phoneCall.START_DATE > min AND phoneCall.END_DATE < max " +
                @" AND incident.TYPE = 'Arson' " +
                $@" AND poi.FULL_NAME = ""{poi.FullName}"" AND " +
                @"  associate.FULL_NAME = suspect.FULL_NAME AND " +
                @"  esri.graph.ST_GeoDistance(ploc.shape, incident.shape) < 100" +
                @"RETURN associate as SuspectCalled, incident ORDER BY incident.objectid";

      QueuedTask.Run(async () =>
      {
        var inc_locations = new List<IncidentLocation>();

        using (var knowledgeGraph = InitKnowledgeGraph())
        {
          var graphQuery5 = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };

          using (var kgRowCursor = knowledgeGraph.SubmitQuery(graphQuery5))
          {
            while (await kgRowCursor.WaitForRowsAsync())
            {
              while (kgRowCursor.MoveNext())
              {
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  var associate = graphRow[0] as KnowledgeGraphEntityValue;
                  var incident = graphRow[1] as KnowledgeGraphEntityValue;

                  var inc_location = new IncidentLocation(associate, incident);

                  inc_locations.Add(inc_location);

                  #endregion
                }
              }
            }
          }

          LayerHelper.ResetLayer(Module1.Current.IncidentLocationFLayer);

          lock (Module1.CollectionLock)
          {
            Module1.Current.Incidents.Clear();

            foreach (var inc_location in inc_locations)
            {
              if (Module1.Current.Incidents.Any(
                inc => inc.IncidentID == inc_location.IncidentID))
                continue;
              Module1.Current.Incidents.Add(inc_location);
            }
          }
          foreach (var inc_location in Module1.Current.Incidents)
            LayerHelper.AddIncidentToMap(
                Module1.Current.IncidentLocationFLayer, inc_location);
        }
      });
    }

    internal static KnowledgeGraph InitKnowledgeGraph()
    {
      if (MapView.Active?.Map == null)
      {
        System.Diagnostics.Debug.WriteLine("\r\n**MapView is null**");
      }

      var kg_layer = MapView.Active?.Map?.GetLayersAsFlattenedList()?
                      .OfType<ArcGIS.Desktop.Mapping.KnowledgeGraphLayer>()?
                      .FirstOrDefault();

      KnowledgeGraph kg = null;
      var fl = kg_layer?.GetLayersAsFlattenedList()?
        .OfType<FeatureLayer>()?.FirstOrDefault();
      if (fl != null)
      {
        using (var fc = fl.GetFeatureClass())
          kg = fc.GetDatastore() as KnowledgeGraph;
      }
      else
      {
        var stbl = kg_layer?.GetStandaloneTablesAsFlattenedList().FirstOrDefault();
        if (stbl != null)
        {
          using (var table = stbl.GetTable())
            kg = table.GetDatastore() as KnowledgeGraph;
        }
      }
      //provision layers
      //var fls = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
      //if (Module1.Current.PersonLayer == null)
      //  Module1.Current.PersonLayer = fls.First(l => l.Name == "Persons");
      //if (Module1.Current.StateLayer == null)
      //  Module1.Current.StateLayer = fls.First(l => l.Name == "States");
      //if (Module1.Current.LinkLayer == null)
      //  Module1.Current.LinkLayer = MapView.Active.Map.GetLayersAsFlattenedList()
      //                              .OfType<GraphicsLayer>().First();
      if (kg == null)
      {
        var kg_connect = new KnowledgeGraphConnectionProperties(
                             new Uri(Module1.KG_URL));
        kg = new KnowledgeGraph(kg_connect);
      }
      return kg;
    }
  }
}
