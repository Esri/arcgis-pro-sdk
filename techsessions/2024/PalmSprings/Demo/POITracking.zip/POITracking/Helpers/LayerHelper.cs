﻿using ArcGIS.Core.Data.DDL;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using POITracking.Models;

namespace POITracking.Helpers
{
  internal class LayerHelper
  {

    public static bool CreateCallLocationFeatureClass(Geodatabase geoDb, string fcName)
    {
      var hasZ = false;
      var hasM = false;
      // Create a ShapeDescription object
      var shapeDescription = new ShapeDescription(
        GeometryType.Point, MapView.Active.Map.SpatialReference)
      {
        HasM = hasM,
        HasZ = hasZ
      };
      var objectIDFieldDescription = new ArcGIS.Core.Data.DDL.FieldDescription(
        "ObjectID", FieldType.OID);
      var fieldDescription1 = new ArcGIS.Core.Data.DDL.FieldDescription(
              "PhoneOwner", FieldType.String);
      var fieldDescription2 = new ArcGIS.Core.Data.DDL.FieldDescription(
        "PhoneNumber", FieldType.String);
      var fieldDescription3 = new ArcGIS.Core.Data.DDL.FieldDescription(
        "LocationID", FieldType.BigInteger);
      var fieldDescription4 = new ArcGIS.Core.Data.DDL.FieldDescription(
        "DateAndTime", FieldType.String);
      var fieldDescription5 = new ArcGIS.Core.Data.DDL.FieldDescription(
       "PhoneNumber_Global_ID", FieldType.String);

      // Assemble a list of all of our field descriptions
      var fieldDescriptions = new List<ArcGIS.Core.Data.DDL.FieldDescription>() {
                    objectIDFieldDescription,
                    fieldDescription1,
                    fieldDescription2,
                    fieldDescription3,
                    fieldDescription4,
                    fieldDescription5
                };
      // Create a FeatureClassDescription object to describe the feature class
      // that we want to create
      var fcDescription =
        new FeatureClassDescription(fcName, fieldDescriptions, shapeDescription);

      // Create a SchemaBuilder object
      SchemaBuilder schemaBuilder = new(geoDb);

      // Add the creation of the new feature class to our list of DDL tasks
      schemaBuilder.Create(fcDescription);

      // Execute the DDL
      return schemaBuilder.Build();
    }

    public static bool CreateIncidentLocationFeatureClass(Geodatabase geoDb, string fcName)
    {
      var hasZ = false;
      var hasM = false;
      // Create a ShapeDescription object
      var shapeDescription = new ShapeDescription(
        GeometryType.Point, MapView.Active.Map.SpatialReference)
      {
        HasM = hasM,
        HasZ = hasZ
      };
      var objectIDFieldDescription = new ArcGIS.Core.Data.DDL.FieldDescription(
        "ObjectID", FieldType.OID);
      var fieldDescription1 = new ArcGIS.Core.Data.DDL.FieldDescription(
              "PhoneOwner", FieldType.String);
      var fieldDescription2 = new ArcGIS.Core.Data.DDL.FieldDescription(
        "PhoneNumber", FieldType.String);
      var fieldDescription3 = new ArcGIS.Core.Data.DDL.FieldDescription(
        "IncidentID", FieldType.BigInteger);
      var fieldDescription4 = new ArcGIS.Core.Data.DDL.FieldDescription(
        "Incident", FieldType.String);
      var fieldDescription5 = new ArcGIS.Core.Data.DDL.FieldDescription(
        "DateAndTime", FieldType.String);
      var fieldDescription6 = new ArcGIS.Core.Data.DDL.FieldDescription(
       "PhoneNumber_Global_ID", FieldType.String);

      // Assemble a list of all of our field descriptions
      var fieldDescriptions = new List<ArcGIS.Core.Data.DDL.FieldDescription>() {
                    objectIDFieldDescription,
                    fieldDescription1,
                    fieldDescription2,
                    fieldDescription3,
                    fieldDescription4,
                    fieldDescription5,
                    fieldDescription6
                };
      // Create a FeatureClassDescription object to describe the feature class
      // that we want to create
      var fcDescription =
        new FeatureClassDescription(fcName, fieldDescriptions, shapeDescription);

      // Create a SchemaBuilder object
      SchemaBuilder schemaBuilder = new(geoDb);

      // Add the creation of the new feature class to our list of DDL tasks
      schemaBuilder.Create(fcDescription);

      // Execute the DDL
      return schemaBuilder.Build();
    }

    internal static void AddLocationToMap(
      string CallLocationFeatLayerName, CallLocation location)
    {

      var fl = GetFeatureLayer(CallLocationFeatLayerName);
      if (fl == null)
        return;

      // create an edit operation
      var editOperation = new EditOperation
      {
        Name = string.Format("Create point in '{0}'", fl.Name),
        CancelMessage = "Operation canceled",
        ErrorMessage = "Error creating point",
        SelectNewFeatures = false
      };

      Dictionary<string, object> attributes = new()
        {
          { "PhoneOwner", location.AssociateName },
          { "PhoneNumber", location.PhoneNumber },
          { "LocationID", location.CallID },
          { "DateAndTime", location.CallDateAndTime },
          { "PhoneNumber_Global_ID", location.PhoneNumber_Global_ID }
        };
      var loc_pt = location.Location as MapPoint;

      editOperation.Create(fl, loc_pt, attributes);
      //execute the operation
      editOperation.Execute();
    }

    internal static void AddIncidentToMap(
      string IncidentFeatLayerName, IncidentLocation incident)
    {

      var fl = GetFeatureLayer(IncidentFeatLayerName);
      if (fl == null)
        return;

      // create an edit operation
      var editOperation = new EditOperation
      {
        Name = string.Format("Create point in '{0}'", fl.Name),
        CancelMessage = "Operation canceled",
        ErrorMessage = "Error creating point",
        SelectNewFeatures = false
      };

      Dictionary<string, object> attributes = new()
        {
          { "PhoneOwner", incident.PhoneOwner },
          { "PhoneNumber", incident.PhoneNumber },
          { "IncidentID", incident.IncidentID },
          { "Incident", incident.Incident },
          { "DateAndTime", incident.DateAndTime },
          { "PhoneNumber_Global_ID", incident.PhoneNumber_Global_ID }
        };
      var loc_pt = incident.Location as MapPoint;

      editOperation.Create(fl, loc_pt, attributes);
      //execute the operation
      editOperation.Execute();
    }

    internal static Task ResetLayersAsync()
    {
      return QueuedTask.Run(() =>
      {
        ResetLayers();
      });
    }

    internal static void ResetLayers()
    {
      var analysis_lyrs = new List<string>()
        {
          Module1.Current.CallLocationFLayer, Module1.Current.IncidentLocationFLayer
        };
      foreach (var featLayer in analysis_lyrs)
        ResetLayer(featLayer);
    }

    internal static void ResetLayer(string featLayer)
    {
      var fl = GetFeatureLayer(featLayer);
      if (fl == null)
        return;

      var sset = fl.Select();
      if (sset.GetCount() == 0)
        return;

      var ed_op = new EditOperation()
      {
        Name = "Delete previous results"
      };
      ed_op.Delete(fl, sset.GetObjectIDs());
      ed_op.Execute();
    }

    internal static FeatureLayer GetFeatureLayer(string featLayer)
    {
      var featLayers =
          MapView.Active.Map.GetLayersAsFlattenedList()
            .OfType<FeatureLayer>()?.ToList() ?? new List<FeatureLayer>();

      return featLayers.FirstOrDefault(l => l.Name == featLayer);
    }
  }
}
