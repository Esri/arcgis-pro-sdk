﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using POITracking.AnalysisUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POITracking.Helpers
{
  internal class ResetDemo : Button
  {
    protected override async void OnClick()
    {
      try
      {
        var vm_analysis =
          FrameworkApplication.DockPaneManager.Find("POITracking_AnalysisReport")
          as AnalysisReportViewModel;
        vm_analysis.Reset();

				//Remove all layouts
				var layouts = Project.Current.GetItems<LayoutProjectItem>();

        //Remove the layout fro the project
        foreach (var layout in layouts)
        {
          await QueuedTask.Run(() => Project.Current.RemoveItem(layout));
        }
			}
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
