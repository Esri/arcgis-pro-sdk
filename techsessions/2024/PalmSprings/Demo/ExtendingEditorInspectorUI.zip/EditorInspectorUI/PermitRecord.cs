﻿using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace EditorInspectorUI
{
  internal class PermitRecord : PropertyChangedBase
  {
    private long _oid;
    private string _jobNo;
    private object _address;
    private object _jobType;
    private string _name;
    public PermitRecord(string Name)
    {
      _name = Name;
    }
    public PermitRecord(long oid, string jobNo, string address, string jobType)
    {
      _oid = oid;
      _jobNo = jobNo;
      _address = address;
      _jobType = jobType;
    }

    public long OID
    {
      get => _oid;
      set => SetProperty(ref _oid, value, () => OID);
    }
    public string JobNo
    {
      get => _jobNo;
      set => SetProperty(ref _jobNo, value, () => JobNo);
    }
    public string Name
    {
      get
      {
        _name = $"{_jobType}, {_address}";
        return _name;
      }
      set
      {
               
        SetProperty(ref _name, value, () => Name);
      }
    }

  }
}
