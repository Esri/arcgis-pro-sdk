﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Data.DDL;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Index = ArcGIS.Core.Data.Index;

namespace DDLDemo
{
  public static class DDLOperations
  {
    private static string _mobileGeodatabaseName = "DDLSampleDemo.geodatabase";
    private static string _gdbLocation = $"C:\\DevSummit2024\\DDLDemo\\SampleDataset\\{_mobileGeodatabaseName}";
    private static Geodatabase _geodatabase;
    private static SchemaBuilder _schemaBuilder;

    public static void CreateMobileGeodatabase()
    {
      QueuedTask.Run(() =>
      {
        _geodatabase = SchemaBuilder.CreateGeodatabase(new MobileGeodatabaseConnectionPath(new Uri(_gdbLocation)));
        _schemaBuilder = new SchemaBuilder(_geodatabase);
      });
    }

    public static void DeleteMobileGeodatabase()
    {
      if (File.Exists(_gdbLocation))
      {
        SchemaBuilder.DeleteGeodatabase(new MobileGeodatabaseConnectionPath(new Uri(_gdbLocation)));
      }
    }

    public static void CreateFeatureClass(string featureClassName = "Parcels")
    {
      QueuedTask.Run(() =>
      {
        #region Parcels' attribute fields
        FieldDescription parcelId = FieldDescription.CreateIntegerField("ParcelId");
        FieldDescription address = FieldDescription.CreateStringField("Address", 150);
        FieldDescription zoning = FieldDescription.CreateIntegerField("Zoning");
        #endregion

        #region Shape and Spatial Reference
        ShapeDescription shapeDescription = new ShapeDescription(GeometryType.Polygon, SpatialReferences.WGS84);
        #endregion

        FeatureClassDescription pracelsFeatureClassDescription = new FeatureClassDescription(featureClassName,
          new List<FieldDescription> { parcelId, address, zoning },
          shapeDescription);

        _schemaBuilder.Create(pracelsFeatureClassDescription);
        _schemaBuilder.Build();
      });
    }
    public static void CreateTable(string tableName = "Buildings")
    {
      QueuedTask.Run(() =>
      {
        #region Buildings' attribute fields
        FieldDescription name = FieldDescription.CreateStringField("Name", 100);
        FieldDescription owner = FieldDescription.CreateStringField("Owner", 150);
        FieldDescription parcelNumber = FieldDescription.CreateIntegerField("ParcelNumber");
        #endregion

        // Buildings table's description
        TableDescription buildingsTableDescription = new TableDescription(tableName,
          new List<FieldDescription> { name, owner, parcelNumber });

        _schemaBuilder.Create(buildingsTableDescription);
        _schemaBuilder.Build();
      });
    }

    public static void AddSubtypeSupport(string featureClassName = "Parcels")
    {
      QueuedTask.Run(() =>
      {
        using (FeatureClassDefinition parcelsFeatureClassDefinition = _geodatabase.GetDefinition<FeatureClassDefinition>(featureClassName))
        {
          // Get description object from existing data set
          FeatureClassDescription parcelFeatureClassDescription = new FeatureClassDescription(parcelsFeatureClassDefinition);
          
          // Field to hold subtype values
          Field subtypeField = parcelsFeatureClassDefinition.GetFields().First(f => f.Name.Contains("Zoning"));

          // Enable subtype support 
          // 3 parcel subtypes  - Residential, Commercial, and Mixed
          SubtypeFieldDescription subtypeFieldDescription = new SubtypeFieldDescription(subtypeField.Name,
            new Dictionary<int, string> { { 1, "Residential" }, { 2, "Commercial" }, { 3, "Mixed" } });

          parcelFeatureClassDescription.SubtypeFieldDescription = subtypeFieldDescription;

          _schemaBuilder.Modify(parcelFeatureClassDescription);
          _schemaBuilder.Build();
        }
      });
    }

    public static void CreateRelationship(string featureClassName = "Parcels", string tableName = "Buildings")
    {
      QueuedTask.Run(() =>
      {
        using (FeatureClassDefinition parcelsFeatureClassDefinition = _geodatabase.GetDefinition<FeatureClassDefinition>(featureClassName))
        using (TableDefinition buildingTableDefinition = _geodatabase.GetDefinition<TableDefinition>(tableName))
        {
          // Relationship desription 
          RelationshipClassDescription relationshipClassDescription =
            new RelationshipClassDescription("Parcel2Building_SimpleRelationship",
            new TableDescription(parcelsFeatureClassDefinition),
            new TableDescription(buildingTableDefinition),
            RelationshipCardinality.OneToMany,
            "ParcelId", "ParcelNumber"); // 'ParcelId' from 'Parcels' feature class and 'ParcelNumber' from 'Buildings' table

          // Enable relationship rule
          //  Parcel subtype code ( 1 = Residential)
          relationshipClassDescription.RelationshipRuleDescriptions.Add(new RelationshipRuleDescription(1, null)); 

          _schemaBuilder.Create(relationshipClassDescription);


          _schemaBuilder.Build();
        }
      });
    }

    public static void RemoveRelationship(string relationshipName = "Parcel2Building_SimpleRelationship")
    {
      QueuedTask.Run(() =>
      {
        using (RelationshipClassDefinition relationshipClassDefinition = _geodatabase.GetDefinition<RelationshipClassDefinition>(relationshipName))
        {
          RelationshipClassDescription relationshipToDeleteDescription = new RelationshipClassDescription(relationshipClassDefinition);

          _schemaBuilder.Delete(relationshipToDeleteDescription);
          
          _schemaBuilder.Build();
        }
      });

    }

    public static void CreateAttributedRelationship(string featureClassName = "Parcels", string tableName = "Buildings")
    {
      QueuedTask.Run(() =>
      {
        using (FeatureClassDefinition parcelsFeatureClassDefinition = _geodatabase.GetDefinition<FeatureClassDefinition>(featureClassName))
        using (TableDefinition buildingTableDefinition = _geodatabase.GetDefinition<TableDefinition>(tableName))
        {
          // Attributed relationship description
          AttributedRelationshipClassDescription attributedRelationshipClassDescription = new AttributedRelationshipClassDescription("Parcel2Building_Composite_Attributed",
            new TableDescription(parcelsFeatureClassDefinition),
            new TableDescription(buildingTableDefinition),
            RelationshipCardinality.OneToMany,
            "ParcelId", "ParcelIdFK", // Origin (Parcels) Key and ForeignKey(ParceIdFK) in the intermediate table
            "ParcelNumber", "ParcelNumberFK") // Destination (Buildings) Key and Foreign Key(ParcelNumberFK) in the intermediate table
            {
              RelationshipType = RelationshipType.Composite // Life time of a 'Building' feature depends on life time of a 'Parcel' feature
            };

          // Additional field in the intermediate table - 'OwershipPercentage'
          attributedRelationshipClassDescription.FieldDescriptions.Add(FieldDescription.CreateIntegerField("OwnershipPercentage"));

          // Enqueue DDL operations
          _schemaBuilder.Create(attributedRelationshipClassDescription);

          // Execute DDL operations
          _schemaBuilder.Build();
        }

        #region Create an attributed relationship between two rows

        using (FeatureClass parcelsFeatureClass = _geodatabase.OpenDataset<FeatureClass>(featureClassName))
        using (Table buildingsTable = _geodatabase.OpenDataset<Table>(tableName))
        using (AttributedRelationshipClass attributedRelationshipClass = _geodatabase.OpenDataset<AttributedRelationshipClass>("Parcel2Building_Composite_Attributed"))
        {
          EditOperation editOperation = new EditOperation();
          editOperation.Callback(context =>
          {
            using (RowBuffer parcelRowBuffer = parcelsFeatureClass.CreateRowBuffer())
            using (RowBuffer buildingRowBuffer = buildingsTable.CreateRowBuffer())
            using (RowBuffer relationshipRowBuffer = attributedRelationshipClass.CreateRowBuffer())
            {
              // Parcel information
              parcelRowBuffer["ParcelId"] = "300";
              parcelRowBuffer["Address"] = "300 Main St";
              parcelRowBuffer["Zoning"] = 3;

              // Parcel's shape
              MapPoint pt1 = MapPointBuilderEx.CreateMapPoint(117.1686255, 34.1014878, SpatialReferences.WGS84);
              MapPoint pt2 = MapPointBuilderEx.CreateMapPoint(117.1595483, 34.1025634, SpatialReferences.WGS84);
              MapPoint pt3 = MapPointBuilderEx.CreateMapPoint(117.1604748, 34.1074350, SpatialReferences.WGS84);
              MapPoint pt4 = MapPointBuilderEx.CreateMapPoint(117.1608841, 34.10522323, SpatialReferences.WGS84);

              List<MapPoint> listParcel = new List<MapPoint>() { pt1, pt2, pt3, pt4 };
              PolygonBuilderEx polygonBuilderParcel = new PolygonBuilderEx(listParcel, AttributeFlags.None);
              Polygon polygonParcel = polygonBuilderParcel.ToGeometry();

              parcelRowBuffer[parcelsFeatureClass.GetDefinition().GetShapeField()] = polygonParcel;
              
              
              // Building information
              buildingRowBuffer["Name"] = " Building: C";
              buildingRowBuffer["Owner"] = "Joe & Jane Doe";
              buildingRowBuffer["ParcelNumber"] = "300";

              // Ownership percentage - 60%  user defined attribute in the intermediate table             
              relationshipRowBuffer["OwnershipPercentage"] = 60; 

              // Create rows
              using (Row parcelRow = parcelsFeatureClass.CreateRow(parcelRowBuffer))
              using (Row buildingRow = buildingsTable.CreateRow(buildingRowBuffer))
              {
                // Create an attributed relationship
                attributedRelationshipClass.CreateRelationship(parcelRow, buildingRow, relationshipRowBuffer);

                //To Indicate that the Map has to draw this feature/row and/or the attribute table has to be updated
                context.Invalidate(parcelRow);
                context.Invalidate(buildingRow);
                context.Invalidate(attributedRelationshipClass);
              }
            }
          }, parcelsFeatureClass, buildingsTable);

          bool creationResult = editOperation.Execute();
        }
        #endregion
      });
    }

    public static void InsertDataRows(string featureClassName = "Parcels", string tableName = "Buildings")
    {
      QueuedTask.Run(() =>
      {
        using (FeatureClass parcelsFeatureClass = _geodatabase.OpenDataset<FeatureClass>(featureClassName))
        using (Table buildingTable = _geodatabase.OpenDataset<Table>(tableName))
        {

          #region Creating parcel features

          EditOperation createParcels = new EditOperation();

          // Parcel A
          Dictionary<string, object> parcelAttributes = new Dictionary<string, object>();
          parcelAttributes.Add("ParcelId", 100);
          parcelAttributes.Add("Address", "100 Main St");
          parcelAttributes.Add("Zoning", 1);

          // Parcel's shape
          MapPoint pt1 = MapPointBuilderEx.CreateMapPoint(117.1686255, 34.1014878, SpatialReferences.WGS84);
          MapPoint pt2 = MapPointBuilderEx.CreateMapPoint(117.1595483, 34.1025634, SpatialReferences.WGS84);
          MapPoint pt3 = MapPointBuilderEx.CreateMapPoint(117.1586432, 34.0943651, SpatialReferences.WGS84);
          MapPoint pt4 = MapPointBuilderEx.CreateMapPoint(117.1684681, 34.0932239, SpatialReferences.WGS84);

          List<MapPoint> listParcelA = new List<MapPoint>() { pt1, pt2, pt3, pt4 };
          PolygonBuilderEx polygonBuilderParcelA = new PolygonBuilderEx(listParcelA, AttributeFlags.None);
          Polygon polygonParcelA = polygonBuilderParcelA.ToGeometry();

          parcelAttributes.Add(parcelsFeatureClass.GetDefinition().GetShapeField(), polygonParcelA);

          // Create a parcel feature
          RowToken parcelTokenA = createParcels.Create(parcelsFeatureClass, parcelAttributes);
          parcelAttributes.Clear();

          // Parcel B
          parcelAttributes.Add("ParcelId", 200);
          parcelAttributes.Add("Address", "200 Main St");
          parcelAttributes.Add("Zoning", 2);

          // Parcel's shape
          MapPoint pt5 = MapPointBuilderEx.CreateMapPoint(117.1595483, 34.1025634, SpatialReferences.WGS84);
          MapPoint pt6 = MapPointBuilderEx.CreateMapPoint(117.1586432, 34.0943651, SpatialReferences.WGS84);
          MapPoint pt7 = MapPointBuilderEx.CreateMapPoint(117.1504569, 34.0951543, SpatialReferences.WGS84);
          MapPoint pt8 = MapPointBuilderEx.CreateMapPoint(117.1521862, 34.1031284, SpatialReferences.WGS84);

          List<MapPoint> listParcelB = new List<MapPoint>() { pt5, pt6, pt7, pt8 };
          PolygonBuilderEx polygonBuilderParcelB = new PolygonBuilderEx(listParcelB, AttributeFlags.None);
          Polygon polygonParcelB = polygonBuilderParcelB.ToGeometry();

          parcelAttributes.Add(parcelsFeatureClass.GetDefinition().GetShapeField(), polygonParcelB);

          // Create a parcel feature
          RowToken parcelTokenB = createParcels.Create(parcelsFeatureClass, parcelAttributes);

          if (!createParcels.IsEmpty)
          {
            createParcels.Execute();
          }
          #endregion

          #region Creating building rows
          EditOperation createBuildings = new EditOperation();

          // Bulding A
          Dictionary<string, object> tableAttributes = new Dictionary<string, object>();
          tableAttributes.Add("Name", "Building: A");
          tableAttributes.Add("Owner", "John Doe");
          tableAttributes.Add("ParcelNumber", 100);

          // Create a table  row
          RowToken rowTokenA = createBuildings.Create(buildingTable, tableAttributes);
          tableAttributes.Clear();

          // Building B
          tableAttributes.Add("Name", "Building: B");
          tableAttributes.Add("Owner", "Jane Doe");
          tableAttributes.Add("ParcelNumber", 200);

          // Create a table row
          RowToken rowtokenB = createBuildings.Create(buildingTable, tableAttributes);

          if (!createBuildings.IsEmpty)
          {
            createBuildings.Execute();
          }
          #endregion

          if (Project.Current.HasEdits)
          {
            Project.Current.SaveEditsAsync();
          }
        }
      });
    }

    public static void CreateAttributeIndex(string tableName = "Buildings")
    {
      QueuedTask.Run(() =>
      {
        using (TableDefinition buildingTableDefinition = _geodatabase.GetDefinition<TableDefinition>(tableName))
        {
          AttributeIndexDescription attributeIndexDescription = new AttributeIndexDescription("Demo_IDX",
            new TableDescription(buildingTableDefinition),
            new List<string> { "Name", "Owner" });

          _schemaBuilder.Create(attributeIndexDescription);

          _schemaBuilder.Build();
        }
      });
    }

    public static void RemoveAttributeIndex(string tableName = "Buildings", string indexName = "Demo_IDX")
    {
      QueuedTask.Run(() =>
      {
        using (TableDefinition buildingTableDefinition = _geodatabase.GetDefinition<TableDefinition>(tableName))
        {
          Index indexToBeRemoved = buildingTableDefinition.GetIndexes().First(f => f.GetName().Equals(indexName));
          if (indexToBeRemoved != null)
          {
            AttributeIndexDescription attributeIndexDescriptionToDelete = new AttributeIndexDescription(indexToBeRemoved, new TableDescription(buildingTableDefinition));

            _schemaBuilder.Delete(attributeIndexDescriptionToDelete);

            _schemaBuilder.Build();
          }
        }
      });

    }

    public static void CreateSpatialIndex(string featureClassName = "Parcels")
    {
      QueuedTask.Run(() =>
      {
        using (FeatureClassDefinition parcelsFeatureClassDefinition = _geodatabase.GetDefinition<FeatureClassDefinition>(featureClassName))
        {
          SpatialIndexDescription spatialIndexDescription = new SpatialIndexDescription(new FeatureClassDescription(parcelsFeatureClassDefinition));

          _schemaBuilder.Create(spatialIndexDescription); // Create or recalculate if already exists

          _schemaBuilder.Build();
        }
      });
    }

    public static void RemoveSpatialIndex(string featureClassName = "Parcels")
    {
      QueuedTask.Run(() =>
      {
        using (FeatureClassDefinition parcelsFeatureClassDefinition = _geodatabase.GetDefinition<FeatureClassDefinition>(featureClassName))
        {
          SpatialIndexDescription spatialIndexDescription = new SpatialIndexDescription(new FeatureClassDescription(parcelsFeatureClassDefinition));

          _schemaBuilder.Delete(spatialIndexDescription);

          _schemaBuilder.Build();
        }
      });
    }

  }
}
