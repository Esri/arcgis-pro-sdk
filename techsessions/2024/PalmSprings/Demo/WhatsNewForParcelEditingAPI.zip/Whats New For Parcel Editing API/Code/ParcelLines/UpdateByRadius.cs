﻿/* Copyright 2024 Esri
 *
 * Licensed under the Apache License Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Core.UnitFormats;

namespace ParcelLines
{
  internal class UpdateByRadius : Button
  {
    protected async override void OnClick()
    {

      await QueuedTask.Run(() =>
      {
        try
        {
          var myParcelFabricLayer =
              MapView.Active?.Map?.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
          //if there is no fabric in the map then bail
          if (myParcelFabricLayer == null)
          {
            MessageBox.Show("There is no fabric layer in the map.", "Update By Radius");
            return;
          }

          var map = MapView.Active?.Map;
          var mapSR = map?.SpatialReference;
          bool mapInGCS = false;

          if (mapSR == null)
            return;

          double mapMetersPerUnit = 1.0;
          if (mapSR.IsProjected)
            mapMetersPerUnit = mapSR.Unit.ConversionFactor;
          else
            mapInGCS = true;

          var backstageDistanceUnit =
                DisplayUnitFormats.Instance.GetDefaultProjectUnitFormat(UnitFormatType.Distance);
          double metersPerBackstageUnit = backstageDistanceUnit.MeasurementUnit.ConversionFactor;

          string unitAbbr = backstageDistanceUnit.Abbreviation;

          //collect ground to grid correction values
          var mapView = MapView.Active;

          var cimDefinition = map?.GetDefinition();
          if (cimDefinition == null)
            return;
          var cimG2G = cimDefinition.GroundToGridCorrection;

          double scaleFactor = cimG2G.GetConstantScaleFactor();
          double directionOffsetCorrection = cimG2G.GetDirectionOffset();

          if (!Module1.GetParcelLineFeatureLayersSelection(MapView.Active,
            out Dictionary<FeatureLayer, List<long>> parcelLineLayerIds))
            return;

          //...confirm we're not editing default version geodatabase.
          if (Module1.IsDefaultVersionOnFeatureService(parcelLineLayerIds.Keys.FirstOrDefault()))
          {
            MessageBox.Show("Editing on the default version is not available.","Non editable");
            return;
          }

          //...check for a valid license.
          if (!Module1.HasValidLicenseForParcelLayer())
          {
            MessageBox.Show("Insufficient license level.", "License");
            return;
          }

          string sRadius = Microsoft.VisualBasic.Interaction.InputBox("Radius (" + unitAbbr + ") :", "Update By Radius", "50");
          if (!Double.TryParse(sRadius, out double circArcRadius))
            return;

          //convert radius to map unit for the geometry edit
          circArcRadius = circArcRadius * metersPerBackstageUnit / mapMetersPerUnit;


          ArcOrientation arcOrientation = circArcRadius < 0.0 ? ArcOrientation.ArcCounterClockwise : ArcOrientation.ArcClockwise;
          bool bIsConvertingToLine = circArcRadius == 0.0;

          circArcRadius = Math.Abs(circArcRadius);

          QueryFilter queryFilterSelectedLines = new();
          Dictionary<string, object> COGORadiusScaleAttributes = new();
          var sourceParcFeats = new Dictionary<MapMember, List<long>>();
          ParcelEditToken MyParcelEditToken = null;

          //1. shrink to seeds
          //2. change the lines
          //3. reconstruct from seeds

          var editOper01 = new EditOperation();
          var editOper02 = new EditOperation();
          var editOper03 = new EditOperation();

          //------  1.Shrink to seeds ----------
          foreach (var lineLyr in parcelLineLayerIds)
          {
            var lineFC = lineLyr.Key.GetFeatureClass();
            var sr = lineFC.GetDefinition().GetSpatialReference();
            var metersPerDatasetUnit = 1.0;
            if (sr.IsProjected)
              metersPerDatasetUnit = sr.Unit.ConversionFactor;

            queryFilterSelectedLines.ObjectIDs = lineLyr.Value;

            //get the parcel type
            var parcelTypeName = Module1.GetParcelTypeNameFromFeatureLayer(myParcelFabricLayer, lineLyr.Key, GeometryType.Polyline).Result;
            var polyGonLyrEnum = myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(parcelTypeName).Result;

            var spatQuery = new SpatialQueryFilter();
            spatQuery.SpatialRelationship = SpatialRelationship.Intersects;

            using (RowCursor rowCursor = lineLyr.Key.Search(queryFilterSelectedLines))
            {
              while (rowCursor.MoveNext())
              {
                using Row rowLine = rowCursor.Current;
                var lineGeom = (rowLine as Feature).GetShape();
                //var lineMidPoint = GeometryEngine.Instance.MovePointAlongLine(lineGeom as Multipart, 0.5,
                //                      true, 0.0, SegmentExtensionType.NoExtension);
                //var midPointBuff = GeometryEngine.Instance.GeodesicBuffer(lineMidPoint, 0.2);
                //spatQuery.FilterGeometry = midPointBuff;

                var lineBuff = GeometryEngine.Instance.GeodesicBuffer(lineGeom, 0.2);
                spatQuery.FilterGeometry = lineBuff;

                //for each polygon layer
                foreach (FeatureLayer polyGonLyr in polyGonLyrEnum)
                {
                  if (!polyGonLyr.CanEditData())
                    continue;

                  using RowCursor rowCursorInner = polyGonLyr.Search(spatQuery);
                  var ids = new List<long>();
                  while (rowCursorInner.MoveNext())
                  {
                    using Row rowPolygon = rowCursorInner.Current;
                    long oid = rowPolygon.GetObjectID();
                    ids.Add(oid);

                  }
                  if (ids.Count > 0)
                  {
                    if (sourceParcFeats.ContainsKey(polyGonLyr))
                    {//add to the existing ids list
                      sourceParcFeats[polyGonLyr].AddRange(ids); 
                    }
                    else
                      sourceParcFeats.Add(polyGonLyr, ids);
                  }
                }
              }
            }
          }

          if (sourceParcFeats.Count > 0)
          {
            MyParcelEditToken =
                    editOper01.ShrinkParcelsToSeeds(myParcelFabricLayer, SelectionSet.FromDictionary(sourceParcFeats));
            if (editOper01.Execute())
              editOper02 = editOper01.CreateChainedOperation();
            else
            {
              string err = editOper01.ErrorMessage;
              MessageBox.Show("Error in Shrink To Seeds function:" + err);
              return;
            }
          }

          //------ 2.Change Lines -------------
          int modFeatCount = 0;
          foreach (var lineLyr in parcelLineLayerIds)
          {
            var lineFC = lineLyr.Key.GetFeatureClass();
            var fcDefinition = lineFC.GetDefinition();
            var datasetProjection = fcDefinition.GetSpatialReference();
            //var chordComparisonTolerance = datasetProjection.XYTolerance * 100.0;
            //var chordComparisonToleranceGCS = datasetProjection.XYTolerance * 100.0 * Math.PI / 180.0 * 6378100.0;

            queryFilterSelectedLines.ObjectIDs = lineLyr.Value;

            bool datasetInGCS = false;
            double datasetMetersPerUnit = 1.0;
            if (fcDefinition.GetSpatialReference().IsProjected)
              datasetMetersPerUnit = fcDefinition.GetSpatialReference().Unit.ConversionFactor;
            else
              datasetInGCS = true;

            if (mapInGCS && datasetInGCS)
            { 
              MessageBox.Show("Please ensure that the map or dataset have a " +
                "projected coordinate system.", "Update By Radius");
              return;
            }

            if (fcDefinition.FindField("cogotype") > -1)
              COGORadiusScaleAttributes.Add("cogotype", 1); //Entered

            using (RowCursor rowCursor = lineLyr.Key.Search(queryFilterSelectedLines))
            {
              while (rowCursor.MoveNext())
              {
                using (Row rowLine = rowCursor.Current)
                {
                  var lineGeom = (rowLine as Feature).GetShape();
                  if (lineGeom == null)
                    continue;

                  //get current circular arc COGO values
                  //var cogoDir = rowLine["direction"];
                  var cogoDist = rowLine["distance"];
                  var cogoRadius = rowLine["radius"];
                  var cogoArclength = rowLine["arclength"];
                  double calcCOGOChord = 0.0;
                  ArcOrientation arcOr = ArcOrientation.ArcClockwise;
                  if (cogoRadius != null && cogoArclength != null)
                  {
                    double dblRadius = (double)cogoRadius;
                    arcOr = dblRadius < 0.0 ? ArcOrientation.ArcCounterClockwise : ArcOrientation.ArcClockwise;
                    dblRadius = Math.Abs(dblRadius);
                    double dblArclength = (double)cogoArclength;
                    calcCOGOChord = 2.0 * dblRadius * Math.Sin(dblArclength / (2.0 * dblRadius));
                  }

                  ICollection<Segment> LineSegments = new List<Segment>();
                  (lineGeom as Polyline).GetAllSegments(ref LineSegments);
                  int numSegments = LineSegments.Count;
                  IList<Segment> iList = LineSegments as IList<Segment>;

                  var startPoint = iList[0].StartPoint;
                  var endPoint = iList[numSegments-1].EndPoint;
                  var chordLine = LineBuilderEx.CreateLineSegment(startPoint, endPoint);
                  var chordSegmentBuilder = SegmentBuilderEx.ConstructSegmentBuilder(chordLine);
                  chordSegmentBuilder.StartPoint = chordLine.StartPoint;
                  chordSegmentBuilder.EndPoint = chordLine.EndPoint;
                  var chordSegment = chordSegmentBuilder.ToSegment();

                  var newGeom = PolylineBuilderEx.CreatePolyline(chordSegment);
                  if (!bIsConvertingToLine)
                  {
                    if (circArcRadius * 2.0 <= chordLine.Length)
                      continue;

                    var deltaInRadians = 2.0 * Math.Asin(chordLine.Length / (2.0 * circArcRadius));
                    if (double.IsNaN(deltaInRadians))
                      continue;


                    MinorOrMajor minMaj = MinorOrMajor.Minor;//for this case always minor.
                    deltaInRadians = minMaj == MinorOrMajor.Minor ? deltaInRadians : (2.0 * Math.PI) - deltaInRadians;
                    var arcLength = deltaInRadians * circArcRadius * scaleFactor; //updated GEOM ArcLength to match radius and chord length

                    COGORadiusScaleAttributes.Add("scale", scaleFactor);
                    COGORadiusScaleAttributes.Add("distance", DBNull.Value);
                    if (arcOrientation == ArcOrientation.ArcCounterClockwise)
                      COGORadiusScaleAttributes.Add("radius", -circArcRadius * mapMetersPerUnit / datasetMetersPerUnit);
                    else
                      COGORadiusScaleAttributes.Add("radius", circArcRadius * mapMetersPerUnit / datasetMetersPerUnit);

                    if (cogoDist != null)
                      calcCOGOChord = (double)cogoDist; //distance field wins

                    if (calcCOGOChord != 0.0)
                    {//get arclength from chord cogo
                      var calcCOGODeltaInRadians = 2.0 * Math.Asin(calcCOGOChord / (2.0 * circArcRadius)); //no unit conversion just a ratio
                      var calcCOGOArcLength = calcCOGODeltaInRadians * circArcRadius;
                      COGORadiusScaleAttributes.Add("arclength", calcCOGOArcLength * mapMetersPerUnit / datasetMetersPerUnit);
                    }

                    var newSegment = EllipticArcBuilderEx.CreateCircularArc(startPoint, chordLine.Length,
                      chordLine.Angle, arcLength, arcOrientation);

                    newGeom = PolylineBuilderEx.CreatePolyline(newSegment, datasetProjection);
                  }
                  else
                  {
                    //Assign the recomputed distance value from the original radius and arclength
                    if(calcCOGOChord != 0.0)
                      COGORadiusScaleAttributes.Add("distance", calcCOGOChord);

                    COGORadiusScaleAttributes.Add("radius", DBNull.Value);
                    COGORadiusScaleAttributes.Add("arclength", DBNull.Value);
                    COGORadiusScaleAttributes.Add("scale", DBNull.Value);
                  }

                  if (newGeom == null)
                    continue;

                  var oid = rowLine.GetObjectID();
                  editOper02.Modify(lineLyr.Key, oid, newGeom, COGORadiusScaleAttributes);
                  modFeatCount++;
                  COGORadiusScaleAttributes.Clear();
                }
              }
            }
          }

          if (modFeatCount == 0)
          {
            editOper01.UndoAsync(); //undo the shrink to seed edit
            return;
          }
          modFeatCount = 0;
          Envelope seedEnv = null;
          if (MyParcelEditToken != null)
          {
            var modFeats = MyParcelEditToken.ModifiedFeatures;
            if (modFeats == null)
              return;
            modFeatCount = modFeats.Count;

            var selSetDictFeatureLayer = modFeats.ToDictionary<FeatureLayer>();
            List<Geometry> seedGeomList = new();
            foreach (KeyValuePair<FeatureLayer, List<long>> featLyrOID in selSetDictFeatureLayer)
            {
              QueryFilter queryFilter = new();
              queryFilter.ObjectIDs = featLyrOID.Value;
              using RowCursor rowCursor = featLyrOID.Key.Search(queryFilter);
              while (rowCursor.MoveNext())
              {
                using Row rowLine = rowCursor.Current;
                var seedGeom = (rowLine as Feature).GetShape();
                seedGeomList.Add(seedGeom);
              }
            }
            seedEnv = GeometryEngine.Instance.Union(seedGeomList).Extent;

            }
          if (modFeatCount > 0)
          {
            if (editOper02.Execute())
              editOper03 = editOper02.CreateChainedOperation();
          }
          else
          {
            editOper02.Name = "Update By Radius";
            if (!editOper02.Execute())
            {
              string err = editOper02.ErrorMessage;
              MessageBox.Show("Error in chnging lines:" + err);
              return;
            }
          }

          //------ 3. reconstruct from seeds -------------
          if (modFeatCount > 0)
          {
            editOper03.Name = "Update By Radius";
            editOper03.ReconstructParcelsFromSeeds(myParcelFabricLayer,seedEnv);
            if (!editOper03.Execute())
            {
              string err = editOper03.ErrorMessage;
              MessageBox.Show("Error in Reconstruct From Seeds function:" + err);
              return;
            }
          }

        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message, "Update By Radius");
        }
      });
    }
  }
}
