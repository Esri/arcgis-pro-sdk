﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ParcelLines
{
  internal class Module1 : Module
  {
    private static Module1 _this = null;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("ParcelLines_Module");

    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

    internal static bool GetParcelLineFeatureLayersSelection(MapView myActiveMapView,
  out Dictionary<FeatureLayer, List<long>> ParcelLineSelections)
    {
      List<FeatureLayer> featureLayer = new();
      ParcelLineSelections = new();

      try
      {
        var fLyrList = myActiveMapView?.Map?.GetLayersAsFlattenedList()?.OfType<FeatureLayer>()?.
          Where(l => l != null).Where(l => (l as Layer).ConnectionStatus != ConnectionStatus.Broken).
          Where(l => l.GetFeatureClass().GetDefinition().IsCOGOEnabled());

        if (fLyrList == null) return false;

        foreach (var fLyr in fLyrList)
        {
          bool isFabricLyr = fLyr.IsControlledByParcelFabricAsync(ParcelFabricType.ParcelFabric).Result;

          if (isFabricLyr && fLyr.SelectionCount > 0)
            featureLayer.Add(fLyr);
        }
      }
      catch
      { return false; }
      foreach (var lyr in featureLayer)
      {
        var fc = lyr.GetFeatureClass();
        List<long> lstOids = new();
        using (RowCursor rowCursor = lyr.GetSelection().Search())
        {
          while (rowCursor.MoveNext())
          {
            using (Row rowFeat = rowCursor.Current)
            {
              if (!ParcelLineSelections.ContainsKey(lyr))
                ParcelLineSelections.Add(lyr, lstOids);
              lstOids.Add(rowFeat.GetObjectID());
            }
          }
        }
        if (lstOids.Count > 0)
          ParcelLineSelections[lyr] = lstOids;
      }
      return true;
    }

    internal static async Task<string> GetParcelTypeNameFromFeatureLayer(ParcelLayer myParcelFabricLayer,
      FeatureLayer featLayer, GeometryType geomType)
    {
      if (featLayer == null) //nothing to do return empty string
        return String.Empty;
      IEnumerable<string> parcelTypeNames = await myParcelFabricLayer.GetParcelTypeNamesAsync();
      foreach (string parcelTypeName in parcelTypeNames)
      {
        if (geomType == GeometryType.Polygon)
        {
          var polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;

          polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelPolygonLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
        if (geomType == GeometryType.Polyline)
        {
          var lineLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelLineLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;

          lineLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelLineLayerByTypeNameAsync(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
      }
      return string.Empty;
    }

    internal static async Task<FeatureLayer> GetFirstFeatureLayerFromParcelTypeName(ParcelLayer myParcelFabricLayer,
      string ParcelTypeName, GeometryType geomType)
    {
      if (geomType == GeometryType.Polygon)
      {
        var targetPolygonTypeEnum =
          await myParcelFabricLayer.GetParcelPolygonLayerByTypeNameAsync(ParcelTypeName);
        if (targetPolygonTypeEnum != null)
          return targetPolygonTypeEnum.FirstOrDefault();
      }
      else
      {
        var targetPolylineTypeEnum =
          await myParcelFabricLayer.GetParcelLineLayerByTypeNameAsync(ParcelTypeName);
        if (targetPolylineTypeEnum != null)
          return targetPolylineTypeEnum.FirstOrDefault();
      }
      return null;
    }

    internal static bool HasValidLicenseForParcelLayer()
    {
      var lic = ArcGIS.Core.Licensing.LicenseInformation.Level;
      if (lic < ArcGIS.Core.Licensing.LicenseLevels.Standard)
        return false;
      else
        return true;
    }

    internal static bool IsDefaultVersionOnFeatureService(FeatureLayer featureLayer)
    {
      using (Table table = featureLayer.GetTable())
      {
        Datastore datastore = table.GetDatastore();
        Geodatabase geodatabase = datastore as Geodatabase;
        if (geodatabase.IsVersioningSupported())
        {
          using VersionManager versionManager = geodatabase.GetVersionManager();
          try
          {
            var currentVersion = versionManager.GetCurrentVersion();
            if (currentVersion.GetParent() == null) //default version
              return true;// "Editing on the default version is not available.";
          }
          catch
          {
            return true;
          }
        }
      }
      return false;
    }

  }
}
