﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using POITracking.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POITracking.Helpers
{
  internal class CreateLayer : Button
  {
    protected override async void OnClick()
    {
      var fileGdbPath = new FileGeodatabaseConnectionPath(
        new Uri(Project.Current.DefaultGeodatabasePath));

      await QueuedTask.Run(() =>
      {
        FeatureClass call_locations_fc = null;
        FeatureClass inc_locations_fc = null;
        using (var geoDb = new Geodatabase(fileGdbPath))
        {
          try
          {
            call_locations_fc = geoDb.OpenDataset<FeatureClass>(
              Module1.Current.CallLocationFC);
          }
          catch (Exception)
          {
            call_locations_fc = null;//does not exist
            if (LayerHelper.CreateCallLocationFeatureClass(geoDb, Module1.Current.CallLocationFC))
            {
              call_locations_fc = geoDb.OpenDataset<FeatureClass>(Module1.Current.CallLocationFC);
            }
          }
          if (call_locations_fc != null)
          {
            var flyrCreateParam = new FeatureLayerCreationParams(call_locations_fc)
            {
              Name = Module1.Current.CallLocationFLayer
            };
            var featureLayer = LayerFactory.Instance.CreateLayer<FeatureLayer>(
              flyrCreateParam, MapView.Active?.Map);
          }

          //incident locations
          try
          {
            inc_locations_fc = geoDb.OpenDataset<FeatureClass>(Module1.Current.IncidentLocationFC);
          }
          catch (Exception)
          {
            inc_locations_fc = null;//does not exist
            if (LayerHelper.CreateIncidentLocationFeatureClass(
              geoDb, Module1.Current.IncidentLocationFC))
            {
              inc_locations_fc = geoDb.OpenDataset<FeatureClass>(Module1.Current.IncidentLocationFC);
            }
          }
          if (inc_locations_fc != null)
          {
            var flyrCreateParam = new FeatureLayerCreationParams(inc_locations_fc)
            {
              Name = Module1.Current.IncidentLocationFLayer
            };
            var featureLayer = LayerFactory.Instance.CreateLayer<FeatureLayer>(
              flyrCreateParam, MapView.Active?.Map);
          }
        }
      });
      
    }
  }
}
