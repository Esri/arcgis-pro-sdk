﻿using ActiproSoftware.Windows.Extensions;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using POITracking.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;


namespace POITracking.UI
{
    /// <summary>
    /// Business logic for the StartPage
    /// </summary>
    internal class StartPageViewModel : PropertyChangedBase
  {
    internal StartPageViewModel()
    {
      BindingOperations.EnableCollectionSynchronization(
        PersonsOfInterest, Module1.CollectionLock);

      RunAnalysisQueries.RunQuery1_ForSuspectList(this);

      SelectedProjectFile = ProProjects.FirstOrDefault();
    }

    public ObservableCollection<SuspectInfo> PersonsOfInterest => Module1.Current.Suspects;

    public SuspectInfo PersonOfInterest
    {
      get { return Module1.Current.PersonOfInterest; }
      set
      {
        Module1.Current.PersonOfInterest = value;
        NotifyPropertyChanged(nameof(PersonOfInterest));
      }
    }

    #region Properties
    /// <summary>
    /// Collection of all ArcGIS Pro project files.
    /// </summary>
    public ICollection<FileInfo> ProProjects
    {
      get
      {
        var fileInfos = Project.GetRecentProjects().Select(f => new FileInfo(f));

        var projectCollection = new Collection<FileInfo>(fileInfos.ToList());
        if (System.IO.File.Exists(Module1.Default_Project))
        {
          var fi = new FileInfo(Module1.Default_Project);
          projectCollection.Insert(0, fi);//add to the front
        }
        if (projectCollection.Count == 1) _selectedProjectFile = projectCollection[0];
        return projectCollection;
      }
    }

    private FileInfo _selectedProjectFile;
    /// <summary>
    /// ArcGIS Pro project file is selected and will be opened.
    /// </summary>
    public FileInfo SelectedProjectFile
    {
      get => _selectedProjectFile;
      set => SetProperty(ref _selectedProjectFile, value);
    }
    #endregion

    #region Commands

    private ICommand _updateSuspectListCMD = null;

    public ICommand UpdateSuspectListCMD
    {
      get
      {
        return new RelayCommand(() =>
        {
          RunAnalysisQueries.RunQuery1_ForSuspectList(this);
        });
      }
    }

    private ICommand _about;
    /// <summary>
    /// Command opens the ArcGIS Pro OpenItemDialog API method to browse to a specific project file.
    /// </summary>
    public ICommand OpenProjectCommand
    {
      get
      {
        return StartPageViewModelHelper.OpenProjectCommand;
      }
    }
    /// <summary>
    /// Command opens the selected ArcGIS Pro project.
    /// </summary>
    public ICommand BeginSessionCmd
    {
      get
      {
        return new RelayCommand((args) => 
        Project.OpenAsync(SelectedProjectFile.FullName), () => SelectedProjectFile != null);
      }
    }
    /// <summary>
    /// Command opens the ArcGIS Pro backstage
    /// </summary>
    public ICommand AboutArcGISProCommand
    {
      get
      {
        if (_about == null)
          _about = new RelayCommand(() => FrameworkApplication.OpenBackstage("esri_core_aboutTab"));
        return _about;
      }
    }
    #endregion
  }
  #region StartPageViewModel helper class
  /// <summary>
  /// 
  /// </summary>
  internal class StartPageViewModelHelper
  {
    internal static void BrowseToProject()
    {
      var dlg = new OpenItemDialog();

      var myDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
      var initFolder = Path.Combine(System.IO.Path.Combine(myDocs, "ArcGIS"), "Projects");
      if (!Directory.Exists(initFolder))
        initFolder = myDocs;
      dlg.Title = "Open Project";
      dlg.InitialLocation = initFolder;
      dlg.Filter = ArcGIS.Desktop.Catalog.ItemFilters.Projects;

      if (dlg.ShowDialog() ?? false)
      {
        var item = dlg.Items.FirstOrDefault();
        if (item != null)
        {
          Project.OpenAsync(item.Path);
        }
      }
    }
    internal static ICommand OpenProjectCommand
    {
      get
      {

        return new RelayCommand((args) => BrowseToProject(), () => true); ;
      }
    }
  }
  #endregion
}
