﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using POITracking.Helpers;
using POITracking.Models;


namespace POITracking.AnalysisUI
{
  internal class AnalysisReportViewModel : DockPane
  {
    private const string _dockPaneID = "POITracking_AnalysisReport";

    protected AnalysisReportViewModel()
    {
      BindingOperations.EnableCollectionSynchronization(
                Suspects, Module1.CollectionLock);
      BindingOperations.EnableCollectionSynchronization(
                SuspectsCalled, Module1.CollectionLock);
      BindingOperations.EnableCollectionSynchronization(
          CallLocations, Module1.CollectionLock);
      BindingOperations.EnableCollectionSynchronization(
          Incidents, Module1.CollectionLock);
      //Reset();
    }

    public void Reset()
    {
      LayerHelper.ResetLayersAsync();
      ClearAnalysis();
    }

    public void ClearAnalysis()
    {
      lock(Module1.CollectionLock)
      {
        SuspectsCalled.Clear();
        CallLocations.Clear();
        Incidents.Clear();
      }

      TitleCallsMade = "Calls Made:";
      var full_name = Module1.Current.PersonOfInterest?.FullName ?? "";
      if (!string.IsNullOrEmpty(full_name))
        TitleCallsMade = $@"Calls made by {full_name}:";
    }

    private string _TitleCallsMade = "Calls Made:";
    public string TitleCallsMade
    {
      get { return _TitleCallsMade; }
      set
      {
        SetProperty(ref _TitleCallsMade, value);
      }
    }

    public SuspectInfo PersonOfInterest
    {
      get { return Module1.Current.PersonOfInterest; }
      set
      {
        if (Module1.Current.PersonOfInterest != value)
        {
          Module1.Current.PersonOfInterest = value;
          Reset();
        }
        NotifyPropertyChanged(nameof(PersonOfInterest));
      }
    }

    public ObservableCollection<SuspectInfo> Suspects => Module1.Current.Suspects;

    public ICommand CmdWhoCalled
    {
      get
      {
        return new RelayCommand(() =>
        {
          TitleCallsMade = $@"Calls made by {PersonOfInterest.FullName}:";

          RunAnalysisQueries.RunQuery2_CalledBySuspect(PersonOfInterest);

        }, () => Module1.Current.PersonOfInterest != null);
      }
    }

    public ObservableCollection<SuspectInfo> SuspectsCalled => Module1.Current.SuspectsCalled;

    private SuspectInfo _selectedSuspectInfo = null;
    public SuspectInfo SelectedSuspectInfo
    {
      get
      {
        return _selectedSuspectInfo;
      }
      set
      {
        SetProperty(ref _selectedSuspectInfo, value);
        Module1.Current.SuspectCalled = value;
      }
    }

    public ICommand CmdAppendToLinkChart
    {
      get
      {
        return new RelayCommand(() =>
        {
          var map_panes = FrameworkApplication.Panes.OfType<IMapPane>().ToList();
          var link_chart = map_panes.FirstOrDefault(mp => mp.MapView.IsLinkChartView == true);

          //var kg_layer = link_chart.MapView.Map.GetLayersAsFlattenedList()
          //                  .OfType<KnowledgeGraphLayer>().FirstOrDefault();
          //if (kg_layer == null)
          //  return;

            RunAnalysisQueries.RunQuery3_CommonCallsForLinkChart(
            PersonOfInterest, SelectedSuspectInfo);

          if (link_chart == null)
            return;
          ((Pane)link_chart).Activate();

        }, () => this.SelectedSuspectInfo != null);
      }
    }

    public ICommand CmdCallLocations
    {
      get
      {
        return new RelayCommand(() =>
        {
          RunAnalysisQueries.RunQuery4_CallsWithLocation(PersonOfInterest);

        }, () => Module1.Current.PersonOfInterest != null);
      }
    }

    public ObservableCollection<CallLocation> CallLocations => Module1.Current.CallLocations;

    private CallLocation _selectedCallLocation = null;
    public CallLocation SelectedCallLocation
    {
      get { return _selectedCallLocation; }
      set
      {
        SetProperty(ref _selectedCallLocation, value);
        if (_selectedCallLocation != null)
        {
          var mapPoint = _selectedCallLocation.Location;
          if (mapPoint != null)
          {
            FlashCallLocation(_selectedCallLocation);
          }
        }
      }
    }

    public ICommand CmdIncidentLocations
    {
      get
      {
        return new RelayCommand(() =>
        {
          RunAnalysisQueries.RunQuery5_CallsWithIncidents(PersonOfInterest);

        }, () => Module1.Current.PersonOfInterest != null);
      }
    }

    public ObservableCollection<IncidentLocation> Incidents => Module1.Current.Incidents;

    public ICommand CmdReport
    {
      get
      {
        return new RelayCommand(() =>
        {
          Reporting.Report.RunReport();
        }, () => Module1.Current.PersonOfInterest != null && Module1.Current.SuspectCalled != null);
      }
    }

    private async void FlashCallLocation(CallLocation selectedCallLocation)
    {
      var phoneLocLayer = LayerHelper.GetFeatureLayer(
            Module1.Current.CallLocationFLayer);
      if (phoneLocLayer == null)
        return;

      try
      {
        await QueuedTask.Run(() =>
        {
          var qf = new QueryFilter
          {
            WhereClause = $@"LocationID = {selectedCallLocation.CallID}"
          };
          using var rowCursor = phoneLocLayer.Search(qf);
          if (rowCursor.MoveNext())
          {
            var row = rowCursor.Current;
            MapView.Active.FlashFeature(phoneLocLayer, row.GetObjectID());
          }
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Exception flashing call location: {ex}");
      }
    }

   
    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
  internal class AnalysisReport_ShowButton : Button
  {
    protected override void OnClick()
    {
      AnalysisReportViewModel.Show();
    }
  }
}
