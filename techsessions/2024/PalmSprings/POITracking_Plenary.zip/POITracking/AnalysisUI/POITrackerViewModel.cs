﻿using ActiproSoftware.Windows.Extensions;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using POITracking.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


namespace POITracking.AnalysisUI
{
    internal class POITrackerViewModel : DockPane
    {
        private const string _dockPaneID = "POITracking_POITracker";

        protected POITrackerViewModel()
        {
            _personsOfInterest.AddRange(Module1.Current.Suspects);
            if (Module1.Current.SelectedPersonOfInterest != null)
            {
                SelectedPersonOfInterest = Module1.Current.SelectedPersonOfInterest;
            }
            VisibleList = _personsOfInterest.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            VisibleText = _personsOfInterest.Count > 0 ? Visibility.Collapsed : Visibility.Visible;
        }

        private ObservableCollection<SuspectInfo> _personsOfInterest = new ObservableCollection<SuspectInfo>();
        public ObservableCollection<SuspectInfo> PersonsOfInterest
        {
            get { return _personsOfInterest; }
            set
            {
                SetProperty(ref _personsOfInterest, value);
            }
        }

        private SuspectInfo _selectedPersonOfInterest;

        public SuspectInfo SelectedPersonOfInterest
        {
            get { return _selectedPersonOfInterest; }
            set
            {
                SetProperty(ref _selectedPersonOfInterest, value);
            }
        }

        private Visibility _visibleList;
        public Visibility VisibleList
        {
            get { return _visibleList; }
            set
            {
                SetProperty(ref _visibleList, value);
            }
        }

        private Visibility _visibleText;
        public Visibility VisibleText
        {
            get { return _visibleText; }
            set
            {
                SetProperty(ref _visibleText, value);
            }
        }

        /// <summary>
        /// SearchOffender
        /// </summary>
        private string _PersonOfInterest = string.Empty;
        public string SearchPersonOfInterest
        {
            get => _PersonOfInterest;
            set
            {
                SetProperty(ref _PersonOfInterest, value);
                foreach (var offender in _personsOfInterest)
                {
                    if (offender.Name.StartsWith(_PersonOfInterest, StringComparison.CurrentCultureIgnoreCase))
                    {
                        SelectedPersonOfInterest = offender;
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Show the DockPane.
        /// </summary>
        internal static void Show()
        {
            DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
            if (pane == null)
                return;

            pane.Activate();
        }
    }

    /// <summary>
    /// Button implementation to show the DockPane.
    /// </summary>
    internal class POITracker_ShowButton : Button
    {
        protected override void OnClick()
        {
            POITrackerViewModel.Show();
        }
    }
}
