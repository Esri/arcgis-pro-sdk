﻿using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Internal.Core.Conda;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POITracking.Models
{
  internal class CallLocation
  {
    public CallLocation(KnowledgeGraphEntityValue associate,
                    KnowledgeGraphEntityValue phone_location,
                    KnowledgeGraphEntityValue call_details)
    {
      CallID = call_details.GetObjectID();

      AssociateName = (string)associate["FULL_NAME"];
      City = (string)associate["CITY"];
      PhoneNumber = (string)associate["PHONE_NUMBER"];
      PhoneNumber_Global_ID = (string)associate["globalid"];
      var dt = (DateTimeOffset)call_details["START_DATE"];
      var call_date = dt.DateTime.ToString("G");
      var call_time = dt.DateTime.ToString("HH:mm:ss tt");

      CallDateAndTime = $"{call_date}";
      CallDuration = $"{(int)call_details["DURATION"]}m";

      Location = phone_location["shape"] as MapPoint;
    }

    public long CallID { get; set; }
    internal string AssociateName { get; set; }
    internal string City { get; set; }
    internal string PhoneNumber { get; set; }
    internal string PhoneNumber_Global_ID { get; set; }
    internal string CallDateAndTime { get; set; }
    internal string CallDuration { get; set; }
    internal Geometry Location { get; set; }

    public string CallDetails
    {
      get
      {
        return $"{AssociateName} ({City}) on " +
               $"{PhoneNumber} @{CallDateAndTime}, for {CallDuration}";
      }
    }

  }
}

