﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Internal.Core.Conda;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POITracking.Models
{
  internal class PhoneLocation
  {
    public long LocationID { get; set; }
    public long PersonOfInterestID { get; set; }
    public string PhoneOwner { get; set; }
    public string PhoneNumber { get; set; }
    public string PersonOfInterest { get; set; }
    public Geometry Location { get; set; }
  }
}
