﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;

namespace POITracking.Models
{
  internal class IncidentLocation
  {
    public IncidentLocation(KnowledgeGraphEntityValue associate,
                            KnowledgeGraphEntityValue incident) 
    {
      PhoneOwner = (string)associate["FULL_NAME"];
      PhoneNumber = (string)associate["PHONE_NUMBER"];
      PhoneNumber_Global_ID = (string)associate["globalid"];
      IncidentID = incident.GetObjectID();
      Incident = (string)incident["TYPE"];

      var dt = (DateTimeOffset)incident["TIME"];
      var inc_date = dt.DateTime.ToString("G");
      var inc_time = dt.DateTime.ToString("HH:mm:ss tt");

      DateAndTime = $"{inc_date}";

      Location = incident["shape"] as MapPoint;
    }

    public long IncidentID { get; set; }
    internal string PhoneOwner { get; set; }
    internal string PhoneNumber { get; set; }
    internal string PhoneNumber_Global_ID { get; set; }

    internal string Incident { get; set; }

    internal string DateAndTime { get; set; }

    internal ArcGIS.Core.Geometry.Geometry Location { get; set; }

    public string IncidentDetails
    {
      get
      {
        return $"{PhoneOwner}, cell: {PhoneNumber} match: " +
               $"{Incident} @{DateAndTime}";
      }
    }
  }
}
