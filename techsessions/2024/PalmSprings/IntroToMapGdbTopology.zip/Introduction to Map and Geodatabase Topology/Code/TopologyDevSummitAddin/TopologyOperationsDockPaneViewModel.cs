﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TopologyAddin
{
  internal class TopologyOperationsDockPaneViewModel : DockPane
  {
    private const string _dockPaneID = "TopologyAddin_TopologyOperationsDockPane";
    private TopologyOperations _topologyOperations;

    public ICommand ExploreTopologyCommand { get; }
    public ICommand ValidateTopologyCommand { get; }
    public ICommand TraverseGraphNodesCommand { get; }
    public ICommand TraverseGraphEdgesCommand { get; }
    public ICommand GetErrorAndExceptionsCommand { get; }
    public ICommand SetErrorAsExceptionsCommand { get; }
    public ICommand ResetErrorAsExceptionsCommand { get; }
    public ICommand FindClosestElementCommand { get; }


    public TopologyOperationsDockPaneViewModel()
    {
      ExploreTopologyCommand = new RelayCommand(ExploreTopologyAsync);
      ValidateTopologyCommand = new RelayCommand(ValidateTopologyAsync);
      TraverseGraphEdgesCommand = new RelayCommand(TraverseGraphEdgesAsync);
      TraverseGraphNodesCommand = new RelayCommand(TraverseGraphNodesAsync);
      GetErrorAndExceptionsCommand = new RelayCommand(GetErrorAndExceptionsAsync);
      SetErrorAsExceptionsCommand = new RelayCommand(SetErrorAsExceptionsAsync);
      ResetErrorAsExceptionsCommand = new RelayCommand(ResetErrorAsExceptionsAsync);
      FindClosestElementCommand = new RelayCommand(FindClosestElementAsync);
      _topologyOperations = new TopologyOperations();

      CustomClickTool.ClickHappened += CustomClickTool_ClickHappened;
    }


    private async void CustomClickTool_ClickHappened(object sender, MapViewMouseButtonEventArgs e)
    {
      MapPoint mapPoint = null;
      await QueuedTask.Run(() =>
      {
        mapPoint = MapView.Active.ClientToMap(e.ClientPoint);             
      });

      MapPointText = $"X:{Math.Round(mapPoint.X, 3)},Y:{Math.Round(mapPoint.Y, 3)}";

      string findClosestElementResults = await _topologyOperations.FindClosestElement(mapPoint);
      TopologyResults = new ObservableCollection<string> { findClosestElementResults };

    }

    private async void ResetErrorAsExceptionsAsync()
    {
      string unmarkErrorAsExceptionResults = await _topologyOperations.UnmarkErrorAsExceptionAsync();
      TopologyResults = new ObservableCollection<string> { unmarkErrorAsExceptionResults };
    }

    private async void SetErrorAsExceptionsAsync()
    {
      string markErrorAsExceptionResults = await _topologyOperations.MarkErrorAsExceptionAsync();
      TopologyResults = new ObservableCollection<string> { markErrorAsExceptionResults };
    }

    private async void GetErrorAndExceptionsAsync()
    {
      string errorAndExceptionResults = await _topologyOperations.GetAllErrorAndExceptionsAsync();
      TopologyResults = new ObservableCollection<string> { errorAndExceptionResults };
    }

    private async void ExploreTopologyAsync()
    {
      //Open and read the topology metadata
      string topologyMetadataResult = await _topologyOperations.ReadTopologyMetadataAsync();
      TopologyResults = new ObservableCollection<string> { topologyMetadataResult };
    }
    private async void ValidateTopologyAsync()
    {
      string topologyValidationResult = await _topologyOperations.ValidateTopologyAsync();
      TopologyResults = new ObservableCollection<string> { topologyValidationResult };
    }
    private async void TraverseGraphEdgesAsync()
    {
      await _topologyOperations.TraverseTopologyGraphEdgesAsync();
    }

    private async void TraverseGraphNodesAsync()
    {
     await _topologyOperations.TraverseTopologyGraphNodeAsync();
    }

    private async void FindClosestElementAsync()
    {
      await ActivateCustomClickTool();
    }

    private string _mapPointText;
    public string MapPointText 
    {
      get
      {
        return _mapPointText;
      }
      set
      {
        SetProperty(ref _mapPointText, value, () => MapPointText);
        NotifyPropertyChanged(nameof(MapPointText));
      }
    }

    private ObservableCollection<string> _topologyResults;
    public ObservableCollection<string> TopologyResults
    {
      get
      {
        return _topologyResults;
      }
      set
      {
        SetProperty(ref _topologyResults, value, () => TopologyResults);
        NotifyPropertyChanged(nameof(TopologyResults));
      }
    }

    private async Task ActivateCustomClickTool()
    {
      await QueuedTask.Run(() =>
      {
        IPlugInWrapper wrapper = FrameworkApplication.GetPlugInWrapper("TopologyAddin_CustomClickTool");
        if (wrapper is ICommand toolCmd)
        {
          // if it is a tool, execute will set current tool
          toolCmd.Execute(null);
        }
      });
    }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

    /// <summary>
    /// Text shown near the top of the DockPane.
    /// </summary>
    private string _heading = "Choose a Topology Operation";
    public string Heading
    {
      get => _heading;
      set => SetProperty(ref _heading, value);
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class TopologyOperationsDockPane_ShowButton : Button
  {
    protected override void OnClick()
    {
      TopologyOperationsDockPaneViewModel.Show();
    }
  }
}
