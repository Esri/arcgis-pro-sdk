﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data.Topology;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;


namespace TopologyDemo
{
  internal class TopologyGraphSymbolControlViewModel : DockPane
  {
    private const string _dockPaneID = "TopologyDemo_TopologyGraphSymbolControl";
    private static TopologyGraphSymbolControlViewModel _this = null;
    private static List<IDisposable> snapshot = new List<IDisposable>();
    private static System.IDisposable _overlayObject = null;
    private static CIMPointSymbol _symbol;
    private static CIMLineSymbol _symbolLine;
    private static CIMSymbolReference _symbolReference;
    private static CIMSymbolReference _symbolReferenceLine;
    private static IReadOnlyList<TopologyNode> topologyGraphNodes;
    private static IReadOnlyList<TopologyEdge> topologyGraphEdges;
    protected TopologyGraphSymbolControlViewModel()
    {
      _this = this;
      var _topoChangedToken = ActiveTopologyChangingEvent.Subscribe(OnTopologyChanged);
    }

    /// <summary>
    /// Waiting for the active map view to change in order to setup event listening
    /// </summary>
    /// <param name="args"></param>
    private void OnTopologyChanged(TopologyEventArgs obj)
    {

    }
    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }

    /// <summary>
    /// Color selection
    /// </summary>
    public static CIMColor _SelectedNodeColor = CIMColor.CreateRGBColor(255, 0, 0);
    public static CIMColor _SelectedEdgeColor = CIMColor.CreateRGBColor(255, 0, 0);
    public CIMColor SelectedNodeColor
    {
      get => _SelectedNodeColor;
      set => SetProperty(ref _SelectedNodeColor, value, () => SelectedNodeColor);
    }
    public CIMColor SelectedEdgeColor
    {
      get => _SelectedEdgeColor;
      set => SetProperty(ref _SelectedEdgeColor, value, () => SelectedEdgeColor);
    }

    /// <summary>
    /// Text shown near the top of the DockPane.
    /// </summary>
    private string _heading = "Change Node and Edge Color";
    public string Heading
    {
      get => _heading;
      set => SetProperty(ref _heading, value, () => Heading);
    }
    private double _nodeSize = 6.0;
    public double NodeSize
    {
      get => _nodeSize;
      set => SetProperty(ref _nodeSize, value, () => NodeSize);
    }

    private double _edgeWidth = 3.0;
    public double EdgeWidth
    {
      get => _edgeWidth;
      set => SetProperty(ref _edgeWidth, value, () => EdgeWidth);
    }

    public SimpleMarkerStyle _selectedMarkerStyle;

    public SimpleMarkerStyle SelectedMarkerStyle
    {
      get => _selectedMarkerStyle;
      set => SetProperty(ref _selectedMarkerStyle, value, () => SelectedMarkerStyle);
    }

    public IEnumerable<SimpleMarkerStyle> MarkerStyleValues
    {
      get
      {
        return Enum.GetValues(typeof(SimpleMarkerStyle))
            .Cast<SimpleMarkerStyle>();
      }
    }

    /// <summary>
    /// Change the polygon fill color
    /// </summary>
    public ICommand CmdChangeColor => new RelayCommand(() =>
    {
      ClearOverlay();
      _ = SetLineRendererColor(SelectedNodeColor, SelectedEdgeColor, _selectedMarkerStyle, _edgeWidth, _nodeSize);

    });


    internal static Task SetLineRendererColor(CIMColor nodeColor, CIMColor edgeColor, SimpleMarkerStyle selectedMarkerStyle, Double edgeWidth, Double nodeSize)
    {
      return QueuedTask.Run(() =>
      {
        //Build the map topology graph
        MapView.Active.BuildMapTopologyGraph<TopologyDefinition>(topologyGraph =>
        {
          //Getting the nodes and edges present in the graph
          topologyGraphNodes = topologyGraph.GetNodes();
          topologyGraphEdges = topologyGraph.GetEdges();


          //Construct point and line symbols
          _symbol = SymbolFactory.Instance.ConstructPointSymbol(nodeColor, nodeSize, selectedMarkerStyle);
          _symbolLine = SymbolFactory.Instance.ConstructLineSymbol(edgeColor, edgeWidth);
          //Get symbol references from the symbols 
          _symbolReference = _symbol.MakeSymbolReference();
          _symbolReferenceLine = _symbolLine.MakeSymbolReference();


          //Draw the nodes and edges on the overlay to highlight them
          foreach (var node in topologyGraphNodes)
          {
            _overlayObject = MapView.Active.AddOverlay(node.GetShape() as MapPoint, _symbolReference);
            snapshot.Add(_overlayObject);
          }
          foreach (var edge in topologyGraphEdges)
          {
            _overlayObject = MapView.Active.AddOverlay(edge.GetShape() as ArcGIS.Core.Geometry.Polyline, _symbolReferenceLine);
            snapshot.Add(_overlayObject);
          }

          MessageBox.Show($"Number of topo graph nodes are:  {topologyGraphNodes.Count}.\n Number of topo graph edges are {topologyGraphEdges.Count}.", "Map Topology Info");
        });
      });
    }

    /// <summary>
    /// Function to clear the current overlay on the map.
    /// </summary>
    private void ClearOverlay()
    {
      //Clearing the currently drawn overlay on the map
      foreach (var graphic in snapshot)
        graphic.Dispose();
      snapshot.Clear();
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class TopologyGraphSymbolControl_ShowButton : Button
  {
    protected override void OnClick()
    {
      TopologyGraphSymbolControlViewModel.Show();


      QueuedTask.Run(() =>
      {
        //just build the graph with the default color for now 
        BuildCorrectGraph();
        //MapView.Active.BuildMapTopologyGraph<TopologyDefinition>(topologyGraph =>
     // { });
      });
    }

    private async void BuildCorrectGraph()
    {
      await QueuedTask.Run(async () =>
      {
        var activetopo = await MapView.Active.Map.GetActiveTopologyAsync();

        if (activetopo.Name.Contains("Map Topology"))
        {
          MapView.Active.BuildMapTopologyGraph<TopologyDefinition>(topologyGraph => { });
        }
        else
        {
          var ptLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<TopologyLayer>().FirstOrDefault(); //.FirstOrDefault(layer => layer.Name == activetopo.Name);
          Topology topology = ptLayer.GetTopology();
          topology.BuildGraph(MapView.Active.Map.GetDefaultExtent(), (topologyGraph) => { });
        }
      });
    }
  }
}
