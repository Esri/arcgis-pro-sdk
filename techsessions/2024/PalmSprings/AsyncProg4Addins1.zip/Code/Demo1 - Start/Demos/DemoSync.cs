﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.DDL;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using AsyncProgForAddins1.Helpers;

namespace AsyncProgForAddins1.Demos
{
	internal class DemoSync : Button
	{
		internal static string DemoCrimeLayer => "Crimes";
		internal static string DemoCrimeSelection => "Assault";
		internal static string DemoAssaultWhereClause => "Offense_Type = 5";
		internal static string DemoGeoDatabasePath => CoreModule.CurrentProject.DefaultGeodatabasePath;
		internal static string DemoAssaultHotSpotsFC => System.IO.Path.Combine(DemoGeoDatabasePath, DemoAssaultHotSpotsName);
		internal static string DemoAssaultHotSpotsName => "Assault_HotSpots";


		/// <summary>
		/// Using the "Interacting with Maps" sample from Pro SDK community samples
		/// </summary>
		protected override async void OnClick()
		{
			// TODO: Sync: Same work flow as in Async Demo, but using synchronous methods where possible
			try
			{
				#region Setup Map Context
				var mv = MapView.Active;
				var map = mv?.Map;
				if (map == null || MapView.Active.ViewingMode != MapViewingMode.Map)
				{
					throw new Exception("MapView must be 2D");
				}
				// get the crime feature layer
				var crimeLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(DemoCrimeLayer));
				if (crimeLayer == null)
				{
					throw new Exception("Crime layer not found");
				}
				#endregion

				await Geoprocessing.ExecuteToolAsync("SelectLayerByAttribute_management", [DemoCrimeLayer, "NEW_SELECTION", DemoAssaultWhereClause]);
				crimeLayer.ShowOnlySelectedFeatures(DemoCrimeSelection, DemoAssaultWhereClause);
				MapView.Active?.ZoomToSelected(new TimeSpan(0, 0, 1));
				await Geoprocessing.ExecuteToolAsync("FindHotSpots_gapro", [DemoCrimeLayer, DemoAssaultHotSpotsFC, "500 Meters", "1000 Meters", "None", "START_TIME", "None"]);
				MapView.Active?.Map.MoveLayerToIndex(DemoAssaultHotSpotsName, 3);

				// show a message box with the number of features used to find hot spots
				var featureCount = MapView.Active?.Map.ClearAllSelections();
				MessageBox.Show($"Used {featureCount} features to find hot spots");

				//});

				//var featureCount = map.ClearAllSelections();
				// MessageBox should not be used from within QueuedTask.Run
				//MessageBox.Show($"Used {featureCount} features to find hot spots");

				// TODO: Custom Sync/Async: Call your async version of ClearAllSelectionsAsync here
				//var featureCount = await map.ClearAllSelectionsAsync();
				//MessageBox.Show($"Used {featureCount} features to find hot spots");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
			#region Clean up
			{
				var mv = MapView.Active;
				var map = mv?.Map;
				if (map == null || MapView.Active.ViewingMode != MapViewingMode.Map)
				{
					throw new Exception("MapView must be 2D");
				}
				// get the crime feature layer
				var crimeLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(DemoCrimeLayer));
				if (crimeLayer == null)
				{
					throw new Exception("Crime layer not found");
				}
				_ = RestartDemo.CleanupMapAsync(map, mv, crimeLayer, true);
			}
			#endregion
		}
		private static Task<int> AddHotSpotAsync(Map map, MapView mv, FeatureLayer crimeLayer)
		{
			return Task.FromResult(0);
		}
	}
}
