﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.DDL;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using AsyncProgForAddins1.Helpers;

namespace AsyncProgForAddins1.Demos
{
	internal class DemoAsync : Button
	{
		internal static string DemoCrimeLayer => "Crimes";
		internal static string DemoCrimeSelection => "Assault";
		internal static string DemoAssaultWhereClause => "Offense_Type = 5";
		internal static string DemoGeoDatabasePath => CoreModule.CurrentProject.DefaultGeodatabasePath;
		internal static string DemoAssaultHotSpotsFC => System.IO.Path.Combine(DemoGeoDatabasePath, DemoAssaultHotSpotsName);
		internal static string DemoAssaultHotSpotsName => "Assault_HotSpots";


		/// <summary>
		/// Using the "Interacting with Maps" sample from Pro SDK community samples
		/// </summary>
		protected override void OnClick()
		{
			// TODO: Async: Adds an 'Assault' hot spot layer to the map using a Crime data layer
			try
			{

				#region Setup Map Context

				var map = MapView.Active?.Map;
				if (map == null || MapView.Active.ViewingMode != MapViewingMode.Map)
				{
					MessageBox.Show("MapView must be 2D");
					return;
				}
				// get the crime feature layer
				var crimeLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(DemoCrimeLayer));
				if (crimeLayer == null)
				{
					MessageBox.Show("Crime layer not found");
					return;
				}
				var gpStatus = new StringBuilder();
				#endregion

				Geoprocessing.ExecuteToolAsync("SelectLayerByAttribute_management", [DemoCrimeLayer, "NEW_SELECTION", DemoAssaultWhereClause]);
				crimeLayer.ShowOnlySelectedFeaturesAsync(DemoCrimeSelection, DemoAssaultWhereClause);

				// Zoom to the selection (Pro API Async)
				MapView.Active.ZoomToSelectedAsync(new TimeSpan(0, 0, 1));

				// Create the hot spot layer "Assault_HotSpots" using the selected features
				Geoprocessing.ExecuteToolAsync("FindHotSpots_gapro", [DemoCrimeLayer, DemoAssaultHotSpotsFC, "500 Meters", "1000 Meters", "None", "START_TIME", "None"], null, null, (eventName, o) => { if (o is IGPMessage[]) gpStatus.AppendLine($@"GP {eventName} = {string.Join(' ', (o as IGPMessage[]).Select((o) => o.Text).ToList())}"); });
				#region Optional: Check ExecuteToolAsync result
				//var iGpResult = 
				//if (iGpResult.IsFailed)
				//MessageBox.Show($@"{gpStatus.ToString()}", $@"GP Tool Error {iGpResult.ErrorCode}");

				// We are not processing our work flow sequentially.
				// The message is displayed before the "FindHotSpots" GP task is completed.
				// and the hot spot layer is not moved to the top to the table of content.
				#endregion
				MessageBox.Show(DemoAssaultHotSpotsName + " created");

				// Move the hot spot layer to the third position in the table of content for better visibility
				map.MoveLayerToIndexAsync(DemoAssaultHotSpotsName, 3);

				// Clear the selection (since the selected set is not needed anymore)
				map.ClearAllSelections_Async();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}

			#region Clean up
			{
				var mv = MapView.Active;
				var map = mv?.Map;
				if (map == null || MapView.Active.ViewingMode != MapViewingMode.Map)
				{
					throw new Exception("MapView must be 2D");
				}
				// get the crime feature layer
				var crimeLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(DemoCrimeLayer));
				if (crimeLayer == null)
				{
					throw new Exception("Crime layer not found");
				}
				_ = RestartDemo.CleanupMapAsync(map, mv, crimeLayer, true);
			}
			#endregion
		}

	}
}
