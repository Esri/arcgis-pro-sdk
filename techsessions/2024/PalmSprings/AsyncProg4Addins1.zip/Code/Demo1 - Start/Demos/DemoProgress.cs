﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncProgForAddins1.Demos
{
	internal class DemoProgress : Button
	{
		protected async override void OnClick()
		{
			// TODO: Progress: Show the usage of ProgressorSource and CancelableProgressorSource

			// TODO: Progress: 1. Simple ProgressorSource

			//ArcGIS.Desktop.Framework.Threading.Tasks.ProgressorSource

			using (var ps = new ProgressorSource("Doing my thing..."))
			  await QueuedTask.Run(() => 
				{
					//simulate doing some work
					Task.Delay(5000).Wait();
				}, ps.Progressor);//Note progressor as the 2nd argument

			MessageBox.Show("Done with simple Progressor... next with Progress Bar");

			// TODO: Progress: 2. ProgressorSource with progress bar (max and step)
			using (var ps = new ProgressorSource(new ProgressDialog("Doing my thing...", 50)))
				await Module1.Current.RunProgressAsync2(ps, 5, 50);

			MessageBox.Show("Done with Progress Bar ... next with Cancel Button");

			// TODO: Progress: 3. CancelableProgressorSource
			using (var cps = new CancelableProgressorSource(
								"Doing my thing...", "Canceled"))
				await Module1.Current.RunCancelableProgressAsync(cps, 10);

			MessageBox.Show("Done Cancel-able Progress");
		}
	}
}
