﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using System.Threading;

namespace AsyncProgForAddins1
{
	internal class Module1 : Module
	{
		private static Module1 _this = null;
		public CancellationTokenSource _cts = null;
		private static readonly object _lock = new object();

		/// <summary>
		/// Retrieve the singleton instance to this module here
		/// </summary>
		public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("AsyncProgForAddins1_Module");

    public Task RunProgressAsync(ProgressorSource ps, int howLongInSeconds)
    {
      
      return QueuedTask.Run(() => {
        //simulate doing some work
        Task.Delay(howLongInSeconds * 1000).Wait();
      },
      ps.Progressor);//Note progressor as the 2nd argument
    }

    public Task<string> RunProgressAsync2(ProgressorSource ps,
                             double howLongInSeconds,
                             uint max = 100,
                             uint step = 10)
    {

      ps.Progressor.Max = max;
      ps.Progressor.Value = 0;

      StringBuilder sb = new();
      return QueuedTask.Run(() =>
      {
        var num_loops = max / step;
        var delay = howLongInSeconds / num_loops;
        sb.AppendLine($"Delay: {delay} Loops: {num_loops}");
        while (ps.Progressor.Value < ps.Progressor.Max)
        {
          Task.Delay((int)(delay * 1000)).Wait();
          ps.Progressor.Value += step;
          ps.Progressor.Status = $"Value: {ps.Progressor.Value}";
          sb.AppendLine($"ps.Progressor.Value: {ps.Progressor.Value}");
        }
        return sb.ToString();
      }, ps.Progressor);
    }

    public Task RunCancelableProgressAsync(CancelableProgressorSource cps, int howLongInSeconds)
    {
      //simulate doing some work which can be canceled
      return QueuedTask.Run(() => {

        cps.Progressor.Max = (uint)howLongInSeconds;

				// check for cancellation every second
				while (!cps.Progressor.CancellationToken.IsCancellationRequested)
        {
          cps.Progressor.Value += 1;
          //are we done?
          if (cps.Progressor.Value == cps.Progressor.Max) 
            break;
          //Do work
          Task.Delay(1000).Wait();
        }
        System.Diagnostics.Debug.WriteLine(
          $"Canceled? {cps.Progressor.CancellationToken.IsCancellationRequested}");
      }, cps.Progressor);
    }

    public Task RunCancelableProgressAsync2(
      CancellationTokenSource cts, int howLongInSeconds)
    {
			//simulate doing some work which can be canceled
			return QueuedTask.Run(() =>
			{
        var num_loops = 10;
        var delay = (double)howLongInSeconds / num_loops;

        //check for cancellation in regular intervals
        var loop = 0;
        while (loop++ < num_loops)
        {
					// Check for cancellation manually
					if (cts.IsCancellationRequested)
					{
            // handle any clean up
            throw new System.OperationCanceledException();
					}
          //Do work
          Task.Delay((int)(delay * 1000)).Wait();
        }
      });
		}

		public CancellationToken CancelToken => _cts?.Token ?? CancellationToken.None;

    public CancellationTokenSource CancellationTokenSource
		{
      get
			{
        if (_cts == null)
        {
          _cts = new CancellationTokenSource();
        }
        return _cts;
      }
		}
		public bool StartProcess()
		{
			var state = false;
			lock (_lock)
			{
				if (_cts == null)
				{
					state = true;
					_cts = new CancellationTokenSource();
				}
			}
			if (state)
				FrameworkApplication.State.Activate("DemoQueuedTask_SelectProcessIsRunning");
			return state;
		}

		public void StopProcess()
		{
			lock (_lock)
				_cts = null;
			FrameworkApplication.State.Deactivate("DemoQueuedTask_SelectProcessIsRunning");
		}

		public void CancelProcess()
		{
			lock (_lock)
				_cts?.Cancel();
			FrameworkApplication.State.Deactivate("DemoQueuedTask_SelectProcessIsRunning");
		}


		#region Overrides
		/// <summary>
		/// Called by Framework when ArcGIS Pro is closing
		/// </summary>
		/// <returns>False to prevent Pro from closing, otherwise True</returns>
		protected override bool CanUnload()
		{
			//return false to ~cancel~ Application close
			return true;
		}

		#endregion Overrides

	}
}
