﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ArcGIS.Core;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace AsyncProgForAddins1.Helpers
{
	internal static class MapHelper
	{
		// TODO: Custom Sync/Async: Add your async version of ClearAllSelections here

		/// <summary>
		/// ClearAllSelections clears all selections in the map
		/// </summary>
		/// <param name="map"></param>
		/// <returns>the number of selections cleared</returns>
		/// <remarks>Must be called on the MCT.  Use QueuedTask.Run. </remarks>
		public static int ClearAllSelections(this Map map)
		{
			var selectionSet = map.GetSelection();
			map.ClearSelection();
			return selectionSet.Count;
		}
		
		/// <summary>
		/// show only selected features in the crime feature layer
		/// </summary>
		/// <param name="crimeLayer"></param>
		/// <param name="defQueryName"></param>
		/// <param name="whereClause"></param>
		/// <remarks>Must be called on the MCT.  Use QueuedTask.Run. </remarks>
		internal static void ShowOnlySelectedFeatures(this FeatureLayer crimeLayer, string defQueryName, string whereClause)
		{
			// Synchronous… no QueuedTask, no modal UI, context as params
			// Use from within QueuedTask.Run.
			crimeLayer.RemoveAllDefinitionQueries();
			crimeLayer.InsertDefinitionQuery(new DefinitionQuery() { Name = defQueryName, WhereClause = whereClause }, true);
		}

		/// <summary>
		/// show only selected features in the crime feature layer, awaitable
		/// </summary>
		/// <param name="crimeLayer"></param>
		/// <param name="defQueryName"></param>
		/// <param name="whereClause"></param>
		internal static Task ShowOnlySelectedFeaturesAsync(this FeatureLayer crimeLayer, string defQueryName, string whereClause)
		{
			// Asynchronous alternative… can be called from the UI awaitable

			return QueuedTask.Run(() =>
			{
				crimeLayer.ShowOnlySelectedFeatures(defQueryName, whereClause);
			});
		}

		/// <summary>
		/// MoveLayerToTop moves the specified layer to the specified index of the map TOC
		/// </summary>
		/// <param name="map"></param>
		/// <param name="layerName">Name of layer to move</param>
		/// <param name="tocIndex">Move the layer to this TOC position</param>
		/// <remarks>Must be called on the MCT.  Use QueuedTask.Run. </remarks>
		public static void MoveLayerToIndex(this Map map, string layerName, int tocIndex)
		{
			var moveLayer = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(layerName));
			if (moveLayer != null)
			{
				map.MoveLayer(moveLayer, tocIndex);
				moveLayer.SetTransparency(50);
			}
		}

		/// <summary>
		/// MoveLayerToTop moves the specified layer to the top of the map, await-able can be called from the UI
		/// </summary>
		/// <param name="map"></param>
		/// <param name="layerName">Name of layer to move</param>
		/// <param name="tocIndex">Move the layer to this TOC position</param>
		/// <returns>Task</returns>
		public static Task MoveLayerToIndexAsync(this Map map, string layerName, int tocIndex)
		{
			return QueuedTask.Run(() =>
			{
				map.MoveLayerToIndex (layerName, tocIndex);
			});
		}


		/// <summary>
		/// ClearAllSelections clears all selections in the map, await-able can be called from the UI
		/// </summary>
		/// <param name="map"></param>
		/// <returns>the number of selections cleared</returns>
		public static Task<int> ClearAllSelections_Async(this Map map)
		{
			return QueuedTask.Run<int>(() =>
			{
				return map.ClearAllSelections();
			});
		}

		public static int SelectWithExtent(this MapView mv, double delta, bool asRatio)
		{
			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			//select features in the middle of the mapview
			if (mv.ViewingMode != ArcGIS.Core.CIM.MapViewingMode.Map)
				throw new ArgumentException("MapView must be 2D");

			var extent = mv.Extent.Expand(0.5, 0.5, true);
			var sel = mv.SelectFeatures(extent);
			mv.ZoomToSelected(new TimeSpan(0, 0, 2));
			
			return sel.ToDictionary().Values.Sum(oids => oids.Count());
		}

		public static Task<int> SelectWithExtentAsync(this MapView mv,
			double delta, bool asRatio)
		{
			return QueuedTask.Run(() =>
			{
				return mv.SelectWithExtent(delta, asRatio);
			});
		}

		//Using the CancelableProgressorSource
		internal static Task<bool> SelectAndProcessFeaturesAsync(
			this MapView mv, double delta, bool asRatio,
			CancelableProgressorSource progSource)
		{
			return QueuedTask.Run(() =>
			{
				return mv.SelectAndProcessFeatures(delta, asRatio, progSource);
			}, progSource.Progressor);
		}

		internal static bool SelectAndProcessFeatures(
				 this MapView mv, double delta, bool asRatio,
				 CancelableProgressorSource progSource)
		{
			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			//select features in the middle of the mapview
			if (mv.ViewingMode != ArcGIS.Core.CIM.MapViewingMode.Map)
				throw new ArgumentException("MapView must be 2D");

			var extent = mv.Extent.Expand(delta, delta, asRatio);
			var selection = mv.SelectFeatures(extent);

			var sel_dict = selection.ToDictionary();
			progSource.Progressor.Max = (uint)sel_dict.Keys.Count();
			progSource.Value = 0;

			foreach (var featureLayer in sel_dict.Keys)
			{
				progSource.Status = $"{featureLayer.Name}";
				progSource.Value++;

				foreach (var oid in sel_dict.Values)
				{
					//Have we been canceled?
					progSource.CancellationTokenSource.Token.ThrowIfCancellationRequested();
				}
				//Simulate processing
				try
				{
					Task.Delay(2000, progSource.CancellationTokenSource.Token).Wait();
				}
				catch (AggregateException ae)
				{
					if (ae.InnerExceptions.Any(e => e is TaskCanceledException))
						progSource.CancellationTokenSource.Token.ThrowIfCancellationRequested();
				}
			}
			return true;
		}

		//Using the Cancel Token
		internal static Task<bool> SelectAndProcessFeatures2Async(
										this MapView mv, double delta, bool asRatio,
										CancellationToken token)
		{
			return QueuedTask.Run(() =>
			{
				return mv.SelectAndProcessFeatures2(delta, asRatio, token);
			});
		}

		internal static bool SelectAndProcessFeatures2(
				this MapView mv, double delta, bool asRatio,
				CancellationToken token)
		{
			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			if (!QueuedTask.OnWorker)
				throw new CalledOnWrongThreadException();

			//select features in the middle of the mapview
			if (mv.ViewingMode != ArcGIS.Core.CIM.MapViewingMode.Map)
				throw new ArgumentException("MapView must be 2D");

			var extent = mv.Extent.Expand(delta, delta, asRatio);
			var selection = mv.SelectFeatures(extent);
			var sel_dict = selection.ToDictionary();

			foreach (var featureLayer in sel_dict.Keys)
			{
				OperationCanceledException oce;
				foreach (var oid in sel_dict.Values)
				{
					//Have we been canceled?
					token.ThrowIfCancellationRequested();
				}
				//Simulate processing
				try
				{
					Task.Delay(2000, token).Wait();
				}
				catch (AggregateException ae)
				{
					if (ae.InnerExceptions.Any(e => e is TaskCanceledException))
						token.ThrowIfCancellationRequested();
				}
			}
			return true;
		}

		public static Task ClearSelectAsync(this MapView mv)
		{
			return QueuedTask.Run(() =>
			{
				var feat_layers = mv.Map.GetLayersAsFlattenedList().OfType<BasicFeatureLayer>();
				foreach (var fl in feat_layers)
					fl.ClearSelection();
			});
		}
	}
}
