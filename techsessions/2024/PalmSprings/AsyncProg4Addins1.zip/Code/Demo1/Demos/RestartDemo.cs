﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.DDL;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Internal.CIM;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AsyncProgForAddins1.Demos
{
	internal class RestartDemo : Button
	{
		protected async override void OnClick()
		{
			var mv = MapView.Active;
			var map = mv?.Map;
			if (map == null)
				return;
			try
			{
				// remove some unwanted dockpanes
				var unwantedDockPanes = FrameworkApplication.DockPaneManager.DockPanes.Where(d => d.ID.Contains("esri_core_projectHistoryDockPane"));
				foreach (var pane in unwantedDockPanes)
				{
					pane.Hide();
				}
				var wantedDockPanes = FrameworkApplication.DockPaneManager.DockPanes.Where(d => d.ID.Contains("esri_core_contentsDockPane"));
				foreach (var pane in wantedDockPanes)
				{
					pane.Activate(true);
				}
				var removeLayers = MapView.Active.Map.GetLayersAsFlattenedList().
										OfType<FeatureLayer>().
										Where(fl => fl.Name.Equals(DemoAsync.DemoAssaultHotSpotsName));
				await QueuedTask.Run(() =>
				{
					map.RemoveLayers(removeLayers);
				});

				await QueuedTask.Run(() =>
				{
					// Opens a file geodatabase. This will open the geodatabase if the folder exists and contains a valid geodatabase.
					using (
						Geodatabase geodatabase = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(DemoAsync.DemoGeoDatabasePath))))
					{
						// Delete the HostSpots feature class if it exists
						if (FeatureClassExists (geodatabase, DemoAsync.DemoAssaultHotSpotsName))
						{
							DeleteFeatureClass(geodatabase, geodatabase.OpenDataset<FeatureClass>(DemoAsync.DemoAssaultHotSpotsName));
						}
					}
				});

				// get the crime feature layer
				var crimeLayer = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(DemoAsync.DemoCrimeLayer));
				if (crimeLayer == null)
				{
					MessageBox.Show("Crime layer not found");
					return;
				}
				// Change the visible features to show only the selected features
				await QueuedTask.Run(() =>
				{
					crimeLayer.RemoveAllDefinitionQueries();
					crimeLayer.ClearSelection();
				});
				var cam = mv.Camera;
				cam.Scale = cam.Scale * 1.1;
				await mv.ZoomToAsync(cam, new TimeSpan(0, 0, 1));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		// Must be called within QueuedTask.Run()
		public bool FeatureClassExists(Geodatabase geodatabase, string featureClassName)
		{
			try
			{
				FeatureClassDefinition featureClassDefinition = geodatabase.GetDefinition<FeatureClassDefinition>(featureClassName);
				featureClassDefinition.Dispose();
				return true;
			}
			catch
			{
				// GetDefinition throws an exception if the definition doesn't exist
				return false;
			}
		}

		public void DeleteFeatureClass(Geodatabase geodatabase, FeatureClass featureClass)
		{
			// Create a FeatureClassDescription object
			FeatureClassDescription featureClassDescription = new FeatureClassDescription(featureClass.GetDefinition());

			// Create a SchemaBuilder object
			SchemaBuilder schemaBuilder = new SchemaBuilder(geodatabase);

			// Add the deletion fo the feature class to our list of DDL tasks
			schemaBuilder.Delete(featureClassDescription);

			// Execute the DDL
			bool success = schemaBuilder.Build();
		}
	}
}
