﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.DDL;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using AsyncProgForAddins1.Helpers;

namespace AsyncProgForAddins1.Demos
{
	internal class DemoAsync : Button
	{
		internal static string DemoCrimeLayer => "Crimes";
		internal static string DemoCrimeSelection => "Assault";
		internal static string DemoAssaultWhereClause => "Offense_Type = 5";
		internal static string DemoGeoDatabasePath => CoreModule.CurrentProject.DefaultGeodatabasePath;
		internal static string DemoAssaultHotSpotsFC => System.IO.Path.Combine(DemoGeoDatabasePath, DemoAssaultHotSpotsName);
		internal static string DemoAssaultHotSpotsName => "Assault_HotSpots";


		/// <summary>
		/// Using the "Interacting with Maps" sample from Pro SDK community samples
		/// </summary>
		protected override async void OnClick()
		{
			// TODO: Async: Goal of this work flow is to create a hot spot map
			// of 'Assault' type crimes using asynchronous methods 
			try
			{
				var map = MapView.Active?.Map;

				#region Input validation
				if (map == null || MapView.Active.ViewingMode != MapViewingMode.Map)
				{
					MessageBox.Show("MapView must be 2D");
					return;
				}
				// get the crime feature layer
				var crimeLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(DemoCrimeLayer));
				if (crimeLayer == null)
				{
					MessageBox.Show("Crime layer not found");
					return;
				}
				#endregion

				// TODO: Async: 1. show the use of Async methods invoked from the UI thread
				// select all 'Assault' crimes (where clause: Offense_Type is 5)

				await Geoprocessing.ExecuteToolAsync("SelectLayerByAttribute_management", [DemoCrimeLayer, "NEW_SELECTION", DemoAssaultWhereClause]);

				// Change the crime layer to show only selected features as visible

				await crimeLayer.ShowOnlySelectedFeaturesAsync(DemoCrimeSelection, DemoAssaultWhereClause);

				// Zoom to the selected features (has a synchronous equivalent: ZoomToSelected)

				// TODO: Async: 2. MapView.Active.ZoomToSelectedAsync has a synchronous equivalent: ZoomToSelected
				await MapView.Active.ZoomToSelectedAsync(new TimeSpan(0, 0, 3));

				// create the hot spot "DemoAssaultHotSpotsFC" using the selected features

				var iGpResult = await Geoprocessing.ExecuteToolAsync("FindHotSpots_gapro", [DemoCrimeLayer, DemoAssaultHotSpotsFC, "500 Meters", "1000 Meters", "None", "START_TIME", "None"]);
				if (iGpResult.IsFailed)
					MessageBox.Show($@"GP failed with code: {iGpResult.ErrorCode}", "Geoprocessing Error");
				// TODO: Async: 3. We are not processing our work flow sequentially.
				// The message is displayed before the "FindHotSpots" GP task is completed.
				// and the hot spot layer is not moved to the top to the table of content.
				//MessageBox.Show(DemoAssaultHotSpotsName + " created");

				// TODO: Async: 4. Sequentially execute the above steps using Async/Await
				// TODO: Async: 5. Let's examine the ExecuteToolAsync method's return value
				// TODO: Async: 6. try / catch block to handle exceptions for all awaited tasks

				// move the hot spot layer to the top and clear the selection
				await map.MoveLayerToIndexAsync(DemoAssaultHotSpotsName, 3);
				await map.ClearAllSelectionsAsync();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

	}
}
