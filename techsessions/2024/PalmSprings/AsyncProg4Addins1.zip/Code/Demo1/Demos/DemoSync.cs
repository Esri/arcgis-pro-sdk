﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.DDL;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using AsyncProgForAddins1.Helpers;

namespace AsyncProgForAddins1.Demos
{
	internal class DemoSync : Button
	{
		internal static string DemoCrimeLayer => "Crimes";
		internal static string DemoCrimeSelection => "Assault";
		internal static string DemoAssaultWhereClause => "Offense_Type = 5";
		internal static string DemoGeoDatabasePath => CoreModule.CurrentProject.DefaultGeodatabasePath;
		internal static string DemoAssaultHotSpotsFC => System.IO.Path.Combine(DemoGeoDatabasePath, DemoAssaultHotSpotsName);
		internal static string DemoAssaultHotSpotsName => "Assault_HotSpots";


		/// <summary>
		/// Using the "Interacting with Maps" sample from Pro SDK community samples
		/// </summary>
		protected override async void OnClick()
		{
			// TODO: Sync: Goal of this work flow is to create a hot spot map
			// of 'Assault' type crimes using synchronous methods

			#region Setup Context

			var map = MapView.Active?.Map;
			if (map == null || MapView.Active.ViewingMode != MapViewingMode.Map)
			{
				MessageBox.Show("MapView must be 2D");
				return;
			}
			// get the crime feature layer
			var crimeLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.Name.Equals(DemoCrimeLayer));
			if (crimeLayer == null)
			{
				MessageBox.Show("Crime layer not found");
				return;
			}
			#endregion

			try
			{
				// TODO: Sync: 1. Submit code in the form of a delegate/anonymous
				// lambda to QueuedTask.Run
				// TODO: Sync: 2. Use same async/await semantics as with Async methods 
				await QueuedTask.Run(async () =>
				{
					// select all 'Assault' crimes (where clause: Offense_Type is 5)

					// TODO: Sync: 3. When calling asynchronous methods _within_ a QueuedTask use async/await 
					await Geoprocessing.ExecuteToolAsync("SelectLayerByAttribute_management", [DemoCrimeLayer, "NEW_SELECTION", DemoAssaultWhereClause]);

					// Change the crime layer to show only selected features as visible

					crimeLayer.ShowOnlySelectedFeatures(DemoCrimeSelection, DemoAssaultWhereClause);

					// Zoom to the selected features (has a synchronous equivalent: ZoomToSelected)

					// TODO: Sync: 4. Show help for the synchronous methods requiring QueuedTask.Run
					// This method must be called on the MCT. Use QueuedTask.Run.
					MapView.Active.ZoomToSelected(new TimeSpan(0, 0, 3));

					// create the hot spot "DemoAssaultHotSpotsFC" using the selected features

					await Geoprocessing.ExecuteToolAsync("FindHotSpots_gapro", [DemoCrimeLayer, DemoAssaultHotSpotsFC, "500 Meters", "1000 Meters", "None", "START_TIME", "None"]);

					// TODO: Sync: 5. Avoid showing MessageBoxes, Dialogs, or other modal UI 
					MessageBox.Show(DemoAssaultHotSpotsName + " created");

					// TODO: Sync: 6. Capture application context/state on the UI -for use within QueuedTask- 

					// move the hot spot layer to the top and clear the selection
					map.MoveLayerToIndex(DemoAssaultHotSpotsName, 3);

					// TODO: Sync: 7. Handle return from QueuedTask 

					//var featureCount = map.ClearAllSelections();
					//MessageBox.Show($"Used {featureCount} features to find hot spots");
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
			// TODO: Custom: Create you own asynchronous and synchronous methods and extension methods
			// TODO: Custom: 1. ClearAllSelections is a synchronous method that can be called from within QueuedTask.Run
			// TODO: Custom: 2. ClearAllSelectionsAsync is the asynchronous alternative that can be called from the UI
			var featureCount = await map.ClearAllSelectionsAsync();
			MessageBox.Show($"Used {featureCount} features to find hot spots");
		}

	}
}
