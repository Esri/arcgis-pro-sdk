﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncProgForAddins1.Demos
{

	internal class CancelProcess : Button
	{
		protected override void OnClick()
		{
			Module1.Current.CancelProcess();
		}
	}

	internal class RunProcess : Button
	{
		protected async override void OnClick()
		{
			try
			{
				// TODO: Cancelable Progress: Show how to implement a cancelable progressor
				await Module1.Current.RunCancelableProgressAsync2(
					Module1.Current.CancellationTokenSource, 5);
				MessageBox.Show("Process completed ok", "Completed");
			}
			catch(System.OperationCanceledException oce)
			{
				MessageBox.Show("Canceled", "Canceled");
			}
			finally
			{
				Module1.Current.StopProcess();
			}
		}
	}
}
