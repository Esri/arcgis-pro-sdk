﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo3_ForKG2 : Button
  {
    protected override void OnClick()
    {
      var map = MapView.Active?.Map;
      if (map == null) return;
      var kg_layer = map.GetLayersAsFlattenedList()
                        .OfType<KnowledgeGraphLayer>().FirstOrDefault();
      if (kg_layer == null)
        return;

      //get the poly from the graphics layer
      var gl = map.GetLayersAsFlattenedList().OfType<GraphicsLayer>().FirstOrDefault();
      if (gl == null) return;

      QueuedTask.Run(async () =>
      {

        //connect to the KG datastore
        using (var kg = kg_layer.GetDatastore())
        {
          var oids = new List<long>() { 3,4,7,8,9,11,12,14,15,19,21,25,29,
            31,32,36,37,51,53,54,55,56,59,63,75,78,80,84,86,88,96,97,98,101,
            103,106};

          var elem = gl.GetElementsAsFlattenedList().First();
          var poly = elem.GetGeometry() as Polygon;

          var qry = @"MATCH (p:PhoneNumber) " +
                    @"WHERE p.objectid IN $object_ids AND " +
                    @"esri.graph.ST_Intersects($sel_geom, p.shape) " +
                    @"RETURN p";
          //create a KG query filter
          var kg_qry_filter = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };

          var kg_oid_array = new KnowledgeGraphArrayValue();
          kg_oid_array.AddRange(oids);
          kg_qry_filter.BindParameters["object_ids"] = kg_oid_array;
          kg_qry_filter.BindParameters["sel_geom"] = poly;
          oids.Clear();

          //Submit query using "SubmitQuery" returns a KG Row Cursor
          using (var kgRowCursor = kg.SubmitQuery(kg_qry_filter))
          {
            //wait for rows to be returned asynchronously from the server
            while (await kgRowCursor.WaitForRowsAsync())
            {
              //get the rows using "standard" move next
              while (kgRowCursor.MoveNext())
              {
                //current row is accessible via ".Current" prop of the cursor
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  var cell_phone = graphRow[0] as KnowledgeGraphEntityValue;
                  var oid = cell_phone.GetObjectID();
                  oids.Add(oid);

                  var name = (string)cell_phone["FULL_NAME"];
                  var ph_number = (string)cell_phone["PHONE_NUMBER"];
                  System.Diagnostics.Debug.WriteLine(
                    $"[{oid}] {name}, {ph_number}");

                  #endregion
                }
              }
            }
          }

          if (oids.Count > 0)
          {
            //select them on the layer
            var qf = new QueryFilter()
            {
              ObjectIDs = oids
            };
            var phone_number_fl = kg_layer.GetLayersAsFlattenedList()
      .OfType<FeatureLayer>().First(l => l.Name == "PhoneNumber");
            phone_number_fl.Select(qf);
          }
        }
      });
    }
  }
}
