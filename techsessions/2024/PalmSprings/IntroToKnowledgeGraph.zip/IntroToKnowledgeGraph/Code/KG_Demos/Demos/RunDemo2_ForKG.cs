﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo2_ForKG : Button
  {
    protected override void OnClick()
    {
			var map = MapView.Active?.Map;
			if (map == null) return;
			var kg_layer = map.GetLayersAsFlattenedList()
												.OfType<KnowledgeGraphLayer>().FirstOrDefault();
			if (kg_layer == null)
				return;

			QueuedTask.Run(async () =>
      {
				//connect to the KG datastore
				//var kg_uri = new Uri(Module1.KG_URL);
				//var kg_conn = new KnowledgeGraphConnectionProperties(kg_uri);
				//var kg = new KnowledgeGraph(kg_conn)

				using (var kg = kg_layer.GetDatastore())
        {
          //Select * From PhoneNumber LIMIT 10 (or TOP 10)
          var qry = @"MATCH (p:PhoneNumber) RETURN p LIMIT 10";
          //create a KG query filter
          var kg_qry_filter = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };

          System.Diagnostics.Debug.WriteLine("\r\n\r\nQuery results:\r\n\r\n");
          //Submit query using "SubmitQuery" returns a KG Row Cursor
          using (var kgRowCursor = kg.SubmitQuery(kg_qry_filter))
          {
            //wait for rows to be returned asynchronously from the server
            while (await kgRowCursor.WaitForRowsAsync())
            {
              //get the rows using "standard" move next
              while (kgRowCursor.MoveNext())
              {
                //current row is accessible via ".Current" prop of the cursor
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  var cell_phone = graphRow[0] as KnowledgeGraphEntityValue;

                  //Use [] indexer to access individual property values
                  var oid = cell_phone.GetObjectID();
                  var full_name = (string)cell_phone["FULL_NAME"];
                  var cell = (string)cell_phone["PHONE_NUMBER"];
                  var city = (string)cell_phone["CITY"];
                  var loc = (MapPoint)cell_phone["shape"];

                  System.Diagnostics.Debug.WriteLine(
                    $"PhoneNumber[{oid}] {full_name}, {cell}, {city}");
                  #endregion
                }
              }
            }
          }

					//Query2 - multiple returns
					var qry2 = @"MATCH (p1:PhoneNumber)-[r1:MADE_CALL|RECEIVED_CALL]" +
						 @"->(c1:PhoneCall)<-[r2:MADE_CALL|RECEIVED_CALL]-(p2:PhoneNumber) " +
						 @"WHERE p1.FULL_NAME <> p2.FULL_NAME " +
						 @"RETURN p1.FULL_NAME, c1.START_DATE, c1.DURATION, p2 LIMIT 10";

					//create a KG query filter
					var kg_qry_filter2 = new KnowledgeGraphQueryFilter()
					{
						QueryText = qry2
					};

					//Submit query using "SubmitQuery" returns a KG Row Cursor
					using (var kgRowCursor = kg.SubmitQuery(kg_qry_filter2))
					{
						int row = 0;
						//wait for rows to be returned asynchronously from the server
						while (await kgRowCursor.WaitForRowsAsync())
						{
							//get the rows using "standard" move next
							while (kgRowCursor.MoveNext())
							{
								//current row is accessible via ".Current" prop of the cursor
								using (var graphRow = kgRowCursor.Current)
								{
									#region Process Row
									//"RETURN p1.FULL_NAME, c1.START_DATE, c1.DURATION, p2"
									//will return 3 primitive values: Name, Date, Duration, and
									//the entity "p2". So our row array will hold 4 values...
									var full_name = (string)graphRow[0];
									var call_date = (DateTimeOffset)graphRow[1];
									var call_mins = (long)graphRow[2];
									var person_called = graphRow[3] as KnowledgeGraphEntityValue;

									var person_called_name = (string)person_called["FULL_NAME"];
									var cell_called = (string)person_called["PHONE_NUMBER"];
									var city = (string)person_called["CITY"];

									var date_str = call_date.DateTime.ToString("G");

									System.Diagnostics.Debug.WriteLine(
										$"[{row++}] {full_name} called {person_called_name} @{date_str} for {call_mins}, {city}");

									#endregion
								}
							}
						}
					}

					//Search does a full text search
					//Uses Apache Lucene Query Parser syntax
					//https://lucene.apache.org/core/2_9_4/queryparsersyntax.html

					var kg_srch_filter = new KnowledgeGraphSearchFilter()
          {
            SearchTarget = KnowledgeGraphNamedTypeCategory.Entity,
            SearchText = "Redlands",
            MaxRowCount = 10 //Default is 100 if not specified
          };

          var e = 0;
          System.Diagnostics.Debug.WriteLine("\r\n\r\nSearch results:\r\n\r\n");
          using (var kgRowCursor = kg.SubmitSearch(kg_srch_filter))
          {
            //wait for rows to be returned asynchronously from the server
            while (await kgRowCursor.WaitForRowsAsync())
            {
              //get the rows using "standard" move next
              while (kgRowCursor.MoveNext())
              {
                //current row is accessible via ".Current" prop of the cursor
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  //We are returning entities from this search
                  var entity = graphRow[0] as KnowledgeGraphEntityValue;
                  var entity_type = entity.GetTypeName();
                  var record = new List<string>();
                  //discover keys(aka "fields") dynamically via GetKeys
                  foreach (var prop_name in entity.GetKeys())
                  {
                    var obj_val = entity[prop_name] ?? "null";
                    record.Add(obj_val.ToString());
                  }
                  System.Diagnostics.Debug.WriteLine(
                    $"{entity_type}[{e++}] " + string.Join(", ", record));
                  
                  #endregion
                }
              }
            }
          }
        }
      });
    }
  }
}
