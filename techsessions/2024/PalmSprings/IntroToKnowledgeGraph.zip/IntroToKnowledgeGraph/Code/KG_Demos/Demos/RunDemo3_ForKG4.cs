﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace KG_Demos.Demos
{
  internal class RunDemo3_ForKG4 : Button
  {
		protected async override void OnClick()
		{
			var map = MapView.Active?.Map;
			if (map == null) return;
			var kg_layer = map.GetLayersAsFlattenedList()
												.OfType<KnowledgeGraphLayer>().FirstOrDefault();
			if (kg_layer == null)
				return;

			var pane = await QueuedTask.Run(async () =>
			{
				using (var kg = kg_layer.GetDatastore())
				{
					var dict = new Dictionary<string, List<long>>();
					dict["Suspects"] = new List<long>();

					var qry2 = "MATCH (s:Suspects) RETURN s";

					var graphQuery = new KnowledgeGraphQueryFilter()
					{
						QueryText = qry2
					};

					System.Diagnostics.Debug.WriteLine("\r\n\r\nAppend to link chart:\r\n\r\n");

					using (var kgRowCursor = kg.SubmitQuery(graphQuery))
					{
						while (await kgRowCursor.WaitForRowsAsync())
						{
							while (kgRowCursor.MoveNext())
							{
								using (var graphRow = kgRowCursor.Current)
								{
									#region Process Row

									var obj_val = graphRow[0] as KnowledgeGraphNamedObjectValue;
									var oid = (long)obj_val.GetObjectID();
									dict["Suspects"].Add(oid);

									#endregion
								}
							}
						}
					}
					//make an ID Set to create the LinkChart
					var idSet = KnowledgeGraphLayerIDSet.FromDictionary(kg, dict);
					//Append to the previously created linkchart

					var mapPanes = FrameworkApplication.Panes.OfType<IMapPane>().ToList();
					var mapPane = mapPanes.FirstOrDefault(mp => mp.MapView.IsLinkChartView);
					var linkChartMap = mapPane.MapView.Map;

					linkChartMap.AppendToLinkChart(idSet);
					return mapPane as Pane;
				}
			});

			pane.Activate();

		}
	}
}
