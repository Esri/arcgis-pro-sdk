﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.Internal.CIM;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo1_ForKG : Button
  {
    protected override void OnClick()
    {
			var map = MapView.Active?.Map;
			if (map == null) return;

			QueuedTask.Run(() =>
      {
        //connect to the KG datastore
        var kg_uri = new Uri(Module1.KG_URL);
        var kg_conn = new KnowledgeGraphConnectionProperties(kg_uri);
        
        using (var kg = new KnowledgeGraph(kg_conn))
				{
          //Graph "side" - Entities and relationships
          var kg_datamodel = kg.GetDataModel();
					//Entity and Relate types are the corrollary to FeatureClass
					//and Table Definitions on the GDB side
					
					var entities = kg_datamodel.GetEntityTypes();
          var relationships = kg_datamodel.GetRelationshipTypes();
          var provenance = kg_datamodel.GetMetaEntityTypes();

          var all_graph_types = new List<KnowledgeGraphNamedObjectType>();
					all_graph_types.AddRange(entities.Values);
					all_graph_types.AddRange(relationships.Values);
					all_graph_types.AddRange(provenance.Values);

					System.Diagnostics.Debug.WriteLine("\r\nGraph Types");

          int c = 0;
          foreach (var graph_type in all_graph_types)
          {
            //var fields = fc_def.GetFields().Select(f => f.Name).ToList();
            //var field_names = string.Join(",", fields);
            var type_name = graph_type.GetName();
						var props = graph_type.GetProperties().Select(p => p.Name).ToList();
            var prop_names = string.Join(",", props);
            var role = graph_type.GetRole().ToString();

            System.Diagnostics.Debug.WriteLine($"[{c++}]: " +
                $"{type_name}, {role}, {prop_names}");
          }
				}

      });
    }
  }
}
