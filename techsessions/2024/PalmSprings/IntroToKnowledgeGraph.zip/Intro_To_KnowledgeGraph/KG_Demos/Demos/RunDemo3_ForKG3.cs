﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo3_ForKG3 : Button
  {
		protected override void OnClick()
		{
			var map = MapView.Active?.Map;
			if (map == null) return;
			var kg_layer = map.GetLayersAsFlattenedList()
												.OfType<KnowledgeGraphLayer>().FirstOrDefault();
			if (kg_layer == null)
				return;

			var qry = @"MATCH (p1:PhoneNumber)-[r1:MADE_CALL|RECEIVED_CALL]->(c1:PhoneCall)<-" +
								@"[r2:MADE_CALL|RECEIVED_CALL]-(p2:PhoneNumber)-[r3:MADE_CALL|RECEIVED_CALL]" +
								@"->(c2:PhoneCall)<-[r4:MADE_CALL|RECEIVED_CALL]-(p3:PhoneNumber) " +
								@"WHERE p1.FULL_NAME = ""Robert Johnson"" AND " +
								@"p3.FULL_NAME= ""Dan Brown"" AND " +
								@"p1.globalid <> p2.globalid AND " +
								@"p2.globalid <> p3.globalid " +
								@"RETURN p1, r1, c1, r2, p2, r3, c2, r4, p3";

			var dict = new Dictionary<string, List<long>>();

			QueuedTask.Run(async () =>
			{
				using (var kg = kg_layer.GetDatastore())
				{
					var graphQuery = new KnowledgeGraphQueryFilter()
					{
						QueryText = qry
					};

					System.Diagnostics.Debug.WriteLine("\r\n\r\nCreate link chart:\r\n\r\n");

					using (var kgRowCursor = kg.SubmitQuery(graphQuery))
					{
						while (await kgRowCursor.WaitForRowsAsync())
						{
							while (kgRowCursor.MoveNext())
							{
								using (var graphRow = kgRowCursor.Current)
								{
									#region Process Row

									var cnt_val = (int)graphRow.GetCount();
									for (int v = 0; v < cnt_val; v++)
									{
										var obj_val = graphRow[v] as KnowledgeGraphNamedObjectValue;
										var type_name = obj_val.GetTypeName();
										var oid = (long)obj_val.GetObjectID();
										if (!dict.ContainsKey(type_name))
										{
											dict[type_name] = new List<long>();
										}
										if (!dict[type_name].Contains(oid))
											dict[type_name].Add(oid);
									}
									#endregion
								}
							}
						}
					}
					//make an ID Set to create the LinkChart
					var idSet = KnowledgeGraphLayerIDSet.FromDictionary(kg, dict);

					//Create the link chart and show it
					var linkChart = MapFactory.Instance.CreateLinkChart(
														"KG Intro", kg, idSet);
					FrameworkApplication.Panes.CreateMapPaneAsync(linkChart);
				}
			});
		}
	}
}
