﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
	internal class RunDemo1_ForKG3 : Button
	{
		protected override void OnClick()
		{
			var map = MapView.Active?.Map;
			if (map == null)
				return;

			QueuedTask.Run(() =>
			{
				var kg_uri = new Uri(Module1.KG_URL);
				var kg_conn = new KnowledgeGraphConnectionProperties(kg_uri);
				using (var kg = new KnowledgeGraph(kg_conn))
				{
					var fc = kg.OpenDataset<FeatureClass>("PhoneNumber");
					//Create a feature layer containing Phone Number
					//NOT ALLOWED - can only be a child of a KG layer
					try
					{
						var fl_params = new FeatureLayerCreationParams(fc);
						if (LayerFactory.Instance.CanCreateLayer<FeatureLayer>(
							fl_params, map))
						{
							//Will throw
							LayerFactory.Instance.CreateLayer<FeatureLayer>(
								fl_params, map);
						}
					}
					catch(Exception ex)
					{
						System.Diagnostics.Debug.WriteLine(ex.ToString());
					}

					//Can only be added as a child of the parent KG
					var dict = new Dictionary<string, List<long>>();
					dict.Add(fc.GetName(), new List<long>());
					var kg_params = new KnowledgeGraphLayerCreationParams(kg)
					{
						Name = $"KG_With_Just_{fc.GetName()}",
						IsVisible = false,
						IDSet = KnowledgeGraphLayerIDSet.FromDictionary(kg, dict)
					};
					var kg_layer = LayerFactory.Instance.CreateLayer<KnowledgeGraphLayer>(
						kg_params, map);

					var layer_id_set = kg_layer.GetIDSet();
					var oids_by_type = layer_id_set.ToOIDDictionary();//Empty list means all records
				}
			});
		}
	}
}
