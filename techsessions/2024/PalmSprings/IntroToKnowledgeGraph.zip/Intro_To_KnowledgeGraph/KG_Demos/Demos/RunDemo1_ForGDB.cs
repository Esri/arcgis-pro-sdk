﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo1_ForGDB : Button
  {
    protected override void OnClick()
    {

      QueuedTask.Run(() =>
      {
        //connect to the KG datastore
        var kg_uri = new Uri(Module1.KG_URL);
        var kg_conn = new KnowledgeGraphConnectionProperties(kg_uri);

        using (var kg = new KnowledgeGraph(kg_conn))
        {
          //Geodatabase "side" - only feature classes and tables

          var fc_defs = kg.GetDefinitions<FeatureClassDefinition>();
          var tbl_defs = kg.GetDefinitions<TableDefinition>();

          int c = 0;
          foreach (var fc_def in fc_defs)
          {
            var fields = fc_def.GetFields().Select(f => f.Name).ToList();
            var field_names = string.Join(",", fields);
            System.Diagnostics.Debug.WriteLine(
              $"FeatureClass Def[{c++}] {fc_def.GetName()}, {field_names}");
          }
          c = 0;
          foreach (var tbl_def in tbl_defs)
          {
            var fields = tbl_def.GetFields().Select(f => f.Name).ToList();
            var field_names = string.Join(",", fields);
            System.Diagnostics.Debug.WriteLine(
              $"Table Def[{c++}] {tbl_def.GetName()}, {field_names}");
          }
          //Retrieve FeatureClass or Table:
          var fc_name = fc_defs[0].GetName();
          //using (var tbl = kg.OpenDataset<Table>(tbl_name))
          using (var fc = kg.OpenDataset<FeatureClass>(fc_name))
          {
            System.Diagnostics.Debug.WriteLine(
               $"FeatureClass: {fc.GetName()}, count: {fc.GetCount()}");

            //using(var rc = fc.Search(null)) //or Select(...)
            //{
            //  while(rc.MoveNext())
            //  {
            //    var row = rc.Current;
            //    //etc
            //  }
            //}
          }
        }
      });
      
    }
  }
}
