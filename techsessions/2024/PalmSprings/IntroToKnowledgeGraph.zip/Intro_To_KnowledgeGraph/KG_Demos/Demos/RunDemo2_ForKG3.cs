﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo2_ForKG3 : Button
  {
    protected override void OnClick()
    {
      var map = MapView.Active?.Map;
      if (map == null) return;
      var kg_layer = map.GetLayersAsFlattenedList()
                        .OfType<KnowledgeGraphLayer>().FirstOrDefault();
      if (kg_layer == null)
        return;

      QueuedTask.Run(async () =>
      {
        //connect to the KG datastore
        using (var kg = kg_layer.GetDatastore())
        {
          var qry = @"MATCH (p:PhoneNumber) RETURN p LIMIT 10";
          //create a KG query filter
          var kg_qry_filter = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry
          };

					System.Diagnostics.Debug.WriteLine("\r\n\r\nMap selection:\r\n\r\n");

					var oids = new List<long>();
          //Submit query using "SubmitQuery" returns a KG Row Cursor
          using (var kgRowCursor = kg.SubmitQuery(kg_qry_filter))
          {
            //wait for rows to be returned asynchronously from the server
            while (await kgRowCursor.WaitForRowsAsync())
            {
              //get the rows using "standard" move next
              while (kgRowCursor.MoveNext())
              {
                //current row is accessible via ".Current" prop of the cursor
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row

                  var cell_phone = graphRow[0] as KnowledgeGraphEntityValue;
                  oids.Add(cell_phone.GetObjectID());

                  #endregion
                }
              }
            }
          }

          if (oids.Count > 0)
          {
            //select them on the layer
            var qf = new QueryFilter()
            {
              ObjectIDs = oids
            };
            var phone_number_fl = kg_layer.GetLayersAsFlattenedList()
                .OfType<FeatureLayer>().First(l => l.Name == "PhoneNumber");
            phone_number_fl.Select(qf);
          }
        }
    });
    }
  }
}
