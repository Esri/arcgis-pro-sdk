﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo1_ForKG2 : Button
  {
    protected override void OnClick()
    {
			var map = MapView.Active?.Map;
			if (map == null) return;

			QueuedTask.Run(() =>
      {
        //connect to the KG datastore
        var kg_uri = new Uri(Module1.KG_URL);
        var kg_conn = new KnowledgeGraphConnectionProperties(kg_uri);
        
        using (var kg = new KnowledgeGraph(kg_conn))
        {

          var kg_params = new KnowledgeGraphLayerCreationParams(kg)
          {
            Name = "KG_With_All_Types",
            IsVisible = false
          };
          var kg_layer1 = LayerFactory.Instance.CreateLayer<KnowledgeGraphLayer>(
              kg_params, map);

          //Subset of types and features with an Id set
          var kg_datamodel = kg.GetDataModel();
          var first_entity = kg_datamodel.GetEntityTypes().Keys.First();
          var first_relate = kg_datamodel.GetRelationshipTypes().Keys.First();

          //Make a dictionary consisting of the types to be added along with
          //a list of the relevant object ids (or uids). An empty list means
          //add everything (for that type)
          var dict = new Dictionary<string, List<long>>();
          dict.Add(first_entity, new List<long>());//Empty list means all records
          dict.Add(first_relate, new List<long>());//Empty list means all records

          var kg_params2 = new KnowledgeGraphLayerCreationParams(kg)
          {
            Name = "KG_With_ID_Set",
            IsVisible = false,
            IDSet = KnowledgeGraphLayerIDSet.FromDictionary(kg, dict)
          };
          var kg_layer2 = LayerFactory.Instance.CreateLayer<KnowledgeGraphLayer>(
              kg_params2, map);

        }
      });
    }
  }
}
