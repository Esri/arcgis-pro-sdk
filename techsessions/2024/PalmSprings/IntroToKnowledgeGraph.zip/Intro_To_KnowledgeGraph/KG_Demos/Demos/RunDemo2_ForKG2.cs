﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.Knowledge;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KG_Demos.Demos
{
  internal class RunDemo2_ForKG2 : Button
  {
    protected override void OnClick()
    {

      QueuedTask.Run(async () =>
      {
        //connect to the KG datastore
        var kg_uri = new Uri(Module1.KG_URL);
        var kg_conn = new KnowledgeGraphConnectionProperties(kg_uri);

        using (var kg = new KnowledgeGraph(kg_conn))
        {
          var qry2 = @"MATCH (p1:PhoneNumber)-[r1:MADE_CALL|RECEIVED_CALL]" +
                     @"->(c1:PhoneCall)<-[r2:MADE_CALL|RECEIVED_CALL]-(p2:PhoneNumber) " +
                     @"WHERE p1.FULL_NAME <> p2.FULL_NAME " +
                     @"RETURN p1.FULL_NAME, c1.START_DATE, c1.DURATION, p2 LIMIT 10";
          //create a KG query filter
          var kg_qry_filter = new KnowledgeGraphQueryFilter()
          {
            QueryText = qry2
          };
          //Submit query using "SubmitQuery" returns a KG Row Cursor
          using (var kgRowCursor = kg.SubmitQuery(kg_qry_filter))
          {
            int row = 0;
            //wait for rows to be returned asynchronously from the server
            while (await kgRowCursor.WaitForRowsAsync())
            {
              //get the rows using "standard" move next
              while (kgRowCursor.MoveNext())
              {
                //current row is accessible via ".Current" prop of the cursor
                using (var graphRow = kgRowCursor.Current)
                {
                  #region Process Row
                  //"RETURN p1.FULL_NAME, c1.START_DATE, c1.DURATION, p2"
                  //will return 3 primitive values: Name, Date, Duration, and
                  //the entity "p2". So our row array will hold 4 values...
                  var full_name = (string)graphRow[0];
                  var call_date = (DateTimeOffset)graphRow[1];
                  var call_mins = (long)graphRow[2];
                  var person_called = graphRow[3] as KnowledgeGraphEntityValue;

                  var person_called_name = (string)person_called["FULL_NAME"];
                  var cell_called = (string)person_called["PHONE_NUMBER"];
                  var city = (string)person_called["CITY"];

                  var date_str = call_date.DateTime.ToString("G");

                  System.Diagnostics.Debug.WriteLine(
                    $"[{row++}] {full_name} called {person_called_name} @{date_str} for {call_mins}, {city}");

                  #endregion
                }
              }
            }
          }
        }
      });
    }
  }
}
