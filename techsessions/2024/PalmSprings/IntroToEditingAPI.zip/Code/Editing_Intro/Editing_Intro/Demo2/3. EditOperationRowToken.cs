﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_Intro
{
  internal class EditOperationRowToken : Button
  {
    protected override void OnClick()
    {
      var fac_point_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                          .First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;
      var fac_poly_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                          .First(l => l.Name == "FacilitySite1") as FeatureLayer;
      if (fac_point_lyr == null)
        return;
      if (fac_poly_lyr == null)
        return;

      QueuedTask.Run(() =>
      {

        //Get an arbitrary point location to use in the edit operation
        var centerPt = MapView.Active.Extent.Center;

        // create edit operation
        var editOp = new EditOperation()
        {
          Name = "Add Attachment w/ Row Token",
          SelectNewFeatures = true
        };

        var rowtoken = editOp.Create(fac_point_lyr, centerPt);
        //ObjectID is provisioned when the operation is executed
        var new_oid = rowtoken.ObjectID ?? -1;
        //Rowtoken is used as the ObjectID "placeholder"
        editOp.AddAttachment(rowtoken,
                      @"C:\Pro_SDK\DevSummit\2024\PalmSprings\Editing\Data\Hydrant.jpg");

        //Execute the operation
        editOp.Execute();

        new_oid = rowtoken.ObjectID ?? -1;
      });
    }
  }
}
