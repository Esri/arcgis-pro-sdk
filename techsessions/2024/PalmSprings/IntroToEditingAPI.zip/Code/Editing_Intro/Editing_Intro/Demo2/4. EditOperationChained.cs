﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_Intro
{
  internal class EditOperationChained : Button
  {
    protected override void OnClick()
    {
      var fac_point_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                            .First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;
      var fac_poly_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                            .First(l => l.Name == "FacilitySite1") as FeatureLayer;
      if (fac_point_lyr == null)
        return;
      if (fac_poly_lyr == null)
        return;

      QueuedTask.Run(() =>
      {

        //Get an arbitrary point location to use in the edit operation
        var centerPt = MapView.Active.Extent.Center;

        // create edit operation
        var editOp = new EditOperation()
        {
          Name = "Add Attachment w/ Chained Op",
          SelectNewFeatures = true
        };

        //At 3.0, delegate is replaced by a row token
        var rowtoken = editOp.Create(fac_point_lyr, centerPt);
        //2.x
        //var new_oid = 0;
        //editOp.Create(fac_point_lyr, label_pt, oid => new_oid = oid);

        //Execute the create and check status
        if (editOp.Execute())
        {
          var chained_op = editOp.CreateChainedOperation(); //chain an operation

          chained_op.AddAttachment(fac_point_lyr, (long)rowtoken.ObjectID,
                  @"C:\Pro_SDK\DevSummit\2024\PalmSprings\Editing\Data\Hydrant.jpg");
          chained_op.Execute();
        }
      });
    }
  }
}
