﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Editing_Intro
{
  internal class Module1 : Module
  {
    private static Module1 _this = null;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("Editing_Intro_Module");


    public Polygon GetBoundaryOfFirstfeature(FeatureLayer polyLayer)
    {
      Polygon boundary = null;

      //get boundary of first polygon in layer
      using (var fc = polyLayer.GetFeatureClass())
      {
        using (var cursor = fc.Search())
        {
          cursor.MoveNext();
          using (var feature = cursor.Current as Feature)
          {
            boundary = feature.GetShape() as Polygon;
          }
        }
      }

      return boundary;
    }

    public MapPoint GetBoundaryLabelPoint(FeatureLayer polyLayer)
    {
      // gets label point of first feature
      return GeometryEngine.Instance.LabelPoint(GetBoundaryOfFirstfeature(polyLayer));
    }

    public List<long> GetObjectIDs(FeatureLayer layer)
    {
      var oids = new List<long>();

      using (var fc = layer.GetFeatureClass())
      {
        using (var cursor = fc.Search())
        {
          while (cursor.MoveNext())
          {
            using (var row = cursor.Current as Row)
            {
              oids.Add(row.GetObjectID());
            }
          }
        }
      }

      return oids;
    }


    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

  }
}
