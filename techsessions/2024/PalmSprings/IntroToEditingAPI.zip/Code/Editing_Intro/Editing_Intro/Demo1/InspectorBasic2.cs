﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_Intro
{
  internal class InspectorBasic2 : Button
  {
    // use Inspector and EditOperation.Modify to modify attributes
    protected async override void OnClick()
    {
      var fac_point_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                    .First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;
      if (fac_point_lyr == null)
        return;

      await QueuedTask.Run(() =>
      {
        var point_oid = Module1.Current.GetObjectIDs(fac_point_lyr).Last();

        var inspector = new Inspector();
        inspector.Load(fac_point_lyr, point_oid);

        inspector["FACILITYID"] = "11055.00";
        inspector["NAME"] = "BLDG 53";    // different from in InspectorBasic1
        inspector["DESCRIPT"] = inspector["NAME"];
        inspector["FACAREA"] = 31118;

        var editOp = new EditOperation()
        {
          Name = $"Modify Facility Point {point_oid}",
          CancelMessage = "Modify Facility Point canceled",
          SelectModifiedFeatures = true
        };

        editOp.Modify(inspector);
        editOp.Execute();
      });

    }
  }
}
