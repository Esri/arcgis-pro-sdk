﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_Intro
{
  internal class EditOperationBasic : Button
  {
    protected override void OnClick()
    {
      var fac_point_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                                    .First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;

      var fac_poly_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                                    .First(l => l.Name == "FacilitySite1") as FeatureLayer;

      if (fac_point_lyr == null)
        return;
      if (fac_poly_lyr == null)
        return;

      //Add and modify some features
      QueuedTask.Run(() =>
      {
        // create 2 points 
        var centerPt = MapView.Active.Extent.Center;
        var centerPtOffset = GeometryEngine.Instance.Move(centerPt, 100.0, 0.0);

        // create edit operation
        var editOp = new EditOperation()
        {
          Name = "Basic Workflow",
          ErrorMessage = "'Basic Workflow' failed",
          SelectModifiedFeatures = true
        };

        //Add two points
        editOp.Create(fac_point_lyr, centerPt);
        editOp.Create(fac_point_lyr, centerPtOffset);


        //Get facility poly...
        var poly_oid = Module1.Current.GetObjectIDs(fac_poly_lyr).First();

        var insp = new Inspector();
        insp.Load(fac_poly_lyr, poly_oid);
        var polyShape = insp["SHAPE"] as Polygon;

        double bufferDistance = polyShape.Length / 25.0;
        var bufferPolyShape = GeometryEngine.Instance.Buffer(polyShape, bufferDistance);


        //Modify the facility site polygon
        editOp.Modify(fac_poly_lyr, poly_oid, bufferPolyShape);

        //Execute the operations
        editOp.Execute();
      });
    }
  }
}
