﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_Intro
{
  internal class InspectorBasic3 : Button
  {
    protected async override void OnClick()
    {
      var fac_point_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                      .First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;
      var fac_poly_lyr = MapView.Active.Map.GetLayersAsFlattenedList()
                      .First(l => l.Name == "FacilitySite1") as FeatureLayer;

      if (fac_point_lyr == null)
        return;
      if (fac_poly_lyr == null)
        return;

      // illustrate different usages of Inspector attributes
      await QueuedTask.Run(() =>
      {
        var oids = Module1.Current.GetObjectIDs(fac_point_lyr);
        var point_oid = oids.Last();

        var centerPt = MapView.Active.Extent.Center;

        var editOp = new EditOperation()
        {
          Name = "Create + Modify Features",
          CancelMessage = "Create + Modify Features cancelled",
          SelectNewFeatures = true,
          SelectModifiedFeatures = true
        };

        var inspector = new Inspector();
        inspector.Load(fac_point_lyr, point_oid);
        // change the location
        inspector.Shape = centerPt;

        // create a new feature with a set of attributes including shape
        editOp.Create(inspector.MapMember, inspector);

        // copy attributes to a different feature
        //  dont want to copy shape so use a Dictionary of attributes without shape
        //  Linq ToDictionary
        var dict_copy = inspector.ToDictionary(a => a.FieldName, a => a.CurrentValue);
        dict_copy.Remove("SHAPE");//keep original location

        var point_oid2 = oids[2];
        editOp.Modify(fac_point_lyr, point_oid2, dict_copy);

        //also enumerate dictionary to obtain attriutes 
        foreach (var attrib in inspector)
        {
          System.Diagnostics.Debug.WriteLine(
            $"{attrib.FieldName}: {attrib.CurrentValue.ToString()}");
        }

        editOp.Execute();
      });
    }
  }
}
