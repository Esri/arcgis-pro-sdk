﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Linq;
using System.Threading.Tasks;


namespace MapTools
{
    internal class MultipatchFootprint : MapTool
    {
        public MultipatchFootprint()
        {
            IsSketchTool = true;
            UseSnapping = true;
            // Select the type of construction tool you wish to implement.  
            // Make sure that the tool is correctly registered with the correct component category type in the daml 
            SketchType = SketchGeometryType.Point;
            // SketchType = SketchGeometryType.Line;
            // SketchType = SketchGeometryType.Polygon;
            //Gets or sets whether the sketch is for creating a feature and should use the CurrentTemplate.
            UsesCurrentTemplate = true;
            //Gets or sets whether the tool supports firing sketch events when the map sketch changes. 
            //Default value is false.
            FireSketchEvents = true;
        }

        /// <summary>
        /// Called when the sketch finishes. This is where we will create the sketch operation and then execute it.
        /// </summary>
        /// <param name="geometry">The geometry created by the sketch.</param>
        /// <returns>A Task returning a Boolean indicating if the sketch complete event was successfully handled.</returns>
        protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
        {
            if (CurrentTemplate == null || geometry == null)
                return Task.FromResult(false);

            return QueuedTask.Run(() =>
            {

                // Create an edit operation
                var createOperation = new EditOperation();
                createOperation.Name = string.Format($"Create new {CurrentTemplate.Layer.Name} and associated footprint");
                createOperation.SelectNewFeatures = true;

                //create a multipatch geometry with the point. 
                var size = 100;       // The size of the shape in m (height, length, width).It must be greater than 0
                var quality = 0.8;    // A value between 0 and 1 inclusive. A higher quality number means more verticies for the shape resulting in a smoother shape.

                var sketchPoint = geometry as MapPoint;
                var mpSphere = MultipatchBuilderEx.CreateMultipatch(MultipatchConstructType.Sphere, sketchPoint, size, quality, ActiveMapView.Map.SpatialReference);

                // Queue feature creation
                createOperation.Create(CurrentTemplate, mpSphere);

                //before returning create the footprint
                var footprintGeom = mpSphere.Extent;
                var poly = PolygonBuilderEx.CreatePolygon(footprintGeom);

                //need to get the footprint layer and template. 
                var footprintLayer = MapView.Active.Map.Layers.FirstOrDefault(l => l.Name == "Footprint");
                var footprintTemplate = footprintLayer.GetTemplate("Footprint");
                if (footprintTemplate == null)
                    footprintTemplate = footprintLayer.CreateTemplate("Footprint", "default poly template");

                createOperation.Create(footprintTemplate, poly);

                // Execute the operation
                if (!createOperation.IsEmpty)
                    createOperation.ExecuteAsync();

                return Task.FromResult(createOperation.IsSucceeded);
            });

        }
    }
}
