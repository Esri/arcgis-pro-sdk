﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Threading.Tasks;

namespace MapTools
{
    internal class CutPolyWithCircle : MapTool
    {
        public CutPolyWithCircle()
        {
            IsSketchTool = true;
            SketchType = SketchGeometryType.Circle;
            SketchOutputMode = SketchOutputMode.Map;
        }

        protected override Task OnToolActivateAsync(bool active)
        {
            return base.OnToolActivateAsync(active);
        }

        protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
        {
            return QueuedTask.Run(() =>
            {
                //this returns intersecting features
                var selection = MapView.Active.SelectFeatures(geometry);
                //will need to filter out lines.

                var editOperation = new EditOperation();
                editOperation.Name = "Cut With Circle";

                editOperation.Split(selection, geometry);

                if (!editOperation.IsEmpty)
                {
                    return editOperation.Execute();
                }
                return false;
            });
        }
    }
}
