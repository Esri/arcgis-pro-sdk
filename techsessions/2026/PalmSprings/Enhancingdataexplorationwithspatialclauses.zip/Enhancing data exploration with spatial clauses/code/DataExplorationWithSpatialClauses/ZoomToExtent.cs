﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataExplorationWithSpatialClauses
{
    internal class ZoomToExtent : Button
    {
        protected async override void OnClick()
        {
            //Get the map
            var map = MapView.Active?.Map;
            if (map == null) return;
            //Get all the feature layers in the map
            var layers = map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
            //This is the Fire Zone layer which is used to create the spatial filter - Our "cookie cutter".
            var fireZoneSpatialDefLyr = layers.FirstOrDefault(f => f.Name == "Los Angeles fires perimeter 2025");
            if (fireZoneSpatialDefLyr == null) return;
            await MapView.Active.ZoomToAsync(fireZoneSpatialDefLyr);
        }
    }
}
