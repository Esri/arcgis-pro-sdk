﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataExplorationWithSpatialClauses
{
    internal class RemoveAll : Button
    {
        protected override void OnClick()
        {
            var map = MapView.Active.Map;
            if (map == null) return;
            var layers = map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
            var laCountyParcelsLyr = layers.FirstOrDefault(f => f.Name == "Los Angeles county parcels");
            if (laCountyParcelsLyr == null) return;
            var fireDamageInspectionLyr = layers.FirstOrDefault(f => f.Name == "Fire Damage Inspection");
            if (fireDamageInspectionLyr == null) return;
            try
            {
                if (MapView.Active == null) return;
                QueuedTask.Run(() =>
                {
                    //Note: needs to be called on the MCT   
                    // Remove all definition queries from the layer
                    laCountyParcelsLyr.RemoveAllDefinitionQueries();
                    fireDamageInspectionLyr.RemoveAllDefinitionQueries();
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Remove All Definition Queries");
            }
        }
    }
}
