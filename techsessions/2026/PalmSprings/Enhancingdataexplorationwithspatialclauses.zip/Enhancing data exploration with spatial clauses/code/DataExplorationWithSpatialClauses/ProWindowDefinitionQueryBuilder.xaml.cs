﻿using ArcGIS.Desktop.Editing.Controls;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Mapping.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataExplorationWithSpatialClauses
{
    /// <summary>
    /// Interaction logic for DefinitionQueryBuilder.xaml
    /// </summary>
    public partial class ProWindowDefinitionQueryBuilder : ArcGIS.Desktop.Framework.Controls.ProWindow
    {
        ProWindowDefinitionQueryBuilderVM definitionQueryBuilderVM = new ProWindowDefinitionQueryBuilderVM();
        internal static MapControl _mapControl = null;
        public static ProWindowDefinitionQueryBuilder Current = null;
        public ProWindowDefinitionQueryBuilder()
        {
            InitializeComponent();
            //Used in the viewmodel to get access to the control
            Current = this;
            // parent the MapControlWindow properly so that even when 'clicks' occur
            // MapControlWindow is not obscured behind ArcGIS Pro or other windows
            base.Owner = FrameworkApplication.Current.MainWindow;

            _mapControl = this.mapControl;
            definitionQueryBuilderVM.UpdateMapControlContent();
            this.DataContext = definitionQueryBuilderVM;
        }
    }
}
