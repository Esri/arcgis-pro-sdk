﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataExplorationWithSpatialClauses
{
    internal class ShowDefinitionQueryBuilder : Button
    {
        private ProWindowDefinitionQueryBuilder _definitionquerybuilder = null;

        protected override void OnClick()
        {
            //already open?
            if (_definitionquerybuilder != null)
                return;
            _definitionquerybuilder = new ProWindowDefinitionQueryBuilder();
            _definitionquerybuilder.Owner = FrameworkApplication.Current.MainWindow;
            _definitionquerybuilder.Closed += (o, e) => { _definitionquerybuilder = null; };
            //_definitionquerybuilder.Show();
          
            //uncomment for modal
            var result = _definitionquerybuilder.ShowDialog();
        }
       
    }
}
