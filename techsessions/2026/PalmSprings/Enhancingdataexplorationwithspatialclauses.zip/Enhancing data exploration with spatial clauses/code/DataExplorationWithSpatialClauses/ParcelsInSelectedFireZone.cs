﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataExplorationWithSpatialClauses
{
    internal class ParcelsInSelectedFireZone : Button
    {
        protected override void OnClick()
        {
            //Get the map
            var map = MapView.Active?.Map;
            if (map == null) return;
            //Get all the feature layers in the map
            var layers = map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
            //This is the Fire Zone layer which is used to create the spatial filter - Our "cookie cutter".
            var fireZoneSpatialDefLyr = layers.FirstOrDefault(f => f.Name == "Los Angeles fires perimeter 2025");
            if (fireZoneSpatialDefLyr == null) return;
            //This is the LA County parcels layer to which we will apply the spatial filter to.
            var laCountyParcelsLyr = layers.FirstOrDefault(f => f.Name == "Los Angeles county parcels");
            if (laCountyParcelsLyr == null) return;
            //This is the Fire Damage Inspection layer to which we will apply the spatial filter to.
            var fireDamageInspectionLyr = layers.FirstOrDefault(f => f.Name == "Fire Damage Inspection");
            if (fireDamageInspectionLyr == null) return;
            try
            {
                QueuedTask.Run(() => {
                    if (fireZoneSpatialDefLyr.GetSelection() == null) return;

                    // Get the spatial filter geometry
                    //Get the geometry from the selected features in the feature layer
                    //Step 1: Get the spatial filter geometry
                    var geometryOfSelectedFirePolygons = fireZoneSpatialDefLyr.GetFeatureOutline(MapView.Active, FeatureOutlineType.Selected);
                    //Step 2:Create the definition query
                    //Create the definition query
                    DefinitionQuery definitionQuery = new DefinitionQuery
                    {
                        //optional to add a where clause along with the spatial filter
                        //WhereClause = "UseType = 'Residential'" //Residential parcels,
                        Name = "Parcels in selected fire zone"
                    };
                    //Step 3: Setting the spatial filter to the Definition Query
                    if (definitionQuery.CanSetFilterGeometry(geometryOfSelectedFirePolygons))
                    {
                        definitionQuery.SetFilterGeometry(geometryOfSelectedFirePolygons);
                    }
                    //Step 4: Apply the definition query to the LA County parcels layer
                    laCountyParcelsLyr.InsertDefinitionQuery(definitionQuery);
                    //Step 5: Activate the definition query to see the results
                    laCountyParcelsLyr.SetActiveDefinitionQuery(definitionQuery.Name);

                    //Apply the definition query to the Fire Damage Inspection layer
                    fireDamageInspectionLyr.InsertDefinitionQuery(definitionQuery);
                    //Activate the definition query to see the results
                    fireDamageInspectionLyr.SetActiveDefinitionQuery(definitionQuery.Name);
                });

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error querying feature layer: {ex.Message}");
            }
        }
    }
}
