﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_2_ConstructionTool
{
  internal class SplitPolyWithBufferUI : MapTool
  {
    public SplitPolyWithBufferUI()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Line;
      SketchOutputMode = SketchOutputMode.Map;
      ControlID = "Editing_2_ConstructionTool_BufferValue";
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return QueuedTask.Run(() =>
      {

        var vm = EmbeddableControl as BufferValueViewModel;
        var buffer = vm.Buffer;
        var cutGeometry = GeometryEngine.Instance.Buffer(geometry, buffer);

        var target = ActiveMapView.GetFeatures(geometry);
        if (target.Count == 0)
          return Task.FromResult(false);

        // Create an edit operation
        var createOperation = new EditOperation();
        createOperation.Name = "Cut with buffered line";
        createOperation.SelectModifiedFeatures = true;
        createOperation.Split(target, cutGeometry);

        // Execute the operation
        return createOperation.ExecuteAsync();
      });
    }
  }
}
