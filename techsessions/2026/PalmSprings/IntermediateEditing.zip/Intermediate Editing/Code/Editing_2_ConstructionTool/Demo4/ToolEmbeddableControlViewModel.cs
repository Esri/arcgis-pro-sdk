﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.

using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Xml.Linq;


namespace Editing_2_ConstructionTool
{
  internal class ToolEmbeddableControlViewModel : ToolOptionsEmbeddableControl
  {
    internal static bool TemplateOverrideDefault = true;

    internal static int SubtypeChoiceDefault = 0;

    public ToolEmbeddableControlViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) { }

		public override ImageSource SelectorIcon =>
			System.Windows.Application.Current.Resources["BexDog32"] as ImageSource;

		public override bool IsAutoOpen(string toolID) => true;

		protected override Task LoadFromToolOptions()
		{
			_useOverride = this.GetToolOption("UseTemplateOverride", TemplateOverrideDefault);
			_subtypeChoice = this.GetToolOption("SubtypeChoiceIndex", SubtypeChoiceDefault);
			return Task.CompletedTask;
		}

		#region Properties

		private bool _useOverride;
		public bool UseOverride
		{
			get => _useOverride;
			set
			{
				SetProperty(ref _useOverride, value);
				//update tool options
				SetToolOption("UseTemplateOverride", value);
			}
		}

		private int _subtypeChoice;
		public int SelectedSubtypeIndex
		{
			get => _subtypeChoice;
			set
			{
				SetProperty(ref _subtypeChoice, value);
				//update tool options
				SetToolOption("SubtypeChoiceIndex", value);
			}
		}
		public List<SubtypeChoice> SubtypeChoices => Module1.Current.SubtypeChoices;
		#endregion
	}
}
