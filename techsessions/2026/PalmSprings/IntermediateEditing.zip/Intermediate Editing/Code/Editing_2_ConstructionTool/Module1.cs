﻿//   Copyright 2023 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.

using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Editing_2_ConstructionTool
{
  internal class SubtypeChoice
  {
    public int SubtypefieldValue { get; set; }
    public string FeatureCodeValue { get; set; }

    public override string ToString()
    {
      return $"{this.SubtypefieldValue} - {this.FeatureCodeValue}";
    }
  }

  internal class Module1 : Module
  {
    private static Module1 _this = null;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("Editing_2_ConstructionTool_Module");

    #region Overrides

    protected override bool Initialize()
    {
      //possible choices for new buildings
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 710,
        FeatureCodeValue = "Industrial Facility"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 720,
        FeatureCodeValue = "Commercial or Retail Facility"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 730,
        FeatureCodeValue = "Education Facility"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 740,
        FeatureCodeValue = "Emergency Response or Law Enforcement Facility"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 790,
        FeatureCodeValue = "Building General"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 800,
        FeatureCodeValue = "Health or Medical Facility"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 810,
        FeatureCodeValue = "Transportation Facility"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 830,
        FeatureCodeValue = "Government or Military Facility"
      });
      _subtypeChoices.Add(new SubtypeChoice()
      {
        SubtypefieldValue = 880,
        FeatureCodeValue = "Information or Communication Facility"
      });

      return true;
    }
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides


    private List<SubtypeChoice> _subtypeChoices = new List<SubtypeChoice>();
    public List<SubtypeChoice> SubtypeChoices => _subtypeChoices;

    public SubtypeChoice GetChoice(int index)
      => SubtypeChoices[index];
  }
}
