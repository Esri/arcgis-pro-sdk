﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Templates;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using Editing_2_Examples.Demo1;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Editing_2_Examples
{
  internal class Module1 : Module
  {
    private static Module1 _this = null;

    public ObservableCollection<string> _entries = new ObservableCollection<string>();
    public ObservableCollection<string> _mapMemberList = new ObservableCollection<string>();
    internal static readonly object _lock = new object();
    private bool _listenToEvents = false;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("Editing_2_Examples_Module");

    protected override bool Initialize()
    {
      ArcGIS.Desktop.Mapping.Events.ActiveMapViewChangedEvent.Subscribe((args) =>
      {
        if (args.OutgoingView != null)
        {
          ClearLayers();
          ClearEntries();
        }

        if (args.IncomingView != null && args.IncomingView.Map != null)
        {
          FillMapMemberList(args.IncomingView);
        }
      });

      ArcGIS.Desktop.Mapping.Events.LayersAddedEvent.Subscribe((args) =>
      {
        //TODO
      });
      ArcGIS.Desktop.Mapping.Events.LayersRemovedEvent.Subscribe((args) =>
      {
        //TODO
      });

      ArcGIS.Desktop.Mapping.Events.MapMemberPropertiesChangedEvent.Subscribe((args) =>
      {
        if (!_listenToEvents)
          return;

        if (args.EventHints.Contains(MapMemberEventHint.Editability) ||
            args.EventHints.Contains(MapMemberEventHint.Visibility) ||
            args.EventHints.Contains(MapMemberEventHint.Renderer))
        {
          var dockpane = FrameworkApplication.DockPaneManager.Find(
                            TemplatesSpyViewModel._dockPaneID) as TemplatesSpyViewModel;
          dockpane.RegenerateTemplateList(args.MapMembers);
        }
      });

      ArcGIS.Desktop.Editing.Events.ActiveTemplateChangedEvent.Subscribe((args) =>
      {
        if (!_listenToEvents)
          return;

        var active_template = args.IncomingTemplate;
        var previous_template = args.OutgoingTemplate;

        lock(_lock) _entries.Clear();

        List<string> entries = null;
        entries = ReadTemplate(args.IncomingTemplate);
        lock (_lock)
        {
          _entries.Add("Active template");
          foreach (var entry in entries)
            _entries.Add(entry);
          _entries.Add("");
        }
        var prev_template = args.OutgoingTemplate?.Name ?? " null";

        lock (_lock)
        {
          _entries.Add($"Previous template {prev_template}");
        }
      });

      FillMapMemberList(MapView.Active);
      return true;
    }

    public ObservableCollection<string> TemplateEntries => _entries;

    public ObservableCollection<string> MapMemberList => _mapMemberList;

    public bool ListenToEvents
    {
      get
      {
        return _listenToEvents;
      }
      set
      {
        _listenToEvents = value;
      }
    }

    internal void FillMapMemberList(MapView mv)
    {
      ClearEntries();
      ClearLayers();

      if (mv == null || mv.Map == null)
        return;

      var flyrs = mv.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>()
                     .Select(layer => layer.Name).ToList();
      lock(_lock)
      {
        foreach(var fname in flyrs)
          _mapMemberList.Add(fname);
      }
    }

    internal void SetAutoGen(string selMapMember, bool autoGenOnOff)
    {
      if (string.IsNullOrEmpty(selMapMember))
        return;

      var fl = MapView.Active.Map.GetLayersAsFlattenedList().
                     OfType<FeatureLayer>().First(l => l.Name == selMapMember);

      var def = fl.GetDefinition() as CIMFeatureLayer;
      def.AutoGenerateFeatureTemplates = autoGenOnOff;
      fl.SetDefinition(def);
    }

    internal (bool autoGen, int templateCount) RegenerateTemplateList(string selMapMember)
    {
      ClearEntries();

      if (string.IsNullOrEmpty(selMapMember))
      {
        return (false, 0);
      }

      var fl = MapView.Active.Map.GetLayersAsFlattenedList().
                     OfType<FeatureLayer>().First(l => l.Name == selMapMember);
      int templateCount = 0;
      //Update AutoGen status
      var autoGen =
        ((CIMFeatureLayer)fl.GetDefinition()).AutoGenerateFeatureTemplates;

      //GetTemplates always generates templates to return
      //(if AutoGenerateFeatureTemplates is true)
      var templates = fl.GetTemplates();

      foreach (var template in templates)
      {
        templateCount++;
        var entries = ReadTemplate(template);
        lock (_lock)
        {
          foreach (var entry in entries)
            _entries.Add(entry);
          _entries.Add("");
        }
      }
      return (autoGen, templateCount);
    }

    internal List<string> ReadTemplate(EditingTemplate template)
    {
      var entries = new List<string>();
      if (template == null)
      {
        entries.Add(" <null>");
        return entries;
      }

      entries.Add($"{template.Name}, MapMember: {template.MapMember.Name}");

      //entries.Add($"Default tool: {template.DefaultToolID}");
      //entries.Add($"Last tool: {template.LastSelectedToolID}");

      ////var tool_ids = string.Join(',', template.ToolIDs);
      ////entries.Add($"Tool ids {tool_ids}");

      ////pick up any default attribute values
      //var def_attrib_vals = "";
      //def_attrib_vals = ReadDefaults(template);
      //entries.Add("Defaults (non null):");
      //entries.Add(def_attrib_vals);

      return entries;
    }

    internal string ReadDefaults(EditingTemplate template)
    {
      //non-null defaults
      var non_null_attribs = new List<string>() ;

      //Use the CIM definition
      var template_def = template.GetDefinition() as CIMRowTemplate;
      if (template_def.DefaultValues != null)
      {
        foreach(var key in template_def.DefaultValues.Keys)
        {
          non_null_attribs.Add(
            $"{key}: {template_def.DefaultValues[key].ToString()} ");
        }
      }

      if (non_null_attribs.Count() == 0)
        return " <none>";
      return String.Join(',',non_null_attribs);
    }

    internal void ClearEntries()
    { 
      if (_entries.Count() == 0)
        return;

      lock (_lock)
      {
        _entries.Clear();
      }
    }

    internal void ClearLayers()
    {
      if (_mapMemberList.Count() == 0)
        return;

      lock (_lock)
      {
        _mapMemberList.Clear();
      }
    }


    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

  }
}
