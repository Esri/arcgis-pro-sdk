﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace Editing_2_Examples.Demo1
{
  internal class TemplatesSpyViewModel : DockPane
  {
    public const string _dockPaneID = "Editing_2_Examples_Demo1_TemplatesSpy";

    private ICommand _refreshCmd;
    private ICommand _clearCmd;
    private ICommand _removeCmd;

    protected TemplatesSpyViewModel() 
    {
      BindingOperations.EnableCollectionSynchronization(
        Module1.Current.TemplateEntries, Module1._lock);
      BindingOperations.EnableCollectionSynchronization(
        Module1.Current.MapMemberList, Module1._lock);
    }

    public ObservableCollection<string> MapMembersList => 
                                Module1.Current.MapMemberList;
    public ObservableCollection<string> TemplateEntriesList => 
                                Module1.Current.TemplateEntries;

    private string _selMapMember = "";

    public string SelMapMemberName
    {
      get
      {
        return _selMapMember;
      }
      set
      {
        _selMapMember = value;
        if (!string.IsNullOrEmpty(_selMapMember))
          ListenToATEvent = false;
        RegenerateTemplateListInternal();
      }
    }

    private bool _autoGenTemplates = true;//default

    public bool AutoGenerateOnOff
    {
      get
      {
        if (string.IsNullOrEmpty(_selMapMember))
          return false;
        return _autoGenTemplates;
      }
      set
      {
        if (string.IsNullOrEmpty(_selMapMember))
          return;
        _autoGenTemplates = value;
        ToggleAutoGen(_autoGenTemplates);
      }
    }

    private bool _activeTemplateEvent = false;

    public bool ListenToATEvent
    {
      get
      {
        return _activeTemplateEvent;
      }
      set
      {
        if (SetProperty(ref _activeTemplateEvent, value))
        {
          if (value)
            this.SelMapMemberName = "";
          Module1.Current.ListenToEvents = value;
        }
      }
    }

    private string _templateListCount = "";
    public string TemplateListCount
    {
      get
      {
        return _templateListCount;
      }
    }

    public ICommand RefreshTemplateListCmd
    {
      get
      {
        if (_refreshCmd == null)
          _refreshCmd = new RelayCommand(() => RegenerateTemplateListInternal());
        return _refreshCmd;
      }
    }

    public ICommand ClearTemplateListCmd
    {
      get
      {
        if (_clearCmd == null)
          _clearCmd = new RelayCommand(() => 
            Module1.Current.ClearEntries());
        return _clearCmd;
      }
    }

    public void RegenerateTemplateList(IEnumerable<MapMember> mapMembers)
    {
      if (string.IsNullOrEmpty(_selMapMember))
        return;
      var flyrs = mapMembers.OfType<FeatureLayer>().ToList();
      var flyr = flyrs.FirstOrDefault(l => l.Name == _selMapMember);
      if (flyr == null)
        return;
      RegenerateTemplateListInternal();
    }

    private void ToggleAutoGen(bool autoGenOnOff)
    {
      QueuedTask.Run(() =>
      {
        Module1.Current.SetAutoGen(_selMapMember, autoGenOnOff);
      });
    }

    private async void RegenerateTemplateListInternal()
    {
      var result = await QueuedTask.Run(() =>
      {
        return Module1.Current.RegenerateTemplateList(_selMapMember);
      });

      _autoGenTemplates = result.autoGen;

      if (string.IsNullOrEmpty(_selMapMember))
        _templateListCount = "";
      else
      {
        var suffix = result.templateCount == 1 ? "template" : "templates";
        _templateListCount =
          $"{_selMapMember}: {result.templateCount} {suffix}";
      }
      var map_member = !string.IsNullOrEmpty(_selMapMember) ?
        _selMapMember : "";

      NotifyPropertyChanged(nameof(AutoGenerateOnOff));
      NotifyPropertyChanged(nameof(TemplateListCount));
    }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;

      pane.Activate();
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class TemplatesSpy_ShowButton : Button
  {
    protected override void OnClick()
    {
      TemplatesSpyViewModel.Show();
    }
  }
}
