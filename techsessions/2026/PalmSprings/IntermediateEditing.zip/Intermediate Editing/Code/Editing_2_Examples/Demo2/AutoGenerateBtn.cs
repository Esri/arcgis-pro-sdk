﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_2_Examples.Demo2
{
  internal class AutoGenerateBtn : Button
  {
    protected override void OnClick()
    {
      var trees = MapView.Active.Map.GetLayersAsFlattenedList().
                    OfType<FeatureLayer>().First(l => l.Name == "Trees");

      QueuedTask.Run(() =>
      {
        //Regenerate - overwrite any changes
        trees.AutoGenerateTemplates(true);
      });
    }
  }
}
