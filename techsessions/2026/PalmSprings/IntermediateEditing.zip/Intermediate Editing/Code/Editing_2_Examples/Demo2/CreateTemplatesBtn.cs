﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Editing.Templates;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_2_Examples.Demo2
{
  internal class CreateTemplatesBtn : Button
  {

    private void CreateUsingTemplateDefinition(FeatureLayer trees)
    {

      var template = trees.GetTemplates().First();

      //Get the Template definition to use as the basis for a new template
      var template_def = template.GetDefinition() as CIMRowTemplate;
      //change relevant properties
      template_def.Name = "Ponderosa Pine1";
      template_def.Description = "From CreateTemplate(template)";
      template_def.Tags = "Point,Sample";

      if (template_def.DefaultValues == null)
        template_def.DefaultValues = new Dictionary<string, object>();
      template_def.DefaultValues["subtype"] = "ponderosa";

      using (var gbd = trees.GetFeatureClass().GetDatastore() as Geodatabase)
      {
        var cv_domains = gbd.GetDomains().OfType<ArcGIS.Core.Data.CodedValueDomain>().ToList();
        var canopies = cv_domains.FirstOrDefault(d => d.GetName() == "TreeCanopyShape_1");
        if (canopies != null)
        {
          template_def.DefaultValues["canopyShape"] = canopies.GetCodedValue("Cone");
          canopies.Dispose();
        }
        var genus = cv_domains.FirstOrDefault(d => d.GetName() == "TreeGenusType");
        if (genus != null)
        {
          template_def.DefaultValues["type"] = genus.GetCodedValue("Pinus");
          genus.Dispose();
        }
        cv_domains.Clear();
      }
      //Auto generate will be turned off
      trees.CreateTemplate(template_def);
    }

    private void CreateUsingInspector(FeatureLayer trees)
    {
      //get a feature to use as basis for default values
      var rc = trees.Search(new QueryFilter()
      {
        SubFields = "*",
        WhereClause = "subtype = 'ponderosa'"
      });

      rc.MoveNext();
      //Load the inspector internal attribute dictionary w/ "the" feature
      var insp = new Inspector();
      insp.Load(rc.Current);//we just take the first row
      rc.Dispose();

      //"blank out" any unwanted defaults
      insp["TreeFID"] = "";
      insp["height"] = 0.0;
      insp["diameter"] = 0.0;
      insp["attribution"] = "";

      //Auto generate will be turned off
      trees.CreateTemplate("Ponderosa Pine2",
        "From CreateTemplate(name, desc, inspector)",
        insp, "", new string[] { "Point", "Sample" });
    }

    protected override void OnClick()
    {
      var trees = MapView.Active.Map.GetLayersAsFlattenedList().
                    OfType<FeatureLayer>().First(l => l.Name == "Trees");
      QueuedTask.Run(() =>
      {
        var def = trees.GetDefinition() as CIMFeatureLayer;
        var auto_gen = def.AutoGenerateFeatureTemplates;

        CreateUsingTemplateDefinition(trees);
        CreateUsingInspector(trees);

        //check auto generate
        def = trees.GetDefinition() as CIMFeatureLayer;
        auto_gen = def.AutoGenerateFeatureTemplates;
      });
    }
  }
}
