﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editing_2_Examples.Demo2
{
  internal class UpdateTemplatesBtn : Button
  {
    protected override void OnClick()
    {
      var trees = MapView.Active.Map.GetLayersAsFlattenedList().
                    OfType<FeatureLayer>().First(l => l.Name == "Trees");

      QueuedTask.Run(() =>
      {
        //get the template to be modified
        var template = trees.GetTemplates().FirstOrDefault(t => t.Name == "Ponderosa Pine1");
        if (template == null)
          return;

        //get the template definition
        var template_def = template.GetDefinition() as CIMRowTemplate;
        template_def.Description = "Updated template";

        //Update Default values
        if (template_def.DefaultValues == null)
          template_def.DefaultValues = new Dictionary<string, object>(); 
        template_def.DefaultValues["description"] = "Editing2 Demo";

        //Change the default tool to whichever is the second available tool
        var second_tool_id = template.RegisteredToolIDs.Skip(1).First();
        template_def.SetDefaultToolID(second_tool_id);

        //we must manually turn off autogenerate on the layer
        var layer_def = trees.GetDefinition() as CIMFeatureLayer;
        if (layer_def.AutoGenerateFeatureTemplates)
        {
          layer_def.AutoGenerateFeatureTemplates = false;
          trees.SetDefinition(layer_def);//apply the change back to the layer
        }

        //apply the changes back to the template
        template.SetDefinition(template_def);
      });

      
    }
  }
}
