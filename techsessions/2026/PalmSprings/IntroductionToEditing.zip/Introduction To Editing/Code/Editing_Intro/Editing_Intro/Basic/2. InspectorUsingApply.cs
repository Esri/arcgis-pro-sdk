﻿using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Linq;

namespace Editing_Intro
{
  internal class InspectorUsingApply : Button
  {
    protected override void OnClick()
    {
      var pointLayer = MapView.Active.Map.GetLayersAsFlattenedList().
                First(l => l.Name == "FacilitySitePoint1");
      if (pointLayer == null) return;

      QueuedTask.Run(() => {

        //The map selection is mixed with point and poly features. 
        var selection = MapView.Active.Map.GetSelection();
        //Just get the points
        var oid = selection[pointLayer];

        var inspector = new Inspector();
        //Load the points and define some new attribute values
        inspector.Load(pointLayer, oid);
        inspector["FACILITYID"] = "23067.00";
        inspector["FEATURECODE"] = "test";
        inspector["DESCRIPT"] = "Dwelling";
        inspector["FACAREA"] = "Island";
        inspector["LASTUPDATE"] = DateTime.Now;
        inspector["LASTEDITOR"] = "Dev and Tech";
        //apply the values
        var succeed = inspector.Apply();
        if (succeed)
        {
            // on success
        }
      });
    }
  }
}
