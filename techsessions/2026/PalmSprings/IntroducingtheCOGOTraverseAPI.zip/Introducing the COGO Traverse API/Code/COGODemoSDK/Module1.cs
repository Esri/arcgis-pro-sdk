﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace COGODemoSDK
{
    internal class Module1 : Module
    {
        private static Module1 _this = null;

        /// <summary>
        /// Retrieve the singleton instance to this module here
        /// </summary>
        public static Module1 Current => _this ??= (Module1)FrameworkApplication.FindModule("COGODemoSDK_Module");

        #region Overrides
        /// <summary>
        /// Called by Framework when ArcGIS Pro is closing
        /// </summary>
        /// <returns>False to prevent Pro from closing, otherwise True</returns>
        protected override bool CanUnload()
        {
            //TODO - add your business logic
            //return false to ~cancel~ Application close
            return true;
        }

    #endregion Overrides

    internal static double ConvertQuadrantBearingDMSToNorthAzimuthDecDeg(string InQuadrantBearing)
    {
      var dirTypeIn = ArcGIS.Core.CIM.DirectionType.QuadrantBearing;
      var dirUnitIn = ArcGIS.Core.CIM.DirectionUnits.DegreesMinutesSeconds;

      var dirTypeOut = ArcGIS.Core.CIM.DirectionType.NorthAzimuth;
      var dirUnitOut = ArcGIS.Core.CIM.DirectionUnits.DecimalDegrees;

      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinitionEx()
      {
        DirectionTypeIn = dirTypeIn,
        DirectionUnitsIn = dirUnitIn,
        DirectionTypeOut = dirTypeOut,
        DirectionUnitsOut = dirUnitOut
      };
      return AngConv.ConvertToDouble(InQuadrantBearing, ConvDef);
    }

    internal static double ConvertAngleDMSToDecDeg(string InAngleDMS)
    {
      var dirTypeIn = ArcGIS.Core.CIM.DirectionType.Polar;
      var dirUnitIn = ArcGIS.Core.CIM.DirectionUnits.DegreesMinutesSeconds;

      var dirTypeOut = ArcGIS.Core.CIM.DirectionType.Polar;
      var dirUnitOut = ArcGIS.Core.CIM.DirectionUnits.DecimalDegrees;

      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinitionEx()
      {
        DirectionTypeIn = dirTypeIn,
        DirectionUnitsIn = dirUnitIn,
        DirectionTypeOut = dirTypeOut,
        DirectionUnitsOut = dirUnitOut
      };
      return AngConv.ConvertToDouble(InAngleDMS, ConvDef);
    }

    internal static void OpenFolder(string folderPath)
    {
      // Define the path of the folder you want to open.
      // Use the '@' symbol for verbatim strings to handle backslashes easily.

      // Ensure the folder actually exists before trying to open it.
      if (Directory.Exists(folderPath))
      {
        // Use Process.Start to open the folder with the default system application (Windows Explorer).
        // For modern .NET Core/.NET 5+ applications, it is best practice 
        // to specify UseShellExecute = true in a ProcessStartInfo object.
        try
        {
          ProcessStartInfo startInfo = new(folderPath)
          {
            UseShellExecute = true
          };
          Process.Start(startInfo);
          Console.WriteLine($"Opened folder: {folderPath}");
        }
        catch (Exception ex)
        {
          Console.WriteLine($"An error occurred: {ex.Message}");
        }
      }
      else
      {
        Console.WriteLine($"Folder not found: {folderPath}");
      }
    }
  }
}
