﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Editing.COGO;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COGODemoSDK
{
  internal class CreateTraverse : Button
  {
    protected async override void OnClick()
    {
      await QueuedTask.Run(async () =>
      {
        string MyDir = "N87-58-47E";
        string MyDist = "290.0";
        var direction = Module1.ConvertQuadrantBearingDMSToNorthAzimuthDecDeg(MyDir);
        var distance = double.Parse(MyDist);
        var cogoLine = COGOLineBuilder.CreateCOGOStraightLine(direction, distance);

        var chordBrng = Module1.ConvertQuadrantBearingDMSToNorthAzimuthDecDeg("N26-06-55W");
        var circularArcDef = new CircularArcDefinition
        {
          ChordDirection = chordBrng,
          Radius = -25.0,
          ArcLength = 21.03
        };
        var cogoLineCircArc = COGOLineBuilder.CreateCOGOCircularArc(circularArcDef);


        chordBrng = Module1.ConvertQuadrantBearingDMSToNorthAzimuthDecDeg("N87-58-47E");
        var centralAngle = Module1.ConvertAngleDMSToDecDeg("276-22-46");
        circularArcDef = new CircularArcDefinition
        {
          ChordDirection = chordBrng,
          Radius = 50.0,
          CentralAngle = centralAngle
        };
        cogoLineCircArc = COGOLineBuilder.CreateCOGOCircularArc(circularArcDef);


        List<COGOLine> cogoLineList = new();
        //Course 1: C11
        chordBrng = Module1.ConvertQuadrantBearingDMSToNorthAzimuthDecDeg("N22-04-28E");
        circularArcDef = new CircularArcDefinition
        {
          ChordDirection = chordBrng,
          Radius = 25.0,
          ArcLength = 21.03 
        };
        cogoLineCircArc = COGOLineBuilder.CreateCOGOCircularArc(circularArcDef);
        cogoLineList.Add(cogoLineCircArc);

        //Course 2: Tangent curve left R50' Arclength 17.03'
        var tangentCurveDefn = new TangentCurveDefinition
        { 
          Radius = -50.0,
          ArcLength = 17.03
        };
        var cogoLineTangentCurve = COGOLineBuilder.CreateCOGOCircularArc(tangentCurveDefn);
        cogoLineList.Add(cogoLineTangentCurve);

        //Course 3: N87-58-47E, 97.13'
        direction = Module1.ConvertQuadrantBearingDMSToNorthAzimuthDecDeg("N87-58-47E");
        cogoLine = COGOLineBuilder.CreateCOGOStraightLine(direction, 97.3);
        cogoLineList.Add(cogoLine);

        //Course 4: Clockwise deflection angle 90 degrees, 50.00'
        var deflectionLine = 
          COGOLineBuilder.CreateCOGOStraightLineByClockwiseDeflectionAngle(90.0, false, 50.00);
        cogoLineList.Add(deflectionLine);

        //Course 5: S87-58-47W, 116.0'
        direction = Module1.ConvertQuadrantBearingDMSToNorthAzimuthDecDeg("S87-58-47W");
        cogoLine = COGOLineBuilder.CreateCOGOStraightLine(direction, 116.0);
        cogoLineList.Add(cogoLine);

        //Course 6: Backsight Deflection 270°, 18.09'
        deflectionLine =
          COGOLineBuilder.CreateCOGOStraightLineByClockwiseDeflectionAngle(270.0, true, 18.09);
        cogoLineList.Add(deflectionLine);

        var spatialRef = MapView.Active.Map.SpatialReference;
        var traverse = new Traverse(spatialRef, cogoLineList);

        //confirm it's a valid traverse
        if (!traverse.IsValid())
          return;

        var closure = traverse.GetClosure();
        string sClosureAndArea = 
          $"Closure Distance: {closure.MiscloseDistance:F2}" + Environment.NewLine +
          $"Closure Ratio: 1:{closure.MiscloseRatio:F0}" + Environment.NewLine +
          $"Closure Direction: {closure.MiscloseDirection:F5}" + Environment.NewLine +
          $"Calculated Area: {closure.CalculatedArea:F0}";
        MessageBox.Show(sClosureAndArea, "Traverse Closure");

        //var traverseStartPoint = MapView.Active.Extent.Center;

        var traverseStartPoint = 
          MapPointBuilderEx.CreateMapPoint(2988957.53, 13955854.39, spatialRef);
        traverse.StartPoint = traverseStartPoint;

        if (traverse.CanAdjust(TraverseAdjustmentMethod.Compass))
          traverse.Adjust(TraverseAdjustmentMethod.Compass);

        var map = MapView.Active.Map;
        var g2gCorrection = map?.GetDefinition()?.GroundToGridCorrection;
        if (g2gCorrection != null)
        {
          traverse.GroundToGridCorrection = g2gCorrection;
          traverse.UseGroundToGridCorrections = true;
        }

        if (traverse.CanCalculateCoordinates())
        {
          var coords = traverse.CalculateCoordinates();

          var sb = new StringBuilder();
          sb.AppendLine("Calculated Coordinates:");
          foreach (var coord in coords)
          {
            sb.AppendLine($"{coord.X:F2}, {coord.Y:F2}");
          }
          //MessageBox.Show(sb.ToString(), "Traverse Unadjusted Coordinates");
        }

        var adjustedCoords = traverse.AdjustmentResults.AdjustedCoordinates;
        if (adjustedCoords != null)
        {
          var sb = new StringBuilder();
          sb.AppendLine("Adjusted Coordinates:");
          foreach (var coord in adjustedCoords)
          {
            sb.AppendLine($"{coord.X:F2}, {coord.Y:F2}");
          }
          MessageBox.Show(sb.ToString(), "Adjusted Traverse Coordinates");
        }

        var layerName = "Connection Lines";
        var fCOGOLayer =
          MapView.Active?.Map?.GetLayersAsFlattenedList().
          OfType<FeatureLayer>().Where(l => l.
          Name.Equals(layerName, StringComparison.OrdinalIgnoreCase))
                              .FirstOrDefault();
        
        var templateCOGOLines = fCOGOLayer.GetTemplates().FirstOrDefault();
        var editOper = new EditOperation
        {
          Name = "Create Traverse",
          SelectNewFeatures = false
        };
        if (editOper.CanCreateTraverse(traverse, templateCOGOLines))
        {
          await editOper.CreateTraverse(traverse, templateCOGOLines);
          if (!editOper.IsEmpty)
            editOper.Execute();
        }

      });
    }
  }
}
