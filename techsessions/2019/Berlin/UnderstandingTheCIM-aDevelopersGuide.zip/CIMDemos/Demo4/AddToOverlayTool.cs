﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo4
{
  internal class AddToOverlayTool : MapTool
  {
    private IDisposable _graphic = null;
    private CIMLineSymbol _lineSymbol = null;

    public AddToOverlayTool()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Line;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolDeactivateAsync(bool hasMapViewChanged)
    {
      if (_graphic != null)
        _graphic.Dispose();//Clear out the old overlay
      _graphic = null;
      return base.OnToolDeactivateAsync(hasMapViewChanged);
    }

    protected async override Task OnToolActivateAsync(bool active)
    {
      if (_lineSymbol == null)
      {
        _lineSymbol = await CreateLineSymbolAsync();
      }
      this.SketchSymbol = _lineSymbol.MakeSymbolReference();
    }

    protected override void OnToolMouseDown(MapViewMouseButtonEventArgs e)
    {
      if (_graphic != null)
      {
        _graphic.Dispose();//Clear out the old overlay
        _graphic = null;
      }
      base.OnToolMouseDown(e);
    }

    protected async override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      _graphic = await this.AddOverlayAsync(geometry, _lineSymbol.MakeSymbolReference());
      var str = _lineSymbol.MakeSymbolReference().ToXml();
      return true;
    }

    internal static Task<CIMLineSymbol> CreateLineSymbolAsync()
    {
      return QueuedTask.Run(() => {
        var stroke = new CIMSolidStroke() { Color = ColorFactory.Instance.RedRGB, Width = 2 };
        stroke.Effects = new CIMGeometricEffect[]
        {
          new CIMGeometricEffectOffset() {Method = GeometricEffectOffsetMethod.Mitered, Offset = -3}
        };
        var stroke2 = new CIMSolidStroke() { Color = ColorFactory.Instance.BlueRGB, Width = 1 };
        stroke2.Effects = new CIMGeometricEffect[]
        {
          new CIMGeometricEffectOffset() {Method = GeometricEffectOffsetMethod.Mitered, Offset = 3},
          new CIMGeometricEffectArrow() { ArrowType = GeometricEffectArrowType.Block, Width = 4}
        };

        var square = SymbolFactory.Instance.ConstructMarker(ColorFactory.Instance.BlueRGB, 12, SimpleMarkerStyle.Circle);
        var circle = SymbolFactory.Instance.ConstructMarker(ColorFactory.Instance.BlackRGB, 12, SimpleMarkerStyle.Circle);

        var lineSymbol = new CIMLineSymbol() { SymbolLayers = new CIMSymbolLayer[] { stroke, stroke2 } };

        //marker.MarkerPlacement = new CIMMarkerPlacementOnVertices()
        //{
        //  AngleToLine = true,
        //  PlaceOnEndPoints = true,
        //  Offset = 0
        //};
        //return new CIMLineSymbol()
        //{
        //  SymbolLayers = new CIMSymbolLayer[2] { marker, stroke }
        //};
        return lineSymbol;
      });
    }
  }
}
