﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo1
{
  internal class ChangeSelColor : Button
  {
    protected async override void OnClick()
    {
      var streets = MapView.Active.Map.FindLayers("streets").First() as FeatureLayer;
      await QueuedTask.Run(() =>
      {
        //access the layer CIM Definition
        var def = streets.GetDefinition() as CIMFeatureLayer;

        //make changes - change the selection color, ensure layer is selectable, visible
        def.SelectionColor = ColorFactory.Instance.RedRGB;
        def.ShowLegends = false;

        var customProperties = def.CustomProperties?.ToList() ?? new List<CIMStringMap>();
        customProperties.Add(
          new CIMStringMap() { Key = "My Property", Value = "My Value" });
        def.CustomProperties = customProperties.ToArray();

        //set the CIM Definition back
        streets.SetDefinition(def);
      });
    }
  }
}
