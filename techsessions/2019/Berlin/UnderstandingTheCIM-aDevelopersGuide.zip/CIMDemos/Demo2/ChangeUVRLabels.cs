﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo2
{
  internal class ChangeUVRLabels : Button
  {
    protected async override void OnClick()
    {
      var crimes = MapView.Active.Map.FindLayers("Crimes").First() as FeatureLayer;
      await QueuedTask.Run(() =>
      {
        //access the layer CIM Definition
        var def = crimes.GetDefinition() as CIMFeatureLayer;
        var uvr = def.Renderer as CIMUniqueValueRenderer;
        
        var field_name = uvr.Fields.First();
        //we are going to use table statistics to get the counts
        var uvr_counts = new Dictionary<string, int>();
        int total_rows = 0;
        using(var fc = crimes.GetFeatureClass())
        {
          using(var fc_def = fc.GetDefinition())
          {
            var uvr_field = fc_def.GetFields().First(f => f.Name == field_name);
            var statsDesc = new StatisticsDescription(uvr_field,
                             new List<StatisticsFunction> { StatisticsFunction.Count });
            var tableStatsDesc = new TableStatisticsDescription(
                                      new List<StatisticsDescription> { statsDesc });
            tableStatsDesc.GroupBy = new List<Field> { uvr_field };
            var results = fc.CalculateStatistics(tableStatsDesc);
            foreach(var result in results)
            {
              var stats_result = result.StatisticsResults[0];
              var field_val = (string)result.GroupBy[0].Value;
              uvr_counts[field_val] = stats_result.Count;
              total_rows += stats_result.Count;
            }
          }
        }

        var running_total = 0;
        foreach (var group in uvr.Groups)
        {
          foreach (var cls in group.Classes)
          {
            var cnt = uvr_counts[cls.Label];
            cls.Label = $"{cls.Label} ({cnt})";
            running_total += cnt;
          }
          group.Heading = $"{group.Heading} (counts)";
        }
        //remainder = total_rows - running_total
        uvr.DefaultLabel = $"{uvr.DefaultLabel} ({total_rows - running_total})";

        //set the CIM Definition back
        crimes.SetDefinition(def);
      });
    }
  }
}
