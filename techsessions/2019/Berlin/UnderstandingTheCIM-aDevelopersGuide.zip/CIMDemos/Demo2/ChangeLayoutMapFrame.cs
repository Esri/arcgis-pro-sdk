﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo2
{
  internal class ChangeLayoutMapFrame : Button
  {
    protected async override void OnClick()
    {
      var file_gdb_path =
				@"E:\Data\SDK\DevSummit\2019\Berlin\TechSessions\1 - UnderstandingTheCIM-ADevelopersGuide\Data\Interacting with Maps.gdb";
      var layout = LayoutView.Active.Layout;
      
      await QueuedTask.Run(() =>
      {
        Polygon mapFramePolygon = null;

        var def = layout.GetDefinition();

        //Get the map frame
        var mapframe = def.Elements.OfType<CIMMapFrame>().First();

        //Make the frame polygon
        using(var gdb = new Geodatabase(new FileGeodatabaseConnectionPath(
          new Uri(file_gdb_path))))
        {
           using(var fc = gdb.OpenDataset<FeatureClass>("Portland_PD_Precincts"))
               mapFramePolygon = MakeMapFramePolygon(fc, mapframe.Frame.Extent);
        }
        
        //Apply the polygon to the frame
        mapframe.Frame = mapFramePolygon;

        //Give it a gray outline
        mapframe.GraphicFrame.BorderSymbol.Symbol =
            SymbolFactory.Instance.ConstructLineSymbol(
              ColorFactory.Instance.CreateRGBColor(120,100,120), 3);

        //Commit the changes back
        layout.SetDefinition(def);
      });
    }

    private Polygon MakeMapFramePolygon(FeatureClass fc, Envelope frameExtent) 
    {
      Geometry unionPoly = null;
      using (var rc = fc.Search())
      {
        while (rc.MoveNext())
        {
          var feature = rc.Current as Feature;
          var poly = feature.GetShape();
          //Step 1 - union the polys
          unionPoly = unionPoly == null ? poly : GeometryEngine.Instance.Union(unionPoly, poly);
        }
      }
      //Step 2 project it flat - Plat Carre
      var projectedPoly = GeometryEngine.Instance.Project(unionPoly,
        SpatialReferenceBuilder.CreateSpatialReference(54001));

      #region Step 3 shrink it to the size of the frame on the page
      var sx = frameExtent.Width / projectedPoly.Extent.Width;
      var sy = frameExtent.Height / projectedPoly.Extent.Height;
      var mid_point = GeometryEngine.Instance.LabelPoint(projectedPoly.Extent);
      #endregion

      var shrankPoly = GeometryEngine.Instance.Scale(projectedPoly, mid_point, sx, sy);

      #region Step 4 Move it onto the page
      var shrank_poly_mid_pt = GeometryEngine.Instance.LabelPoint(shrankPoly.Extent);
      var mapframe_mid_pt_x = frameExtent.XMin + (frameExtent.Width / 2);
      var mapframe_mid_pt_y = frameExtent.YMin + (frameExtent.Height / 2);

      double dx = 0;
      double dy = 0;
      if (shrank_poly_mid_pt.X < 0)
        dx = mapframe_mid_pt_x + Math.Abs(shrank_poly_mid_pt.X);
      else
        dx = mapframe_mid_pt_x - shrank_poly_mid_pt.X;

      if (shrank_poly_mid_pt.Y < 0)
        dy = mapframe_mid_pt_y + Math.Abs(shrank_poly_mid_pt.Y);
      else
        dy = mapframe_mid_pt_y - shrank_poly_mid_pt.Y;
      #endregion
      var frame_poly = GeometryEngine.Instance.Move(shrankPoly, dx, dy);

      //Step 5 Generalize to remove unnecessary detail
      double maxDeviation = 0.03;
      return GeometryEngine.Instance.Generalize(frame_poly, maxDeviation, true) as Polygon;
    }
  }
}
