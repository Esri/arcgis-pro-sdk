﻿using Google.Cloud.Translation.V2;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo2
{

  /// <summary>
  /// Represents the ComboBox
  /// </summary>
  internal class TranslateLegendLabels : ComboBox
  {

    private Dictionary<string, string> _langLookup = null;

    /// <summary>
    /// Combo Box constructor
    /// </summary>
    public TranslateLegendLabels()
    {
      UpdateCombo();
    }

    /// <summary>
    /// Updates the combo box with all the items.
    /// </summary>
    private void UpdateCombo()
    {
      TranslationClient client = TranslationClient.Create();
      IList<Language> languages = client.ListLanguages(target: "en");
      client.Dispose();
      _langLookup = languages.ToDictionary(l => l.Code, l => l.Name);

      Clear();
      Add(new ComboBoxItem(_langLookup[LanguageCodes.Afrikaans]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.Armenian]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.ChineseTraditional]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.Dutch]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.English]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.French]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.German]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.Greek]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.Italian]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.Spanish]));
      Add(new ComboBoxItem(_langLookup[LanguageCodes.ScotsGaelic]));
      Add(new ComboBoxItem("-- RESET --"));

      Enabled = true; //enables the ComboBox
      SelectedItem = ItemCollection.FirstOrDefault(); //set the default item in the comboBox

    }

    /// <summary>
    /// The on comboBox selection change event. 
    /// </summary>
    /// <param name="item">The newly selected combo box item</param>
    protected async override void OnSelectionChange(ComboBoxItem item)
    {
      await QueuedTask.Run(() =>
      {

        if (item == null || CheckReset(item))
          return;

        var crimes = MapView.Active.Map.FindLayers("Crimes").First() as FeatureLayer;
        string targetLanguage = _langLookup.First(l => l.Value == item.Text).Key;

        //access the layer CIM Definition
        var def = crimes.GetDefinition() as CIMFeatureLayer;
        var uvr = def.Renderer as CIMUniqueValueRenderer;
        
        using (var client = TranslationClient.Create())
        {
          uvr.DefaultLabel = client.TranslateText(uvr.DefaultLabel, targetLanguage).TranslatedText;
          foreach (var group in uvr.Groups)
          {
            group.Heading = client.TranslateText(group.Heading, targetLanguage).TranslatedText;
            foreach (var cls in group.Classes)
            {
              cls.Label = client.TranslateText(cls.Label, targetLanguage).TranslatedText;
            }
          }
        }

        crimes.SetDefinition(def);
      });
    }

    private bool CheckReset(ComboBoxItem item)
    {
      SaveOriginalLabelsForReset();
      if (item.Text != "-- RESET--")
        return false;

      var crimes = MapView.Active.Map.FindLayers("Crimes").First() as FeatureLayer;
      //access the layer CIM Definition
      var def = crimes.GetDefinition() as CIMFeatureLayer;
      var uvr = def.Renderer as CIMUniqueValueRenderer;
      var labels = new List<string>();
      int c = 0;
      uvr.DefaultLabel = Module1.Current.Preservedlabels[c++];

      foreach (var group in uvr.Groups)
      {
        group.Heading = Module1.Current.Preservedlabels[c++];

        foreach (var cls in group.Classes)
        {
          cls.Label = Module1.Current.Preservedlabels[c++];
        }
      }

      crimes.SetDefinition(def);
      return true;
    }

    private void SaveOriginalLabelsForReset()
    {
      if (Module1.Current.Preservedlabels != null)
        return;
      var crimes = MapView.Active.Map.FindLayers("Crimes").First() as FeatureLayer;

      //access the layer CIM Definition
      var def = crimes.GetDefinition() as CIMFeatureLayer;
      var uvr = def.Renderer as CIMUniqueValueRenderer;
      var labels = new List<string>();
      labels.Add(uvr.DefaultLabel);

      foreach (var group in uvr.Groups)
      {
        labels.Add(group.Heading);

        foreach (var cls in group.Classes)
        {
          labels.Add(cls.Label);
        }
      }
      Module1.Current.Preservedlabels = labels;
    }
  }
}
