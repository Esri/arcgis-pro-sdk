﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo3
{
  internal class DeserializeCIM2 : Button
  {
    internal static XNamespace xsi = "http://www.w3.org/2001/XMLSchema-instance";

    protected async override void OnClick()
    {
      var layout = LayoutView.Active.Layout;

      await QueuedTask.Run(() =>
      {

        var def = layout.GetDefinition();

        var mapframe = def.Elements.OfType<CIMMapFrame>().First();
        var xml = mapframe.ToXml();
        //deserialize via utility method and reflection
        var mapframe2 = DeserializeCIMXml(xml) as CIMMapFrame;

        //same idea via a copy or "clone" extension method
        mapframe2 = mapframe.Clone() as CIMMapFrame;

        mapframe2.Name = mapframe2.Name + "2";
        mapframe2.Frame = GeometryEngine.Instance.Move(
                                     mapframe2.Frame, 0.25, -0.25) as Polygon;

        //add the mapframe copy to the layout
        var elementList = def.Elements.ToList();
        elementList.Add(mapframe2);
        def.Elements = elementList.ToArray();

        //Commit the changes back
        layout.SetDefinition(def);
      });
    }

    private CIMObject DeserializeCIMXml(string xml)
    {
      using (var stringReader = new StringReader(xml)) {
        using (var reader = new XmlTextReader(stringReader)) {
          reader.MoveToContent();
          var typeName = reader.GetAttribute("xsi:type").Replace(
                                            "typens:", "ArcGIS.Core.CIM.");
          var cimObject = System.Activator.CreateInstance(
                   "ArcGIS.Core", typeName).Unwrap() as CIMObject;
          cimObject.ReadXml(reader);
          return cimObject;
        }
      }
    }
  }

  public static class CIMExtensions {
    public static CIMObject Clone(this CIMObject cimObject)
    {
      var typename = cimObject.GetType().ToString();
      var clone = Activator.CreateInstance(
                   "ArcGIS.Core", typename).Unwrap() as CIMObject;
      using (var stringReader = new StringReader(cimObject.ToXml())) {
        using (var xmlReader = new XmlTextReader(stringReader)) {
          clone.ReadXml(xmlReader);
          return clone;
        }
      }
    }
  }
}
