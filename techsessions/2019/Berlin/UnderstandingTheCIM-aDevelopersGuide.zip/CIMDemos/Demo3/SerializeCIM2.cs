﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo3
{
	internal class SerializeCIM2 : Button
	{
		protected async override void OnClick()
		{
			var layout = LayoutView.Active.Layout;

			await QueuedTask.Run(() =>
			{
				//Serialization / Deserialization with JSON
				var def = layout.GetDefinition();
				var mapframe = def.Elements.OfType<CIMMapFrame>().First();

				var settings = new JsonSerializationSettings()
				{
					PrettyPrint = true
				};
				var json = mapframe.ToJson(settings);
				dynamic cim_object = Newtonsoft.Json.Linq.JObject.Parse(json);
				var cimType = (string)cim_object.type.Value;

				if (cimType == "CIMMapFrame")
				{
					var mapframe2 = CIMMapFrame.FromJson(json);
					mapframe2.Name = mapframe2.Name + "2";
					mapframe2.Frame = GeometryEngine.Instance.Move(
																 mapframe2.Frame, 0.25, -0.25) as Polygon;

					//add the mapframe copy to the layout
					var elementList = def.Elements.ToList();
					elementList.Add(mapframe2);
					def.Elements = elementList.ToArray();

					//Commit the changes back
					layout.SetDefinition(def);
				}
				
			});
		}
	}
}
