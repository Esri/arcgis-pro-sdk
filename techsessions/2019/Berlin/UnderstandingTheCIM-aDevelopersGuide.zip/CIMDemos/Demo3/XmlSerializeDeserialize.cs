﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo3
{
	internal class XmlSerializeDeserialize : Button
	{
		protected async override void OnClick()
		{

			var layout = LayoutView.Active.Layout;

			await QueuedTask.Run(() =>
			{

				var def = layout.GetDefinition();
				var mapframe = def.Elements.OfType<CIMMapFrame>().First();

				//Serialize to Xml
				var xml = mapframe.ToXml();

				//Make a copy using Deserialization
				//ctor + ReadXml
				var mapframe2 = new CIMMapFrame();
				mapframe2.ReadXml(new XmlTextReader(new StringReader(xml)));

				//Deserialize using static FromXml method
				var mapframe3 = CIMMapFrame.FromXml(xml);

				mapframe2.Name = mapframe2.Name + "2";
				mapframe2.Frame = GeometryEngine.Instance.Move(
															 mapframe2.Frame, 0.25, -0.25) as Polygon;

				//add the mapframe copy to the layout
				var elementList = def.Elements.ToList();
				elementList.Add(mapframe2);
				def.Elements = elementList.ToArray();

				//Commit the changes back
				layout.SetDefinition(def);
		});
		}
	}
}
