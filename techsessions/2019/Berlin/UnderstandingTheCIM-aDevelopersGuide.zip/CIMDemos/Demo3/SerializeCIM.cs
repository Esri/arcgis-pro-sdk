﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos.Demo3
{
  internal class SerializeCIM : Button
  {
    protected async override void OnClick()
    {
      var layout = LayoutView.Active.Layout;

      await QueuedTask.Run(() =>
      {

        var def = layout.GetDefinition();
        var xml = def.ToXml();

        //Serialized CIM is "regular" xml. 
        //E.g. load the CIM into a DOM
        var reader = XmlReader.Create(new StringReader(xml));
        var xdoc = XDocument.Load(reader);
        var nsp = xdoc.Root.Name.Namespace;

        //Query the xml if desired (same as "any" xml)
        var layoutElements = xdoc.Descendants(nsp + "CIMElement");
        foreach (var element in layoutElements)
        {
          //Note: These are XElements though, not CIM elements...
        }

        //Commit the changes back
        layout.SetDefinition(def);
      });
    }
  }
}
