﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace AcmeEnhancementsLicensed
{
	internal class Module1 : Module, IExtensionConfig
	{
		private static Module1 _this = null;

		/// <summary>
		/// Retrieve the singleton instance to this module here
		/// </summary>
		public static Module1 Current
		{
			get
			{
				return _this ?? (_this = (Module1)FrameworkApplication.FindModule("AcmeEnhancementsLicensed_Module"));
			}
		}


		private static string _licensedState = "acme_enhancements_is_licensed";

		private ExtensionState _state = ExtensionState.Disabled;
		public ExtensionState State
		{
			get => _state;
			set
			{
				if (_state == ExtensionState.Disabled)
				{
					_state = ExtensionState.Enabled;
					FrameworkApplication.State.Activate(
						"acme_enhancements_is_licensed");
				}
				else if (_state == ExtensionState.Enabled)
				{
					_state = ExtensionState.Disabled;
					FrameworkApplication.State.Deactivate(
						"acme_enhancements_is_licensed");
				}
			}
		}

		private string _label = "Acme Enhancements Licensed";
		public string Message { get => _label; set { } }
		public string ProductName { get => _label; set { } }

		#region Overrides
		/// <summary>
		/// Called by Framework when ArcGIS Pro is closing
		/// </summary>
		/// <returns>False to prevent Pro from closing, otherwise True</returns>
		protected override bool CanUnload()
		{
			//TODO - add your business logic
			//return false to ~cancel~ Application close
			return true;
		}

		#endregion Overrides

	}
}
