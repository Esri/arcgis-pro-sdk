﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using IntermediateEditing.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntermediateEditing.Modify
{
	internal class DifferenceTool2 : MapTool
	{
		public DifferenceTool2()
		{
			IsSketchTool = true;
			SketchType = SketchGeometryType.Polygon;
			SketchOutputMode = SketchOutputMode.Map;
		}

		protected override Task OnToolActivateAsync(bool active)
		{
			return base.OnToolActivateAsync(active);
		}

		protected override Task<bool> OnSketchCompleteAsync(Geometry sketchGeometry)
		{

			return QueuedTask.Run(() =>
			{
				var select = MapView.Active.SelectFeatures(sketchGeometry);
				var poly_layers = select.Where(
					kvp => kvp.Key.ShapeType == esriGeometryType.esriGeometryPolygon).ToList();
				if (poly_layers.Count() == 0)
					return false;

				//do the difference
				var editOp = new EditOperation()
				{
					Name = "Difference",
					ErrorMessage = "Difference failed"
				};

				foreach (var kvp in poly_layers)
				{
					var diffGeom = GeometryEngine.Instance.Project(sketchGeometry,
																						 kvp.Key.GetSpatialReference());
					editOp.Difference(kvp.Key, kvp.Value, diffGeom);
				}
				return editOp.Execute();
			});
		}
	}
}
