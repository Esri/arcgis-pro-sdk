﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using IntermediateEditing.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntermediateEditing.Modify
{
  internal class DifferenceTool1 : MapTool
  {
    public DifferenceTool1()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Polygon;
      SketchOutputMode = SketchOutputMode.Map;
    }

		protected override Task OnToolActivateAsync(bool active)
		{
			return base.OnToolActivateAsync(active);
		}

		protected override Task<bool> OnSketchCompleteAsync(Geometry sketchGeometry)
		{

			return QueuedTask.Run(() =>
			{
				var select = MapView.Active.SelectFeatures(sketchGeometry);
				var poly_layers = select.Where(
					kvp => kvp.Key.ShapeType == esriGeometryType.esriGeometryPolygon).ToList();
				if (poly_layers.Count() == 0)
					return false;

				//do the difference
				//we will use EditOperation.Modify to edit the selected feature shapes
				var editOp = new EditOperation()
				{
					Name = "Difference",
					ErrorMessage = "Difference failed"
				};

				foreach (var kvp in poly_layers)
				{
					var layer = kvp.Key;
					var diffGeom = GeometryEngine.Instance.Project(sketchGeometry,
																						 layer.GetSpatialReference());
					var oids = kvp.Value;
					foreach (var oid in oids)
					{
						//load the feature
						var insp = new Inspector();
						insp.Load(layer, oid);
						//do the difference
						var geom = GeometryEngine.Instance.Difference((Geometry)insp["SHAPE"], 
							                                            diffGeom);
						//assign the shape
						insp["SHAPE"] = geom;
						//call modify
						editOp.Modify(insp);
					}
				}
			  //execute the operation
				return editOp.Execute();
			});
		}
	}
}
