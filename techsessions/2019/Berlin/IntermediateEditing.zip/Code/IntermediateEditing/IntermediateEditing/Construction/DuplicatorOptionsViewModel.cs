﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Xml.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Templates;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;


namespace IntermediateEditing.Construction
{
	internal class DuplicatorOptionsViewModel : EmbeddableControl, IEditingCreateToolControl
	{
		public DuplicatorOptionsViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) {

		}

		/// <summary>
		/// Text shown in the control.
		/// </summary>
		private string _text = "Embeddable Control";
		public string Text
		{
			get { return _text; }
			set
			{
				SetProperty(ref _text, value, () => Text);
			}
		}

		private bool _saveOverridesToDefault = false;

		public bool SaveOverridesToDefault
		{
			get { return _saveOverridesToDefault; }
			set
			{
				if (SetProperty(ref _saveOverridesToDefault, value, () => SaveOverridesToDefault))
				{
					if (ToolOptions != null)
					{
						_dirty = true;//flag options for persistence on OK. 
						ToolOptions["SaveOverridesToDefault"] = value;
					}
				}
			}
		}


		//1. These are for the Active Template Pane
		public ImageSource ActiveTemplateSelectorIcon => System.Windows.Application.Current.Resources["BexDog32"] as ImageSource;

		public bool AutoOpenActiveTemplatePane(string toolID)
		{
			return true;
		}

		public bool InitializeForActiveTemplate(ToolOptions options)
		{
			//consume tool options
			LoadToolOptions(options);
			return true;//return false to hide the UI
		}

		//2. These are for the Template Properties Dialog
		public bool IsValid => true; //False disables the OK button

		private bool _dirty = false;
		public bool IsDirty => _dirty;//True indicates ToolOptions have been changed

		private ToolOptions ToolOptions { get; set; }

		public bool InitializeForTemplateProperties(ToolOptions options)
		{
			LoadToolOptions(options);
			ToolOptions = options;
			return true;//return false to hide the UI
		}

		private void LoadToolOptions(ToolOptions options)
		{
			if (options?.ContainsKey("SaveOverridesToDefault") ?? false)
			{
				_saveOverridesToDefault = (bool)options["SaveOverridesToDefault"];
			}
		}
	}
}
