﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Xml.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;


namespace IntermediateEditing.Construction
{
	internal class ConstructFacilitiesToolOptionsViewModel : 
		         EmbeddableControl, IEditingCreateToolControl {
		#region Properties
		public bool SaveLastSubtypeChoiceToDefaults
		{
			get => Module1.Current.SaveLastSubtypeChoiceToDefaults;
			set => Module1.Current.SaveLastSubtypeChoiceToDefaults = value;
		}

		public bool UseSubtypeChoiceOverride
		{
			get => Module1.Current.UseSubtypeChoiceOverride;
			set => Module1.Current.UseSubtypeChoiceOverride = value;
		}

		public List<SubtypeChoice> SubtypeChoices => Module1.Current.SubtypeChoices;
		#endregion

		#region IEditingCreateToolControl

		//These are for the Active Template Pane
		public ImageSource ActiveTemplateSelectorIcon => 
			System.Windows.Application.Current.Resources["BexDog32"] as ImageSource;

		public bool AutoOpenActiveTemplatePane(string toolID) => true;

		//We are being activated on the Active Template Pane
		//We are the active tool.
		public bool InitializeForActiveTemplate(ToolOptions options) => true;

		//These are for the Template Properties Dialog
		//We are being activated on the Template Properties Dialog
		public bool InitializeForTemplateProperties(ToolOptions options) => false;
		public bool IsValid => true;
		public bool IsDirty => false;

		#endregion




		public ConstructFacilitiesToolOptionsViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) { }


		public int SelectedSubtypeChoiceIndex
		{
			get
			{
				return Module1.Current.SelectedSubtypeChoiceIndex;
			}
			set
			{
				Module1.Current.SelectedSubtypeChoiceIndex = value;
			}
		}
		private void SetCheckboxes(ToolOptions options)
		{
			if (options.ContainsKey("SaveLastSubtypeChoiceToDefaults"))
				SaveLastSubtypeChoiceToDefaults = (bool)options["SaveLastSubtypeChoiceToDefaults"];
			
			if (options.ContainsKey("UseSubtypeChoiceOverride"))
				UseSubtypeChoiceOverride = (bool)options["UseSubtypeChoiceOverride"];
			
		}

		private ToolOptions _toolOptions;
		private bool _dirty = false;
	}
}
