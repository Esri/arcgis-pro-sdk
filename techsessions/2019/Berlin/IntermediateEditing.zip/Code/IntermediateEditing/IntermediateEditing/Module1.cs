﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Windows;
using ArcGIS.Desktop.Editing.Templates;

namespace IntermediateEditing
{
	internal class SubtypeChoice
	{
		public int SubtypefieldValue { get; set; }
		public string FeatureCodeValue { get; set; }

		public override string ToString()
		{
			return $"{this.SubtypefieldValue} - {this.FeatureCodeValue}";
		}
	}

	internal class Module1 : Module
	{
		private static Module1 _this = null;
		private List<IDisposable> overlay = new List<IDisposable>();

		/// <summary>
		/// Retrieve the singleton instance to this module here
		/// </summary>
		public static Module1 Current
		{
			get
			{
				return _this ?? (_this = (Module1)FrameworkApplication.FindModule("IntermediateEditing_Module"));
			}
		}

		#region API

		private List<SubtypeChoice> _subtypeChoices = new List<SubtypeChoice>();
		private int _currentSubtypeChoice = 0;
		private bool _saveLastSubtypeChoiceToDefaults = true;
		private bool _useSubtypeChoiceOverride = true;

		public bool SaveLastSubtypeChoiceToDefaults
		{
			get
			{
				return _saveLastSubtypeChoiceToDefaults;
			}
			set
			{
				_saveLastSubtypeChoiceToDefaults = value;
			}
		}

		public bool UseSubtypeChoiceOverride
		{
			get
			{
				return _useSubtypeChoiceOverride;
			}
			set
			{
				_useSubtypeChoiceOverride = value;
			}
		}

		public int SelectedSubtypeChoiceIndex
		{
			get
			{
				return _currentSubtypeChoice;
			}
			set
			{
				_currentSubtypeChoice = value;
			}
		}

		public SubtypeChoice SelectedSubtypeChoice => _subtypeChoices[_currentSubtypeChoice];

		public List<SubtypeChoice> SubtypeChoices => _subtypeChoices;


		#endregion

		protected override bool Initialize()
		{
			//possible choices for new buildings
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 710, FeatureCodeValue = "Industrial Facility" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 720, FeatureCodeValue = "Commercial or Retail Facility" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 730, FeatureCodeValue = "Education Facility" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 740, FeatureCodeValue = "Emergency Response or Law Enforcement Facility" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 790, FeatureCodeValue = "Building General" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 800, FeatureCodeValue = "Health or Medical Facility" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 810, FeatureCodeValue = "Transportation Facility" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 830, FeatureCodeValue = "Government or Military Facility" });
			_subtypeChoices.Add(new SubtypeChoice() {
				SubtypefieldValue = 880, FeatureCodeValue = "Information or Communication Facility" });
			
			return true;
		}

		internal Cursor GetCursor(string cursorFile)
		{
			try
			{
				var streamResourceInfo = Application.GetResourceStream(new Uri(cursorFile, UriKind.Relative));
				return streamResourceInfo == null ? Cursors.Arrow : new Cursor(streamResourceInfo.Stream);
			}
			catch (Exception e) { }
			return Cursors.Arrow;
		}

		public MapPoint GetBoundaryLabelPoint(FeatureLayer polyLayer)
		{
			return GeometryEngine.Instance.LabelPoint(GetBoundary(polyLayer));
		}

		public Polygon GetBoundary(FeatureLayer polyLayer)
		{
			//get a starting point to use
			var rc = polyLayer.GetFeatureClass().Search();
			rc.MoveNext();
			var boundary = ((Feature)rc.Current).GetShape() as Polygon;
			rc.Dispose();

			return boundary;
		}

		#region Overlay

		public CIMSymbolReference MakeHollowSymbol()
		{
			return SymbolFactory.Instance.ConstructPolygonSymbol(
										 null,
										 SymbolFactory.Instance.ConstructStroke(ColorFactory.Instance.RedRGB, 1.5))
										 .MakeSymbolReference();
		}

		public CIMSymbolReference MakeRedLineSymbol()
		{
			return SymbolFactory.Instance.ConstructLineSymbol(
								 SymbolFactory.Instance.ConstructStroke(ColorFactory.Instance.RedRGB, 1.5))
								 .MakeSymbolReference();
		}

		public void AddToOverlay(Geometry geometry)
		{
			if (geometry is Polygon)
			{
				overlay.Add(MapView.Active.AddOverlay(geometry, MakeHollowSymbol()));
			}
			else if (geometry is Polyline)
			{
				overlay.Add(MapView.Active.AddOverlay(geometry, MakeRedLineSymbol()));
			}
		}

		public void ClearOverlay()
		{
			foreach (var ov in overlay)
				ov.Dispose();
			overlay.Clear();
		}

		#endregion

		#region Overrides
		/// <summary>
		/// Called by Framework when ArcGIS Pro is closing
		/// </summary>
		/// <returns>False to prevent Pro from closing, otherwise True</returns>
		protected override bool CanUnload()
		{
			//TODO - add your business logic
			//return false to ~cancel~ Application close
			return true;
		}

		#endregion Overrides


		private void Foo()
		{
			//QueuedTask.Run(() =>
			//{
			//	EditingTemplate.Current.Layer.AutoGenerateTemplates(false);
			//	var templateDef = EditingTemplate.Current.GetDefinition() as CIMFeatureTemplate;

			//	if (string.IsNullOrEmpty(templateDef.ToolProgID) || templateDef.ReadDefaultToolDamlID() != _tool_id)
			//		templateDef.SetDefaultToolDamlID(this.ID);

			//	var exclude_ids = new string[] { "esri_editing_SketchPointAtLineEndPointsTool" };
			//	//any of our "to be" excluded tools still shown on the palette
			//	var notexcluded = exclude_ids.Where(id => !templateDef.GetExcludedToolDamlIds().Contains(id)).ToArray();
			//	if (notexcluded.Count() > 0)
			//		templateDef.SetExcludedToolDamlIds(notexcluded);

			//	//specify tool options
			//	var all_tooloptions = templateDef.ToolOptions?.ToList() ?? new List<CIMEditingTemplateToolOptions>();
			//	var tooloptions = all_tooloptions.FirstOrDefault(to => to.ToolProgID == _tool_id);
			//	if (tooloptions == null)
			//	{
			//		tooloptions = new CIMEditingTemplateToolOptions();
			//		tooloptions.Options = new Dictionary<string, object>();
			//		tooloptions.Options["SaveOverridesToDefault"] = false;
			//		tooloptions.ToolProgID = _tool_id;
			//		all_tooloptions.Add(tooloptions);
			//	}
			//	templateDef.ToolOptions = all_tooloptions.ToArray();

			//	EditingTemplate.Current.SetDefinition(templateDef);
			//});
		}
	}
}
