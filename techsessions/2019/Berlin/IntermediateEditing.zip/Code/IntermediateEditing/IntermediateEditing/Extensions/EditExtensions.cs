﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntermediateEditing.Extensions
{
	public static class EditExtensions
	{
		public static void Difference(this EditOperation editOp, 
			                            BasicFeatureLayer layer,
																  IEnumerable<long> oids, Geometry diffGeom)
		{
			foreach (var oid in oids)
				editOp.Difference(layer, oid, diffGeom);
		}

		public static void Difference(this EditOperation editOp, 
			                                 BasicFeatureLayer layer,
																			 long oid, Geometry diffGeom)
		{
			//get the feature geometry
			var insp = new Inspector();
			insp.Load(layer, oid);

			//do the difference
			var geom = GeometryEngine.Instance.Difference((Geometry)insp["SHAPE"], 
				                                                            diffGeom);
			insp["SHAPE"] = geom;
			//call modify
			editOp.Modify(insp);
		}
	}
}
