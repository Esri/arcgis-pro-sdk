﻿using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntermediateEditing.EditOperations
{
	internal class InspectorBasic1 : Button
	{
		protected async override void OnClick()
		{
			var pointsLayer1 = MapView.Active.Map.GetLayersAsFlattenedList()
				.First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;

			await QueuedTask.Run(() =>
			{
				var inspector = new Inspector();
				inspector.Load(pointsLayer1, 28);
				inspector["FACILITYID"] = "11055.00";
				inspector["NAME"] = "BLDG 52";
				inspector["DESCRIPT"] = inspector["NAME"];
				inspector["FACAREA"] = 31118;

				inspector.Apply();
			});


		}
	}
}
