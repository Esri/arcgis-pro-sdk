﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntermediateEditing.EditOperations
{
	internal class InspectorBasic3 : Button
	{
		protected async override void OnClick()
		{
			var pointsLayer1 = MapView.Active.Map.GetLayersAsFlattenedList()
				.First(l => l.Name == "FacilitySitePoint1") as FeatureLayer;
			var polyLayer3 = MapView.Active.Map.GetLayersAsFlattenedList()
				.First(l => l.Name == "FacilitySite3") as FeatureLayer;
			var distance = 100.0;

			await QueuedTask.Run(() =>
			{
				var pt = Module1.Current.GetBoundaryLabelPoint(polyLayer3);

				var editOp = new EditOperation()
				{
					Name = "Create Feature",
					CancelMessage = "Create Feature cancelled",
					SelectNewFeatures = true
				};

				var inspector = new Inspector();
				inspector.Load(pointsLayer1, 28);
				inspector.Shape = pt;

				editOp.Create(inspector.MapMember, inspector);

				//Linq ToDictionary
				editOp.Modify(pointsLayer1, 24,
									 inspector.ToDictionary(a => a.FieldName, a => a.CurrentValue));

				//old-school copy
				var attribs = new Dictionary<string, object>();
				var pt2 = MapPointBuilder.CreateMapPoint(pt.X + distance, pt.Y);

				foreach (var attrib in inspector)
					attribs[attrib.FieldName] = attrib.IsGeometryField ? pt2 : 
					                                       attrib.CurrentValue;

				editOp.Create(pointsLayer1, attribs);
				editOp.Execute();
			});
		}
	}
}
