﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace IntermediateEditing.EditOperations
{
  internal class EditOperationBasic : Button
  {
    protected override void OnClick()
    {
      var pointsLayer1 = MapView.Active.Map.GetLayersAsFlattenedList().First(
				l => l.Name == "FacilitySitePoint1") as FeatureLayer;
      var pointsLayer2 = MapView.Active.Map.GetLayersAsFlattenedList().First(
				l => l.Name == "FacilitySitePoint2") as FeatureLayer;
      var pointsLayer3 = MapView.Active.Map.GetLayersAsFlattenedList().First(
				l => l.Name == "FacilitySitePoint3") as FeatureLayer;

      var polyLayer1 = MapView.Active.Map.GetLayersAsFlattenedList().First(
				l => l.Name == "FacilitySite1") as FeatureLayer;
      var polyLayer2 = MapView.Active.Map.GetLayersAsFlattenedList().First(
				l => l.Name == "FacilitySite2") as FeatureLayer;
      var polyLayer3 = MapView.Active.Map.GetLayersAsFlattenedList().First(
				l => l.Name == "FacilitySite3") as FeatureLayer;

      //Add and modify some features
      QueuedTask.Run(() =>
      {
        // create edit operation
        var editOp = new EditOperation();
        editOp.Name = "FileGDB edit operation";
        editOp.CancelMessage = $"{editOp.Name} cancelled";

        using (var fc = polyLayer1.GetFeatureClass())
        using (var rc = fc.Search())
        {
          //Get a starting point to use
          rc.MoveNext();
          var boundary = ((Feature)rc.Current).GetShape() as Polygon;
          var start_pt = GeometryEngine.Instance.LabelPoint(boundary);
          var distance = boundary.Length / 100.0;

          //Add three points - 1 point to each layer
          editOp.Create(pointsLayer1, start_pt);
          editOp.Create(pointsLayer2, GeometryEngine.Instance.Move(
						start_pt, distance, 0.0));
          editOp.Create(pointsLayer3, GeometryEngine.Instance.Move(
						start_pt, distance * 2, 0.0));

          double bufferDistance = boundary.Length / 25.0;
          //Modify two polygons - 1 polygon in two layers
          editOp.Modify(polyLayer2, 3, 
						GeometryEngine.Instance.Buffer(boundary, bufferDistance));
          editOp.Modify(polyLayer3, 5, 
						GeometryEngine.Instance.Buffer(boundary, bufferDistance * 2));
          editOp.SelectModifiedFeatures = true;

          //Execute the operations
          editOp.Execute();
        }
      });
    }
  }
}
