﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;

namespace Geocode
{
    internal class Custom : Button
    {
        protected override void OnClick()
        {
        }
    }
}
