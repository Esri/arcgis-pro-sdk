﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ArcGIS.Desktop.Framework;

namespace Geocode.Geocode {
    internal class GeocodeStartPageViewModel : INotifyPropertyChanged
    {

      private ICommand _about;
        private string _address = "380 New York St, Redlands, Ca, 92373";

        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
                NotifyPropertyChanged();
            }
        }

    #region About

    public ICommand AboutArcGISProCommand
    {
      get
      {
        if (_about == null)
          _about = new RelayCommand(() => FrameworkApplication.OpenBackstage());
        return _about;
      }
    }
    #endregion

    #region INotifyPropertyChanged
    public event PropertyChangedEventHandler PropertyChanged = delegate { };

        protected virtual void NotifyPropertyChanged([CallerMemberName] string propName = "") {
            PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

        #endregion
    }
}

