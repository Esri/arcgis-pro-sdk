﻿using ArcGIS.Core.Events;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Mapping;
using Geocode.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Geocode.Geocode
{
    /// <summary>
    /// Interaction logic for GeocodeUI.xaml
    /// </summary>
    public partial class GeocodeUI : UserControl
    {
        private SubscriptionToken _eventToken = null;
        private SubscriptionToken _eventToken2 = null;
        private OnlineLocator _locator = null;

        public GeocodeUI()
        {
            InitializeComponent();
            this.RootContent.DataContext = this;
        }

        #region Properties

        public string GeocodeHelp => $"Hello \"{System.Security.Principal.WindowsIdentity.GetCurrent().Name}\", please enter your address or ticket#:";

        public static readonly DependencyProperty AddressProperty =
                      DependencyProperty.Register("Address", typeof(string),
                               typeof(GeocodeUI), new PropertyMetadata(string.Empty));

        public string Address
        {
            get { return (string)GetValue(AddressProperty); }
            set { SetValue(AddressProperty, value); }
        }

        public ICommand CmdGeocodeAddress
        {
            get
            {
                return new RelayCommand((args) => GeocodeAddress(), () => true); ;
            }
        }

        #endregion Properties

        private async void GeocodeAddress()
        {
            _eventToken = ArcGIS.Desktop.Mapping.Events.MapViewInitializedEvent.Subscribe(async (args) => {
                await ZoomToGeocodedLocationAsync(args.MapView);
                ArcGIS.Desktop.Mapping.Events.MapViewInitializedEvent.Unsubscribe(_eventToken);
                _eventToken = null;
            });

            _locator = new OnlineLocator();
            _locator.Find(this.Address);
            if (Project.Current != null)
            {
                await ZoomToGeocodedLocationAsync(MapView.Active);
                FrameworkApplication.CloseBackstage();
            }
            else
            {
                await Project.OpenAsync(Module1.AcmeProject);
            }
        }

        private async Task ZoomToGeocodedLocationAsync(MapView mv)
        {
            //if (MapView.Active == null)
            //    return;
            await _locator.AddLocationToMapAndZoomAsync(mv);

            //Clean up the graphic on the first pan or zoom
            _eventToken2 = ArcGIS.Desktop.Mapping.Events.MapViewCameraChangedEvent.Subscribe((arg) => {
                _locator.ClearGraphic();
                ArcGIS.Desktop.Mapping.Events.MapViewCameraChangedEvent.Unsubscribe(_eventToken2);
                _eventToken2 = null;
            });
        }
    }
}
