﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;


namespace Geocode.Geocode
{
    internal class GeocodeBackstageTabViewModel : BackstageTab
    {
        /// <summary>
        /// Called when the backstage tab is selected.
        /// </summary>
        protected override Task InitializeAsync()
        {
            return base.InitializeAsync();
        }

        /// <summary>
        /// Called when the backstage tab is unselected.
        /// </summary>
        protected override Task UninitializeAsync()
        {
            return base.UninitializeAsync();
        }

        private string _tabHeading = "Enter Address:";
        public string TabHeading
        {
            get
            {
                return _tabHeading;
            }
            set
            {
                SetProperty(ref _tabHeading, value, () => TabHeading);
            }
        }
        private string _address = "San Diego";
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                SetProperty(ref _address, value, () => Address);
            }
        }
    }
}
