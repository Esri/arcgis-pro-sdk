﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using Newtonsoft.Json.Linq;

namespace Geocode.Models {
    internal class OnlineLocator {

        private Tuple<double, double, int> _result = null;

        private IDisposable _graphic = null;
        public Tuple<double, double, int> Result => _result;

        public void Find(string address) {
            WebClient wc = new WebClient();
            wc.Headers.Add("user-agent", "GeocodeExample");
            wc.Headers.Add("referer", "GeocodeExample");
            wc.Encoding = System.Text.Encoding.UTF8;

            using (StreamReader sr = new StreamReader(wc.OpenRead(new GeocodeUri(address).Uri),
                                                      System.Text.Encoding.UTF8, true)) {
                string response = sr.ReadToEnd();
                if (!ResponseIsError(response)) {
                    dynamic queryResults = JObject.Parse(response);
                    if (queryResults.locations != null) {
                        List<dynamic> locations = new List<dynamic>();
                        // store the results in the list
                        locations.AddRange(queryResults.locations);
                        if (locations.Count > 0) {
                            var bestMatch = locations[0];
                            double x = bestMatch.feature.geometry.x.Value;
                            double y = bestMatch.feature.geometry.y.Value;
                            int wkid = (int)queryResults.spatialReference.latestWkid.Value;
                            _result = new Tuple<double, double, int>(x, y, wkid);
                        }
                    }
                }
            }
        }

        public Task AddLocationToMapAndZoomAsync(MapView mv) {
            return QueuedTask.Run(() => {
                ClearGraphic();
                if (_result != null) {
                    var pt = MapPointBuilder.CreateMapPoint(
                    _result.Item1, _result.Item2, SpatialReferenceBuilder.CreateSpatialReference(_result.Item3));
                    //Buffer it
                    var poly = GeometryEngine.Instance.Buffer(pt, 1500);                   
                    int wkid = mv.Map.SpatialReference.LatestWkid;

                    if (!mv.Map.SpatialReference.IsEqual(poly.SpatialReference)) {
                        //project the point and polygon
                        pt = GeometryEngine.Instance.Project(pt, mv.Map.SpatialReference) as MapPoint;
                        poly = GeometryEngine.Instance.Project(poly, mv.Map.SpatialReference);
                    }

                    //Zoom
                    mv.ZoomTo(
                        poly,
                        new TimeSpan(0, 0, 0, 3));

                    //Add the location to the overlay
                    var sym = SymbolFactory.Instance.ConstructPointSymbol(ColorFactory.Instance.RedRGB, 14.0, SimpleMarkerStyle.Circle);
                    _graphic = mv.AddOverlay(pt, sym.MakeSymbolReference());
                }
            });
        }

        public void ClearGraphic() {
            if (_graphic != null) {
                _graphic.Dispose();
                _graphic = null;
            }
        }

        private bool ResponseIsError(string response) {
            return response.Substring(0, "{\"error\":".Length).CompareTo("{\"error\":") == 0;
        }
    }
}
