﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geocode.Models {
    internal class GeocodeUri {
        //http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/find?text=380+New+York+Street%2C+Redlands%2C+CA+92373&outFields=match_addr,addr_type,region,postal,country&outSR=102100&maxLocations=5&f=pjson
        //http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/find?text=380%20New%20York%20St,%20Redlands,%20Ca,%2092373&outSR=102100&f=json
        //http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/find?text=London&outSR=4326&f=pjson

        private static string _baseURL = "http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/";
        private static string _verb = "find";
        private static string _format = "json";//change to "pjson" to "pretty-print"
        private static int _wkid = 102100;// 4326;
        private StringBuilder _url = new StringBuilder();
        public static string outFields = "match_addr,addr_type,region,postal,country,score";

        /// <summary>
        /// Default constructor. Provide the search text for geocoding and a flag indicating whether or not
        /// to escape the search text. The default is True (i.e. escape the text)
        /// </summary>
        /// <param name="text">The text to search for</param>
        public GeocodeUri(string text) {
            //build the URL
            _url.Append(_baseURL);
            _url.Append(_verb);
            //string queryStringFormat = "text={0}&outFields={1}&outSR={2}&maxLocations={3}&f={4}";

            //fill in the parameters
            string query = $"text={System.Web.HttpUtility.UrlPathEncode(text)}&outSR={_wkid}&f={_format}";

            _url.Append("?");
            _url.Append(query);
        }
        /// <summary>
        /// The Uri containing all the relevant parameters and search text
        /// </summary>
        public Uri Uri
        {
            get
            {
                return new Uri(_url.ToString(), UriKind.Absolute);
            }
        }

        public static int Wkid => _wkid;
    }
}
