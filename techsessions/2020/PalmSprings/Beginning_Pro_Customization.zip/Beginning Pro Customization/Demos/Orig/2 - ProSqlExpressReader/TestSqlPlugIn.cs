﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.PluginDatastore;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ProSqlExpressReader
{
	internal class TestSqlPlugIn : Button
	{
		/// <summary>
		/// TODO: 7 - Using [consuming] a plugin datasource
		/// </summary>
		protected override void OnClick()
		{
			try
			{
				QueuedTask.Run(() =>
				{
					var mapToAddTo = MapView.Active?.Map;
					var path = @"C:\Data\PluginData\SQLExpressData\SqlExpress.sqlexpress|Server=localhost;Database=TestSqlExpress;Integrated Security=SSPI;|";
					var conSql = new PluginDatasourceConnectionPath("ProSqlExpressPluginDatasource",
																					new Uri(path.Replace(";", "||"), UriKind.Absolute));
					using (var pluginSql = new PluginDatastore(conSql))
					{
						foreach (var tn in pluginSql.GetTableNames())
						{
							using (var table = pluginSql.OpenTable(tn))
							{
								if (table is FeatureClass)
								{
									//Add as a layer to the active map or scene
									LayerFactory.Instance.CreateFeatureLayer((FeatureClass)table, mapToAddTo);
								}
								else
								{
									//add as a standalone table
									StandaloneTableFactory.Instance.CreateStandaloneTable(table, mapToAddTo);
								}
							}
						}
					}
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show($@"Exception: {ex.ToString()}");
			}
		}
	}
}
