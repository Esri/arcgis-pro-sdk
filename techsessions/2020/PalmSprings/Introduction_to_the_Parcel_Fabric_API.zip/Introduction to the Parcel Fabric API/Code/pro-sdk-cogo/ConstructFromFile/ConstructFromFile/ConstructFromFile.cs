﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Core.SystemCore;
using System.Windows.Forms;
using System.IO;

namespace ConstructFromFile
{
  internal class ConstructFromFile : ArcGIS.Desktop.Framework.Contracts.Button
  {
    protected override void OnClick()
    {
      //Simple check for selected layer
      if (MapView.Active.GetSelectedLayers().Count == 0)
      {
        System.Windows.MessageBox.Show("Please select a feature layer in the table of contents", "Construct From File");
        return;
      }

      //go get a traverse file
      // Display .Net dialog for File selection.
      System.Windows.Forms.OpenFileDialog openFileDialog = new System.Windows.Forms.OpenFileDialog();
      // Set File Filter
      openFileDialog.Filter = "Traverse file (*.txt)|*.txt|Cadastral XML (*.xml)|*.xml";
      // Enable multi-select
      openFileDialog.Multiselect = true;
      // Don't need to Show Help
      openFileDialog.ShowHelp = false;
      // Set Dialog Title
      openFileDialog.Title = "Construct Features From File";
      openFileDialog.FilterIndex = 1;
      // Display Open File Dialog
      if (openFileDialog.ShowDialog() != DialogResult.OK)
      {
        openFileDialog = null;
        return;
      }

      //make a temporary file for the combined traverse files if more than one was selected
      string sTempPath = System.IO.Path.GetTempPath();
      string sCombinedTraverseFile = System.IO.Path.Combine(sTempPath, "LastUpdatedCombinedTraverseFileFromBatch.txt");
      int iTotalFiles = openFileDialog.FileNames.GetLength(0);

      const int chunkSize = 2 * 1024; // 2KB
      using (var output = File.Create(sCombinedTraverseFile))
      {
        foreach (var file in openFileDialog.FileNames)
        {
          using (var input = File.OpenRead(file))
          {
            var buffer = new byte[chunkSize];
            int bytesRead;
            while ((bytesRead = input.Read(buffer, 0, buffer.Length)) > 0)
              output.Write(buffer, 0, bytesRead);           
          }
        }
      }

      TextReader tr = null;
      try
      {
        tr = new StreamReader(sCombinedTraverseFile);
      }
      catch (Exception ex)
      {
        System.Windows.Forms.MessageBox.Show(ex.Message);
        return;
      }

      string sCourse = "";
      int iCount = 0;

      var DirType = new ArcGIS.Core.SystemCore.DirectionType();
      var DirUnit = new ArcGIS.Core.SystemCore.DirectionUnits();

      List<string> sFileLines = new List<string>();
      List<string> sValidCodes = new List<string>();
      sValidCodes.Add("DT ");
      sValidCodes.Add("DU ");
      sValidCodes.Add("SP ");
      sValidCodes.Add("EP ");
      sValidCodes.Add("DD ");
      sValidCodes.Add("AD ");
      sValidCodes.Add("TC ");
      sValidCodes.Add("NC ");

      //Run on MCT
      QueuedTask.Run( async () =>
      {
        try
        {
          sCourse = tr.ReadLine();
          //fill the array with the lines from the file
          while (sCourse != null)
          {
            try
            {
              if (sCourse.Trim().Length >= 3) //test for valid string length
              {
                if(sValidCodes.Contains(sCourse.Trim().Substring(0,3).ToUpper()))
                  sFileLines.Add(sCourse);
              }
              iCount++;
              sCourse = tr.ReadLine();
            }
            catch (Exception ex)
            {
              System.Windows.Forms.MessageBox.Show(ex.Message);
            }
          }
          tr.Close(); //close the file and release resources
        }
        catch (Exception ex)
        {
          System.Windows.Forms.MessageBox.Show(ex.Message);
        }

        //Get the active map view.
        var mapView = MapView.Active;
        if (mapView?.Map == null)
          return;

        var cimDefinition = mapView.Map?.GetDefinition();
        if (cimDefinition == null) return;
        var cim_g2g = cimDefinition.GroundToGridCorrection;

        double dDirectionOffsetCorrection = 0;
        double dScaleFactor = 1;

        if (cim_g2g.UsingConstantScaleFactor())
          dScaleFactor = cim_g2g.GetConstantScaleFactor();
        //else scale factor is computed from elevation obtained from each feature    , see relevant code below.

        if (cim_g2g.UsingDirectionOffset()) 
          dDirectionOffsetCorrection = cim_g2g.GetDirectionOffset() * Math.PI / 180; 
        // this property is in decimal degrees, and is converted to radians
  
        var featLyr = MapView.Active.GetSelectedLayers().First() as FeatureLayer;
        var fcDefinition = featLyr.GetFeatureClass().GetDefinition();
        bool bIsCOGOEnabled = fcDefinition.IsCOGOEnabled();

        var spatRef = featLyr.Map.SpatialReference;
        string shapeFldName = fcDefinition.GetShapeField();

        bool bIsParcelFabricLine = (bIsCOGOEnabled && fcDefinition.FindField("CreatedByRecord") > -1 
                                    && fcDefinition.FindField("RetiredByRecord") > -1
                                    && fcDefinition.FindField("COGOType") > -1 
                                    && fcDefinition.FindField("Scale") > -1 
                                    && fcDefinition.FindField("Rotation") > -1);

        bool bIsParcelFabricPolygon = (fcDefinition.FindField("CreatedByRecord") > -1 && fcDefinition.FindField("RetiredByRecord") > -1
                            && fcDefinition.FindField("StatedArea") > -1 && fcDefinition.FindField("StatedAreaUnit") > -1);

        Coordinate2D StartCoord = new Coordinate2D();
        Coordinate2D EndCoord = new Coordinate2D();

        var op = new EditOperation();
        op.Name = "Construct Features From File";
        op.SelectModifiedFeatures = false;
        op.SelectNewFeatures = true;


        //Create the geometry segments parsed out from the in-memory file courses
        #region Create features
        List<Segment> segments = new List<Segment>();
        LineSegment ExitTangent;
        LineSegment EntryTangent = null;
        EllipticArcSegment pCircArc;

        Polygon newPolygon = null;
        Polyline newPolyline = null;

        GeometryType geomType = fcDefinition.GetShapeType();
        Dictionary<string, object> COGOAttributes = new Dictionary<string, object>();

        foreach (string sTraverseCourse in sFileLines)
        {
          sCourse = sTraverseCourse.ToLower();
          if (sCourse.Contains("dt"))
          {
            if (sCourse.Contains("qb"))
              DirType = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing;
            else if (sCourse.Contains("na"))
              DirType = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth;
            else if (sCourse.Contains("sa"))
              DirType = ArcGIS.Core.SystemCore.DirectionType.SouthAzimuth;
            else if (sCourse.Contains("p"))
              DirType = ArcGIS.Core.SystemCore.DirectionType.Polar;
          }
          if (sCourse.Contains("du"))
          {
            if (sCourse.Contains("dms"))
              DirUnit = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds;
            else if (sCourse.Contains("dd"))
              DirUnit = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees;
            else if (sCourse.Contains("g"))
              DirUnit = ArcGIS.Core.SystemCore.DirectionUnits.Gradians;
            else if (sCourse.Contains("r"))
              DirUnit = ArcGIS.Core.SystemCore.DirectionUnits.Radians;
          }

          bool IsLoopTraverse = false;
          bool IsClosedTraverse = false;
          //note  that EP code comes immediately after SP code, but EP is optional.
          //use presence of EP to indicate an adjustable closed traverse that may or may not be loop

          if (sCourse.Contains("sp"))
          {//start point

            ////TODO: may need MapPoint for map projection...
            ////var MapPt1 = MapPointBuilder.CreateMapPoint(StartPoint, spatRef);

            //Since this code supports multiple traverses in the same file, and multiple files we create the 
            //polygon from the previous loop of courses when geometry type is polygon, and
            //the next start point is found.

            if (geomType == GeometryType.Polygon && segments.Count > 0)
            {
              newPolygon = PolygonBuilder.CreatePolygon(segments, spatRef);
              segments.Clear();
              if (newPolygon != null)
              {
                COGOAttributes.Add(fcDefinition.GetShapeField(), newPolygon);
                op.Create(featLyr, COGOAttributes);
                COGOAttributes.Clear();//this is OK. Create makes a clone / copy of the attributes
              }
            }

            string[] XY = sTraverseCourse.Split(' ');
            double x = Convert.ToDouble(XY[1]);
            double y = Convert.ToDouble(XY[2]);
            StartCoord.X = x;
            StartCoord.Y = y;
          }

          if (sCourse.Contains("ep"))
          {//end point, indicates closed traverse
            IsClosedTraverse = true;
            ////TODO: may need MapPoint for map projection...
            ////var MapPt2 = MapPointBuilder.CreateMapPoint(EndPoint, spatRef);

            string[] XY = sTraverseCourse.Split(' ');
            double x = Convert.ToDouble(XY[1]);
            double y = Convert.ToDouble(XY[2]);
            EndCoord.X = x;
            EndCoord.Y = y;
            //Test for loop traverse. NB: as currently written this is dependent on the EP code directly following after the SP code
            if (Math.Abs(EndCoord.X - StartCoord.X) < 0.001 && Math.Abs(EndCoord.Y - StartCoord.Y) < 0.001)
              IsLoopTraverse = true;
            else if (EndCoord.X == 0 && EndCoord.Y == 0 && StartCoord.X == 0 && StartCoord.Y == 0)
              IsLoopTraverse = true;
            else
              IsLoopTraverse = false;
          }

          if (cim_g2g.UsingElevationMode())
          {
            double dElevation = 0;
            if (StartCoord.X != 0 && StartCoord.Y != 0)
            {
              var ptSpotXY = MapPointBuilder.CreateMapPoint(StartCoord, spatRef);
              if (ptSpotXY != null)
              {
                //check if the elevation mode is using a surface, and get the value from surface.
                if (ElevationCapturing.CaptureMode == ElevationCaptureMode.Surface)
                {
                  var ptSpotZ = (await mapView.Map.GetZsFromSurfaceAsync(ptSpotXY)).Geometry;
                  //scale factor is computed using elevation obtained from the location of each feature.
                  if (ptSpotZ != null)
                  {
                    dElevation = (ptSpotZ as MapPoint).Coordinate3D.Z;
                    dScaleFactor = await mapView.Map.ComputeCombinedScaleFactor(StartCoord.X, StartCoord.Y, StartCoord.X + 100, StartCoord.Y + 100, dElevation);
                  }
                }
                //otherwise, if the mode is Constant, then get the elevation directly
                else if (ElevationCapturing.CaptureMode == ElevationCaptureMode.Constant)
                {
                  dElevation = ElevationCapturing.ElevationConstantValue;
                  dScaleFactor = await mapView.Map.ComputeCombinedScaleFactor(StartCoord.X, StartCoord.Y, StartCoord.X + 100, StartCoord.Y + 100, dElevation);
                }
              }
            }
          }                                              

          var pSeg = CreateSegmentFromStringCourse(sTraverseCourse, StartCoord, DirType, DirUnit,
            EntryTangent, dScaleFactor, dDirectionOffsetCorrection, out ExitTangent, out pCircArc);

          if (pSeg == null)
            continue;

          StartCoord = pSeg.EndCoordinate; //set last computed point for start of next line
          EntryTangent = ExitTangent; //set the Entry tangent to be the previous course exit tangent

          if (pCircArc != null)
            segments.Add(pCircArc);
          else
            segments.Add(pSeg);

          if (geomType == GeometryType.Polyline)
          {
            newPolyline = PolylineBuilder.CreatePolyline(segments, spatRef);
            segments.Clear();
          }

          if (newPolyline != null)
          {
            COGOAttributes.Add(shapeFldName, newPolyline);

            if (bIsCOGOEnabled)
            { 
              COGOAttributes.Add("Direction", PolarRadiansToNorthAzimuthDecimalDegrees(pSeg.Angle - dDirectionOffsetCorrection));
              if (pCircArc != null)
              {
                if (pCircArc.IsCounterClockwise)
                  COGOAttributes.Add("Radius", -1 * pCircArc.SemiMajorAxis / dScaleFactor);
                else
                  COGOAttributes.Add("Radius", pCircArc.SemiMajorAxis / dScaleFactor);
                COGOAttributes.Add("ArcLength", pCircArc.Length / dScaleFactor);
              }
              else
                COGOAttributes.Add("Distance", pSeg.Length / dScaleFactor);
            }

            if (bIsParcelFabricLine)
            {
              if (cim_g2g.UsingDistanceFactor() || cim_g2g.UsingDirectionOffset())
                COGOAttributes.Add("COGOType", 1); //since this is coming in from a file we will set this COGO type as From measurements = 1

              if (cim_g2g.UsingDistanceFactor())
                COGOAttributes.Add("Scale", dScaleFactor);

              if (cim_g2g.UsingDirectionOffset())
                COGOAttributes.Add("Rotation", dDirectionOffsetCorrection < Math.PI ? dDirectionOffsetCorrection * 180 / Math.PI : (dDirectionOffsetCorrection * 180 / Math.PI) - 360);
            }

            op.Create(featLyr, COGOAttributes);
            COGOAttributes.Clear();//this is OK. Create makes a clone / copy of the attributes
          }
        }

        if (geomType == GeometryType.Polygon)
        {
          newPolygon = PolygonBuilder.CreatePolygon(segments, spatRef);
          segments.Clear();
          if (newPolygon != null)
          {
            COGOAttributes.Add(fcDefinition.GetShapeField(), newPolygon);
            op.Create(featLyr, COGOAttributes);
            COGOAttributes.Clear(); //this is OK. Create makes a clone / copy of the attributes, prior to op.Execute();
          }
        }

        #endregion

        op.Execute();
      });

    }

    private double PolarRadiansToNorthAzimuthDecimalDegrees(double InPolarRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InPolarRadians, ConvDef);
    }

    private LineSegment CreateSegmentFromStringCourse(String inCourse, Coordinate2D FromCoordinate, ArcGIS.Core.SystemCore.DirectionType DirType,
      ArcGIS.Core.SystemCore.DirectionUnits DirUnits,
      LineSegment EntryTangent, double ScaleFactor, double DirectionOffsetInRadians, out LineSegment ExitTangent, out EllipticArcSegment outCircularArc)
    {
      string[] sCourse = inCourse.Split(' ');
      outCircularArc = null;
      ExitTangent = null;
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = DirType,
        DirectionUnitsIn = DirUnits,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };

      string item = (string)sCourse.GetValue(0);
      if (item.ToLower() == "dd")
      {//Direction distance -- straight line course

        double vecDirn = AngConv.ConvertToDouble((string)sCourse.GetValue(1), ConvDef);

        Coordinate3D pVec1 = new Coordinate3D(FromCoordinate.X, FromCoordinate.Y, 0);
        Coordinate3D pVec2 = new Coordinate3D();
        pVec2.SetPolarComponents(vecDirn - DirectionOffsetInRadians, 0, Convert.ToDouble(sCourse.GetValue(2)) * ScaleFactor);
        Coordinate2D coord2 = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
        var pSeg = LineBuilder.CreateLineSegment(FromCoordinate, coord2);

        ExitTangent = pSeg;
        return pSeg;
      }
      if (item.ToLower() == "ad")
      {//Angle deflection distance
       //  double dDeflAngle = Angle_2_Radians((string)sCourse.GetValue(1), inDirectionUnits);
        ConvDef.DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth; //temp setting
        double dDeflAngle = AngConv.ConvertToDouble((string)sCourse.GetValue(1), ConvDef);
        //now need to take the previous tangent segment, reverse its orientation and 
        //add +ve clockwise to get the bearing
        var calcLine = EntryTangent; //this is currently in polar radians

        ConvDef.DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians; //temp setting
        ConvDef.DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar; //temp setting
        ConvDef.DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.SouthAzimuth; //temp setting
        double dBear = AngConv.ConvertToDouble(calcLine.Angle, ConvDef) + dDeflAngle;
        ConvDef.DirectionUnitsIn = DirUnits; //set it back
        ConvDef.DirectionTypeIn = DirType; //set it back

        ConvDef.DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth; //set it back

        Coordinate3D pVec1 = new Coordinate3D(FromCoordinate.X, FromCoordinate.Y, 0);
        Coordinate3D pVec2 = new Coordinate3D();
        pVec2.SetPolarComponents(dBear, 0, Convert.ToDouble(sCourse.GetValue(2)) * ScaleFactor);
        Coordinate2D coord2 = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
        var pSeg = LineBuilder.CreateLineSegment(FromCoordinate, coord2);

        ExitTangent = pSeg;
        return pSeg;
      }
      else if ((item.ToLower() == "nc") || (item.ToLower() == "tc"))
      {
        double dChordlength;
        double dChordBearing;
        var pArcSeg = ConstructCurveFromString(inCourse, EntryTangent, DirType, DirUnits, ScaleFactor,
          out dChordlength, out dChordBearing);

        if (pArcSeg == null)
          return null;

        double dRadius = pArcSeg.SemiMajorAxis;
        esriArcOrientation ArcOrientation = pArcSeg.IsCounterClockwise ? esriArcOrientation.esriArcCounterClockwise : esriArcOrientation.esriArcClockwise;
        MinorOrMajor MinMajor = pArcSeg.IsMinor ? MinorOrMajor.Minor : MinorOrMajor.Major;

        if(item.ToLower() == "nc")
          dChordBearing += DirectionOffsetInRadians; // only correct non-tangent curve, because the tangent curve's previous course was already corrected.

        pArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(FromCoordinate.ToMapPoint(),
          dChordlength, dChordBearing, dRadius, ArcOrientation, MinMajor);

        try
        {
          ConvDef.DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians; //temp setting
          ConvDef.DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar; //temp setting

          double d90 = pArcSeg.IsCounterClockwise ? -Math.PI / 2 : Math.PI / 2;
          var ExitTangentBearing = AngConv.ConvertToDouble(pArcSeg.EndAngle, ConvDef) + d90;//convert to north az radians
          dChordBearing = AngConv.ConvertToDouble(dChordBearing, ConvDef);

          ConvDef.DirectionUnitsIn = DirUnits; //set it back
          ConvDef.DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth; //set it back

          Coordinate3D pVec1 = new Coordinate3D(pArcSeg.StartCoordinate.X, pArcSeg.StartCoordinate.Y, 0);
          Coordinate3D pVec2 = new Coordinate3D();
          pVec2.SetPolarComponents(ExitTangentBearing, 0, 100);
          Coordinate2D coord2 = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
          ExitTangent = LineBuilder.CreateLineSegment(pArcSeg.StartCoordinate, coord2);

          pVec1 = new Coordinate3D(FromCoordinate.X, FromCoordinate.Y, 0);
          pVec2 = new Coordinate3D();
          pVec2.SetPolarComponents(dChordBearing, 0, dChordlength);
          coord2 = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
          var pSeg = LineBuilder.CreateLineSegment(FromCoordinate, coord2);

          outCircularArc = pArcSeg;
          return pSeg;
        }
        catch { }
      }
      return null;
    }

    private EllipticArcSegment ConstructCurveFromString(string inString, LineSegment ExitTangentFromPreviousCourse,
          ArcGIS.Core.SystemCore.DirectionType DirType, ArcGIS.Core.SystemCore.DirectionUnits DirUnits, double ScaleFactor, out double outChordLength, out double outChordBearing)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = DirType,
        DirectionUnitsIn = DirUnits,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };

      EllipticArcSegment ArcSeg = null;

      Coordinate2D pPt = new Coordinate2D() { X = 1000, Y = 1000 };
      //initialize the curve params
      bool bHasRadius = false; double dRadius = -1;
      bool bHasChord = false; double dChord = -1;
      bool bHasArc = false; double dArcLength = -1;
      bool bHasDelta = false; double dDelta = -1;
      bool bCCW = false; //assume curve to right unless proven otherwise
      //now initialize bearing types for non-tangent curves
      bool bHasRadialBearing = false; double dRadialBearing = -1;
      bool bHasChordBearing = false; double dChordBearing = -1;
      bool bHasTangentBearing = false; double dTangentBearing = -1;

      int iItemPosition = 0;
      string[] sCourse = inString.ToLower().Split(' ');
      int UpperBound = sCourse.GetUpperBound(0);
      bool bIsTangentCurve = (((string)sCourse.GetValue(0)).ToLower() == "tc");
      foreach (string item in sCourse)
      {
        if (item == null)
          break;
        if (item == "r" && !bHasRadius && iItemPosition <= 3)
        {// this r is for radius
          dRadius = Convert.ToDouble(sCourse.GetValue(iItemPosition + 1));
          dRadius *= ScaleFactor;
          bHasRadius = true; //found a radius
        }
        if (item == "c" && !bHasChord && iItemPosition <= 3)
        {// this c is for chord length
          dChord = Convert.ToDouble(sCourse.GetValue(iItemPosition + 1));
          dChord *= ScaleFactor;
          bHasChord = true; //found a chord length
        }
        if (item == "a" && !bHasArc && iItemPosition <= 3)
        {// this a is for arc length
          dArcLength = Convert.ToDouble(sCourse.GetValue(iItemPosition + 1));
          dArcLength *= ScaleFactor;
          bHasArc = true; //found an arc length
        }
        if (item == "d" && !bHasDelta && iItemPosition <= 3)
        {// this d is for delta or central angle
          ConvDef.DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar;//temp
          dDelta = AngConv.ConvertToDouble((string)sCourse.GetValue(iItemPosition + 1), ConvDef);
          ConvDef.DirectionTypeIn = DirType;//setting it back
          bHasDelta = true; //found a central angle
        }
        if (item == "r" && !bHasRadialBearing && iItemPosition > 3 && iItemPosition < 7 && UpperBound > 5)
        {// this r is for radial bearing
          try
          {
            dRadialBearing = AngConv.ConvertToDouble((string)sCourse.GetValue(iItemPosition + 1), ConvDef);
            bHasRadialBearing = true; //found a radial bearing
          }
          catch
          {
            bHasRadialBearing = true; //found a radial bearing. This will catch case of final R meaning a curve right and not radial bearing
          }
        }
        if (item == "c" && !bHasChordBearing && iItemPosition > 3)
        {// this c is for chord bearing
          dChordBearing = AngConv.ConvertToDouble((string)sCourse.GetValue(iItemPosition + 1), ConvDef);
          bHasChordBearing = true; //found a chord bearing
        }
        if (item == "t" && !bHasTangentBearing && iItemPosition > 3)
        {// this t is for tangent bearing
          dTangentBearing = AngConv.ConvertToDouble((string)sCourse.GetValue(iItemPosition + 1), ConvDef);
          bHasTangentBearing = true; //found a tangent bearing
        }
        if (item == "l")
          // this l is for defining a curve to the left
          bCCW = true;

        iItemPosition++;
      }

      esriArcOrientation CCW = bCCW ? esriArcOrientation.esriArcCounterClockwise : esriArcOrientation.esriArcClockwise;
      var MapPt1 = MapPointBuilder.CreateMapPoint(pPt, null);

      if (!(bIsTangentCurve)) //non-tangent curve
      {//chord bearing
        if (bHasRadius && bHasChord && bHasChordBearing) // A.
        {
          try
          {
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
            dRadius, CCW, MinorOrMajor.Minor, null);
          }
          catch { };
        }

        if (bHasRadius && bHasArc && bHasChordBearing) // B.
        {            
          try
          {
            double dCentralAngle = dArcLength / dRadius;
            dChord = 2 * dRadius * Math.Sin(dCentralAngle / 2);
            MinorOrMajor MinMaj = dCentralAngle > Math.PI ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructBearingRadiusArc(pPt, dChordBearing, bCCW, dRadius, dArcLength);

        if (bHasRadius && bHasDelta && bHasChordBearing) // C.
        {            
          try
          {
            dChord = 2 * dRadius * Math.Sin(dDelta / 2);
            MinorOrMajor MinMaj = Math.Abs(dDelta) > Math.PI ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructBearingRadiusAngle(pPt, dChordBearing, bCCW, dRadius, dDelta);

        if (bHasChord && bHasDelta && bHasChordBearing) // D.
        {
          try
          {
            dRadius = (0.5 * dChord) / Math.Sin(dDelta / 2);
            MinorOrMajor MinMaj = dDelta > Math.PI ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
            
          }
          catch { };
        }//pConstArc.ConstructBearingAngleChord(pPt, dChordBearing, bCCW, dDelta, dChord);

        if (bHasChord && bHasArc && bHasChordBearing) // E.
        {
          try
          {
            //Newton's approximation method
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
                dArcLength, CCW, null);
          }
          catch { };
        }//pConstArc.ConstructBearingChordArc(pPt, dChordBearing, bCCW, dChord, dArcLength);

        //tangent bearing
        if (bHasRadius && bHasChord && bHasTangentBearing) // F.
        {
          try
          {
            double dHalfDelta = Math.Abs(Math.Asin(dChord / (2 * dRadius)));
            //get chord bearing from given tangent bearing in polar radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dTangentBearing + dHalfDelta;
            else
              dChordBearing = dTangentBearing - dHalfDelta;
            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }//pConstArc.ConstructTangentRadiusChord(EntryTangentSegment, false, bCCW, dRadius, dChord);
          catch { };
        }

        if (bHasRadius && bHasArc && bHasTangentBearing) // G.
        {
          try
          {
            double dHalfDelta = (dArcLength / dRadius) / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dTangentBearing + dHalfDelta;
            else
              dChordBearing = dTangentBearing - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusArc(EntryTangentSegment, false, bCCW, dRadius, dArcLength);

        if (bHasRadius && bHasDelta && bHasTangentBearing) // H.
        {
          try
          {
            double dHalfDelta = (dDelta) / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dTangentBearing + dHalfDelta;
            else
              dChordBearing = dTangentBearing - dHalfDelta;

            MinorOrMajor MinMaj = dDelta > Math.PI ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusAngle(EntryTangentSegment, false, bCCW, dRadius, dDelta);

        if (bHasChord && bHasDelta && bHasTangentBearing) // I.
        {
          try
          {
            double dHalfDelta = (dDelta) / 2;
            dRadius = dChord / (2 * Math.Sin(dHalfDelta));
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dTangentBearing + dHalfDelta;
            else
              dChordBearing = dTangentBearing - dHalfDelta;

            MinorOrMajor MinMaj = dDelta > Math.PI ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentAngleChord(EntryTangentSegment, false, bCCW, dDelta, dChord);

        if (bHasChord && bHasArc && bHasTangentBearing) // J.
        {
          try
          {
            //Newton's approximation method. First computation uses a 0 bearing just to get the initial curve geometry, and central angle:
            //the computed central angle is then used to apply to the tangent bearing
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, 0,
              dArcLength, CCW, null);
            //Get the Delta central angle from the approximation, and then ...
            double dHalfDelta = Math.Abs(ArcSeg.CentralAngle) / 2;
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dTangentBearing + dHalfDelta;
            else
              dChordBearing = dTangentBearing - dHalfDelta;

            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dArcLength, CCW, null);
          }
          catch { };
        }//pConstArc.ConstructTangentChordArc(EntryTangentSegment, false, bCCW, dChord, dArcLength);

        if (bHasRadius && bHasChord && bHasRadialBearing) // K.
        {
          try
          {
            double dHalfDelta = Math.Abs(Math.Asin(dChord / (2 * dRadius)));

            //get chord bearing from given radial bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dRadialBearing - Math.PI / 2 + dHalfDelta;
            else
              dChordBearing = dRadialBearing + Math.PI / 2 - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null); 
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusChord(EntryTangentSegment, false, bCCW, dRadius, dChord);

        if (bHasRadius && bHasArc && bHasRadialBearing) // L.
        {
          try
          {
            double dHalfDelta = (dArcLength / dRadius) / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dRadialBearing - Math.PI / 2 + dHalfDelta;
            else
              dChordBearing = dRadialBearing + Math.PI / 2 - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null); 
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusArc(EntryTangentSegment, false, bCCW, dRadius, dArcLength);

        if (bHasRadius && bHasDelta && bHasRadialBearing) // M.
        {
          try
          {
            double dHalfDelta = (dDelta) / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dRadialBearing - Math.PI / 2 + dHalfDelta;
            else
              dChordBearing = dRadialBearing + Math.PI / 2 - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);    
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusAngle(EntryTangentSegment, false, bCCW, dRadius, dDelta);

        if (bHasChord && bHasDelta && bHasRadialBearing) // N.
        {
          try
          {
            double dHalfDelta = (dDelta) / 2;
            dRadius = dChord / (2 * Math.Sin(dHalfDelta));
            //get chord bearing from given radial bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dRadialBearing - Math.PI / 2 + dHalfDelta;
            else
              dChordBearing = dRadialBearing + Math.PI / 2 - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentAngleChord(EntryTangentSegment, false, bCCW, dDelta, dChord);

        if (bHasChord && bHasArc && bHasRadialBearing) // O.
        {
          try
          {
            //Newton's approximation method. First computation uses a 0 bearing just to get the initial curve geometry, and central angle:
            //the computed central angle is then used to apply to the radial bearing from the previous course
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, 0,
              dArcLength, CCW, null);
            //Get the Delta central angle from the approximation, and then ...
            double dHalfDelta = Math.Abs(ArcSeg.CentralAngle) / 2;
            //get chord bearing from given radial bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dRadialBearing - Math.PI / 2 + dHalfDelta;
            else
              dChordBearing = dRadialBearing + Math.PI / 2 - dHalfDelta;

            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dArcLength, CCW, null);

          }
          catch { };
        }

        if (bHasDelta && bHasArc && bHasChordBearing) // O2.
        {
          try
          {
            //get the radius and chord from the Central Angle and Arc Length
            dRadius = dArcLength / dDelta;
            double dHalfDelta = dDelta / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);

          }
          catch { };
        }

        if (bHasDelta && bHasArc && bHasTangentBearing) // O3.
        {
          try
          {
            //get the radius and chord from the Central Angle and Arc Length
            dRadius = dArcLength / dDelta;
            double dHalfDelta = dDelta / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dTangentBearing + dHalfDelta;
            else
              dChordBearing = dTangentBearing - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);

          }
          catch { };
        }

        if (bHasDelta && bHasArc && bHasRadialBearing) // O4.
        {
          try
          {
            //get the radius and chord from the Central Angle and Arc Length
            dRadius = dArcLength / dDelta;
            double dHalfDelta = dDelta / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given radial bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = dRadialBearing - Math.PI / 2 + dHalfDelta;
            else
              dChordBearing = dRadialBearing + Math.PI / 2 - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);

          }
          catch { };
        }
      }
      else
      { //tangent curve
        if (bHasRadius && bHasChord) // P.
        {
          try
          {
            double dHalfDelta = Math.Abs(Math.Asin(dChord / (2 * dRadius)));
            //get chord bearing from given tangent bearing in polar radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = ExitTangentFromPreviousCourse.Angle + dHalfDelta;
            else
              dChordBearing = ExitTangentFromPreviousCourse.Angle - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusChord(ExitTangentFromPreviousCourse, false, bCCW, dRadius, dChord);

        if (bHasRadius && bHasArc) // Q.
        {
          try
          {
            double dHalfDelta = (dArcLength / dRadius) / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = ExitTangentFromPreviousCourse.Angle + dHalfDelta;
            else
              dChordBearing = ExitTangentFromPreviousCourse.Angle - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusArc(ExitTangentFromPreviousCourse, false, bCCW, dRadius, dArcLength);

        if (bHasRadius && bHasDelta) // R.
        {
          try
          {
            double dHalfDelta = (dDelta) / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = ExitTangentFromPreviousCourse.Angle + dHalfDelta;
            else
              dChordBearing = ExitTangentFromPreviousCourse.Angle - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentRadiusAngle(ExitTangentFromPreviousCourse, false, bCCW, dRadius, dDelta);

        if (bHasChord && bHasDelta) // S.
        {
          try
          {
            double dHalfDelta = (dDelta) / 2;
            dRadius = dChord / (2 * Math.Sin(dHalfDelta));
            //get chord bearing from given tangent bearing in north azimuth radians
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = ExitTangentFromPreviousCourse.Angle + dHalfDelta;
            else
              dChordBearing = ExitTangentFromPreviousCourse.Angle - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }//pConstArc.ConstructTangentAngleChord(ExitTangentFromPreviousCourse, false, bCCW, dDelta, dChord);

        if (bHasChord && bHasArc) // T.
        {
          try
          {
            //Newton's approximation method. First computation uses a 0 bearing just to get the initial curve geometry, and central angle:
            //the computed central angle is then used to apply to the exit tangent from the previous course
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, 0,
              dArcLength, CCW, null);
            //pConstArc.ConstructTangentChordArc(ExitTangentFromPreviousCourse, false, bCCW, dChord, dArcLength);
            //Get the Delta central angle from the approximation, and then ...
            double dHalfDelta = Math.Abs(ArcSeg.CentralAngle) / 2;
            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = ExitTangentFromPreviousCourse.Angle + dHalfDelta;
            else
              dChordBearing = ExitTangentFromPreviousCourse.Angle - dHalfDelta;

            //recompute here...
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dArcLength, CCW, null);
          }
          catch { };
        }

        if (bHasDelta && bHasArc) // U.
        {
          try
          {
            //get the radius and chord from the Central Angle and Arc Length
            dRadius = dArcLength / dDelta;
            double dHalfDelta = dDelta / 2;
            dChord = 2 * dRadius * Math.Sin(dHalfDelta);

            if (CCW == esriArcOrientation.esriArcCounterClockwise)
              dChordBearing = ExitTangentFromPreviousCourse.Angle + dHalfDelta;
            else
              dChordBearing = ExitTangentFromPreviousCourse.Angle - dHalfDelta;

            MinorOrMajor MinMaj = dHalfDelta > Math.PI / 2 ? MinorOrMajor.Major : MinorOrMajor.Minor;
            ArcSeg = EllipticArcBuilder.CreateEllipticArcSegment(MapPt1, dChord, dChordBearing,
              dRadius, CCW, MinMaj, null);
          }
          catch { };
        }

      }
      try
      {
        var pSeg = LineBuilder.CreateLineSegment(ArcSeg.StartPoint, ArcSeg.EndPoint);
        outChordLength = pSeg.Length;
        outChordBearing = pSeg.Angle;
      }
      catch
      {
        outChordLength = -1; outChordBearing = -1;
        return null;
      }

      return ArcSeg;
    }

  }
}
