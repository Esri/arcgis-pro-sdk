NOTE: For the ArcGIS Pro SDK 2.5 parcel fabric API pre-release, parcel fabric objects and methods can be accessed using the internal namespace of the editing and mapping assemblies. This means that the add-ins that you create with the 2.5 pre-release will need to be re-compiled and re-deployed when the parcel fabric portion of the Pro SDK is released as a final product.

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;