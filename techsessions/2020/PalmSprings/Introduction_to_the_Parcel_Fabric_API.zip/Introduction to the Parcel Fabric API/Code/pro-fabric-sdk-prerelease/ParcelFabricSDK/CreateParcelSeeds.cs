﻿using System.Linq;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class CreateParcelSeeds : Button
  {
    protected async override void OnClick()
    {
      await QueuedTask.Run( () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
        {
          System.Windows.MessageBox.Show("Please select a target parcel polygon layer in the table of contents", "Create Parcel Seeds");
          return;
        }
        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        if (myParcelFabricLayer == null)
        {
          System.Windows.MessageBox.Show("Please add a parcel fabric to the map", "Create Parcel Seeds");
          return;
        }

        //first get the feature layer that's selected in the table of contents
        var destPolygonL = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();
        var fcDefinition = destPolygonL.GetFeatureClass().GetDefinition();
        GeometryType geomType = fcDefinition.GetShapeType();
        if (geomType != GeometryType.Polygon)
        {
          System.Windows.MessageBox.Show("Please select a target parcel polygon layer in the table of contents", "Create Parcel Seeds");
          return;
        }

        //check to see if it's a parcel fabric polygon type

        if (destPolygonL is FeatureLayer)
        {
          //is it a fabric parcel type template?
          string sTemplateID = destPolygonL.GetDefinition().LayerTemplate.LayerTemplateId;
          if (sTemplateID.ToLower() != "esriparcels")
          {
            System.Windows.MessageBox.Show("Please select a target parcel polygon layer in the table of contents", "Create Parcel Seeds");
            return;
          }  
        }
        
        var layers = MapView.Active.Map.GetLayersAsFlattenedList();


        //hard-coded tests to find the line feature portion of the parcel type.
        string destLineLyrName1 = destPolygonL.Name + "_Lines";
        string destLineLyrName2 = destPolygonL.Name + " Lines";
        string destLineLyrName3 = destPolygonL.Name + "Lines";

        var destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName1);
        if (destLineL == null)
          destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName2);

        if (destLineL == null)
          destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName3);

        if (destLineL == null || destPolygonL == null)
          return;

        var pRec = myParcelFabricLayer.GetActiveRecord();

        if (pRec == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Create Parcel Seeds");
          return;
        }

        var guid = pRec.Guid;

        var editOper = new EditOperation()
        {
          Name = "Create Parcel Seeds",
          ProgressMessage = "Create Parcel Seeds...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true
        };

        editOper.CreateParcelSeeds(myParcelFabricLayer, MapView.Active.Extent, guid);
        editOper.Execute(); //Execute must be called within QueuedTask.Run

      });

    }
  }
}
