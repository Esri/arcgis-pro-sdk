﻿using System;
using System.Linq;
using ArcGIS.Core.Data;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class SetActiveRecord : Button
  {
    protected async override void OnClick()
    {

      await QueuedTask.Run( async () =>
      {
        var layers = MapView.Active.Map.GetLayersAsFlattenedList();
        var myParcelFabricLayer = 
           MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().First();
        //if there is no fabric in the map then bail
        if (myParcelFabricLayer == null)
          return;

        var recordsLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "Records");
        string sExistingRecord = Microsoft.VisualBasic.Interaction.InputBox("Record Name:", "Set Active Parcel Fabric Record", "MyRecordName");

        var pFeatClass = recordsLayer.GetFeatureClass();

        QueryFilter queryFilter = new QueryFilter
        {
          WhereClause = "Name = '" + sExistingRecord + "'"
        };

        Guid guid = new Guid();
        long lOID = -1;

        using (RowCursor rowCursor = pFeatClass.Search(queryFilter, false))
        {
          while (rowCursor.MoveNext())
          {
            using (Row row = rowCursor.Current)
            {
              guid = row.GetGlobalID();
              long oid = row.GetObjectID();
            }
          }
        }

        var parcelRecord=new ParcelRecord(myParcelFabricLayer.Map, sExistingRecord, guid, lOID);
        await myParcelFabricLayer.SetActiveRecord(parcelRecord);

      });


    }
  }
}
