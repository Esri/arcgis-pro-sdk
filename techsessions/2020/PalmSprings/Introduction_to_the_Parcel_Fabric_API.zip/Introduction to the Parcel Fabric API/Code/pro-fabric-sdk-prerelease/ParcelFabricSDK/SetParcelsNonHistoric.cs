﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class SetParcelsNonHistoric : Button
  {
    protected async override void OnClick()
    {
      await QueuedTask.Run(() =>
      {
        //Get selection from a parcel fabric type's polygon layer
        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        if (myParcelFabricLayer == null)
        {
          System.Windows.MessageBox.Show("Please add a parcel fabric to the map", "Set Parcels Current");
          return;
        }
        var layers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
        int countLayersWithSelection = 0;
        var destPolygonL = layers.FirstOrDefault();
        foreach (var flyr in layers)
        {
          var fcDefinition = (flyr as FeatureLayer).GetFeatureClass().GetDefinition();
          GeometryType geomType = fcDefinition.GetShapeType();
          if (geomType == GeometryType.Polygon)
          {
            if (flyr.SelectionCount > 0)
            {
              destPolygonL = flyr;
              //is it a fabric parcel type layer template?
              var lyrTemplate = flyr.GetDefinition().LayerTemplate;
              if (lyrTemplate == null)
                continue;
              string sTemplateID = lyrTemplate.LayerTemplateId;
              if (sTemplateID == "esriParcels")
                countLayersWithSelection++;
            }
          }
        }

        if (countLayersWithSelection != 1)
        {
          System.Windows.MessageBox.Show("Please select features from only one source polygon parcel layer", "Set Current");
          return;
        }

        if (destPolygonL == null)
          return;

        var theActiveRecord = myParcelFabricLayer.GetActiveRecord();

        if (theActiveRecord == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Set Parcels Current");
          return;
        }

        var ids = new List<long>(destPolygonL.GetSelection().GetObjectIDs());
        //can do multi layer selection but using single per code above

        var kvp = new KeyValuePair<MapMember, List<long>>(destPolygonL, ids);
        var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp };

        Guid guid = theActiveRecord.Guid;

        var editOper = new EditOperation()
        {
          Name = "Set Parcels Current",
          ProgressMessage = "Set Parcels Current...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };

        editOper.UpdateParcelHistory(myParcelFabricLayer, sourceFeatures, guid, false);
        editOper.Execute();

      });

    }
  }
}
