﻿using System.Collections.Generic;
using System.Linq;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class ChangeParcelType : Button
  {
    protected async override void OnClick()
    {

      await QueuedTask.Run( () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
        {
          System.Windows.MessageBox.Show("Please select a source layer in the table of contents", "Change Parcel Type");
          return;
        }

        //first get the feature layer that's selected in the table of contents
        var sourcePolygonL = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();
        
        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        Dictionary<string, object> RecordAttributes = new Dictionary<string, object>();
        var recordsLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "Records");
        var spatRef = recordsLayer.Map.SpatialReference;

        string sTargetParcelType = Microsoft.VisualBasic.Interaction.InputBox("Target Parcel Type:", "Change Parcel Type", "Tax");

        if (sTargetParcelType.Trim().Length == 0)
          return;

        var targetFeatLyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == sTargetParcelType);

        if (myParcelFabricLayer == null || sourcePolygonL == null)
          return;

        var ids = new List<long>(sourcePolygonL.GetSelection().GetObjectIDs());

        var kvp = new KeyValuePair<MapMember, List<long>>(sourcePolygonL, ids);
        var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp };

        var opCpToPT = new EditOperation()
        {
          Name = "Change Parcel Type",
          ProgressMessage = "Change Parcel Type...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };

        opCpToPT.ChangeParcelType(myParcelFabricLayer, sourceFeatures, targetFeatLyr, -1);
        opCpToPT.Execute();

      });
    }
  }
}
