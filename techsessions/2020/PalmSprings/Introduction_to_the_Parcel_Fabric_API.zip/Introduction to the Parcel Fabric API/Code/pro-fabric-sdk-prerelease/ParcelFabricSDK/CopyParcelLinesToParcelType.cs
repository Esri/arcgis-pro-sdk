﻿using System.Collections.Generic;
using System.Linq;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;


namespace ParcelFabricSDK
{
  internal class CopyParcelLinesToParcelType : Button
  {
    protected async override void OnClick()
    {

      await QueuedTask.Run(async () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
        {
          System.Windows.MessageBox.Show("Please select a source parcel polygon feature layer in the table of contents", "Copy Parcel Lines To");
          return;
        }

        //first get the feature layer that's selected in the table of contents
        var srcParcelFeatLyr = MapView.Active.GetSelectedLayers().First() as FeatureLayer;

        //var layers = MapView.Active.Map.GetLayersAsFlattenedList();

        string sTargetParcelType = Microsoft.VisualBasic.Interaction.InputBox("Target Parcel Type:", "Copy Parcel Lines To", "Tax");

        if (sTargetParcelType.Trim().Length == 0)
          return;

        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();

        string destLineLyrName1 = sTargetParcelType + "_Lines";
        string destLineLyrName2 = sTargetParcelType + " Lines";
        string destLineLyrName3 = sTargetParcelType + "Lines";

        var destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName1);
        if (destLineL == null)
          destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName2);

        if (destLineL == null)
          destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName3);

        var destPolygonL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == sTargetParcelType);

        if (myParcelFabricLayer == null || destLineL == null || destPolygonL == null)
          return;

        var pRec = myParcelFabricLayer.GetActiveRecord();

        if (pRec == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Copy Line Features To");
          return;
        }

        await myParcelFabricLayer.SetActiveRecord(pRec);

        var ids = new List<long>(srcParcelFeatLyr.GetSelection().GetObjectIDs());

        if (ids.Count == 0)
        {
          System.Windows.MessageBox.Show("No selected parcels found. Please select parcels and try again.", "Copy Parcel Lines To");
          return;
        }

        var kvp = new KeyValuePair<MapMember, List<long>>(srcParcelFeatLyr, ids);
        var sourceParcelFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp };

        var editOper = new EditOperation()
        {
          Name = "Copy Lines To Parcel Type",
          ProgressMessage = "Copy Lines To Parcel Type ...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };
        ParcelEditToken peToken = editOper.CopyParcelLinesToParcelType(myParcelFabricLayer, sourceParcelFeatures, destLineL, destPolygonL, null, true, false, true);

        var createdIDsSelectionSet = peToken.CreatedFeatures;
        
        editOper.Execute();

      });


    }

  }
}