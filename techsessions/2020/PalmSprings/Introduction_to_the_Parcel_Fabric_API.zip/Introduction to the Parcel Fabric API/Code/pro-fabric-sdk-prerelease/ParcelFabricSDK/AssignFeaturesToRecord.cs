﻿using System.Collections.Generic;
using System.Linq;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class AssignFeaturesToRecord : Button
  {
    protected async override void OnClick()
    {

      await QueuedTask.Run( () =>
      {
        //check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
        {
          System.Windows.MessageBox.Show("Please select a source feature layer in the table of contents", "Assign Features To Record");
          return;
        }

        //first get the feature layer that's selected in the table of contents
        var srcFeatLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();
        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();

        if (myParcelFabricLayer == null)
          return;
        
        var pRec = myParcelFabricLayer.GetActiveRecord();

        if (pRec == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Assign Features To Record");
          return;
        }

        var guid = pRec.Guid;

        var ids = new List<long>(srcFeatLyr.GetSelection().GetObjectIDs());
        var kvp = new KeyValuePair<MapMember, List<long>>(srcFeatLyr, ids);

        var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp };
        var editOper= new EditOperation()
        {
          Name = "Assign Features to Record",
          ProgressMessage = "Assign Features to Record...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };
        editOper.AssignFeaturesToRecord(myParcelFabricLayer, sourceFeatures, guid, ParcelRecordAttribute.CreatedByRecord); 
        editOper.Execute();

      });

    }
  }
}
