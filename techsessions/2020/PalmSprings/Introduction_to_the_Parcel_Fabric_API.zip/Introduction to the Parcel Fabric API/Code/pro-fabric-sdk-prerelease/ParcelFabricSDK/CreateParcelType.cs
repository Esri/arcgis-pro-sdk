﻿using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.Mapping;
using ArcGIS.Desktop.Mapping;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ParcelFabricSDK
{
  internal class CreateParcelType : Button
  {
    protected async override void OnClick()
    {
      string sNewParcelTypeName = Interaction.InputBox("New Parcel Type Name:", "Add New Parcel Type", "MyNewParcelType");

      var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      await AddParcelType(myParcelFabricLayer, sNewParcelTypeName);
    }

    protected async Task<string> AddParcelType(ParcelLayer parcelLayer, string ptName)
    {
      // Progress dialog
      var progDlg = new ProgressDialog("Creating feature class adjusted points", "Cancel", 100, true);
      var progSrc = new CancelableProgressorSource(progDlg);
      progDlg.Show();
  
      // Geoprocessing
      IReadOnlyList<string> args = Geoprocessing.MakeValueArray(parcelLayer, ptName);
      IGPResult gpResult = await Geoprocessing.ExecuteToolAsync("parcel.AddParcelType", args, 
                                                                  null, progSrc.Progressor, GPExecuteToolFlags.RefreshProjectItems);

      var message = string.IsNullOrEmpty(gpResult.ReturnValue)
        ? $"Error adding Parcel Type: {gpResult.ErrorMessages}"
        : $"OK: Successfully created the parcel type {ptName} - {gpResult.ReturnValue}";
      return message;
    }
  }
}
