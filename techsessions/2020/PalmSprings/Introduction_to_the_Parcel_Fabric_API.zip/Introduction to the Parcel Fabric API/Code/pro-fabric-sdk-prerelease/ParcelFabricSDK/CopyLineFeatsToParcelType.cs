﻿using System.Collections.Generic;
using System.Linq;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class CopyLineFeatsToParcelType : Button
  {
    protected async override void OnClick()
    {

      await QueuedTask.Run( () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
        {
          System.Windows.MessageBox.Show("Please select a target parcel polygon layer in the table of contents", "Copy Line Features To");
          return;
        }

        //first get the feature layer that's selected in the table of contents
        var destPolygonL = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();
        var fcDefinition = destPolygonL.GetFeatureClass().GetDefinition();
        GeometryType geomType = fcDefinition.GetShapeType();
        if (geomType != GeometryType.Polygon)
        {
          System.Windows.MessageBox.Show("Please select a target parcel polygon layer in the table of contents", "Copy Line Features To");
          return;
        }

        var srcFeatLyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name.Contains("Lines SP") && l.IsVisible);

        if (srcFeatLyr == null)
        {
          System.Windows.MessageBox.Show("Source layer with string Lines SP* not found in the table of contents", "Copy Line Features To");
          return;
        }

        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();

        string destLineLyrName1 = destPolygonL.Name + "_Lines";
        string destLineLyrName2 = destPolygonL.Name + " Lines";
        string destLineLyrName3 = destPolygonL.Name + "Lines";

        var destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName1);
        if (destLineL == null)
          destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName2);

        if (destLineL == null)
          destLineL = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == destLineLyrName3);

        if (myParcelFabricLayer == null || destLineL == null || destPolygonL == null)
          return;

        var pRec = myParcelFabricLayer.GetActiveRecord();

        if (pRec == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Copy Line Features To");
          return;
        }

        var editOper = new EditOperation()
        {
          Name = "Copy Line Features To Parcel Type",
          ProgressMessage = "Copy Line Features To Parcel Type...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };

        var ids = new List<long>((srcFeatLyr as FeatureLayer).GetSelection().GetObjectIDs());

        if (ids.Count == 0)
        {
          System.Windows.MessageBox.Show("No selected lines were found. Please select line features and try again.", "Copy Line Features To");
          return;
        }

        ParcelEditToken peToken = editOper.CopyLineFeaturesToParcelType(srcFeatLyr, ids, destLineL, destPolygonL);

        editOper.Execute();

        SelectionSet FeatSelSet = peToken.CreatedFeatures;
        var selSetDict = FeatSelSet.SelectionSetDictionary;
        var xx = new HashSet<long>();
        if (selSetDict.TryGetValue(destLineL, out xx))
        {
          var newLinesFC = (destLineL as FeatureLayer).GetFeatureClass();
          //TODO transfer other attributes from source lines
        }
      
      });


    }
  }
}
