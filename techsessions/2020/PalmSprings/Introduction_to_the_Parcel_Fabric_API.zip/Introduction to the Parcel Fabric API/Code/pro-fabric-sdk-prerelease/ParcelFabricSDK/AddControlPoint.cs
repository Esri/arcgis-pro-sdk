﻿using System.Collections.Generic;
using System.Linq;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class AddControlPoint : Button
  {
    protected async override void OnClick()
    {
      await QueuedTask.Run( () =>
      {
        //make sure there is a fabric and an active record
        var myParcelFabricLayer = 
              MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().First();

        if (myParcelFabricLayer == null)
          return;

        var pRec = myParcelFabricLayer.GetActiveRecord();

        if (pRec == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Add Test Point");
          return;
        }

        var pointLyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "Points");
        if (pointLyr==null)
          return;

        var newPoint = MapView.Active.Extent.Center;
        if (newPoint == null)
          return;

        Dictionary<string, object> PointAttributes = new Dictionary<string, object>();        
        PointAttributes.Add("Name", "MyTestPoint");
        PointAttributes.Add("IsFixed", 1);
        var editOper = new EditOperation()
        {
          Name = "Create a test parcel fabric point",
          ProgressMessage = "Create a test parcel fabric point...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };
        var editRowToken = editOper.CreateEx(pointLyr, newPoint, PointAttributes);
        editOper.Execute();
          
      });
    }
  }
}
