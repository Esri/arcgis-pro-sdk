﻿using System;
using System.Collections.Generic;
using System.Linq;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class CreateNewRecord : Button
  {
    protected async override void OnClick()
    {
      await QueuedTask.Run( () =>
      {
        Dictionary<string, object> RecordAttributes = new Dictionary<string, object>();

        string sNewRecord = Microsoft.VisualBasic.Interaction.InputBox("New Record Name:", "Create Parcel Fabric Record", "MyRecordName");

        if (sNewRecord.Trim().Length == 0)
          return;

        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();

        //if there is no fabric in the map then bail
        if (myParcelFabricLayer == null)
          return;

        var recordsLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "Records");
        var spatRef = recordsLayer.Map.SpatialReference;

        var editOper = new EditOperation()
        {
          Name = "Create Parcel Fabric Record",
          ProgressMessage = "Create Parcel Fabric Record...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = false,
          SelectModifiedFeatures = false
        };

        Polygon newPolygon = null;
        newPolygon = PolygonBuilder.CreatePolygon(spatRef);
        if (newPolygon != null)
        {
          RecordAttributes.Add("Name", sNewRecord);
          var editRowToken = editOper.CreateEx(recordsLayer, newPolygon, RecordAttributes);
          RecordAttributes.Clear();
          if (! editOper.Execute())
           return;

          //Default Guid
          var defGuid = new Guid("dddddddd-dddd-dddd-dddd-dddddddddddd");
          var defOID = -1;
          var guid = editRowToken.GlobalID.HasValue ? editRowToken.GlobalID.Value : defGuid;
          var lOid = editRowToken.ObjectID.HasValue ? editRowToken.ObjectID.Value : defOID;

          if (guid == defGuid | lOid == defOID)
            return;

          ParcelRecord parcelRecord = new ParcelRecord(myParcelFabricLayer.Map, sNewRecord, guid, lOid);
          myParcelFabricLayer.SetActiveRecord(parcelRecord);
        }

      });

    }
  }
}
