﻿using System;
using System.Collections.Generic;
using System.Linq;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class DuplicateParcels : Button
  {
    protected async override void OnClick()
    {
      await QueuedTask.Run( () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
        {
          System.Windows.MessageBox.Show("Please select the source layer in the table of contents", "Duplicate Parcels");
          return;
        }

        //first get the feature layer that's selected in the table of contents
        var sourcePolygonL = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();
        var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        if (myParcelFabricLayer == null)
        {
          System.Windows.MessageBox.Show("Please add a parcel fabric to the map", "Duplicate Parcels");
          return;
        }
        string sTargetParcelType = Microsoft.VisualBasic.Interaction.InputBox("Target Parcel Type:", "Duplicate Parcels", "Tax");

        if (sTargetParcelType.Trim().Length == 0)
          return;

        var targetFeatLyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == sTargetParcelType);

        if (myParcelFabricLayer == null || sourcePolygonL == null)
          return;

        var ids = new List<long>(sourcePolygonL.GetSelection().GetObjectIDs());

        if (ids.Count == 0)
        {
          System.Windows.MessageBox.Show("No selected parcels found. Please select parcels and try again.", "Duplicate Parcels");
          return;
        }

        var kvp = new KeyValuePair<MapMember, List<long>>(sourcePolygonL, ids);
        var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp };

        var pRec = myParcelFabricLayer.GetActiveRecord();

        if (pRec == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Duplicate Parcels");
          return;
        }

        Guid guid = pRec.Guid;

        var editOper  = new EditOperation()
        {
          Name = "Duplicate Parcels",
          ProgressMessage = "Duplicate Parcels...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = false
        };

        editOper.DuplicateParcels(myParcelFabricLayer, sourceFeatures, guid,targetFeatLyr, -1);
        editOper.Execute();

      });

    }
  }
}
