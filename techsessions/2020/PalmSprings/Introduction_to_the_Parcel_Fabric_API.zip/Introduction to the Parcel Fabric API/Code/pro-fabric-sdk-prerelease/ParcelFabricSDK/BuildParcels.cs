﻿using System.Linq;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//Internal namespaces
using ArcGIS.Desktop.Internal.Editing;
using ArcGIS.Desktop.Internal.Mapping;

namespace ParcelFabricSDK
{
  internal class BuildParcels : Button
  {
    protected async override void OnClick()
    {
      await QueuedTask.Run( () =>
      {
        var myParcelFabricLayer = 
           MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().First();

        if (myParcelFabricLayer == null)
          return;

        var theActiveRecord = myParcelFabricLayer.GetActiveRecord();

        if (theActiveRecord == null)
        {
          System.Windows.MessageBox.Show("There is no Active Record. Please set the active record and try again.", "Add Test Point");
          return;
        }

        var guid = theActiveRecord.Guid;

        var editOper = new EditOperation()
        {
          Name = "Build Parcels",
          ProgressMessage = "Build Parcels...",
          ShowModalMessageAfterFailure = true,
          SelectNewFeatures = true,
          SelectModifiedFeatures = true
        };

        editOper.BuildParcelsByRecord(myParcelFabricLayer, guid);
        editOper.Execute();

      });
    }
  }
}
