﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace PolygonMapFrame
{
	internal class ChangeLayoutMapframe : Button
	{
    protected async override void OnClick()
    {
      try
      {
        var file_gdb_path = @"C:\Data\Islander\Island.gdb";
        var layout = LayoutView.Active.Layout;

				await QueuedTask.Run(() =>
				{
					Polygon mapFramePolygon = null;

					var def = layout.GetDefinition();

					//Get the map frame
					var mapframe = def.Elements.OfType<CIMMapFrame>().First();

					//Make the frame polygon
					using (var gdb = new Geodatabase(new FileGeodatabaseConnectionPath(
							new Uri(file_gdb_path))))
					{
						using (var fc = gdb.OpenDataset<FeatureClass>("KauaiBorder_Buffer"))
							mapFramePolygon = MakeMapFramePolygon(fc, mapframe.Frame.Extent);
					}

					//Apply the polygon to the frame
					mapframe.Frame = mapFramePolygon;

					//Give it a gray outline
					mapframe.GraphicFrame.BorderSymbol.Symbol =
								SymbolFactory.Instance.ConstructLineSymbol(
									ColorFactory.Instance.CreateRGBColor(153.0, 217.0, 234.0), 3);

					//Commit the changes back
					layout.SetDefinition(def);
				});
			}
      catch (Exception ex)
      {
        MessageBox.Show($@"Exception: {ex}");
      }
    }

    private Polygon MakeMapFramePolygon(FeatureClass fc, Envelope frameExtent)
    {

      var frameExtWidth = frameExtent.Width * 0.9;
      var frameExtHeight = frameExtent.Height * 0.9;
      var frameXMin = frameExtent.XMin + (frameExtent.Width * 0.05);
      var frameYMin = frameExtent.YMin + (frameExtent.Height * 0.05);

      Geometry unionPoly = null;
      using (var rc = fc.Search())
      {
        while (rc.MoveNext())
        {
          var feature = rc.Current as Feature;
          var poly = feature.GetShape();
          //Step 1 - union the polygons
          unionPoly = unionPoly == null ? poly : GeometryEngine.Instance.Union(unionPoly, poly);
        }
      }
      //Step 2 project it flat - Plate Carrée
      var projectedPoly = GeometryEngine.Instance.Project(unionPoly,
        SpatialReferenceBuilder.CreateSpatialReference(54001));

      #region Step 3 shrink it to the size of the frame on the page
      var sx = frameExtWidth / projectedPoly.Extent.Width;
      var sy = frameExtHeight / projectedPoly.Extent.Height;
      if (sx < sy) sy = sx;
      else sx = sy;
      var mid_point = GeometryEngine.Instance.LabelPoint(projectedPoly.Extent);
      #endregion

      var shrankPoly = GeometryEngine.Instance.Scale(projectedPoly, mid_point, sx, sy);

      #region Step 4 Move it onto the page
      var shrank_poly_mid_pt = GeometryEngine.Instance.LabelPoint(shrankPoly.Extent);
      var mapframe_mid_pt_x = frameXMin + (frameExtWidth / 2);
      var mapframe_mid_pt_y = frameYMin + (frameExtHeight / 2);

      double dx = 0;
      double dy = 0;
      if (shrank_poly_mid_pt.X < 0)
        dx = mapframe_mid_pt_x + Math.Abs(shrank_poly_mid_pt.X);
      else
        dx = mapframe_mid_pt_x - shrank_poly_mid_pt.X;

      if (shrank_poly_mid_pt.Y < 0)
        dy = mapframe_mid_pt_y + Math.Abs(shrank_poly_mid_pt.Y);
      else
        dy = mapframe_mid_pt_y - shrank_poly_mid_pt.Y;
      #endregion
      
      var frame_poly = GeometryEngine.Instance.Move(shrankPoly, dx, dy);

      //Step 5 Generalize to remove unnecessary detail
      double maxDeviation = 0.03;
      return GeometryEngine.Instance.Generalize(frame_poly, maxDeviation, true) as Polygon;
    }
  }
}
