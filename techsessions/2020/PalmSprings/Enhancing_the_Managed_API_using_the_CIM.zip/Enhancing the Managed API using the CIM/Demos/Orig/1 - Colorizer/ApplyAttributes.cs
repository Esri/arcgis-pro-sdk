//   Copyright 2019 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Mapping;
using System.Windows;
using MessageBox = ArcGIS.Desktop.Framework.Dialogs.MessageBox;
using ComboBox = ArcGIS.Desktop.Framework.Contracts.ComboBox;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Core;

namespace Colorizer
{
	/// <summary>
	/// Represents the Apply Colorizers ComboBox.
	/// </summary>
	internal class ApplyAttributes : ComboBox
	{
		static Dictionary<string, CIMColor> ColorMap = new Dictionary<string, CIMColor>();
		BasicRasterLayer basicRasterLayer = null;
		// holds the names of field names in the raster's attribute table
		private List<string> _fieldList = new List<string>();

		/// <summary>
		/// Combo Box constructor. Make sure the combo box is enabled if raster layer is selected
		/// and subscribe to the layer selection changed event.
		/// </summary>
		public ApplyAttributes()
		{
			SelectedLayersChanged(new ArcGIS.Desktop.Mapping.Events.MapViewEventArgs(MapView.Active));
			ArcGIS.Desktop.Mapping.Events.TOCSelectionChangedEvent.Subscribe(SelectedLayersChanged);

			Add(new ComboBoxItem("First: Select a Raster in the TOC"));

			ColorMap.Add("Water", CIMColor.CreateRGBColor(14,62, 252, 100));
			ColorMap.Add("Wetlands", CIMColor.CreateRGBColor(80, 115, 252, 100));
			ColorMap.Add("Forest", CIMColor.CreateRGBColor(0, 100, 0, 100));
			ColorMap.Add("Built up", CIMColor.CreateRGBColor(0, 0, 0, 100));
			ColorMap.Add("Brush/transitional", CIMColor.CreateRGBColor(255, 162, 117, 100));
			ColorMap.Add("Barren land", CIMColor.CreateRGBColor(205, 209, 187, 100));
			ColorMap.Add("Agriculture", CIMColor.CreateRGBColor(100, 255, 113, 100));
		}

		/// <summary>
		/// Event handler for layer selection changes.
		/// </summary>
		private async void SelectedLayersChanged(ArcGIS.Desktop.Mapping.Events.MapViewEventArgs mapViewArgs)
		{
			// Clears the combo box items when layer selection changes. 
			Clear();

			// Checks the state of the active pane. 
			// Returns the active pane state if the active pane is not null, else returns null.
			State state = (FrameworkApplication.Panes.ActivePane != null) ? FrameworkApplication.Panes.ActivePane.State : null;

			if (state != null && mapViewArgs.MapView != null)
			{
				// Gets the selected layers from the current Map.
				IReadOnlyList<Layer> selectedLayers = mapViewArgs.MapView.GetSelectedLayers();

				// The combo box will update only if one layer is selected.
				if (selectedLayers.Count == 1)
				{
					// Gets the selected layer.
					Layer firstSelectedLayer = selectedLayers.First();

					// The combo box will update only if a raster layer is selected.
					if (firstSelectedLayer != null && (firstSelectedLayer is BasicRasterLayer || firstSelectedLayer is MosaicLayer))
					{
						// Gets the basic raster layer from the selected layer. 
						if (firstSelectedLayer is BasicRasterLayer)
							basicRasterLayer = (BasicRasterLayer)firstSelectedLayer;
						else if (firstSelectedLayer is MosaicLayer)
							basicRasterLayer = ((MosaicLayer)firstSelectedLayer).GetImageLayer() as BasicRasterLayer;

						// Updates the combo box with the corresponding colorizers for the selected layer.
						await UpdateCombo(basicRasterLayer);

						// Sets the combo box to display the first combo box item.
						SelectedIndex = 0;
					}
				}
			}
		}

		/// <summary>
		/// Destructor. Unsubscribe from the layer selection changed event.
		/// </summary>
		~ApplyAttributes()
		{
			ArcGIS.Desktop.Mapping.Events.TOCSelectionChangedEvent.Unsubscribe(SelectedLayersChanged);
			Clear();
		}

		/// <summary>
		/// Updates the combo box with the raster's attribute table field names.
		/// </summary>
		/// <param name="basicRasterLayer">the selected layer.</param>
		private async Task UpdateCombo(BasicRasterLayer basicRasterLayer)
		{
			try
			{
				_fieldList.Clear();
				await QueuedTask.Run(() =>
				{
					// get access to the raster's attribute table
					var rasterTbl = basicRasterLayer.GetRaster().GetAttributeTable();
					if (rasterTbl == null) return;
					var fields = rasterTbl.GetDefinition().GetFields();
					_fieldList.AddRange(from field in fields select field.Name);
				});
				bool hasRgb = _fieldList.Contains("red", StringComparer.OrdinalIgnoreCase)
												&& _fieldList.Contains("green", StringComparer.OrdinalIgnoreCase)
												&& _fieldList.Contains("blue", StringComparer.OrdinalIgnoreCase);
				if (_fieldList.Count == 0)
				{
					Add(new ComboBoxItem("First: Raster has no Attribute table"));
					return;
				}
				foreach (var fieldName in _fieldList)
				{
					Add(new ComboBoxItem(fieldName));
				}
				if (hasRgb)
				{
					Add(new ComboBoxItem(@"Attribute driven RGB"));
				}
				if (_fieldList.Contains ("LANDUSE"))
				{
					Add(new ComboBoxItem(@"Custom land use colors"));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($@"Exception caught on Update combo box: {ex.Message}", "Exception", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		/// <summary>
		/// The on comboBox selection change event. 
		/// </summary>
		/// <param name="item">The newly selected combo box item</param>
		protected override void OnSelectionChange(ComboBoxItem item)
		{
			if (item == null)
				MessageBox.Show("The combo box item is null.", "Combo box Error:", MessageBoxButton.OK, MessageBoxImage.Error);
			if (item.Text.StartsWith("First: ")) return;
			if (string.IsNullOrEmpty(item.Text))
				MessageBox.Show("The combo box item text is null or empty.", "Combo box Error:", MessageBoxButton.OK, MessageBoxImage.Error);
			if (MapView.Active == null)
				MessageBox.Show("There is no active MapView.", "Combo box Error:", MessageBoxButton.OK, MessageBoxImage.Error);
			try
			{
				// Gets the first selected layer in the active MapView.
				Layer firstSelectedLayer = MapView.Active.GetSelectedLayers().First();

				// Gets the BasicRasterLayer from the selected layer.
				if (firstSelectedLayer is BasicRasterLayer)
					basicRasterLayer = (BasicRasterLayer)firstSelectedLayer;
				else if (firstSelectedLayer is MosaicLayer)
					basicRasterLayer = ((MosaicLayer)firstSelectedLayer).GetImageLayer() as BasicRasterLayer;
				else
					MessageBox.Show("The selected layer is not a basic raster layer", "Select Layer Error:", MessageBoxButton.OK, MessageBoxImage.Error);
				if (basicRasterLayer != null)
				{
					switch (item.Text)
					{
						case @"Attribute driven RGB":
							SetRasterColorByRGBAttributeFieldsAsync(basicRasterLayer as RasterLayer, _fieldList);
							break;
						case @"Custom land use colors":
							SetRasterColorByMapAsync(basicRasterLayer as RasterLayer, "LANDUSE", _fieldList);
							break;
						default:
							var style = Project.Current.GetItems<StyleProjectItem>().First(s => s.Name == "ArcGIS Colors");
							SetRasterColorByAttributeField(basicRasterLayer as RasterLayer, item.Text, style);
							break;
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Exception caught in OnSelectionChange:" + ex.Message, "Exception", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private static async void SetRasterColorByMapAsync(RasterLayer rasterLayer, string fieldName, List<string> fieldList)
		{
			await QueuedTask.Run(() =>
			{
				var labelMap = GetReplacementLabelMap(rasterLayer, fieldName, fieldList);

				var colorizerDef = new UniqueValueColorizerDefinition(fieldName);
				var colorizer = rasterLayer.CreateColorizer(colorizerDef) as CIMRasterUniqueValueColorizer;
				// override the colors using the color map
				if (colorizer.Groups.Length > 0)
				{
					for (int idxClass = 0; idxClass < colorizer.Groups[0].Classes.Length; idxClass++)
					{
						var colorClass = colorizer.Groups[0].Classes[idxClass];
						if (ColorMap.ContainsKey (colorClass.Label))
						{
							colorClass.Color = ColorMap[colorClass.Label];
						}
						if (labelMap.ContainsKey (colorClass.Label))
						{
							colorClass.Label = labelMap[colorClass.Label];
						}
					}
				}
				rasterLayer.SetColorizer(colorizer);
			});
		}

		private static Dictionary<string, string> GetReplacementLabelMap(BasicRasterLayer basicRasterLayer, 
			string fieldName, List<string> fieldList)
		{
			Dictionary<string, string> replacementLabels = new Dictionary<string, string>();
			var rasterTbl = basicRasterLayer.GetRaster().GetAttributeTable();
			if (rasterTbl != null)
			{
				using (var rowCursor = rasterTbl.Search())
				{
					if (fieldList.Contains("Count", StringComparer.InvariantCultureIgnoreCase))
					{
						while (rowCursor.MoveNext())
						{
							var row = rowCursor.Current;
							var lookupValue = row[fieldName];
							var countValue = row["Count"];
							replacementLabels.Add(lookupValue.ToString(), $@"{lookupValue}: {countValue}");
						}
					}
					else
					{
						while (rowCursor.MoveNext())
						{
							var row = rowCursor.Current;
							var lookupValue = row[fieldName];
							replacementLabels.Add(lookupValue.ToString(), $@"{lookupValue}");
						}
					}
				}
			}
			return replacementLabels;
		}

		private static async void SetRasterColorByRGBAttributeFieldsAsync(RasterLayer raster, List<string> fields)
		{
			await QueuedTask.Run(() =>
			{
				// set fieldName to the first column after the value column
				var fieldName = "n/a";
				bool setFieldName = false;
				foreach (var attributeColumn in fields)
				{
					if (attributeColumn.Equals("value", StringComparison.OrdinalIgnoreCase))
						setFieldName = true;
					else
					{
						if (setFieldName)
						{
							fieldName = attributeColumn;
							break;
						}
					}
				}
				var colorizerDef = new UniqueValueColorizerDefinition(fieldName);
				var colorizer = raster.CreateColorizer(colorizerDef);

				raster.SetColorizer(colorizer);
			});
		}

		private static async void SetRasterColorByAttributeField(RasterLayer raster, string fieldName, StyleProjectItem styleProjItem)
		{
			await QueuedTask.Run(() =>
			{
				var ramps = styleProjItem.SearchColorRamps("Green Blues");
				CIMColorRamp colorRamp = ramps[0].ColorRamp;
				var colorizerDef = new UniqueValueColorizerDefinition(fieldName, colorRamp);
				var colorizer = raster.CreateColorizer(colorizerDef);
							// fix up colorizer ... due to a problem with getting the values for different attribute table fields:
							// we use the Raster's attribute table to collect a dictionary with the correct replacement values
							Dictionary<string, string> landuseToFieldValue = new Dictionary<string, string>();
				if (colorizer is CIMRasterUniqueValueColorizer uvrColorizer)
				{
					var rasterTbl = raster.GetRaster().GetAttributeTable();
					var cursor = rasterTbl.Search();
					while (cursor.MoveNext())
					{
						var row = cursor.Current;
						var correctField = row[fieldName].ToString();
						var key = row[uvrColorizer.Groups[0].Heading].ToString();
						landuseToFieldValue.Add(key.ToLower(), correctField);
					}
					uvrColorizer.Groups[0].Heading = fieldName;
					for (var idxGrp = 0; idxGrp < uvrColorizer.Groups[0].Classes.Length; idxGrp++)
					{
						var grpClass = uvrColorizer.Groups[0].Classes[idxGrp];
						var oldValue = grpClass.Values[0].ToLower();
						var correctField = landuseToFieldValue[oldValue];
						grpClass.Values[0] = correctField;
						grpClass.Label = $@"{correctField}";
					}
				}
				raster.SetColorizer(colorizer);
			});
		}
	}
}
