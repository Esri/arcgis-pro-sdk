﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos
{
    internal class ToggleLegend : Button
    {
        protected override void OnClick()
        {
            var layersToToggle = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>();
            QueuedTask.Run(() => {
                if (layersToToggle.Count() == 0)
                    layersToToggle = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();
                foreach (var lyr in layersToToggle)
                {
                    var lyrDef = lyr.GetDefinition() as CIMFeatureLayer;
                    lyrDef.ShowLegends = lyrDef.ShowLegends ? false : true;
                    lyr.SetDefinition(lyrDef);
                }
            });
        }
    }
}
