﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos
{
    internal class ApplySymbologyFromLyrXFile : Button
    {
        protected async override void OnClick()
        {
            //The layer in the TOC we want to render and label
            var hydrologyLyr = MapView.Active.Map.FindLayers("Hydrology").First() as FeatureLayer;
            await QueuedTask.Run(() => {
                var hydroLyrDefn = hydrologyLyr.GetDefinition() as CIMFeatureLayer;

                //Get the Layer Document from the lyrx file
                var lyrDocFromLyrxFile = new LayerDocument(@"C:\DevSummit\2020\Enhancing the Managed API using the CIM\Symbology.lyrx");
                var cimLyrDoc = lyrDocFromLyrxFile.GetCIMLayerDocument();

                //Get the renderer from the CIMLayerDocument
                var rendererFromLayerFile = ((CIMFeatureLayer)cimLyrDoc.LayerDefinitions[0]).Renderer as CIMClassBreaksRenderer;

                //Get the Label class from the CIMLayerDocument
                var labelClassFromLayerFile = ((CIMFeatureLayer)cimLyrDoc.LayerDefinitions[0]).LabelClasses[0];

                //Set renderer from LayerDoc to the hydrology layer
                hydroLyrDefn.Renderer = rendererFromLayerFile;

                //Set the label class from LayerDoc to the hydrology layer
                hydroLyrDefn.LabelClasses[0] = labelClassFromLayerFile;
                hydroLyrDefn.LabelVisibility = true;

                hydrologyLyr.SetDefinition(hydroLyrDefn);

            });
            
        }
    }
}
