﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos
{
    internal class LayerDocumentBasicPattern : Button
    {
        protected override void OnClick()
        {
            var hydrologyLyr = MapView.Active.Map.FindLayers("Hydrology").First() as FeatureLayer;
            QueuedTask.Run( () => {
                //1. Create new LayerDocument
                var layerDoc = new LayerDocument(hydrologyLyr);
                // get the CIMLayerDocument
                var cimLayerDoc = layerDoc.GetCIMLayerDocument();

                //2. Manipulate the layer definitions (optional)
                // Example: change the legend visibility and renderer
                var layerDefinitions = cimLayerDoc.LayerDefinitions;
                var layerDef = layerDefinitions[0] as CIMFeatureLayer;
                layerDef.ShowLegends = false;
                layerDef.Renderer = new CIMSimpleRenderer()
                {
                    Symbol = SymbolFactory.Instance.ConstructLineSymbol(
                                            CIMColor.CreateRGBColor(255, 0, 0)).MakeSymbolReference()
                };

                //3. Create a new layer using the configured LayerDocument.
                var layerParams = new LayerCreationParams(cimLayerDoc);
                LayerFactory.Instance.CreateLayer<FeatureLayer>(layerParams, MapView.Active.Map, LayerPosition.AddToTop);
                hydrologyLyr?.SetVisibility(false);
            });
        }
    }
}
