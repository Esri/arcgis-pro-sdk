﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos
{
    internal class BasicPattern : Button
    {
        protected async override void OnClick()
        {
            var hydrologyLyr = MapView.Active.Map.FindLayers("Hydrology").First() as FeatureLayer;
            await QueuedTask.Run(() => {
                //Use GetDefinition to retrieve the CIM Definition – ‘CIMFeatureLayer’
                //in this case
                var def = hydrologyLyr.GetDefinition() as CIMFeatureLayer;

                var str = def.ToXml();//Get the XML representation for Debug

                //TODO Make changes to the CIM

                //Commit changes back
                hydrologyLyr.SetDefinition(def);
            });

        }
    }
}
