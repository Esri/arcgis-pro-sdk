﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos
{
    internal class ChangeMap : Button
    {
        protected async override void OnClick()
        {
            Map map = MapView.Active.Map;
            await QueuedTask.Run( () => {
                //Get the CIM Definition of the Map
                var def = map.GetDefinition();

                //Change the Map name property
                def.Name = "U.S. Hydrology Map";

                //Set the Map Definition back
                map.SetDefinition(def);
            
            });
        }
    }
}
