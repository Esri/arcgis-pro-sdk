﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos
{
    internal class ChangeSymbology : Button
    {
        protected async override void OnClick()
        {
            var hydrologyLyr = MapView.Active.Map.FindLayers("Hydrology").First() as FeatureLayer;
            await QueuedTask.Run( () =>{
                //access the layer CIM Definition
                var def = hydrologyLyr.GetDefinition() as CIMFeatureLayer;
                //Create a Blue line symbol
                var hydrologyLineSymbol = SymbolFactory.Instance.ConstructLineSymbol(ColorFactory.Instance.BlueRGB, 1.0, SimpleLineStyle.Solid);
                //Create a simple renderer using the blue line symbol
                var simpleRendererDef = new CIMSimpleRenderer { 
                  Symbol = hydrologyLineSymbol.MakeSymbolReference()
                };
                //Make changes to the CIM: Modify the renderer property to use the new Blue line symbol renderer.
                def.Renderer = simpleRendererDef;
                //Apply the CIM Changes back to the Layer.
                hydrologyLyr.SetDefinition(def);
            });
        }
    }
}
