﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace CIMDemos
{
    internal class ChangeSelectionColor : Button
    {
        protected async override void OnClick()
        {
            var hydrologyLyr = MapView.Active.Map.FindLayers("Hydrology").First() as FeatureLayer;
            await QueuedTask.Run(() =>
            {
                //access the layer CIM Definition
                var def = hydrologyLyr.GetDefinition() as CIMFeatureLayer;

                //make changes - change the selection color, hide the legend
                def.SelectionColor = ColorFactory.Instance.RedRGB;
                def.ShowLegends = false;

                //add a custom property
                var customProperties = new List<CIMStringMap>();
                customProperties.Add(new CIMStringMap() { Key = "My Property", Value = "My Value" });
                def.CustomProperties = customProperties.ToArray();

                //set the CIM Definition back
                hydrologyLyr.SetDefinition(def);
            });

        }
    }
}
