﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditingWithUICustomizations
{
  class Utils
  {
    public static async void NonAwaitCall(Task task)
    {
      try
      {
        if (task != null)
          await task;
      }
      catch
      {
      }
    }
  }
}
