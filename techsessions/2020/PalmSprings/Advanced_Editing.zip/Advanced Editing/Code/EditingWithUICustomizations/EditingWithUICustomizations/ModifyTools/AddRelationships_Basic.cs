﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace EditingWithUICustomizations
{
  internal class AddRelationships_Basic : MapTool
  {
    public AddRelationships_Basic()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Rectangle;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override async Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      bool result = await QueuedTask.Run(() =>
      {
        // get features under the geometry
        var features = MapView.Active.GetFeatures(geometry);
        if (features.Count == 0)
          return false;

        // find only the features from the Fire Stations layer
        var fireStationFeatures = features.Where(l => l.Key is BasicFeatureLayer bfl && bfl.Name == "Fire Stations").FirstOrDefault();

        var fireStationLayer = fireStationFeatures.Key;
        var fireStationOIDs = fireStationFeatures.Value;

        if (fireStationLayer == null)
          return false;

        // make sure the table is in the map
        var table = MapView.Active.Map.FindStandaloneTables("FireServices").FirstOrDefault();
        if (table == null)
          return false;

        // use the fireStation layer to obtain the gdb datastore
        using (var tbl = fireStationLayer.GetTable())
        {
          using (var gdb = tbl.GetDatastore() as Geodatabase)
          {

            // find the relationship in the gdb
            using (var rc = gdb.OpenDataset<RelationshipClass>("Fire_Stations_FireServices"))
            {
              // create the edit operation
              var op = new EditOperation();
              op.Name = "Add relationship";

              // find all the related records for these oids
              var destRows = rc.GetRowsRelatedToOriginRows(fireStationOIDs);
              // delete them all
              op.Delete(destRows);

              // create a row handle to a FireService record
              var destHandle = new RowHandle(table, 1);   // record 1 = Hazardous Materials

              // foreach of the fire station records
              foreach (var oid in fireStationOIDs)
              {
                // create a rowHandle to the fireStation feature
                var srcHandle = new RowHandle(fireStationLayer, oid);

                // create a relationship description object between the fireStation feature and the FireService record
                var rd = new RelationshipDescription(rc, srcHandle, destHandle);

                // queue the create of the relationship record
                op.Create(rd);

              }
              // Execute the operation
              return op.Execute();

            }
          }
        }

      });
      if (!result)
        MessageBox.Show("Add Relationship failed");

      return result;
    }
  }
}

