﻿using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace EditingWithUICustomizations
{
  internal class ServiceItem : ViewModelBase
  {
    public long OID { get; set; }
    public string ServiceName { get; set; }
    public bool IsSelected { get; set; }
  }

  internal class RelationshipOptionsViewModel : EmbeddableControl
  {
    public RelationshipOptionsViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions)
    {
      Utils.NonAwaitCall(GetData());
    }

    public IEnumerable<long> SelectedServices
    {
      get
      {
        List<long> services = new List<long>();
        foreach (var item in _values)
        {
          if (item.IsSelected)
            services.Add(item.OID);
        }
        return services;
      }
    }


    private List<ServiceItem> _values = new List<ServiceItem>();
    public List<ServiceItem> Values => _values;

    private Task GetData()
    {
      _values.Clear();

      // make sure the table is in the map
      var table = MapView.Active.Map.FindStandaloneTables("FireServices").FirstOrDefault();
      if (table == null)
        return Task.CompletedTask;

      return QueuedTask.Run(() =>
      {
        using (var cursor = table.Search())
        {
          while (cursor.MoveNext())
          {
            using (var row = cursor.Current)
            {
              if (row != null)
              {
                var item = new ServiceItem() { OID = row.GetObjectID(), ServiceName = row["ServiceName"].ToString(), IsSelected = false };
                _values.Add(item);
              }
            }
          }
        }
      });
    }
  }
}
