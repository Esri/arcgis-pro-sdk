﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;


namespace EditingWithUICustomizations
{
  internal class AttachmentOptionsViewModel : EmbeddableControl, IEditingCreateToolControl
  {
    public AttachmentOptionsViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) { }

    internal const string AttachmentOptionName = "Attachment";

    private ToolOptions ToolOptions { get; set; }
    private void InitializeOptions()
    {
      // no options
      if (ToolOptions == null)
        return;

      // if attachment exists in options, retrieve it
      if (ToolOptions.ContainsKey(AttachmentOptionName))
        _attachment = (string)ToolOptions[AttachmentOptionName];
      else
      {
        // otherwise assign the default value and add to the ToolOptions dictionary
        _attachment = Module1.FireStationFile;
        ToolOptions.Add(AttachmentOptionName, _attachment);
        // ensure options are notified that changes have been made
        NotifyPropertyChanged(AttachmentOptionName);
      }
    }

    #region Browse cmd
    private ICommand _browseCmd;
    public ICommand BrowseCommand
    {
      get
      {
        if (_browseCmd == null)
          _browseCmd = new RelayCommand(() => BrowseForJpg());

        return _browseCmd;
      }
    }
    #endregion

    private void BrowseForJpg()
    {
      var filter = BrowseProjectFilter.GetFilter("esri_browseDialogFilters_browseFiles");
      filter.FileExtension = ".jpg";
      filter.BrowsingFilesMode = true;

      var openItemDialog = new OpenItemDialog { BrowseFilter = filter };
      openItemDialog.Title = "Open jpg";
      if (openItemDialog.ShowDialog() == true)
        Attachment = openItemDialog.Items.FirstOrDefault().Path;
    }


    // binds in xaml
    private string _attachment;
    public string Attachment
    {
      get => _attachment; 
      set
      {
        if (SetProperty(ref _attachment, value))
        {
          _isDirty = true;
          _isValid = true;
          // add/update the buffer value to the tool options
          if (!ToolOptions.ContainsKey(AttachmentOptionName))
            ToolOptions.Add(AttachmentOptionName, value);
          else
            ToolOptions[AttachmentOptionName] = value;
          // ensure options are notified
          NotifyPropertyChanged(AttachmentOptionName);
        }
      }

    }


    #region IEditingCreateToolControl

    /// <summary>
    /// Gets the optional icon that will appear in the active template pane as a button selector.  
    /// If returning null then the Tool's small image that is defined in DAML will be used. 
    /// </summary>
		public ImageSource ActiveTemplateSelectorIcon =>
      System.Windows.Application.Current.Resources["BexDog32"] as ImageSource;

    private bool _isValid;
    /// <summary>
    /// Set this flag to indicate if tool options are valid and ready for saving.
    /// </summary>
    /// <remarks>
    /// When this IEditingCreateToolControl is being displayed in the Template Properties
    /// dialog, calling code will use this property to determine if the current Template
    /// Properties may be saved.
    /// </remarks>
    bool IEditingCreateToolControl.IsValid => _isValid;

    private bool _isDirty;
    /// <summary>
    /// Set this flag when any tool options have been changed.
    /// </summary>
    /// <remaarks>
    /// When this IEditingCreateToolControl is being displayed in the Template Properties
    /// dialog, the calling code will use this property to determine if any changes have
    /// been made.  
    /// </remaarks>
    bool IEditingCreateToolControl.IsDirty => _isDirty;

    /// <summary>
    /// Gets if the contents of this control is auto-Opened in the Active Template Pane when the 
    /// tool is activated.
    /// </summary>
    /// <param name="toolID">the ID of the current tool</param>
    /// <returns>True the active template pane will be opened to the tool's options view.
    /// False, nothing in the active template pane changes when the tool is selected.</returns>
    bool IEditingCreateToolControl.AutoOpenActiveTemplatePane(string toolID)
    {
      return true;
    }

    /// <summary>
    /// Called just before ArcGIS.Desktop.Framework.Controls.EmbeddableControl.OpenAsync
    /// when this IEditingCreateToolControl is being used within the ActiveTemplate pane.
    /// </summary>
    /// <param name="options">tool options obtained from the template for the given toolID</param>
    /// <returns>true if the control is to be displayed in the ActiveTemplate pane.. False otherwise</returns>
    bool IEditingCreateToolControl.InitializeForActiveTemplate(ToolOptions options)
    {
      // assign the current options
      ToolOptions = options;
      // initialize the view
      InitializeOptions();
      return true;    // true <==> do show me in ActiveTemplate;   false <==> don't show me
    }

    /// <summary>
    /// Called just before ArcGIS.Desktop.Framework.Controls.EmbeddableControl.OpenAsync
    /// when this IEditingCreateToolControl is being used within the Template Properties
    /// dialog
    /// </summary>
    /// <param name="options">tool options obtained from the template for the given toolID</param>
    /// <returns>true if the control is to be displayed in Template Properties. False otherwise</returns>
    bool IEditingCreateToolControl.InitializeForTemplateProperties(ToolOptions options)
    {
      return false;     // don't show the options in template properties
    }

    #endregion
  }
}
