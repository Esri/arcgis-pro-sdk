﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using System.Threading;

namespace ArcGISDemo
{
  internal class SampleModule : Module
  {
    private static SampleModule _this = null;

    /// <summary>
    /// Retrieve the singleton instance to this module here
    /// </summary>
    public static SampleModule Current
    {
      get
      {
        return _this ?? (_this = (SampleModule)FrameworkApplication.FindModule("ArcGISDemo_Module"));
      }
    }

    // Stand in for an operation that runs for awhile...
    public Task DoLongWork(Progressor prog)
    {
      return QueuedTask.Run(() => { Thread.SpinWait(1000000000); }, prog);
    }

    // Stand in for an operation that that's quick
    public Task DoWork(Progressor prog)
    {
      return QueuedTask.Run(() => { Thread.SpinWait(100000); }, prog);
    }

    #region Overrides
    /// <summary>
    /// Called by Framework when ArcGIS Pro is closing
    /// </summary>
    /// <returns>False to prevent Pro from closing, otherwise True</returns>
    protected override bool CanUnload()
    {
      //TODO - add your business logic
      //return false to ~cancel~ Application close
      return true;
    }

    #endregion Overrides

  }
}
