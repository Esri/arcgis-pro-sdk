﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;


namespace ArcGISDemo
{
    internal class DemoDockPane : DockPane
    {
        private const string _dockPaneID = "ArcGISDemo_DemoDockPane";
        private static readonly ObservableCollection<String> _items = new ObservableCollection<string>();
        private static object _lock = new object();

        protected DemoDockPane() { }

        /// <summary>
        /// Show the DockPane.
        /// </summary>
        internal static void Show()
        {
            DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
            if (pane == null)
                return;

            pane.Activate();
        }

        /// <summary>
        /// Text shown near the top of the DockPane.
        /// </summary>
        private string _heading = "Items";
        public string Heading
        {
            get { return _heading; }
            set
            {
                SetProperty(ref _heading, value, () => Heading);
            }
        }

        public ObservableCollection<string> TheItems
        {
            get
            {
                // Synchronize access to the collection 
                BindingOperations.EnableCollectionSynchronization(_items, _lock);

                return _items;
            }
        }

        internal static Task ComputeAndAddItemsB(Progressor prog)
        {
            Show();

            return QueuedTask.Run(() =>
            {
                lock (_lock)
                {
                    for (int i = 0; i < 10000; ++i)
                    {
                        SampleModule.Current.DoWork(prog);
                        _items.Add($"Computed Result {i}");
                    }
                }
            }, prog);
        }

        internal static Task ComputeAndAddItemsG(Progressor prog)
        {
            Show();

            return QueuedTask.Run(() =>
            {
                var chunk = new List<string>(100);

                for (int i = 0; i < 10000; ++i)
                {
                    SampleModule.Current.DoWork(prog);
                    chunk.Add($"Computed result {i}");

                    // Minimize lock entries to chunk intervals
                    if (chunk.Count > 100)
                    {
                        lock (_lock)
                        {
                            foreach (var item in chunk) { _items.Add(item); }
                        }
                        chunk.Clear();
                    }
                }
            }, prog);
        }

    }

}
