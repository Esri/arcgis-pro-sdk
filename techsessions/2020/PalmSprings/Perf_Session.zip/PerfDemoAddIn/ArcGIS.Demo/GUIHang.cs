﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;


namespace ArcGISDemo
{
  internal class GUIHang_B1 : Button
  {
    protected override void OnClick()
    {
      // Calling Wait or Result on a Task here will hang the UI 
      SampleModule.Current.DoLongWork(Progressor.None).Wait();

      PerfUtil.ShowMessage("B1 - GUI hang test", "Completed");
    }
  }

  internal class GUIHang_G1 : Button
  {
    protected override async void OnClick()
    {
      using (var ps = new ProgressorSource("Working..."))
      {
        await SampleModule.Current.DoLongWork(ps.Progressor);

        PerfUtil.ShowMessage("G1 - GUI hang test", "Completed");
      }
    }
  }
}
