﻿using ArcGIS.Desktop.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArcGISDemo
{
  public class BoldNotification : Notification
  {
    
  }

  public class PerfUtil
  {
    public PerfUtil(string name)
    {
      _name = name;
    }

    static public void ShowMessage(string title, string message)
    {
      var notification = new Notification
      {
        Title = title,
        Message = message,
        ImageUrl = @"pack://application:,,,/ArcGIS.Demo;component/Images/gear.png",
      };
      
      FrameworkApplication.AddNotification(notification);
    }

  public void Start()
    {
      _stopwatch.Start();
    }

    public void Stop()
    {
      _stopwatch.Stop();

      var notification = new Notification
      {
        Title = "PerfUtil",
        Message = $"{_name} time (ms): {_stopwatch.ElapsedMilliseconds}",
        ImageUrl = @"pack://application:,,,/ArcGIS.Demo;component/Images/gear-clock.png"
      };

      FrameworkApplication.AddNotification(notification);
    }

    private Stopwatch _stopwatch = new Stopwatch();
    private string _name;
  }

}
