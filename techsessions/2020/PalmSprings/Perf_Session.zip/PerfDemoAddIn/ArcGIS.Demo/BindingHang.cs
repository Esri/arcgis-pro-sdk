﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;


namespace ArcGISDemo
{
  internal class BindingHang_B4 : Button
  {
    protected override async void OnClick()
    {
      using (var ps = new ProgressorSource("Working..."))
      {
        await DemoDockPane.ComputeAndAddItemsB(ps.Progressor);

        PerfUtil.ShowMessage("B4 - Binding Hang Test", "Completed");
      }
    }
  }

  internal class BindingHang_G4 : Button
  {
    protected override async void OnClick()
    {
      using (var ps = new ProgressorSource("Working..."))
      {
        await DemoDockPane.ComputeAndAddItemsG(ps.Progressor);

        PerfUtil.ShowMessage("G4 - Binding Hang Test", "Completed");
      }
    }
  }
}
