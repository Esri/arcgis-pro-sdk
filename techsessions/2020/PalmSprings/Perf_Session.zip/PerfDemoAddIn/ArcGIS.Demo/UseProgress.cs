﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;

namespace ArcGISDemo
{
  internal class UseProgress_B2 : Button
  {
    protected override async void OnClick()
    {
      await SampleModule.Current.DoLongWork(Progressor.None);

      PerfUtil.ShowMessage("B1 - Use Progress Test ", "Completed");
    }
  }

  internal class UseProgress_G2 : Button
  {
    protected override async void OnClick()
    {
      using (var ps = new ProgressorSource("Working..."))
      {
        await SampleModule.Current.DoLongWork(ps.Progressor);

        PerfUtil.ShowMessage("G1 - Use Progress Test", "Completed");
      }
    }
  }

}
