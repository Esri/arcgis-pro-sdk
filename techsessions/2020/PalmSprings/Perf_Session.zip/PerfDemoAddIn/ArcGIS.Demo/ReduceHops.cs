﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;

namespace ArcGISDemo
{
  internal class ReduceHops_B3 : Button
  {
    protected override async void OnClick()
    {
      var timer = new PerfUtil("B3 - Reduce Hops Test");

      using (ProgressDialog prgDlg = new ProgressDialog("Working..."))
      {
        prgDlg.Show();

        timer.Start();

        // Slower, with many cross thread jumps
        for (int i = 0; i < 6000; ++i)
        {
          await SampleModule.Current.DoWork(Progressor.None);
        }

        timer.Stop();
      }
    }

  }

  // Raster case
  internal class ReduceHops_G3 : Button
  {
    protected override async void OnClick()
    {
      var timer = new PerfUtil("G3 - Reduce Hops Test");

      using (var ps = new ProgressorSource("Working..."))
      {
        timer.Start();

        // Faster, with a single cross thread jump
        await QueuedTask.Run(() =>
        {
          for (int i = 0; i < 6000; ++i)
          {
            // This async method call will be inlined.
            SampleModule.Current.DoWork(ps.Progressor);
          }
        });

        timer.Stop();
      }

    }
  }

}
