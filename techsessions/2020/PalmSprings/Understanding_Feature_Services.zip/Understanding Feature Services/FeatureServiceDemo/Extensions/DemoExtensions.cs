﻿using ArcGIS.Core.Data;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeatureServiceDemo.Extensions
{
	public enum FeatureServiceType
	{
		Unknown = 0,
		NonVersioned,
		BranchVersionedDefault,
		BranchVersionedNamedVersion
	};

	public static class DemoExtensions
	{
		public static bool GetIsFeatureServiceLayer(
																 this BasicFeatureLayer layer)
		{
			var gdbt_type = layer.GetGeodatabaseType();
			return gdbt_type == GeodatabaseType.Service;
		}

		public static GeodatabaseType GetGeodatabaseType(
																		this BasicFeatureLayer layer)
		{
			using (var dataset = layer.GetTable())
			using (var gdb = dataset.GetDatastore())
				return ((Geodatabase)gdb).GetGeodatabaseType();
		}

		public static FeatureServiceType GetFeatureServiceType(
																			this BasicFeatureLayer layer)
		{

			if (!layer.GetIsFeatureServiceLayer())
			{
				return FeatureServiceType.Unknown;
			}
			//We need the connection string and registration type
			using (var dataset = layer.GetTable())
			{
				var reg = dataset.GetRegistrationType();
				//Versioned or NonVersioned?
				if (reg == RegistrationType.Nonversioned)
				{
					return FeatureServiceType.NonVersioned;
				}
				else //RegistrationType.Versioned
				{
					//Branch default or branch named version?
					using (var gdb = dataset.GetDatastore() as Geodatabase)
					{
						var conn_props = gdb.GetConnector() as ServiceConnectionProperties;
						return conn_props.Version.ToLower() == "sde.default" ?
							FeatureServiceType.BranchVersionedDefault : FeatureServiceType.BranchVersionedNamedVersion;
					}
				}
			}
		}

		public static RegistrationType GetRegistrationType(
																				 this BasicFeatureLayer layer)
		{
			using (var dataset = layer.GetTable())
				return dataset.GetRegistrationType();
		}

		public static bool ServiceLayerHasUndoRedo(this BasicFeatureLayer layer)
		{
			//We need the connection string and registration type
			using (var dataset = layer.GetTable())
			{
				var reg = dataset.GetRegistrationType();
				//Versioned or NonVersioned? Pro 2.5
				if (reg == RegistrationType.Nonversioned)
					return true;
				else //RegistrationType.Versioned
				{
					//Branch default or branch named version?
					using (var gdb = dataset.GetDatastore() as Geodatabase)
					{
						var conn_props = gdb.GetConnector() as ServiceConnectionProperties;
						return conn_props.Version.ToLower() == "sde.default" ?
							false : true;
					}
				}
			}
		}
	}
}
