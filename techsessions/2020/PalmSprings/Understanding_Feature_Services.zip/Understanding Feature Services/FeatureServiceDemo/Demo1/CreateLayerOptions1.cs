﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo1
{
	internal class CreateLayerOptions1 : Button
	{
		protected async override void OnClick()
		{
			//feature service urls
			var hosted =
	$"https://{Module1.fed_server}/server/rest/services/Hosted/Buildings_Hosted/FeatureServer";

			var by_ref =
		$"https://{Module1.fed_server}/server/rest/services/Buildings_Branch/FeatureServer";

			//portal item - portal must be the active portal
			var portal =
	$"http://{Module1.fed_server}/portal/home/item.html?id=9d3a404c86fc47d589b0cfce02a45ba1";

			var container = MapView.Active.Map;
			await QueuedTask.Run(() =>
			{
				var groupLyr1 = LayerFactory.Instance.CreateLayer(
	new Uri(hosted, UriKind.Absolute), container);

				var groupLyr2 = LayerFactory.Instance.CreateLayer(
		new Uri(by_ref, UriKind.Absolute), container);

				var groupLyr3 = LayerFactory.Instance.CreateLayer(
					new Uri(portal, UriKind.Absolute), container, 0, "Portal_Item");

				var gl_params = new LayerCreationParams(new Uri(portal, UriKind.Absolute))
				{
					Name = "Portal_Item2",
					IsVisible = false
				};
				var groupLyr4 = LayerFactory.Instance.CreateLayer<GroupLayer>(gl_params, container);


			});

			#region Zoom default
			QueuedTask.Run(() =>
			{
				var bmrk = MapView.Active.Map.GetBookmarks().FirstOrDefault(b => b.Name == "Default");
				if (bmrk == null)
					return;
				MapView.Active.ZoomTo(bmrk);
			});
			#endregion
		}
	}
}
