﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo1
{
	internal class SelectFeatures : Button
	{
		protected override void OnClick()
		{
			var groupLayer =
			 MapView.Active.Map.GetLayersAsFlattenedList().OfType<GroupLayer>().First();
			var feature_layers =
			 groupLayer.GetLayersAsFlattenedList().OfType<FeatureLayer>();
			var extent = MapView.Active.Extent;

			QueuedTask.Run(() =>
			{
				groupLayer.SetExpanded(true);
				var sf = new SpatialQueryFilter()
				{
					FilterGeometry = extent,
					SpatialRelationship = SpatialRelationship.Contains,
					SubFields = "*"
				};
				foreach (var fl in feature_layers)
				{
					var selection = fl.Select(sf);
					var num_sel = selection.GetCount();
					using (var rc = selection.Search())
					{
						while (rc.MoveNext())
						{
							var feature = rc.Current as Feature;
							//etc
						}
					}
				}
			});
		}
	}
}
