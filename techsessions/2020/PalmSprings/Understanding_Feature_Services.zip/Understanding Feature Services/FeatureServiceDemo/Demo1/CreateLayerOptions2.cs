﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo1
{
	internal class CreateLayerOptions2 : Button
	{
		protected async override void OnClick()
		{
			//feature service urls
			var by_ref0 =
$"https://{Module1.fed_server}/server/rest/services/Buildings_ByRef/FeatureServer/0";
			var by_ref1 =
$"https://{Module1.fed_server}/server/rest/services/Buildings_ByRef/FeatureServer/1";

			var hosted0 =
$"https://{Module1.fed_server}/server/rest/services/Hosted/Buildings_Hosted/FeatureServer/0";
			var branch0 =
$"https://{Module1.fed_server}/server/rest/services/Buildings_Branch/FeatureServer/0";

			var container = MapView.Active.Map;
			await QueuedTask.Run(() =>
			{
				var fl1_0 = LayerFactory.Instance.CreateLayer(
					new Uri(by_ref1, UriKind.Absolute), container, 0) as FeatureLayer;

				var fl2 = LayerFactory.Instance.CreateLayer(
					new Uri(hosted0, UriKind.Absolute), container) as FeatureLayer;

				var fl3 = LayerFactory.Instance.CreateFeatureLayer(
					new Uri(branch0, UriKind.Absolute), container);

				var fl_params = new FeatureLayerCreationParams(new Uri(by_ref0, UriKind.Absolute))
				{
					RendererDefinition = new SimpleRendererDefinition()
					{
						SymbolTemplate = SymbolFactory.Instance.ConstructPolygonSymbol(
															 ColorFactory.Instance.CreateRGBColor(255, 255, 0)).MakeSymbolReference()
					}
				};
				var fl4 = LayerFactory.Instance.CreateLayer<FeatureLayer>(fl_params, container);
			});

			#region Zoom default
			QueuedTask.Run(() =>
			{
				var bmrk = MapView.Active.Map.GetBookmarks().FirstOrDefault(b => b.Name == "Default");
				if (bmrk == null)
					return;
				MapView.Active.ZoomTo(bmrk);
			});
			#endregion
		}
	}
}
