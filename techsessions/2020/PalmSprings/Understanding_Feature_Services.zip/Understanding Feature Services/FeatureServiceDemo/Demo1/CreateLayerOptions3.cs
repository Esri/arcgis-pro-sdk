﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo1
{
	internal class CreateLayerOptions3 : Button
	{
		protected async override void OnClick()
		{
			//feature service urls
			var by_ref =
$"https://{Module1.fed_server}/server/rest/services/Buildings_ByRef/FeatureServer";
			var hosted =
$"https://{Module1.fed_server}/server/rest/services/Hosted/Buildings_Hosted/FeatureServer";
			var branch =
$"https://{Module1.fed_server}/server/rest/services/Buildings_Branch/FeatureServer";

			var container = MapView.Active.Map;
			var index = 0;
			await QueuedTask.Run(() =>
			{
				foreach (var url in new string[] { by_ref, hosted, branch })
				{
					var uri = new Uri(url, UriKind.Absolute);
					var svc_props = new ServiceConnectionProperties(uri);
					//connect to the Feature Service DB
					using (var fs_db =
									new ArcGIS.Core.Data.Geodatabase(svc_props))
					{
						var layerName = System.IO.Path.GetFileName(
																 System.IO.Path.GetDirectoryName(url));
						//Create a group layer for each feature layer from the service
						var grpLayer = LayerFactory.Instance.CreateGroupLayer(
																				 container, index++, layerName);

						//Retrieve the Feature Class(es)
						var fc_defs = fs_db.GetDefinitions<FeatureClassDefinition>();
						foreach (var def in fc_defs)
						{
							using (var fc = fs_db.OpenDataset<FeatureClass>(def.GetName()))
							{
								//Create layers for each
								var layer = LayerFactory.Instance.CreateFeatureLayer(fc, grpLayer);
							}
						}
						var table_defs = fs_db.GetDefinitions<TableDefinition>();
						foreach (var def in table_defs)
						{
							using (var table = fs_db.OpenDataset<Table>(def.GetName()))
							{
								//Create standalone tables for each
								var tbl =
								 StandaloneTableFactory.Instance.CreateStandaloneTable(
																														table, container);
							}
						}
					}
				}
			});

			#region Zoom default
			QueuedTask.Run(() =>
			{
				var bmrk = MapView.Active.Map.GetBookmarks().FirstOrDefault(b => b.Name == "Default");
				if (bmrk == null)
					return;
				MapView.Active.ZoomTo(bmrk);
			});
			#endregion
		}
	}
}