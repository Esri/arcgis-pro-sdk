﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo3
{
	internal class CreateLayersEditing : Button
	{
		protected async override void OnClick()
		{

			var by_ref0 =
$"https://{Module1.fed_server}/server/rest/services/Buildings_ByRef/FeatureServer/0";

			var branch =
$"https://{Module1.fed_server}/server/rest/services/Buildings_Branch/FeatureServer";
			var branch0 = $"{branch}/0";

			var container = MapView.Active.Map;

			await QueuedTask.Run(() =>
			{
				var fl1_0 = LayerFactory.Instance.CreateLayer(
					new Uri(by_ref0, UriKind.Absolute), container, 0, "Buildings_ByRef (Non Vers)") as FeatureLayer;

				var fl3 = LayerFactory.Instance.CreateFeatureLayer(
					new Uri(branch0, UriKind.Absolute), container, 0, "Buildings_Branch (Vers)");

				//Add a versioned connection
				var uri = new Uri(branch, UriKind.Absolute);
				var svc_props = new ServiceConnectionProperties(uri);
				svc_props.Version = "VersionA";

				//connect to the Feature Service DB
				using (var fs_db = new ArcGIS.Core.Data.Geodatabase(svc_props))
				{

					//Retrieve the Feature Class(es)
					using (var fc_def = fs_db.GetDefinitions<FeatureClassDefinition>().First())
					{
						using (var fc = fs_db.OpenDataset<FeatureClass>(fc_def.GetName()))
						{
							var layer = LayerFactory.Instance.CreateFeatureLayer(fc, container, 0);
							layer.SetName(layer.Name + "_VA (Vers)");
							var dc = layer.GetDataConnection() as CIMStandardDataConnection;

							#region Change symbol color to orange
							var sr = layer.GetRenderer() as CIMSimpleRenderer;
							var orange = ColorFactory.Instance.CreateRGBColor(255, 172, 0);
							sr.Symbol = SymbolFactory.Instance.ConstructPolygonSymbol(
														 orange).MakeSymbolReference();
							layer.SetRenderer(sr);
							#endregion
						}
					}
				}

			});

			#region Zoom Editing Extent
			QueuedTask.Run(() =>
			{
				var bmrk = MapView.Active.Map.GetBookmarks().FirstOrDefault(b => b.Name == "Editing");
				if (bmrk == null)
					return;
				MapView.Active.ZoomTo(bmrk);
			});
			#endregion
		}
	}
}
