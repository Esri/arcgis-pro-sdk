﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo3
{
	internal class SelectForBranchNamed : Button
	{
		protected override void OnClick()
		{
			var feature_layers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();

			QueuedTask.Run(() =>
			{
				Module1.Current.ClearSelection();

				var buildings_branch_named = feature_layers.First(fl => fl.Name == "Buildings_Branch_VA (Vers)");

				var oids1 = new List<long> { 261, 132, 133, 139 };
				var qf = new QueryFilter()
				{
					ObjectIDs = oids1
				};
				buildings_branch_named.Select(qf, SelectionCombinationMethod.New);

				Module1.Current.UpdateSelection();
			});
		}
	}
}
