﻿using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeatureServiceDemo.Demo3
{
	internal class MoveDistance : EditBox
	{

		public MoveDistance()
		{
			this.Text = Module1.Current.MoveDistance.ToString();
		}

		protected override void OnEnter()
		{
			double newValue = 0;
			if (double.TryParse(Text, out newValue))
			{
				Module1.Current.MoveDistance = newValue;
			}
			Text = Module1.Current.MoveDistance.ToString();
		}
	}
}

