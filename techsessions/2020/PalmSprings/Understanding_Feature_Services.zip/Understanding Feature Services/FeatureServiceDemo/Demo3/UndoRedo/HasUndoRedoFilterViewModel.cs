﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;



namespace FeatureServiceDemo.Demo3.UndoRedo
{
	internal class HasUndoRedoFilterViewModel : CustomControl
	{
		private bool _hasUndoRedo = false;
		private bool _noUndoRedo = false;
		private bool _either = false;

		public HasUndoRedoFilterViewModel()
		{
			if (Module1.Current.UndoRedoFilter == UndoRedoFilter.HasUndoRedo)
				_hasUndoRedo = true;
			else if (Module1.Current.UndoRedoFilter == UndoRedoFilter.NoUndoRedo)
				_noUndoRedo = true;
			else
				_either = true;
		}

		public bool HasUndoRedo
		{
			get
			{
				return _hasUndoRedo;
			}
			set
			{
				_hasUndoRedo = value;
				if (_hasUndoRedo)
				{
					Module1.Current.UndoRedoFilter = UndoRedoFilter.HasUndoRedo;
					Module1.Current.FilterSelectionsAsync(Module1.Current.CachedSelection, Module1.Current.UndoRedoFilter);
				}

				NotifyPropertyChanged();
			}
		}

		public bool NoUndoRedo
		{
			get
			{
				return _noUndoRedo;
			}
			set
			{
				_noUndoRedo = value;
				if (_noUndoRedo)
				{
					Module1.Current.UndoRedoFilter = UndoRedoFilter.NoUndoRedo;
					Module1.Current.FilterSelectionsAsync(Module1.Current.CachedSelection, Module1.Current.UndoRedoFilter);
				}
				NotifyPropertyChanged();
			}
		}

		public bool Either
		{
			get
			{
				return _either;
			}
			set
			{
				_either = value;
				if (_either)
				{
					Module1.Current.UndoRedoFilter = UndoRedoFilter.Either;
					Module1.Current.FilterSelectionsAsync(Module1.Current.CachedSelection, Module1.Current.UndoRedoFilter);
				}
				NotifyPropertyChanged();
			}
		}

	}
}
