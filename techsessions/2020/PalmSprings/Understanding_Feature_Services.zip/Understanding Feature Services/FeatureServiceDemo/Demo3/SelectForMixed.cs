﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo3
{
	internal class SelectForMixed : Button
	{
		protected override void OnClick()
		{
			var feature_layers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>();

			QueuedTask.Run(() =>
			{
				Module1.Current.ClearSelection();

				var buildings_by_ref = feature_layers.First(fl => fl.Name == "Buildings_ByRef (Non Vers)");
				var buildings_branch_default = feature_layers.First(fl => fl.Name == "Buildings_Branch (Vers)");
				var buildings_branch_named = feature_layers.First(fl => fl.Name == "Buildings_Branch_VA (Vers)");

				//select features from each
				buildings_branch_named.Select(null, SelectionCombinationMethod.New);

				var oids1 = new List<long> { 239, 265 };
				var qf = new QueryFilter()
				{
					ObjectIDs = oids1
				};
				buildings_by_ref.Select(qf, SelectionCombinationMethod.New);

				var oids2 = new List<long> { 142, 141, 132, 261, 140, 139, 133, 138, 135, 136, 262, 134 };
				qf.ObjectIDs = oids2;
				buildings_branch_default.Select(qf, SelectionCombinationMethod.New);

				Module1.Current.UpdateSelection();
			});

		}
	}
}
