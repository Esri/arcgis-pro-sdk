﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using FeatureServiceDemo.Extensions;

namespace FeatureServiceDemo.Demo2
{
	internal class GeneralInfo : Button
	{
		protected async override void OnClick()
		{
			var container = MapView.Active.Map;
			var layerInfo = new FormatNameValues();

			var info = await QueuedTask.Run(() =>
			{

				//Query all the layers just added
				var child_layers = container.GetLayersAsFlattenedList().OfType<FeatureLayer>();
				foreach (var child_layer in child_layers)
				{
					if (!child_layer.GetIsFeatureServiceLayer())
						continue;

					//Get some information about the layer
					layerInfo.Append("Layer name:", child_layer.Name);
					var dataset_name = child_layer.GetFeatureClass().GetName();
					layerInfo.Append("Dataset:", dataset_name);
					var dc = child_layer.GetDataConnection() as CIMStandardDataConnection;
					layerInfo.Append("Url:", dc.WorkspaceConnectionString);
					layerInfo.Append("Layer Id:", dc.Dataset);
					layerInfo.AppendLine("IsFeatureService: ", "Yes");

				}
				return layerInfo.ToString();
			});
			InfoMessageBox.Show(info, "Feature Layers");
		}
	}

	internal class FormatNameValues
	{
		private StringBuilder sb;

		public FormatNameValues()
		{
			sb = new StringBuilder();
			sb.AppendLine(string.Format("{0,-16} {1,-70}", "Name", "Value"));
			sb.AppendLine(string.Format("{0}", new string('_', 86)));
		}

		public void Append(string name, string value)
		{
			sb.AppendLine(string.Format("{0,-16} {1}", name, value));
		}

		public void AppendLine(string name, string value)
		{
			sb.AppendLine(string.Format("{0,-16} {1}\r\n", name, value));
		}

		public void Clear()
		{
			sb.Clear();
			sb.AppendLine(string.Format("{0,-16} {1}", "Name", "Value"));
			sb.AppendLine(string.Format("{0}", new string('_', 86)));
		}

		public override string ToString()
		{
			return sb.ToString();
		}
	}
}
