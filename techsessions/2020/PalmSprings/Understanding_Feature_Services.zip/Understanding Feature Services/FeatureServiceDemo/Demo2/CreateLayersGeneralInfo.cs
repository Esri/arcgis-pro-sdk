﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Demo2
{
	internal class CreateLayersGeneralInfo : Button
	{
		protected async override void OnClick()
		{
			//file gdb
			var file_gdb1 = $@"{Module1.file_gdb_path}\Buildings_Local";
			//feature service urls
			var branch =
$"https://{Module1.fed_server}/server/rest/services/Buildings_Branch/FeatureServer";
			var portal =
$"http://{Module1.fed_server}/portal/home/item.html?id=9d3a404c86fc47d589b0cfce02a45ba1";
			var hosted =
$"https://{Module1.fed_server}/server/rest/services/Hosted/Buildings_Hosted/FeatureServer";

			var container = MapView.Active.Map;
			var layerInfo = new FormatNameValues();

			await QueuedTask.Run(() =>
			{
				var sr_def = new SimpleRendererDefinition(
					SymbolFactory.Instance.ConstructPolygonSymbol(
						ColorFactory.Instance.CreateRGBColor(225, 0, 0)).MakeSymbolReference());

				var bldg_local = LayerFactory.Instance.CreateFeatureLayer(
					new Uri(file_gdb1, UriKind.Absolute), container, 0, "", sr_def);

				var groupLyr1 = LayerFactory.Instance.CreateLayer(
					new Uri(branch, UriKind.Absolute), container);

				var groupLyr2 = LayerFactory.Instance.CreateLayer(
					new Uri(portal, UriKind.Absolute), container);

				var groupLyr3 = LayerFactory.Instance.CreateLayer(
					new Uri(hosted, UriKind.Absolute), container);

				#region expand group layers
				groupLyr1.SetExpanded(true);
				groupLyr2.SetExpanded(true);
				groupLyr3.SetExpanded(true);
				//groupLyr4.SetExpanded(true);
				#endregion
			});

			#region Zoom default
			QueuedTask.Run(() =>
			{
				var bmrk = MapView.Active.Map.GetBookmarks().FirstOrDefault(b => b.Name == "Default");
				if (bmrk == null)
					return;
				MapView.Active.ZoomTo(bmrk);
			});
			#endregion
		}
	}
}