﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Editing.Attributes;
using FeatureServiceDemo.Extensions;

namespace FeatureServiceDemo
{
	public enum UndoRedoFilter
	{
		Either = 0,
		HasUndoRedo,
		NoUndoRedo
	};

	internal class Module1 : Module
	{
		private static Module1 _this = null;

		internal static string user = "admin";
		internal static string superSecretPwd = "123Letmeinnow.";
		internal static string fed_server = "sdk5.esri.com";
		//internal static string non_fed_server = "dev0006807.esri.com";
		//internal static string non_fed_server = "sdkaodoc.esri.com";
		internal static string non_fed_server = "cmacleod3.esri.com:6443";
		internal static string file_gdb_path =
			@"E:\Data\SDK\DevSummit\2020\PalmSprings\TechSessions\UnderstandingFeatureServices\FeatureServices\FeatureServices.gdb";

		private Dictionary<string, List<long>> _savedCreates;
		private Dictionary<string, Dictionary<long, Geometry>> _savedShapes;

		public Dictionary<string, Dictionary<long, Geometry>> SavedShapes => _savedShapes;

		/// <summary>
		/// Retrieve the singleton instance to this module here
		/// </summary>
		public static Module1 Current
		{
			get
			{
				return _this ?? (_this = (Module1)FrameworkApplication.FindModule("FeatureServiceDemo_Module"));
			}
		}

		#region Overrides

		protected override bool Initialize()
		{
			_savedShapes = new Dictionary<string, Dictionary<long, Geometry>>();
			_savedCreates = new Dictionary<string, List<long>>();
			return true;
		}


		/// <summary>
		/// Called by Framework when ArcGIS Pro is closing
		/// </summary>
		/// <returns>False to prevent Pro from closing, otherwise True</returns>
		protected override bool CanUnload()
		{
			//TODO - add your business logic
			//return false to ~cancel~ Application close
			return true;
		}

		#endregion Overrides

		private double _moveDistance = -350;
		internal double MoveDistance
		{
			get
			{
				return _moveDistance;
			}
			set
			{
				_moveDistance = value;
			}
		}

		private UndoRedoFilter _hasUndoRedo = UndoRedoFilter.Either;
		internal UndoRedoFilter UndoRedoFilter
		{
			get
			{
				return _hasUndoRedo;
			}
			set
			{
				_hasUndoRedo = value;
			}
		}

		private Dictionary<BasicFeatureLayer, List<long>> _cachedSelection = null;
		public Dictionary<BasicFeatureLayer, List<long>> CachedSelection
		{
			get
			{
				return _cachedSelection;
			}
			set
			{
				_cachedSelection = value;
			}
		}

		public void ClearSelection()
		{
			//Needs QTR
			MapView.Active?.Map?.ClearSelection();
			_cachedSelection?.Clear();
			_cachedSelection = new Dictionary<BasicFeatureLayer, List<long>>();
		}

		public void UpdateSelection()
		{
			var feature_layers = MapView.Active?.Map?.GetLayersAsFlattenedList()?.OfType<FeatureLayer>()?.ToList() ?? new List<FeatureLayer>();
			_cachedSelection?.Clear();
			_cachedSelection = new Dictionary<BasicFeatureLayer, List<long>>();
			foreach (var fl in feature_layers)
			{
				var select = fl.GetSelection();
				if (select.GetCount() > 0)
					_cachedSelection.Add(fl, select.GetObjectIDs().ToList());
			}
		}

		public Task FilterSelectionsAsync(Dictionary<BasicFeatureLayer, List<long>> selectedFeatures, UndoRedoFilter filter)
		{
			return QueuedTask.Run(() => FilterSelections(selectedFeatures, filter));
		}

		public void FilterSelections(
			Dictionary<BasicFeatureLayer, List<long>> initialSelection,
			UndoRedoFilter filter)
		{
			if (initialSelection == null || initialSelection.Count() == 0)
				return;

			//clear everything
			MapView.Active.Map.ClearSelection();

			//add back in what ever is not being filtered out
			foreach (var kvp in initialSelection)
			{
				var svcLayer = kvp.Key;

				var oids = kvp.Value;
				var qf = new QueryFilter() { ObjectIDs = oids };

				var hasUndoRedo = svcLayer.ServiceLayerHasUndoRedo();
				if (LayerUndoRedoMatchesFilter(hasUndoRedo, filter))
				{
					//add the selection to the map otherwise skip it
					svcLayer.Select(qf);
				}
			}
		}

		private bool LayerUndoRedoMatchesFilter(bool hasUndoRedo, UndoRedoFilter filter)
		{
			if (filter == UndoRedoFilter.Either)
			{
				return true;
			}
			else if (hasUndoRedo && filter == UndoRedoFilter.HasUndoRedo)
			{
				return true;
			}
			else if (!hasUndoRedo && filter == UndoRedoFilter.NoUndoRedo)
			{
				return true;
			}
			return false;
		}


		public bool CheckSelection(IEnumerable<KeyValuePair<MapMember, List<long>>> set)
		{
			if (set.Count() == 0)
				return false;
			foreach (var kvp in set)
			{
				if (kvp.Key is BasicFeatureLayer)
				{
					var featureLayer = kvp.Key as BasicFeatureLayer;
					if (!featureLayer.ServiceLayerHasUndoRedo())
					{
						if (!_savedShapes.ContainsKey(featureLayer.Name))
						{
							var rows = new Dictionary<long, Geometry>();
							_savedShapes[featureLayer.Name] = rows;
						}
						foreach (var oid in kvp.Value)
						{
							var insp = new Inspector();
							insp.Load(featureLayer, oid);
							var shape = (Geometry)insp["SHAPE"];
							_savedShapes[featureLayer.Name][oid] = shape;
						}
					}
				}
			}
			return true;
		}

		public void Undo()
		{
			var undo = new EditOperation()
			{
				Name = "Undo Demo Edits",
				SelectModifiedFeatures = true
			};
			bool edit_added = false;
			foreach (var kvp in _savedShapes)
			{
				var rows = kvp.Value;
				var featureLayer = MapView.Active.Map.GetLayersAsFlattenedList()
							.OfType<FeatureLayer>().First(lyr => lyr.Name == kvp.Key);

				foreach (var oid_geom_pair in rows)
				{
					undo.Modify(featureLayer, oid_geom_pair.Key, oid_geom_pair.Value);
					edit_added = true;
				}
			}

			//undo creates with deletes
			foreach (var kvp in _savedCreates)
			{
				var featureLayer = MapView.Active.Map.GetLayersAsFlattenedList()
							.OfType<FeatureLayer>().First(lyr => lyr.Name == kvp.Key);
				undo.Delete(featureLayer, kvp.Value);
				edit_added = true;
			}

			if (edit_added)
			{
				if (undo.Execute())
				{
					_savedShapes.Clear();
					_savedCreates.Clear();
				}
			}
		}

	}
}
