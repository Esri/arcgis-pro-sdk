﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace FeatureServiceDemo.Utilities
{
	internal class DeleteLayers : Button
	{
		protected async override void OnClick()
		{
			await QueuedTask.Run(() =>
			{
				var grpLayers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<GroupLayer>().ToList();
				if (grpLayers.Count() > 0)
					MapView.Active.Map.RemoveLayers(grpLayers);

				var flayers = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().ToList();
				if (flayers.Count() > 0)
					MapView.Active.Map.RemoveLayers(flayers);

				var tables = MapView.Active.Map.StandaloneTables.ToList();
				if (tables.Count() > 0)
					MapView.Active.Map.RemoveStandaloneTables(tables);

			});

		}
	}
}
