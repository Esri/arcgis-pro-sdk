﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Events;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace Events
{
  internal class HookEvents : Button
  {
    FeatureLayer policeLayer = null;
    FeatureLayer precinctLayer = null;

    protected override void OnClick()
    {
      policeLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(l => l.Name == "Police Stations").FirstOrDefault();
      precinctLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(l => l.Name == "Portland Precincts").FirstOrDefault();

      if ((policeLayer == null) || (precinctLayer == null))
        return;

      QueuedTask.Run(() =>
      {
        if (Module1.rowCreatedToken == null)
        {
          var fc = policeLayer.GetFeatureClass();
          Module1.rowCreatedToken = RowCreatedEvent.Subscribe(onRowCreated, fc);
        }

        if (Module1.rowChangedToken == null)
        {
          var fc = precinctLayer.GetFeatureClass();
          Module1.rowChangedToken = RowChangedEvent.Subscribe(onRowChanged, fc);
        }

        if (Module1.editCompletedToken == null)
          Module1.editCompletedToken = EditCompletedEvent.Subscribe(onEditCompleted);

        if (Module1.editCompletingToken == null)
          Module1.editCompletingToken = EditCompletingEvent.Subscribe(onEditCompleting);
      });
    }

    #region EditCompleted
    private Task onEditCompleted(EditCompletedEventArgs args)
    {
      if (args == null)
        return Task.CompletedTask;

      // features created, modified, deleted
      var creates = args.Creates;  //  args.Modifies     args.Deletes;

      var featureChanged = args.FeatureChanged(policeLayer, 1);
      // args.FeatureDeleted(policeLayer, 1);
      // args.FeatureModified(policeLayer, 1);

      bool changes = args.FeaturesCreated(policeLayer);
      //args.FeaturesModified(policeLayer);
      //args.FeaturesDeleted(policeLayer);


      changes = args.MapMemberChanged(policeLayer);

      return Task.CompletedTask;
    }
    #endregion

    #region EditCompleting

    private void onEditCompleting(EditCompletingEventArgs args)
    {
      // args.CancelEdit;
    }
    #endregion

    private void onRowCreated(RowChangedEventArgs args)
    {
      var row = args?.Row;
      if (row == null)
        return;

      var shape = row["Shape"] as Geometry;

      // find precinct field - make sure it exists 
      int fldIndex = row.FindField("Precinct");
      if (fldIndex != -1)
      {
        // use the Precinct layer to determine which precinct the new feature lies within
        var spatialFilter = new SpatialQueryFilter();
        spatialFilter.FilterGeometry = shape;
        spatialFilter.SpatialRelationship = SpatialRelationship.Within;

        using (var cursor = precinctLayer.Search(spatialFilter))
        {
          if (cursor.MoveNext())
          {
            using (var current = cursor.Current)
            {
              string districtName = current["Name"].ToString();

              // assign to the new feature
              row["Precinct"] = districtName;

              row.Store();
            }
          }
        }
      }

      // add audit record
      AddChange(row, args.Operation);
    }

    private static Guid guidOperation = Guid.Empty;
    private void onRowChanged(RowChangedEventArgs args)
    {
      var row = args?.Row;
      if (row == null)
        return;

      // check against re-entrancy
      if (guidOperation == args.Guid)
        return;

      guidOperation = args.Guid;

      // want to prevent geometry edits, but allow attribute edits

      // find shape field
      int fldIndex = row.FindField("Shape");
      if (fldIndex != -1)
      {
        // if edits have been made to this field
        if (row.HasValueChanged(fldIndex))
        {
          args.CancelEdit("No geometry edits are allowed", false);
          return;
        }
      }

      // any attribute edit is ok

      // update a dependant attribute
      row["ModifiedBy"] = Environment.UserName;
      // store
      row.Store();

      // add audit record
      AddChange(row, args.Operation);
    }

    private void AddChange(Row row, EditOperation op)
    {
      if (row == null)
        return;

      var table = row.GetTable();

      // now add a record to an audit table 
      // previously had to use GDB API - CreateRowBuffer, CreateRow  now can use the args.Operation

      var history = MapView.Active.Map.FindStandaloneTables("CHANGEHISTORY").FirstOrDefault();
      if (history != null)
      {
        Dictionary<string, object> values = new Dictionary<string, object>();

        values.Add("TABLENAME", table.GetName());
        values.Add("DESCRIPTION", $"OID: {row.GetObjectID()}, {DateTime.Now.ToString("g")}");
        values.Add("WHO", Environment.UserName);

        op.Create(history, values);
      }
    }
  }



  internal class UnHookEvents : Button
  {

   protected override void OnClick()
   {
      QueuedTask.Run(() =>
      {
        if (Module1.rowCreatedToken != null)
        {
          RowCreatedEvent.Unsubscribe(Module1.rowCreatedToken);
          Module1.rowCreatedToken = null;
        }
        if (Module1.rowChangedToken != null)
        {
          RowChangedEvent.Unsubscribe(Module1.rowChangedToken);
          Module1.rowChangedToken = null;
        }

        if (Module1.editCompletedToken != null)
        {
          EditCompletedEvent.Unsubscribe(Module1.editCompletedToken);
          Module1.editCompletedToken = null;
        }

        if (Module1.editCompletingToken != null)
        {
          EditCompletingEvent.Unsubscribe(Module1.editCompletingToken);
          Module1.editCompletingToken = null;
        }
      });
    }
  }
}