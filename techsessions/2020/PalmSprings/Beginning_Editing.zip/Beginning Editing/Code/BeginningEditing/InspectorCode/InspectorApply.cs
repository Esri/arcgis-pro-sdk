﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace BeginningEditing.InspectorCode
{
  internal class InspectorApply : Button
  {
    protected override void OnClick()
    {
      QueuedTask.Run(() =>
      {
        //get the selected features from the map
        var selected = MapView.Active.Map.GetSelection();
        if (selected.Count == 0)
          return;

        //read station number and place in district
        var insp = new Inspector();
        insp.Load(selected.Keys.First(), selected.Values.First().First());
        var station = insp["STATION"];
        insp["DISTRICT"] = $"Precinct {station}";
        insp.Apply();
      });
    }
  }
}