﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace BeginningEditing.EditOperationCode
{
  internal class EditOperationBasic : Button
  {
    protected override void OnClick()
    {
      //find the fire and precinct layer
      var fireLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(l => l.Name == "Fire Stations").FirstOrDefault();
      var precinctLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(l => l.Name == "Portland Precincts").FirstOrDefault();

      //create a fire station and buffer
      QueuedTask.Run(() =>
      {
        //create edit operation
        var editOp = new EditOperation();
        editOp.Name = "Create a new Fire Station";

        //get the center of the map
        var centerPnt = MapView.Active.Extent.Center;

        //To use a template...
        //var template = fireLayer.GetTemplate("name_of_template);

        //create a default feature with the geometry
        editOp.Create(fireLayer, centerPnt);

        //create a buffer
        editOp.Create(precinctLayer, GeometryEngine.Instance.Buffer(centerPnt, 10000));
        editOp.SelectModifiedFeatures = true;

        //Execute the operations
        editOp.Execute();
      });
    }
  }
}
