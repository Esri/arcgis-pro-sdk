﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace BeginningEditing.EditOperationCode
{
  internal class EditOperationChained : Button
  {
    protected override void OnClick()
    {
      var fireLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(l => l.Name == "Fire Stations").FirstOrDefault();

      //Create a feature and add an attachment
      QueuedTask.Run(() => {
        var editOp = new EditOperation();
        editOp.Name = "Create a new Fire Station";
        editOp.SelectNewFeatures = true;

        //get the center of the map
        var centerPnt = MapView.Active.Extent.Center;

        //dictionary of fire station attributes
        var attribs = new Dictionary<string, object>();
        attribs["SHAPE"] = centerPnt;
        attribs["Station"] = 152;
        attribs["City"] = "PORTLAND";

        //create new record - capture oid
        long new_oid = -1;
        editOp.Create(fireLayer, attribs, oid => new_oid = oid);

        if (editOp.Execute())
        {
          //create succceeded so chain a new operation to update the table
          var history = MapView.Active.Map.FindStandaloneTables("CHANGEHISTORY").FirstOrDefault();
          if (history != null)
          {
            var chained_op = editOp.CreateChainedOperation();

            Dictionary<string, object> values = new Dictionary<string, object>();
            values.Add("TABLENAME", fireLayer.Name);
            values.Add("DESCRIPTION", $"OID: {new_oid}, {DateTime.Now.ToString("g")}");
            values.Add("WHO", "Esri");

            chained_op.Create(history, values);
            chained_op.Execute();
          }
        }
      });
    }
  }
}
