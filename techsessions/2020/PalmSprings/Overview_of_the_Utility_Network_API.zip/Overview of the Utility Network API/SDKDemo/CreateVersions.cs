﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Core.Data;

namespace SDKDemo
{
  internal class CreateVersions : Button
  {
    protected override void OnClick()
    {
      //Connect to a known FeatureService and then create a whole bunch of versions
      Geodatabase geodatabase = new Geodatabase(new ServiceConnectionProperties(new Uri("https://AMACHINE.esri.com/server/rest/services/ASERVICE/FeatureServer")));
      VersionManager versionManager = geodatabase.GetVersionManager();

      for (int i = 0; i < 1000; i++)
      {
        VersionDescription versionDescription = new VersionDescription()
        {
          AccessType = VersionAccessType.Private,
          Description = "Auto-Generated Version",
          Name = "unlab_private_" + i
        };

        versionManager.CreateVersion(versionDescription);
      }

      for (int i = 0; i < 1000; i++)
      {
        VersionDescription versionDescription = new VersionDescription()
        {
          AccessType = VersionAccessType.Public,
          Description = "Auto-Generated Version",
          Name = "unlab_public_" + i
        };

        versionManager.CreateVersion(versionDescription);
      }

      for (int i = 0; i < 1000; i++)
      {
        VersionDescription versionDescription = new VersionDescription()
        {
          AccessType = VersionAccessType.Protected,
          Description = "Auto-Generated Version",
          Name = "unlab_protected_" + i
        };

        versionManager.CreateVersion(versionDescription);
      }
    }
  }
}
