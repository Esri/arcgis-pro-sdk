﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Editing;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing.Templates;

namespace SDKDemo
{
  internal class CreateFeature_PresetTemplate : MapTool
  {
    public static UtilityNetwork utilityNetwork = null;
    public static Layer fuseLayer = null;
    public static Layer connectionPointLayer = null;
    public static Layer fuseBankLayer = null;
    public static Layer poleLayer = null;
    public static bool option1 = true;
    public static bool option2 = false;
    public static Geometry validateExtent = null;

    public CreateFeature_PresetTemplate()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return CreateAndConfigureFuseBankPresetTemplate((MapPoint)geometry);
    }

    protected Task<bool> CreateAndConfigureFuseBankBasicFeatures(MapPoint locationToCreate)
    {
      return QueuedTask.Run<bool>(() =>
      {
        SetNecessaryGlobals(ActiveMapView.Map.Layers);

        var op = new EditOperation();
        op.Name = "Create 3 Fuses inside the FuseBank and Associated them";

        //Create the location for the fuse bank, based on where the User clicked.
        //Make sure you enable the Z on the shape (the Utility Network requires 3D shapes)
        //Clicks on a Map are 2D coordinates and MapPoints.
        //Set the Z value to the real world value.
        MapPointBuilder fuseBankLocation = new MapPointBuilder(locationToCreate);
        fuseBankLocation.Y = fuseBankLocation.Y + 1;
        fuseBankLocation.HasZ = true;
        fuseBankLocation.Z = 30;

        Dictionary<string, object> fuseBankAttributes = new Dictionary<string, object>();
        fuseBankAttributes.Add("ASSETTYPE", 222);

        //Create the Fuse Bank Token by using CreateEx - this allows the associations later on.
        RowToken fuseBankToken = op.CreateEx(fuseBankLayer, fuseBankLocation.ToGeometry(), fuseBankAttributes);

        //Create the fuses at slightly offset locations, for visualization purposes.
        MapPointBuilder fuseALocation = new MapPointBuilder(locationToCreate);
        fuseALocation.HasZ = true;
        fuseALocation.X = fuseALocation.X - 0.5;
        fuseALocation.Z = 31;

        MapPointBuilder fuseBLocation = new MapPointBuilder(locationToCreate);
        fuseBLocation.HasZ = true;
        fuseBLocation.X = fuseBLocation.X - 0.25;
        fuseBLocation.Z = 30;

        MapPointBuilder fuseCLocation = new MapPointBuilder(locationToCreate);
        fuseCLocation.HasZ = true;
        fuseCLocation.X = fuseCLocation.X + 0.5;
        fuseCLocation.Z = 29;

        //Create the attributes that are needed for the fuse objects which go in the Fuse Bank
        //The AssetType = 2 is 'Expulsion' type fuse.
        //The Phases values are = 4  is 'A' phase - based on the Coded Value Domain in the Utility Network
        Dictionary<string, object> fuseAAttributes = new Dictionary<string, object>();
        fuseAAttributes.Add("ASSETTYPE", 564);
        fuseAAttributes.Add("PHASESCURRENT", 4);
        fuseAAttributes.Add("PHASESNORMAL", 4);

        //The AssetType = 2 is 'Expulsion' type fuse.
        //The Phases values are = 2  is 'B' phase - based on the Coded Value Domain in the Utility Network
        Dictionary<string, object> fuseBAttributes = new Dictionary<string, object>();
        fuseBAttributes.Add("ASSETTYPE", 564);
        fuseBAttributes.Add("PHASESCURRENT", 2);
        fuseBAttributes.Add("PHASESNORMAL", 2);

        //The AssetType = 2 is 'Expulsion' type fuse.
        //The Phases values are = 1  is 'C' phase - based on the Coded Value Domain in the Utility Network
        Dictionary<string, object> fuseCAttributes = new Dictionary<string, object>();
        fuseCAttributes.Add("ASSETTYPE", 564);
        fuseCAttributes.Add("PHASESCURRENT", 1);
        fuseCAttributes.Add("PHASESNORMAL", 1);

        //Create each of the fuse features by providing the Layer, the location of the fuse, and the attributes.
        //Create with CreateEx - because this returns a RowToken which allows up to generate associations in the 
        //    same edit operation as the features are themselves created.
        RowToken fusePhaseARowToken = op.CreateEx(fuseLayer, fuseALocation.ToGeometry(), fuseAAttributes);
        RowToken fusePhaseBRowToken = op.CreateEx(fuseLayer, fuseBLocation.ToGeometry(), fuseBAttributes);
        RowToken fusePhaseCRowToken = op.CreateEx(fuseLayer, fuseCLocation.ToGeometry(), fuseCAttributes);

        //Create the shape for the pole where the user clicked.
        MapPointBuilder poleLocation = new MapPointBuilder(locationToCreate);
        poleLocation.HasZ = true;
        poleLocation.Z = 40;

        //Create the Pole that is going to have the Fuse Bank attached to it
        Dictionary<string, object> poleAttributes = new Dictionary<string, object>();
        poleAttributes.Add("ASSETTYPE", 2);
        poleAttributes.Add("HEIGHT", 40);

        //Create the pole with CreateEx, to get the RowToken object returned.
        RowToken poleRowToken = op.CreateEx(poleLayer, poleLocation.ToGeometry(), poleAttributes);

        //Convert all of the RowToken objects into RowHandle objects. This allows a user to create Association objects.
        RowHandle poleRowHandle = new RowHandle(poleRowToken);
        RowHandle fuseBankRowHandle = new RowHandle(fuseBankToken);
        RowHandle fusePhaseARowHandle = new RowHandle(fusePhaseARowToken);
        RowHandle fusePhaseBRowHandle = new RowHandle(fusePhaseBRowToken);
        RowHandle fusePhaseCRowHandle = new RowHandle(fusePhaseCRowToken);

        //Now put the new fuses inside of the FuseBank you just created to start this all off.
        StructuralAttachmentAssociationDescription fuseBankAttached = new StructuralAttachmentAssociationDescription(poleRowHandle, fuseBankRowHandle);
        ContainmentAssociationDescription fuse1Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseARowHandle, true);
        ContainmentAssociationDescription fuse2Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseBRowHandle, true);
        ContainmentAssociationDescription fuse3Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseCRowHandle, true);

        op.Create(fuse1Containment);
        op.Create(fuse2Containment);
        op.Create(fuse3Containment);

        return op.ExecuteAsync();
      });
    }
    protected Task<bool> CreateAndConfigureFuseBankPresetTemplate(MapPoint locationToCreate)
    {
      return QueuedTask.Run<bool>(() =>
      {
        SetNecessaryGlobals(ActiveMapView.Map.Layers);

        EditOperation op = new EditOperation();
        op.Name = "Use a Preset Template to lay down the complete assembly with associations";

        //find the Present template that we are interested in creating.
        EditingTemplate fuseAssemblyWithAssociationsTemplate = ((FeatureLayer)fuseBankLayer).GetTemplate("FuseBankWith3PhaseFuses");

        //Create the features with the preset template - this creates the associations and features all at once.
        op.Create(fuseAssemblyWithAssociationsTemplate, locationToCreate);
        return op.ExecuteAsync();
      });
    }
    protected Task<bool> CreateAndConfigureFuseBankWithCoreData(MapPoint locationToCreate)
    {
      return QueuedTask.Run<bool>(() =>
      {
        //Setup all of the location objects that we are interested in.
        MapPointBuilder fuseBankLocation = new MapPointBuilder(locationToCreate);
        fuseBankLocation.HasZ = true;
        fuseBankLocation.Z = 0;

        MapPointBuilder fuseALocation = new MapPointBuilder(locationToCreate);
        fuseALocation.HasZ = true;
        fuseALocation.Y = fuseALocation.Y - 1;
        fuseALocation.Z = 0;

        MapPointBuilder fuseBLocation = new MapPointBuilder(locationToCreate);
        fuseBLocation.HasZ = true;
        fuseBLocation.Y = fuseBLocation.Y - 0.22;
        fuseBLocation.Z = 0;

        MapPointBuilder fuseCLocation = new MapPointBuilder(locationToCreate);
        fuseCLocation.HasZ = true;
        fuseCLocation.Y = fuseCLocation.Y + 1;
        fuseCLocation.Z = 0;

        //Open the Utility Network and the Network Sources where you will be creating features
        UtilityNetwork utilityNetwork = UtilityFunctions.OpenUtilityNetwork_FromGeodatabase();
        UtilityNetworkDefinition unDefinition = utilityNetwork.GetDefinition();
        NetworkSource fuseBankFeatureSource = unDefinition.GetNetworkSource("Electric Distribution Assembly");
        NetworkSource fuseFeatureSource = unDefinition.GetNetworkSource("Electric Distribution Device");

        //Find the AssetGroup and AssetType objects that are relevant to what we are creating.
        AssetGroup fuseBankAssetGroup = fuseBankFeatureSource.GetAssetGroup("FuseBank");
        AssetType fuseBankAssetType = fuseBankAssetGroup.GetAssetTypes().First(x => !x.Name.Equals("Unknown"));
        AssetGroup fuseAssetGroup = fuseFeatureSource.GetAssetGroup("Fuse");
        AssetType fuseAssetType = fuseAssetGroup.GetAssetTypes().First(x => x.Name.Equals("Expulsion"));

        //Open the FeatureClasses directly from the FeatureServer Geodatabase.
        FeatureClass fuseBankFeatureClass = ((Geodatabase)utilityNetwork.GetDatastore()).OpenDataset<FeatureClass>(fuseBankFeatureSource.Name);
        FeatureClass fuseFeatureClass = ((Geodatabase)utilityNetwork.GetDatastore()).OpenDataset<FeatureClass>(fuseFeatureSource.Name);
        Geodatabase geodatabase = fuseBankFeatureClass.GetDatastore() as Geodatabase;

        //Create a RowBuffer which stores the attributes used to create the feature in the CreateRow call.
        Subtype fuseBankSubtype = fuseBankFeatureClass.GetDefinition().GetSubtypes().First(x => x.GetCode().Equals(fuseBankAssetGroup.Code));
        RowBuffer fuseBankRowBuffer = fuseBankFeatureClass.CreateRowBuffer(fuseBankSubtype);
        fuseBankRowBuffer[(fuseBankFeatureClass.GetDefinition()).GetShapeField()] = fuseBankLocation.ToGeometry();
        fuseBankRowBuffer["ASSETTYPE"] = fuseBankAssetType.Code;

        //Create a RowBuffer which stores the attributes used to create the feature in the CreateRow call.
        Subtype fuseSubtype = fuseFeatureClass.GetDefinition().GetSubtypes().First(x => x.GetCode().Equals(fuseAssetType.Code));
        RowBuffer fuseARowBuffer = fuseFeatureClass.CreateRowBuffer(fuseSubtype);
        fuseARowBuffer[(fuseFeatureClass.GetDefinition().GetShapeField())] = fuseALocation.ToGeometry();
        fuseARowBuffer["ASSETTYPE"] = fuseAssetType.Code;
        fuseARowBuffer["PHASESNORMAL"] = 4;
        fuseARowBuffer["PHASESCURRENT"] = 4;

        //Create a RowBuffer which stores the attributes used to create the feature in the CreateRow call.
        RowBuffer fuseBRowBuffer = fuseFeatureClass.CreateRowBuffer(fuseSubtype);
        fuseBRowBuffer[(fuseFeatureClass.GetDefinition().GetShapeField())] = fuseBLocation.ToGeometry();
        fuseBRowBuffer["ASSETTYPE"] = fuseAssetType.Code;
        fuseBRowBuffer["PHASESNORMAL"] = 2;
        fuseBRowBuffer["PHASESCURRENT"] = 2;

        //Create a RowBuffer which stores the attributes used to create the feature in the CreateRow call.
        RowBuffer fuseCRowBuffer = fuseFeatureClass.CreateRowBuffer(fuseSubtype);
        fuseCRowBuffer[(fuseFeatureClass.GetDefinition().GetShapeField())] = fuseCLocation.ToGeometry();
        fuseCRowBuffer["ASSETTYPE"] = fuseAssetType.Code;
        fuseCRowBuffer["PHASESNORMAL"] = 1;
        fuseCRowBuffer["PHASESCURRENT"] = 1;

        Row fuseBankRow = null;
        Row fuseARow = null;
        Row fuseBRow = null;
        Row fuseCRow = null;
        geodatabase.ApplyEdits(() =>
        {
          //Within an ApplyEdits call, create the rows that we are working with.
          fuseBankRow = fuseBankFeatureClass.CreateRow(fuseBankRowBuffer);
          fuseARow = fuseFeatureClass.CreateRow(fuseARowBuffer);
          fuseBRow = fuseFeatureClass.CreateRow(fuseBRowBuffer);
          fuseCRow = fuseFeatureClass.CreateRow(fuseBRowBuffer);
        });

        Element fuseBankElement = utilityNetwork.CreateElement(fuseBankRow);
        Element fuseAElement = utilityNetwork.CreateElement(fuseARow);
        Element fuseBElement = utilityNetwork.CreateElement(fuseBRow);
        Element fuseCElement = utilityNetwork.CreateElement(fuseCRow);

        geodatabase.ApplyEdits(() =>
        {
          //Create the associations for everything to the actual fuse bank.
          utilityNetwork.AddContainmentAssociation(fuseBankElement, fuseAElement);
          utilityNetwork.AddContainmentAssociation(fuseBankElement, fuseBElement);
          utilityNetwork.AddContainmentAssociation(fuseBankElement, fuseCElement);
        });

        //Using seperate ApplyEdits calls will result in 2 calls to the Service, and not just 1.
        //This could be written to be more efficient if I wrapped up all calls to the service in a Single 
        //ApplyEdits call to the Geodatabase.

        return true;
      });
    }
    protected Task<bool> CreateAndConfigureFuseBankWithTemplates(MapPoint locationToCreate)
    {
      return QueuedTask.Run<bool>(() =>
      {
        SetNecessaryGlobals(ActiveMapView.Map.Layers);

        var op = new EditOperation();
        op.Name = "Create 3 Fuses inside the FuseBank and Associated them";

        //Open the Templates which are needed for all feature creation.
        var fuseBankTemplate = ((FeatureLayer)fuseBankLayer).GetTemplate("Fuse Bank");
        var fusePhaseATemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase A)");
        var fusePhaseBTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase B)");
        var fusePhaseCTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase C)");

        //Setup all of the locations, with the content slightly offset.
        MapPointBuilder fuseBankLocation = new MapPointBuilder(locationToCreate);
        fuseBankLocation.HasZ = true;
        fuseBankLocation.Z = 0;

        MapPointBuilder fuseALocation = new MapPointBuilder(locationToCreate);
        fuseALocation.HasZ = true;
        fuseALocation.X = fuseALocation.X + 5;
        fuseALocation.Z = 0;

        MapPointBuilder fuseBLocation = new MapPointBuilder(locationToCreate);
        fuseBLocation.HasZ = true;
        fuseBLocation.X = fuseBLocation.X + 8;
        fuseBLocation.Z = 0;

        MapPointBuilder fuseCLocation = new MapPointBuilder(locationToCreate);
        fuseCLocation.HasZ = true;
        fuseCLocation.X = fuseCLocation.X + 11;
        fuseCLocation.Z = 0;

        //Create all of the RowToken objects using the template and the shapes.
        RowToken fuseBankToken = op.CreateEx(fuseBankTemplate, fuseBankLocation.ToGeometry());
        RowToken fusePhaseARowToken = op.CreateEx(fusePhaseATemplate, fuseALocation.ToGeometry());
        RowToken fusePhaseBRowToken = op.CreateEx(fusePhaseBTemplate, fuseBLocation.ToGeometry());
        RowToken fusePhaseCRowToken = op.CreateEx(fusePhaseCTemplate, fuseCLocation.ToGeometry());

        //Convert all of the RowToken objects into RowHandle objects.
        RowHandle fuseBankRowHandle = new RowHandle(fuseBankToken);
        RowHandle fusePhaseARowHandle = new RowHandle(fusePhaseARowToken);
        RowHandle fusePhaseBRowHandle = new RowHandle(fusePhaseBRowToken);
        RowHandle fusePhaseCRowHandle = new RowHandle(fusePhaseCRowToken);

        //Now put the new fuses inside of the FuseBank you just created to start this all off.
        ContainmentAssociationDescription fuse1Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseARowHandle, true);
        ContainmentAssociationDescription fuse2Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseBRowHandle, true);
        ContainmentAssociationDescription fuse3Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseCRowHandle, true);

        op.Create(fuse1Containment);
        op.Create(fuse2Containment);
        op.Create(fuse3Containment);

        return op.ExecuteAsync();
      });
    }
    protected void SetNecessaryGlobals(IReadOnlyList<Layer> layers)
    {
      //Loop through all the layers, and store some of those at the global level so that editing can go.
      foreach (Layer layer in layers)
      {
        //Check that we are working with a SubtypeGroupLayer - if not, it's the Utility Network or Service Territory
        //This application will be working with Fuse Bank, Poe and Fuse - so make sure those layers are stored.
        if (layer is SubtypeGroupLayer)
        {
          SubtypeGroupLayer subtypeLayer = layer as SubtypeGroupLayer;
          //There are duplicated ASSETGROUPS (subtypes) between Transmission and Distribution Domain Networks
          //The editing app is specifically interested  in editing Distribution network classes, so make sure 
          //we are only looking at the SubtypeGroupLayer which includes Distribution in the name.
          foreach (Layer subLayer in subtypeLayer.Layers)
          {
            //When we find the Fuse layer - store it in the global variable: 'fuseLayer'
            if (subLayer.Name.Equals("Medium Voltage Fuse", StringComparison.OrdinalIgnoreCase))
            {
              fuseLayer = subLayer;
            }
            //When we find the Connection Point layer - store it in the global variable: 'connectionPointLayer'
            if (subLayer.Name.Equals("Medium Voltage Connection Point", StringComparison.OrdinalIgnoreCase))
            {
              connectionPointLayer = subLayer;
            }
            //When we find the Fuse Bank layer - store it in the global variable: 'fuseBankLayer'
            if (subLayer.Name.Equals("Medium Voltage Fuse Bank", StringComparison.OrdinalIgnoreCase))
            {
              fuseBankLayer = subLayer;
            }
          }
          if (subtypeLayer.Name.Contains("Structure"))
          {
            foreach (Layer subLayer in subtypeLayer.Layers)
            {
              //When we find the Pole layer - store it in the global variable: 'poleLayer'
              if (subLayer.Name.Equals("Pole", StringComparison.OrdinalIgnoreCase))
              {
                poleLayer = subLayer;
              }
            }
          }
        }
        else
        {
          //If we are not a Subtype Group Layer - check if the Feature Layers we are interested in are present.
          if (layer.Name.Equals("Fuse", StringComparison.OrdinalIgnoreCase))
          {
            fuseLayer = layer;
          }
          if (layer.Name.Equals("Connection Point", StringComparison.OrdinalIgnoreCase))
          {
            connectionPointLayer = layer;
          }
          if (layer.Name.Equals("Pole", StringComparison.OrdinalIgnoreCase))
          {
            poleLayer = layer;
          }
          if (layer.Name.Equals("Fuse Bank", StringComparison.OrdinalIgnoreCase))
          {
            fuseBankLayer = layer;
          }
        }
      }
    }
  }
}
