﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Editing;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing.Templates;

namespace SDKDemo
{
  internal class OneClickTracing : MapTool
  {

    public OneClickTracing()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return TraceUpstreamFromLocation(geometry);
    }

    protected Task<bool> TraceUpstreamFromLocation(Geometry geometry)
    {
      //Intersect with all the layers of the Map, to find the feature which the user clicked on.
      //Add the Selected Feature as the Trace Starting Location
      //Run the Upstream Trace from this location.
      //Convert the Results from the Trace into a selection in the map.
      //We could optionally generate graphics here, and display them on the map.
      return QueuedTask.Run<bool>(() =>
      {
        Dictionary<BasicFeatureLayer, List<long>> selectedFeatures = MapView.Active.SelectFeatures(geometry);

        UtilityNetwork utilityNetwork = UtilityFunctions.OpenUtilityNetwork_FromGeodatabase();
        TraceManager tracer = utilityNetwork.GetTraceManager();
        UpstreamTracer upstreamTracer = tracer.GetTracer<UpstreamTracer>();

        //TraceArgument traceArgument = new TraceArgument()
        return false;
      });
    }
  }
}
