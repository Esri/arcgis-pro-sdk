﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Data;
using ArcGIS.Core;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Core;
using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Editing;
using ArcGIS.Core.Events;
using ArcGIS.Desktop.Editing.Events;
using SDKDemo;

namespace SDKDemo
{
  internal class SDKDemo_DevSummit : Button
  {
    protected override void OnClick()
    {
      //Three ways to open a Utility Network. 


      //This is a method that opens the Utility Network which works in Pro and in a 'headless' CoreHost app.

      using (UtilityNetwork utilityNetwork = UtilityFunctions.OpenUtilityNetwork_FromGeodatabase())
      {
        QueuedTask.Run(() =>
        {
          String utilityNetworkName = utilityNetwork.GetName();
          DatasetType utilityNetworkDatasetType = utilityNetwork.Type;
        }).Wait();
      }

      //This is a method that opens the Utility Network using a Subtype Group Layer of a Source in the Utility Network
      using (UtilityNetwork utilityNetwork2 = UtilityFunctions.OpenUtilityNetwork_FromSubtypeLayer(MapView.Active.Map.Layers))
      {
        QueuedTask.Run(() =>
        {
          String utilityNetworkName = utilityNetwork2.GetName();
          DatasetType utilityNetworkDatasetType = utilityNetwork2.Type;
        }).Wait();
      }

      //This is a method that opens the Utility Network using the Utility Network Layer
      using (UtilityNetwork utilityNetwork3 = UtilityFunctions.OpenUtilityNetwork_FromUtilityNetworkLayer(MapView.Active.Map.Layers))
      {
        QueuedTask.Run(() =>
        {
          String utilityNetworkName = utilityNetwork3.GetName();
          DatasetType utilityNetworkDatasetType = utilityNetwork3.Type;
        }).Wait();
      }
    }
  

    public static Map FindOpenExistingMap(string mapName)
    {
      Map map = null;

      QueuedTask.Run(async () =>
      {
        Project proj = Project.Current;

        //Finding the first project item with name matches with mapName
        MapProjectItem mpi =
            proj.GetItems<MapProjectItem>()
                .FirstOrDefault(m => m.Name.Equals(mapName, StringComparison.CurrentCultureIgnoreCase));
        if (mpi != null)
        {
          map = mpi.GetMap();
          //Opening the map in a mapview
          await ProApp.Panes.CreateMapPaneAsync(map);
        }
      }).Wait();

      return map;
    }
  }
}
