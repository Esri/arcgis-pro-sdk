﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Data.UtilityNetwork.NetworkDiagrams;
using ArcGIS.Desktop.Framework.Threading.Tasks;

namespace SDKDemo
{
  internal class SecondDiagramUpdate : Button
  {
    protected override void OnClick()
    {
      QueuedTask.Run(() =>
      {
        UtilityNetwork utilityNetwork = UtilityFunctions.OpenUtilityNetwork_FromGeodatabase();
        DiagramManager diagramManager = utilityNetwork.GetDiagramManager();

        IReadOnlyList<NetworkDiagram> allDiagrams = diagramManager.GetNetworkDiagrams();
        NetworkDiagram diagramToUpdate = allDiagrams.First(x => x.Name.Contains("RMT001") && x.GetDiagramInfo().IsSystem);

        DiagramLayoutParameters thisDiagramLayout = new SmartTreeDiagramLayoutParameters();

        //Change the root flag, and apply the Radial tree - to show updating the diagram.
        diagramToUpdate.AddFlag(NetworkDiagramFlagType.RootJunction, 300);

        DiagramLayoutParameters newDiagramLayout = new SmartTreeDiagramLayoutParameters();
        diagramToUpdate.ApplyLayout(newDiagramLayout);
      }).Wait();
    }
  }
}
