﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Editing;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Geometry;

namespace SDKDemo
{
  internal class EventHanders : Button
  {
    public static UtilityNetwork utilityNetwork = null;
    public static Layer fuseLayer = null;
    public static Layer connectionPointLayer = null;
    public static Layer fuseBankLayer = null;
    public static Layer poleLayer = null;
    public static bool option1 = true;
    public static bool option2 = false;
    public static Geometry validateExtent = null;

    protected override void OnClick()
    {
      //var editComplete = EditCompletedEvent.Subscribe(OnEditComplete);
      QueuedTask.Run(() =>
      {
        var allLayers = MapView.Active.Map.Layers;
        foreach (var layer in allLayers)
        {
          if (layer is UtilityNetworkLayer)
          {
            utilityNetwork = ((UtilityNetworkLayer)layer).GetUtilityNetwork();
            continue;
          }

          var subtypeGroupLayer = layer as SubtypeGroupLayer;
          if (subtypeGroupLayer != null)
          {
            IReadOnlyList<Layer> allSubLayers = subtypeGroupLayer.GetLayersAsFlattenedList();
            SetNecessaryGlobals(allSubLayers);
            var featLayer = allSubLayers.First() as FeatureLayer;
            if (featLayer != null)
            {
              var layerTable = featLayer.GetTable();
              var rowCreateToken = RowCreatedEvent.Subscribe(OnRowEvent, layerTable);
              var rowChangeToken = RowChangedEvent.Subscribe(OnRowEvent, layerTable);
              var rowDeleteToken = RowDeletedEvent.Subscribe(OnRowEvent, layerTable);
            }
          }
        }
      }).Wait();
    }

    protected void OnEditComplete(EditCompletedEventArgs args)
    {
      QueuedTask.Run(() =>
      { utilityNetwork.ValidateNetworkTopology(validateExtent); }).Wait();
    }
    protected void OnRowEvent(RowChangedEventArgs args)
    {
      Row row = args.Row;
      switch (args.EditType)
      {
        case ArcGIS.Desktop.Editing.EditType.Create:
          //Implement the OnCreate event to create a related feature, and create an association
          Element createdFeatureElement = utilityNetwork.CreateElement(row);
          if (createdFeatureElement.AssetGroup.Name.Equals("Fuse Bank", StringComparison.OrdinalIgnoreCase))
          {
            if (option1)
            {
              var op = new EditOperation();
              op.Name = "Create 3 Fuses inside the FuseBank and Associated them";

              var fuseBankTemplate = ((FeatureLayer)fuseBankLayer).GetTemplate("Fuse Bank");

              //Geometry will be the same as the same as the container feature. (with slight moves for clarity)
              var fusePhaseATemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase A)");
              var fusePhaseBTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase B)");
              var fusePhaseCTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase C)");

              Geometry geometry = row[((FeatureClass)row.GetTable()).GetDefinition().GetShapeField()] as Geometry;
              MapPoint createMapPoint = geometry as MapPoint;
              MapPointBuilder mapPointBuilder1 = new MapPointBuilder(createMapPoint);
              mapPointBuilder1.Y = mapPointBuilder1.Y + 5;

              MapPointBuilder mapPointBuilder2 = new MapPointBuilder(createMapPoint);
              mapPointBuilder2.Y = mapPointBuilder2.Y + 8;

              MapPointBuilder mapPointBuilder3 = new MapPointBuilder(createMapPoint);
              mapPointBuilder3.Y = mapPointBuilder3.Y - 3;

              RowToken fusePhaseARowToken = op.CreateEx(fusePhaseATemplate, mapPointBuilder1.ToGeometry());
              RowToken fusePhaseBRowToken = op.CreateEx(fusePhaseBTemplate, mapPointBuilder2.ToGeometry());
              RowToken fusePhaseCRowToken = op.CreateEx(fusePhaseCTemplate, mapPointBuilder3.ToGeometry());

              QueuedTask.Run(() =>
              {
                row["ASSETTYPE"] = 2;
                row.Store();
              }).Wait();

              RowHandle fuseBankRowHandle = new RowHandle(row);
              RowHandle fusePhaseARowHandle = new RowHandle(fusePhaseARowToken);
              RowHandle fusePhaseBRowHandle = new RowHandle(fusePhaseBRowToken);
              RowHandle fusePhaseCRowHandle = new RowHandle(fusePhaseCRowToken);

              //Now put the new fuses inside of the FuseBank you just created to start this all off.
              ContainmentAssociationDescription fuse1Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseARowHandle, true);
              ContainmentAssociationDescription fuse2Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseBRowHandle, true);
              ContainmentAssociationDescription fuse3Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseCRowHandle, true);

              op.Create(fuse1Containment);
              op.Create(fuse2Containment);
              op.Create(fuse3Containment);

              op.ExecuteAsync();
            }
            if(option2)
            {
              var op = new EditOperation();
              op.Name = "Use a Preset Template to lay down the complete assembly with associations";

              var fuseAssemblyWithAssociationsTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse Assembly (with Associations)");

              Geometry geometry = row[((FeatureClass)row.GetTable()).GetDefinition().GetShapeField()] as Geometry;

              op.Create(fuseAssemblyWithAssociationsTemplate, geometry);
              op.ExecuteAsync();
            }
          }
          break;
        case ArcGIS.Desktop.Editing.EditType.Change:
          break;
        case ArcGIS.Desktop.Editing.EditType.Delete:
          break;
        default:
          //Not sure how we can get here.  What is the unknown type
          break;
      }
    }

    protected void CreateFuseBankWithContent()
    {
      //if (option1)
      //{
      //  var op = new EditOperation();
      //  op.Name = "Create 3 Fuses inside the FuseBank and Associated them";

      //  //var fuseBankTemplate = ((FeatureLayer)fuseBankLayer).GetTemplate("Fuse Bank");

      //  //Geometry will be the same as the same as the container feature. (with slight moves for clarity)
      //  var fusePhaseATemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase A)");
      //  var fusePhaseBTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase B)");
      //  var fusePhaseCTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse (phase C)");

      //  Geometry geometry = row[((FeatureClass)row.GetTable()).GetDefinition().GetShapeField()] as Geometry;
      //  MapPoint createMapPoint = geometry as MapPoint;
      //  MapPointBuilder mapPointBuilder1 = new MapPointBuilder(createMapPoint);
      //  mapPointBuilder1.Y = mapPointBuilder1.Y + 5;

      //  MapPointBuilder mapPointBuilder2 = new MapPointBuilder(createMapPoint);
      //  mapPointBuilder2.Y = mapPointBuilder2.Y + 8;

      //  MapPointBuilder mapPointBuilder3 = new MapPointBuilder(createMapPoint);
      //  mapPointBuilder3.Y = mapPointBuilder3.Y - 3;

      //  RowToken fusePhaseARowToken = op.CreateEx(fusePhaseATemplate, mapPointBuilder1.ToGeometry());
      //  RowToken fusePhaseBRowToken = op.CreateEx(fusePhaseBTemplate, mapPointBuilder2.ToGeometry());
      //  RowToken fusePhaseCRowToken = op.CreateEx(fusePhaseCTemplate, mapPointBuilder3.ToGeometry());

      //  QueuedTask.Run(() =>
      //  {
      //    row["ASSETTYPE"] = 2;
      //    row.Store();
      //  }).Wait();

      //  RowHandle fuseBankRowHandle = new RowHandle(row);
      //  RowHandle fusePhaseARowHandle = new RowHandle(fusePhaseARowToken);
      //  RowHandle fusePhaseBRowHandle = new RowHandle(fusePhaseBRowToken);
      //  RowHandle fusePhaseCRowHandle = new RowHandle(fusePhaseCRowToken);

      //  //Now put the new fuses inside of the FuseBank you just created to start this all off.
      //  ContainmentAssociationDescription fuse1Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseARowHandle, true);
      //  ContainmentAssociationDescription fuse2Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseBRowHandle, true);
      //  ContainmentAssociationDescription fuse3Containment = new ContainmentAssociationDescription(fuseBankRowHandle, fusePhaseCRowHandle, true);

      //  op.Create(fuse1Containment);
      //  op.Create(fuse2Containment);
      //  op.Create(fuse3Containment);

      //  op.ExecuteAsync();
      //}
      //if (option2)
      //{
      //  var op = new EditOperation();
      //  op.Name = "Use a Preset Template to lay down the complete assembly with associations";

      //  var fuseAssemblyWithAssociationsTemplate = ((FeatureLayer)fuseLayer).GetTemplate("Fuse Assembly (with Associations)");

      //  Geometry geometry = row[((FeatureClass)row.GetTable()).GetDefinition().GetShapeField()] as Geometry;

      //  op.Create(fuseAssemblyWithAssociationsTemplate, geometry);
      //  op.ExecuteAsync();
      //}
    }
    
    protected void CreateFuseBankContent(EditOperation editOp, FeatureClass sourceTable, Row assemblyRow)
    {
     //C Phase = 1 ,  B Phase = 2 and A Phase = 4 
      var sourceRowShape = assemblyRow[assemblyRow.FindField(sourceTable.GetDefinition().GetShapeField())];
      UtilityNetworkDefinition unDefinition = utilityNetwork.GetDefinition();
      NetworkSource fuseFeatureSource = unDefinition.GetNetworkSource("Electric Distribution Device");
      NetworkSource connectionPointSource = unDefinition.GetNetworkSource("Electric Distribution Junction");

      AssetGroup fuseAssetGroup = fuseFeatureSource.GetAssetGroup("Fuse");
      AssetType fuseAssetType = fuseAssetGroup.GetAssetTypes().First(x => !x.Name.Equals("Unknown"));
      AssetGroup connectionPointAssetGroup = connectionPointSource.GetAssetGroup("ConnectionPoint");
      AssetType connectionPointAssetType = connectionPointAssetGroup.GetAssetTypes().First(x => !x.Name.Equals("Unknown"));
      

      FeatureClass fuseFeatureClass = ((Geodatabase)utilityNetwork.GetDatastore()).OpenDataset<FeatureClass>(fuseFeatureSource.Name);
      FeatureClass connectionPointFeatureClass = ((Geodatabase)utilityNetwork.GetDatastore()).OpenDataset<FeatureClass>(connectionPointSource.Name);

      //Create a couple fuses to go inside the fuse bank.
      //Create a couple connection Points to also go inside the fuse bank

      //Create the associations for everything inside the fuse Bank

      //Create the associations for everything to the actual fuse bank.

      //Create a pole
      NetworkSource poleFeatureSource = unDefinition.GetNetworkSource("Structure Junction");
      AssetGroup poleAssetGroup = poleFeatureSource.GetAssetGroup("Pole");
      AssetType poleAssetType = poleAssetGroup.GetAssetTypes().First(x => !x.Name.Equals("Unknown"));
      //Attach the Fuse Bank to that pole.

    }
    protected void SetNecessaryGlobals(IReadOnlyList<Layer> layers)
    {
      foreach(Layer layer in layers)
      {
        if(layer.Name.Equals("Fuse", StringComparison.OrdinalIgnoreCase))
        {
          fuseLayer = layer;
        }
        if(layer.Name.Equals("Connection Point", StringComparison.OrdinalIgnoreCase))
        {
          connectionPointLayer = layer;
        }
        if(layer.Name.Equals("Pole", StringComparison.OrdinalIgnoreCase))
        {
          poleLayer = layer;
        }
        if(layer.Name.Equals("Fuse Bank", StringComparison.OrdinalIgnoreCase))
        {
          fuseBankLayer = layer;
        }
      }
    }
  }
}
