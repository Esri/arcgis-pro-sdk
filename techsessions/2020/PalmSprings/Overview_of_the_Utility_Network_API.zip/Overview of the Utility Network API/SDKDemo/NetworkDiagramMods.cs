﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Data.UtilityNetwork.NetworkDiagrams;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Core.Data.UtilityNetwork.Trace;

namespace SDKDemo
{
  internal class NetworkDiagramMods : Button
  {
    protected override void OnClick()
    {
      CreateADiagramFromAnExistingDiagram();
      CreateDiagramFromATrace();
      CreateADiagramFromAKnownFeature();
    }

    public void CreateADiagramFromAnExistingDiagram()
    {
      QueuedTask.Run(() =>
      {
        UtilityNetwork utilityNetwork = UtilityFunctions.OpenUtilityNetwork_FromGeodatabase();
        DiagramManager diagramManager = utilityNetwork.GetDiagramManager();

        //Get the Diagram Template that we are going to apply for the new Diagram
        DiagramTemplate diagramTemplate = diagramManager.GetDiagramTemplate("Basic");

        //Get all of the Network Diagrams in the system
        IReadOnlyList<NetworkDiagram> allDiagrams = diagramManager.GetNetworkDiagrams();
        foreach (NetworkDiagram diagramToFind in allDiagrams)
        {
          if (diagramToFind.Name.Contains("RMT001") && diagramToFind.GetDiagramInfo().IsSystem)
          {
            //Apply the smart Tree layout algorithm to the new diagram.
            DiagramLayoutParameters thisDiagramLayout = new SmartTreeDiagramLayoutParameters();
            diagramToFind.ApplyLayout(thisDiagramLayout);
          }
        }
      }).Wait();
    }
    public void CreateDiagramFromATrace()
    {
      QueuedTask.Run(() =>
      {
        UtilityNetwork utilityNetwork = UtilityFunctions.OpenUtilityNetwork_FromGeodatabase();
        DomainNetwork domainNetwork = utilityNetwork.GetDefinition().GetDomainNetwork("Electric");
        Tier tier = domainNetwork.GetTier("Electric Distribution");

        SubnetworkManager subnetManager = utilityNetwork.GetSubnetworkManager();
        Subnetwork subnetwork = subnetManager.GetSubnetwork("RMT003");

        TraceManager tracer = utilityNetwork.GetTraceManager();

        SubnetworkTracer subnetworkTrace = tracer.GetTracer<SubnetworkTracer>();
        TraceConfiguration traceConfiguration = tier.TraceConfiguration;
        TraceArgument traceArgument = new TraceArgument(subnetwork);
        traceArgument.Configuration = traceConfiguration;

        List<Guid> allFeatures = new List<Guid>();
        IReadOnlyList<Result> traceResults = subnetworkTrace.Trace(traceArgument);
        foreach (Result tResult in traceResults)
        {
          if (tResult is ElementResult)
          {
            ElementResult elementResult = tResult as ElementResult;
            foreach (ArcGIS.Core.Data.UtilityNetwork.Element elem in elementResult.Elements)
            {
              allFeatures.Add(elem.GlobalID);
            }
          }
        }

        DiagramManager diagramManager = utilityNetwork.GetDiagramManager();

        //Get the Diagram Template that we are going to apply for the new Diagram
        DiagramTemplate diagramTemplate = diagramManager.GetDiagramTemplate("Basic");

        NetworkDiagram newNetworkDiagram = diagramManager.CreateNetworkDiagram(diagramTemplate, allFeatures);
        newNetworkDiagram.Store("BasicDiagram_of_RMT003", NetworkDiagramAccessType.PublicAccess, "This is my Smart Tree Diagram");
      }).Wait();
    }
    public void CreateADiagramFromAKnownFeature()
    {
      QueuedTask.Run(() =>
      {
        UtilityNetwork utilityNetwork = UtilityFunctions.OpenUtilityNetwork_FromGeodatabase();
        DiagramManager diagramManager = utilityNetwork.GetDiagramManager();

        //Get the Diagram Template that we are going to apply for the new Diagram
        DiagramTemplate diagramTemplate = diagramManager.GetDiagramTemplate("CircuitBreaker_Switching");

        List<Guid> featuresForNewDiagram = new List<Guid>() { Guid.Parse("{DEAD44B0-73F8-4C7E-B40F-F12B196544F1}") };
        NetworkDiagram newDiagram = diagramManager.CreateNetworkDiagram(diagramTemplate, featuresForNewDiagram);
        newDiagram.Store("CircuitBreaker_8_Feeder", NetworkDiagramAccessType.PublicAccess, "CB");
      }).Wait();
    }
  }
}
