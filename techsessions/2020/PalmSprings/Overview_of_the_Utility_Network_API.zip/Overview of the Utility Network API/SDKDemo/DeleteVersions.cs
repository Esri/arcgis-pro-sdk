﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Core.Data;

namespace SDKDemo
{
  internal class DeleteVersions : Button
  {
    protected override void OnClick()
    {
      //Connect to a known FeatureService and then create a whole bunch of versions
      Geodatabase geodatabase = new Geodatabase(new ServiceConnectionProperties(new Uri("https://AMACHINE.esri.com/server/rest/services/ASERVICE/FeatureServer")));
      VersionManager versionManager = geodatabase.GetVersionManager();

      IReadOnlyList<ArcGIS.Core.Data.Version> allVersions = versionManager.GetVersions();
      foreach(ArcGIS.Core.Data.Version version in allVersions)
      {
        if (!version.GetName().Equals("sde.default", StringComparison.OrdinalIgnoreCase) &&
          !version.GetName().Equals("dbo.default", StringComparison.OrdinalIgnoreCase))
        {
          version.Delete();
          version.Dispose();
        }
      }
    }
  }
}
