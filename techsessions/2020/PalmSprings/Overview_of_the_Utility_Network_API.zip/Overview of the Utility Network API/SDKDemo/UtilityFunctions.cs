﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Editing.Events;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Editing;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork;

namespace SDKDemo
{
  class UtilityFunctions
  {
    public static bool versioning = false;

    public static UtilityNetwork OpenUtilityNetwork_FromGeodatabase()
    {
      UtilityNetwork utilityNetwork = null;
      QueuedTask.Run(() =>
      {
        Geodatabase geodatabase = new Geodatabase(new ServiceConnectionProperties(new Uri("https://stonecutter.esri.com/server/rest/services/Electric_Utility_Network/FeatureServer")));

        if(versioning)
        {
          VersionManager versionManager = geodatabase.GetVersionManager();
          VersionDescription versionDescription = new VersionDescription()
          {
            AccessType = VersionAccessType.Public,
            Description = "This is a child version",
            Name = "MyVersion"
          };
          ArcGIS.Core.Data.Version childVersion = versionManager.CreateVersion(versionDescription);
          Geodatabase childGeodatabase = childVersion.Connect();
        }

        IReadOnlyList<UtilityNetworkDefinition> utilityNetworkDefinitions = geodatabase.GetDefinitions<UtilityNetworkDefinition>();
        foreach (UtilityNetworkDefinition unDef in utilityNetworkDefinitions)
        {
          utilityNetwork = geodatabase.OpenDataset<UtilityNetwork>(unDef.GetName());
        }
      }).Wait();

      return utilityNetwork;
    }
    public static UtilityNetwork OpenUtilityNetwork_FromFeatureLayer(Layer layer)
    {
      UtilityNetwork utilityNetwork = null;
      FeatureLayer featureLayer = layer as FeatureLayer;
      if (featureLayer != null)
      {
        var layerTable = featureLayer.GetTable();
        Geodatabase geodatabase = null;
        QueuedTask.Run(() =>
        {
          geodatabase = layerTable.GetDatastore() as Geodatabase;
          IReadOnlyList<UtilityNetworkDefinition> utilityNetworkDefinitions = geodatabase.GetDefinitions<UtilityNetworkDefinition>();
          foreach (UtilityNetworkDefinition unDefinition in utilityNetworkDefinitions)
          {
            utilityNetwork = geodatabase.OpenDataset<UtilityNetwork>(unDefinition.GetName());
          }
        });
      }
      return utilityNetwork;
    }
    public static UtilityNetwork OpenUtilityNetwork_FromSubtypeLayer(IReadOnlyList<Layer> allLayers)
    {
      foreach (var layer in allLayers)
      {
        if (layer is UtilityNetworkLayer)
        {
          continue;
        }

        var subtypeGroupLayer = layer as SubtypeGroupLayer;
        if (subtypeGroupLayer != null)
        {
          var featLayer = subtypeGroupLayer.GetLayersAsFlattenedList().First() as FeatureLayer;
          if (featLayer != null)
          {
            Table layerTable = null;
            UtilityNetwork utilityNetwork = null;
            QueuedTask.Run(() =>
            {
              layerTable = featLayer.GetTable();

              if (layerTable.IsControllerDatasetSupported())
              {
                IReadOnlyList<Dataset> controllerDatasets = layerTable.GetControllerDatasets();
                foreach (Dataset controller in controllerDatasets)
                {
                  if (controller is UtilityNetwork)
                  {
                    utilityNetwork = (UtilityNetwork)controller;
                  }

                }
              }
            }).Wait();
            return utilityNetwork;
          }
          else
          {
            return null;
          }

        }
      }
      return null;
    }

    public static UtilityNetwork OpenUtilityNetwork_FromUtilityNetworkLayer(IReadOnlyList<Layer> allLayers)
    {
      foreach (Layer layer in allLayers)
      {
        if (layer is UtilityNetworkLayer)
        {
          UtilityNetwork utilityNetwork = null;

          QueuedTask.Run(() =>
          {
            UtilityNetworkLayer utilityNetworkLayer = layer as UtilityNetworkLayer;
            utilityNetwork = utilityNetworkLayer.GetUtilityNetwork();
            UtilityNetworkDefinition utilityNetworkDefinition = utilityNetwork.GetDefinition();
          }).Wait();

          return utilityNetwork;
        }
      }
      return null;
    }
    public static FeatureClass OpenFeatureClass(Geodatabase geodatabase, string name)
    {
      IReadOnlyList<FeatureClassDefinition> fcDefinitions = geodatabase.GetDefinitions<FeatureClassDefinition>();
      foreach(FeatureClassDefinition fcDef in fcDefinitions)
      {
        if(fcDef.GetAliasName().Equals(name, StringComparison.OrdinalIgnoreCase))
        {
          return geodatabase.OpenDataset<FeatureClass>(fcDef.GetName());
        }
      }
      return null;
    }
  }
}
