//   Copyright 2019 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using ArcGIS.Desktop.Framework.Dialogs;

namespace CalculateStatistics
{
  internal class Dockpane1ViewModel : DockPane
  {
    private const string _dockPaneID = "ProAppModule3_Dockpane1";

    protected Dockpane1ViewModel()
    {
      BindingOperations.EnableCollectionSynchronization(Fields, _collectionLock);

      TOCSelectionChangedEvent.Subscribe(UpdateFields);
      SelectedLayer = @"Select Layer in TOC";
    }

    /// <summary>
    /// Make sure there is a feature layer selected
    /// Update the Fields Combobox with the Fields corresponding to the Layer Selected
    /// </summary>
    /// <param name="args"></param>
    private void UpdateFields(MapViewEventArgs args)
    {
      if (args.MapView == null) return;
      if (args.MapView.GetSelectedLayers().Count == 0)
      {
        SelectedLayer = @"Select Layer in TOC";
        return;
      }
      var selectedLayer = args.MapView.GetSelectedLayers()[0];
      if (!(selectedLayer is FeatureLayer))
      {
        SelectedLayer = @"Select Layer in TOC";
        return;
      }
      SelectedLayer = args.MapView.GetSelectedLayers()[0].Name;
      _featureLayer = selectedLayer as FeatureLayer;
      QueuedTask.Run(() =>
      {
        using (var table = _featureLayer.GetTable())
        {
          var newFields = new ObservableCollection<string>(table.GetDefinition().GetFields().Select(field => field.Name));
          lock (_collectionLock)
          {
            Fields.Clear();
            foreach (var field in newFields) Fields.Add(field);
          }
        }
      });
    }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      var pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      pane?.Activate();
    }

    /// <summary>
    /// Text shown near the top of the DockPane.
    /// </summary>
    private string _heading = "Calculate Statistics";

    private FeatureLayer _featureLayer;
    private ObservableCollection<string> _fields = new ObservableCollection<string>();
    private readonly object _collectionLock = new object();
    private string _selectedLayer;
    private string _selectedField;
    private string _groupbyField;
    private string _fieldValue;
    private double _resultCount = 0;
    private DataTable _resultData;
    private ICommand _cmdWork;


    /// <summary>
    /// Encapsulates Cadinality settings
    /// </summary>
    internal class StatisticsFunctionInfo
    {
        /// <summary>
        /// Description
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// StatisticsFunction
        /// </summary>
        public StatisticsFunction enumStatisticsFunction { get; set; }
    }

        public ObservableCollection<string> Fields
    {
      get { return _fields; }
      set
      {
        _fields = value;
        NotifyPropertyChanged(new PropertyChangedEventArgs("Fields"));
      }
    }
    public DataTable ResultData
    {
        get { return _resultData; }
        set
        {
            SetProperty(ref _resultData, value, () => ResultData);
        }
    }
        
    public string SelectedField
    {
      get { return _selectedField; }
      set
      {
        SetProperty(ref _selectedField, value, () => SelectedField);
      }
    }

    public string GroupByField
        {
        get { return _groupbyField; }
        set
        {
            SetProperty(ref _groupbyField, value, () => GroupByField);
        }
    }

        public string FieldValue
    {
      get { return _fieldValue; }
      set
      {
        SetProperty(ref _fieldValue, value, () => FieldValue);
      }
    }

    public string Heading
    {
      get { return _heading; }
      set
      {
        SetProperty(ref _heading, value, () => Heading);
      }
    }

    public double ResultCount
    {
      get { return _resultCount; }
      set
      {
        SetProperty(ref _resultCount, value, () => ResultCount);
      }
    }

    public string SelectedLayer
    {
      get { return _selectedLayer; }
      set
      {
        SetProperty(ref _selectedLayer, value, () => SelectedLayer);
      }
    }

    public List<StatisticsFunctionInfo> StatisticsFunctions => new List<StatisticsFunctionInfo> { new StatisticsFunctionInfo {Name = "Count", enumStatisticsFunction = StatisticsFunction.Count},
                                                                              new StatisticsFunctionInfo {Name = "Sum", enumStatisticsFunction = StatisticsFunction.Sum},
                                                                              new StatisticsFunctionInfo {Name = "Min", enumStatisticsFunction = StatisticsFunction.Min},
                                                                              new StatisticsFunctionInfo {Name = "Max", enumStatisticsFunction = StatisticsFunction.Max},
                                                                              new StatisticsFunctionInfo {Name = "Average", enumStatisticsFunction = StatisticsFunction.Average},
                                                                              new StatisticsFunctionInfo {Name = "StandardDeviation", enumStatisticsFunction = StatisticsFunction.StandardDeviation}
                                                                            };
    public StatisticsFunctionInfo SelectedFunction { get; set; }

        /// <summary>
        /// Get the selected Feature Layer and the corresponding FeatureClass
        /// If there are any features selected for that layer, Zoom to the extent and use the extent for a Spatial Query
        /// If there are no feature selected, perform Calculate Statistics on all the features for that FeatureClass
        /// List the Statistics Calculation Result in the datagrid by assigning them to ResultData property (bound to the datagrid)
        /// </summary>
    public ICommand CmdWork
    {
      get
      {
        return _cmdWork ?? (_cmdWork = new RelayCommand(() =>
        {
          try
          {
            if (MapView.Active.GetSelectedLayers().Count == 0) return;
            var selectedLayer = MapView.Active.GetSelectedLayers()[0];
            var statisticsField = GetFieldByName(SelectedField).Result;
            var groupbyField = GetFieldByName(GroupByField).Result;
            if (!(selectedLayer is FeatureLayer)) return;
            var featureLayer = selectedLayer as FeatureLayer;
            QueryFilter queryFilter = new QueryFilter();
            QueuedTask.Run(() =>
               {
                  using (FeatureClass table = featureLayer.GetFeatureClass())
                  {
                    var quote = statisticsField.FieldType == FieldType.String ? "'" : "";
                    using (var mapSelection = featureLayer.GetSelection())
                    {
                      //QueryFilter queryFilter;
                      if (mapSelection.GetCount() > 0)
                      {
                        Envelope envelope = null;
                        using (var cursor = mapSelection.Search())
                        {
                          while (cursor.MoveNext())
                          {
                            using (var feature = cursor.Current as Feature)
                            {
                              envelope = envelope == null
                                          ? feature.GetShape().Extent
                                          : envelope.Union(feature.GetShape().Extent);
                            }
                          }
                        }
                        queryFilter = new SpatialQueryFilter
                        {
                          FilterGeometry = new EnvelopeBuilder(envelope).ToGeometry(),
                          SpatialRelationship = SpatialRelationship.Contains
                        };
                      }
                      try
                      {
                        using (FeatureClassDefinition featureClassDefinition = table.GetDefinition())
                        {                            
                            // Create StatisticsDescriptions
                            StatisticsDescription statisticsDescription = new StatisticsDescription(statisticsField, new List<StatisticsFunction>() { SelectedFunction.enumStatisticsFunction});

                            // Create TableStatisticsDescription
                            TableStatisticsDescription tableStatisticsDescription = new TableStatisticsDescription(new List<StatisticsDescription>() { statisticsDescription });
                            tableStatisticsDescription.GroupBy = new List<Field>() { groupbyField };
                            
                            // Create SortDescription for Sort By field
                            ArcGIS.Core.Data.SortDescription crimeSortDescription = new ArcGIS.Core.Data.SortDescription(groupbyField);
                            crimeSortDescription.CaseSensitivity = CaseSensitivity.Insensitive;
                            crimeSortDescription.SortOrder = SortOrder.Ascending;

                            tableStatisticsDescription.OrderBy = new List<ArcGIS.Core.Data.SortDescription>() { crimeSortDescription };
                            tableStatisticsDescription.QueryFilter = queryFilter;
                            // Calculate Statistics
                            IReadOnlyList<TableStatisticsResult> statisticsResults = table.CalculateStatistics(tableStatisticsDescription);

                            // Code to process results goes here...
                            var result = new DataTable("results");
                            result.Columns.Add("GroupID", typeof(int));
                            result.Columns.Add(groupbyField.Name, typeof(string));
                            result.Columns.Add(SelectedFunction.Name + "_" + statisticsField.Name, typeof(double));
                            int subGroupCount = 0;
                            double Total = 0;
                            double statisticsResult = 0;
                            foreach (TableStatisticsResult calculateStatisticsResult in statisticsResults)
                            {
                                // Get the Region name
                                // If multiple fields had been passed into TableStatisticsDescription.GroupBy, there would be multiple values in TableStatisticsResult.GroupBy
                                var groupByValue = calculateStatisticsResult.GroupBy.First().Value;
                                // Get the statistics results for the Statistics field
                                StatisticsResult fieldStatistics = calculateStatisticsResult.StatisticsResults[0];

                                subGroupCount += 1;  
                                var rowResult = result.NewRow();
                                rowResult[0] = subGroupCount ;
                                rowResult[1] = groupByValue == null ? "Undefined" : Convert.ToString(groupByValue);
                                switch (SelectedFunction.enumStatisticsFunction)
                                {
                                    case StatisticsFunction.Count:
                                        statisticsResult = fieldStatistics.Count;
                                        break; 
                                    case StatisticsFunction.Sum:
                                        statisticsResult = fieldStatistics.Sum;
                                        break;
                                    case StatisticsFunction.Min:
                                        statisticsResult = fieldStatistics.Min;
                                        break;
                                    case StatisticsFunction.Max:
                                        statisticsResult = fieldStatistics.Max;
                                        break;
                                    case StatisticsFunction.Average:
                                        statisticsResult = fieldStatistics.Average;
                                        break;
                                    case StatisticsFunction.StandardDeviation:
                                        statisticsResult = fieldStatistics.StandardDeviation;
                                        break;
                                    default:
                                        statisticsResult = fieldStatistics.Count;
                                        break;
                                }
                                rowResult[2] = statisticsResult;
                                result.Rows.Add(rowResult);
                                
                                Total += statisticsResult;
                                
                            }
                            ResultData = result;
                            ResultCount = Total;

                        }
                    }
                      catch (Exception ex)
                      {
                        MessageBox.Show($@"Query error: {ex}");
                        ResultCount = 0;
                      }
                    }
                  }
                });
          }
          catch (Exception ex)
          {
            MessageBox.Show($@"Query error: {ex}");
            ResultCount = 0;

          }
        }, true));
      }
    }

    private static Task<Field> GetFieldByName(string fieldName)
    {
      var selectedLayer = MapView.Active.GetSelectedLayers()[0];
      var featureLayer = selectedLayer as FeatureLayer;
      return QueuedTask.Run(() =>
      {
        Field resultField = null;
        if (featureLayer != null)
        {
          using (var table = featureLayer.GetTable())
          {
            resultField = table.GetDefinition().GetFields().FirstOrDefault(field => field.Name == fieldName);
          }
        }
        return resultField;
      });
    }
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
  internal class Dockpane1_ShowButton : Button
  {
    protected override void OnClick()
    {
      Dockpane1ViewModel.Show();
    }
  }
}
