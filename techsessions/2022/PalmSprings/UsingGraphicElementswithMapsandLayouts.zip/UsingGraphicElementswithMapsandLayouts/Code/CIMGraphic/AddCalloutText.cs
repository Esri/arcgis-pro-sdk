﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMGraphic
{
  internal class AddCalloutText : Button
  {
    private List<IDisposable> _graphics = new List<IDisposable>();

    protected override void OnClick()
    {
      try
      {
        if (_graphics.Count() > 0)
        {
          // clear existing graphic
          foreach (var graphic in _graphics)
            graphic.Dispose();
          _graphics.Clear();
          return;
        }
        QueuedTask.Run(() =>
        {
          Envelope zoomExtent;

          var cityName = "Redlands";
          var geometry = Module1.GetGeometry("U.S. Cities", $@"city_name = '{cityName}'"); // USHighways, route_num = 'I10'  States, state_name = 'California'  
                  var cimGraphic = CreateCIMCalloutTextGraphic(cityName, geometry);
          var graphic = MapView.Active.AddOverlay(cimGraphic);
          _graphics.Add(graphic);
          zoomExtent = geometry.Extent;

          cityName = "Palm Springs";
          geometry = Module1.GetGeometry("U.S. Cities", $@"city_name = '{cityName}'");  
                  cimGraphic = CreateCIMCalloutTextGraphic(cityName, geometry);
          graphic = MapView.Active.AddOverlay(cimGraphic);
          _graphics.Add(graphic);
          zoomExtent = zoomExtent.Union(geometry.Extent);

          MapView.Active.ZoomTo(zoomExtent.Expand(1.5, 1.5, true), new TimeSpan(0, 0, 1));
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private static CIMTextGraphic CreateCIMCalloutTextGraphic(string text, Geometry geometry)
    {
      var textSymbolRef = SymbolFactory.Instance.ConstructTextSymbol(
          ColorFactory.Instance.BlackRGB, 10, "Tahoma", "Bold").MakeSymbolReference();

      //now set text and location for the CIMGraphic
      var textGraphic = new CIMTextGraphic
      {
        Symbol = textSymbolRef,
        Text = text,
        Shape = geometry
      };
      textGraphic.Placement = Anchor.BottomLeftCorner;

      //Create a call out
      var backgroundCalloutSymbol = new CIMBackgroundCallout();

      // set callout colors and leader line
      #region callout colors and leader line
      //colors used by bounding callout box
      CIMColor accentColor = CIMColor.CreateRGBColor(0, 255, 0);
      CIMColor backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 255, 190, 50);

      //Leader line
      //Get a line symbol
      var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
      //Create a solid fill polygon symbol for the callout.
      var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);
      //accent symbol
      var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);

      //assign the leader line to the callout
      backgroundCalloutSymbol.LeaderLineSymbol = lineSymbol;
      backgroundCalloutSymbol.LineStyle = LeaderLineStyle.Base;
      backgroundCalloutSymbol.LeaderOffset = 2;

      //Assign the polygon to the background callout
      backgroundCalloutSymbol.BackgroundSymbol = polySymbol;

      //Set margins for the callout to center the text
      backgroundCalloutSymbol.Margin = new CIMTextMargin
      {
        Left = 5,
        Right = 5,
        Top = 5,
        Bottom = 5
      };

      //define the Accent bar
      backgroundCalloutSymbol.AccentBarSymbol = accentSymbol;
      #endregion callout colors and leader line

      //change the Offset for the textbox ... move 20 right and 20 high
      var textSym = textGraphic.Symbol.Symbol as CIMTextSymbol;
      textSym.OffsetX = 20;
      textSym.OffsetY = -40;

      //assign the callout to the textSymbol
      textSym.Callout = backgroundCalloutSymbol;

      if (geometry.GeometryType == GeometryType.Point)
      {
        // create a leader point
        CIMLeaderPoint leaderPt = new CIMLeaderPoint
        {
          Point = geometry as MapPoint
        };
        // assign to the textGraphic
        textGraphic.Leaders = new List<CIMLeader>() { leaderPt }.ToArray();
      }

      return textGraphic;
    }
  }
}
