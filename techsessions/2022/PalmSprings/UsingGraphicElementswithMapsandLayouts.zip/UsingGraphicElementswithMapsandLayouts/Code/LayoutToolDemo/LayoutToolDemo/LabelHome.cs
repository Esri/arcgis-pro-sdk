﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayoutToolDemo
{
  internal class LabelHome : LayoutTool
  {
    public LabelHome()
    {
      SketchType = SketchGeometryType.Point;
    }
    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }
    protected async override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      //Create a CIMTextSymbol
      CIMTextSymbol simpleTextSymbol = await CreateSimpleTextSymbolAsync(ColorFactory.Instance.RedRGB);
      var mp = geometry as MapPoint;
      var pointToLabel = mp.Coordinate2D;
      await QueuedTask.Run(() =>
      {
        if (ActiveElementContainer.CanCreateGraphicElement())
          LayoutElementFactory.Instance.CreatePointTextGraphicElement(ActiveElementContainer, pointToLabel, "Redlands", simpleTextSymbol);
      });
      return true;
    }

    private static Task<CIMTextSymbol> CreateSimpleTextSymbolAsync(CIMColor textColor)
    {
      return QueuedTask.Run<CIMTextSymbol>(() =>
      {
        //create a text symbol
        var textSymbol = SymbolFactory.Instance.ConstructTextSymbol(textColor, 11, "Corbel", "Regular");
        return textSymbol;
      });
    }
  }
}
