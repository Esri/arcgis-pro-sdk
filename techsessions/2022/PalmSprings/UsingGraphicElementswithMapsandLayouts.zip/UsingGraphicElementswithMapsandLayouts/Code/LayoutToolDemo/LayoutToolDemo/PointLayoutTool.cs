﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayoutToolDemo
{
  internal class PointLayoutTool : LayoutTool
  {
    private CIMPointSymbol _ptSymbol;

    public PointLayoutTool()
    {
      SketchType = SketchGeometryType.Point;
    }
    protected async override Task OnToolActivateAsync(bool active)
    {
      //Get the StyleProjectItem from Pro.
      var styleProjectItem = Project.Current.GetItems<StyleProjectItem>().FirstOrDefault(s => s.Name == "ArcGIS 2D");
      await QueuedTask.Run(() => {
        //Find the Campground symbol in style project item
        var hikingSymbolStyleItem = styleProjectItem.SearchSymbols(StyleItemType.PointSymbol, "Campground").FirstOrDefault();
        if (hikingSymbolStyleItem == null) return;
        _ptSymbol = hikingSymbolStyleItem.Symbol as CIMPointSymbol;
        _ptSymbol.SetSize(18.5);
        //MapView graphics are red
        if (MapView.Active != null)
          _ptSymbol.SetColor(CIMColor.CreateRGBColor(255, 85, 0));
        //Layout graphics are blue.
        if (LayoutView.Active != null)
          _ptSymbol.SetColor(CIMColor.CreateRGBColor(0, 197, 255));
      });
      
      return;
    }
    protected async override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      if (ActiveElementContainer == null) return true;
      //Convert sketch geometry to Coordinate2D
      var coordinate2D = new Coordinate2D(geometry as MapPoint);

      await QueuedTask.Run( () => {        
        if (ActiveElementContainer.CanCreateGraphicElement())
          //Create Point graphic - Campground
          LayoutElementFactory.Instance.CreatePointGraphicElement(ActiveElementContainer, coordinate2D, _ptSymbol);
      });   
      return true;
    }    
  }
}
