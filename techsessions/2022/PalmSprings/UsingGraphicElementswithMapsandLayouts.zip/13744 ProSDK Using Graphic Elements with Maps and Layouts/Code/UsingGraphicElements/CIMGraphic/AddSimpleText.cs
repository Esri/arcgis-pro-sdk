﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMGraphic
{
  internal class AddSimpleText : Button
  {
    private List<IDisposable> _graphics = new List<IDisposable>();

    protected override void OnClick()
    {
      try
      {
        if (_graphics.Count() > 0)
        {
          // clear existing graphic
          foreach (var graphic in _graphics)
            graphic.Dispose();
          _graphics.Clear();
          return;
        }
        QueuedTask.Run(() =>
        {
          Envelope zoomExtent;

          var cityName = "Redlands";
          var geometry = Module1.GetGeometry("U.S. Cities", $@"city_name = '{cityName}'");
          var txtSymbolRef = SymbolFactory.Instance.ConstructTextSymbol(
              ColorFactory.Instance.RedRGB, 10, "Tahoma", "Bold").MakeSymbolReference();
          var cimGraphic = new CIMTextGraphic()
          {
            Symbol = txtSymbolRef,
            Shape = geometry,
            Text = cityName
          };
          var graphic = MapView.Active.AddOverlay(cimGraphic);
          _graphics.Add(graphic);
          zoomExtent = geometry.Extent;

          cityName = "Palm Springs";
          geometry = Module1.GetGeometry("U.S. Cities", $@"city_name = '{cityName}'"); // USHighways, route_num = 'I10'  States, state_name = 'California'  
                  txtSymbolRef = SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.RedRGB, 10, "Tahoma", "Bold").MakeSymbolReference();
          cimGraphic = new CIMTextGraphic()
          {
            Symbol = txtSymbolRef,
            Shape = geometry,
            Text = cityName
          };
          graphic = MapView.Active.AddOverlay(cimGraphic);
          _graphics.Add(graphic);
          zoomExtent = zoomExtent.Union(geometry.Extent);

          MapView.Active.ZoomTo(zoomExtent.Expand(1.5, 1.5, true), new TimeSpan(0, 0, 1));
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
  }
}
