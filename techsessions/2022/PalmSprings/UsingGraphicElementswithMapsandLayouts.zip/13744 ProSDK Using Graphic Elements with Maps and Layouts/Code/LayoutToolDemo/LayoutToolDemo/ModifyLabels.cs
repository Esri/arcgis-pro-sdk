﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayoutToolDemo
{
  internal class ModifyLabels : LayoutTool
  {
    public ModifyLabels()
    {
      SketchType = SketchGeometryType.Rectangle;
    }
    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }
    protected async override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      if (ActiveElementContainer == null) return true;
      //Balloon callout symbol
      var balloonTextSymbol = await CreateBalloonCalloutAsync(ColorFactory.Instance.BlackRGB);

      await QueuedTask.Run(() =>
      {
        //Select all graphics that intersect the geometry.
        ActiveElementContainer.SelectElements(geometry, SelectionCombinationMethod.New, false);
        //Get the selected elements.
        var selElems = ActiveElementContainer.GetSelectedElements();
        List<TextElement> textGraphicElements = new List<TextElement>();
        //Get only the selected text graphics.
        foreach (var elem in selElems)
        {          
          if (elem is TextElement textGraphicElement){
            textGraphicElements.Add(textGraphicElement);
          }
        }
        //Select the text graphics.
        ActiveElementContainer.SelectElements(textGraphicElements);
        //Converts the symbology for the selected text graphics
        CIMTextGraphic labelGraphic = new CIMTextGraphic();
        foreach (var textGraphicElem in textGraphicElements){
          labelGraphic.Text = textGraphicElem.TextProperties.Text;
          labelGraphic.Symbol = balloonTextSymbol.MakeSymbolReference();          
          labelGraphic.Symbol.SymbolName = "0";
          //Get leader point
          #region Leader Point
          var expandedEnv = textGraphicElem.GetBounds().Expand(2, 2, true);
          var leaderPt = MapPointBuilder.CreateMapPoint(expandedEnv.Extent.XMin, expandedEnv.Extent.YMin);
          List<CIMLeader> leaders = new List<CIMLeader>{
                new CIMLeaderPoint{Point = leaderPt}
          };
          #endregion
          labelGraphic.Leaders = leaders.ToArray();
          labelGraphic.Shape = textGraphicElem.GetBounds();
          textGraphicElem.SetGraphic(labelGraphic);
        }
      });
      return true;
    }

    private static Task<CIMTextSymbol> CreateBalloonCalloutAsync(CIMColor textColor)
    {
      return QueuedTask.Run<CIMTextSymbol>(() =>
      {
        //create a text symbol
        var textSymbol = SymbolFactory.Instance.ConstructTextSymbol(textColor, 11, "Corbel", "Regular");
        //A balloon callout
        var balloonCallout = new CIMBalloonCallout();
        //set the callout's style
        balloonCallout.BalloonStyle = BalloonCalloutStyle.RoundedRectangle;
        //Create a solid fill polygon symbol for the callout.
        var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.CreateRGBColor(255, 235, 190), SimpleFillStyle.Solid);
        //Set the callout's background to be the black polygon symbol
        balloonCallout.BackgroundSymbol = polySymbol;
        //margin inside the callout to place the text
        balloonCallout.Margin = new CIMTextMargin
        {
          Left = 5,
          Right = 5,
          Bottom = 5,
          Top = 5
        };
        //assign the callout to the text symbol's callout property
        textSymbol.Callout = balloonCallout;
        return textSymbol;
      });
    }
  }
}
