﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayoutToolDemo
{
  internal class DashLineTool : LayoutTool
  {
    public DashLineTool()
    {
      SketchType = SketchGeometryType.OpenLasso;
    }
    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }
    protected async override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      //Check if the ActiveElementContainer exists.
      if (ActiveElementContainer == null) return true;
      await QueuedTask.Run( () => {
        var lineSketched = geometry as Polyline;
        var styleProjectItem = Project.Current.GetItems<StyleProjectItem>().FirstOrDefault(s => s.Name == "ArcGIS 2D");
        var routeLineSymbol = styleProjectItem.SearchSymbols(StyleItemType.LineSymbol, "Dashed Arrow 3").FirstOrDefault();
        if (routeLineSymbol == null) return;
        var lineSymbol = routeLineSymbol.Symbol as CIMLineSymbol;
        lineSymbol.SetColor(CIMColor.CreateRGBColor(255, 85, 0));
        lineSymbol.SetSize(20);
        //Check if you can create the element in the container
        if (ActiveElementContainer.CanCreateGraphicElement()) 
          //Create 
          LayoutElementFactory.Instance.CreateLineGraphicElement(ActiveElementContainer, geometry as Polyline, lineSymbol);
      });
      return true;
    }
  }
}
