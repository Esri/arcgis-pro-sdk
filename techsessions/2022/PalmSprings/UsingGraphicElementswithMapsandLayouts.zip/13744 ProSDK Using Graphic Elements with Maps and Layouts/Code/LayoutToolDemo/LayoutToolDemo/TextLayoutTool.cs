﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayoutToolDemo
{
  internal class TextLayoutTool : LayoutTool
  {
    public TextLayoutTool()
    {
      SketchType = SketchGeometryType.Rectangle;
    }
    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }
    protected async override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      if (ActiveElementContainer == null) return true;
      //Get the graphics layer
      var graphicsLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<GraphicsLayer>().FirstOrDefault(); //USNationalParks
      //Get the national parks layer
      var nationalParksLyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name == "USNationalParks"); 
      //Create a CIMTextSymbol
      CIMTextSymbol simpleTextSymbol = await CreateSimpleTextSymbolAsync(ColorFactory.Instance.RedRGB);
      //CIMTextSymbol balloonCalloutTextSymbol = await CreateBalloonCalloutAsync(ColorFactory.Instance.RedRGB);
      var map = MapView.Active.Map;
      var sr = map.SpatialReference;
      await QueuedTask.Run(() =>
      {
        //get the features that intersect the geometry
        var features = MapView.Active.GetFeatures(geometry);
        var layerOfInterest = features.Keys.FirstOrDefault(f => f == nationalParksLyr) as FeatureLayer;
        if (layerOfInterest == null) return;// no features intersect the geometry

        var layerOIDs = features[layerOfInterest];

        string oidField; string shapeField;
        int idxField = -1;
        using (var fc = layerOfInterest.GetFeatureClass())
        {
          var def = fc.GetDefinition();
          idxField = def.FindField("PARKNAME");
          oidField = def.GetObjectIDField();
          shapeField = def.GetShapeField();
        }

        // Field was not found
        if (idxField == -1)
          return;

        //Query the layer to get the "field" values of the features
        QueryFilter qf = new QueryFilter()
        {
          ObjectIDs = layerOIDs,
          SubFields = $"{shapeField},PARKNAME,ParkEstab"
        };
        CIMTextGraphic labelGraphic = new CIMTextGraphic();
        
        using (var rc = layerOfInterest.GetFeatureClass().Search(qf))
        {
          while (rc.MoveNext())
          {
            using (var row = rc.Current)
            {
              //The park is found. Get the point to label at.
              var shape = row as Feature;
              var poly = shape.GetShape() as Polygon;
              var projectPoly = GeometryEngine.Instance.Project(poly, MapView.Active.Map.SpatialReference);
              var centroid = projectPoly.Extent.Center;
              var coordinate2D = new Coordinate2D(centroid);
              labelGraphic.Shape = poly.Extent.Center;
              labelGraphic.Placement = Anchor.BottomLeftCorner;
              //Add leaderline
              List<CIMLeader> leaders = new List<CIMLeader>
                {
                new CIMLeaderPoint{Point = poly.Extent.Center as MapPoint}
                };
              labelGraphic.Leaders = leaders.ToArray();
              //Label with the "label string"
              string date = $"{row["ParkEstab"]}".Substring(0,9);
              labelGraphic.Text = $"{date}";
              labelGraphic.Symbol = simpleTextSymbol.MakeSymbolReference();
              //Add the graphic to the graphic layer
              if (ActiveElementContainer.CanCreateGraphicElement())
                LayoutElementFactory.Instance.CreatePointTextGraphicElement(ActiveElementContainer, coordinate2D, date, simpleTextSymbol);
              //graphicsLayer.AddElement(labelGraphic);
            }
          }
        }
      });

      return true;
    }

    private static Task<CIMTextSymbol> CreateBalloonCalloutAsync(CIMColor textColor)
    {
      return QueuedTask.Run<CIMTextSymbol>(() =>
      {
        //create a text symbol
        var textSymbol = SymbolFactory.Instance.ConstructTextSymbol(textColor, 11, "Corbel", "Regular");
        //A balloon callout
        var balloonCallout = new CIMBalloonCallout();
        //set the callout's style
        balloonCallout.BalloonStyle = BalloonCalloutStyle.RoundedRectangle;
        //Create a solid fill polygon symbol for the callout.
        var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(ColorFactory.Instance.CreateRGBColor(255, 235, 190), SimpleFillStyle.Solid);
        //Set the callout's background to be the black polygon symbol
        balloonCallout.BackgroundSymbol = polySymbol;
        //margin inside the callout to place the text
        balloonCallout.Margin = new CIMTextMargin
        {
          Left = 5,
          Right = 5,
          Bottom = 5,
          Top = 5
        };
        //assign the callout to the text symbol's callout property
        textSymbol.Callout = balloonCallout;
        return textSymbol;
      });
    }

    private static Task<CIMTextSymbol> CreateSimpleTextSymbolAsync(CIMColor textColor)
    {
      return QueuedTask.Run<CIMTextSymbol>(() =>
      {
        //create a text symbol
        var textSymbol = SymbolFactory.Instance.ConstructTextSymbol(textColor, 11, "Corbel", "Regular");
        return textSymbol;
      });
    }
  }
}
