﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using System.Threading.Tasks;

using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Layouts.Events;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Core.Geometry;
using System.Media;

namespace PuzzleApp
{

    public static class Globals
    {
        public static String mf_Name = "";
        public static Int32 i_correct = 0;
        public static Int32 i_guesses = 0;
        public static bool selEvents = false;
        public static String elmType = "MF";
    }
    internal class Module1 : Module
    {
        private static Module1 _this = null;

        public static Module1 Current
        {
            get
            {
                return _this ?? (_this = (Module1)FrameworkApplication.FindModule("PuzzleApp_Module"));
            }
        }

        public static string AddinAssemblyLocation()
        {
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            return System.IO.Path.GetDirectoryName(
                              Uri.UnescapeDataString(
                                      new Uri(asm.CodeBase).LocalPath));
        }

        #region Overrides
        protected override bool Initialize()
        {
            IPlugInWrapper Create_Button = FrameworkApplication.GetPlugInWrapper("PuzzleApp_CreateGameBoard");

            IPlugInWrapper Scramble_Button = FrameworkApplication.GetPlugInWrapper("PuzzleApp_ScramblePieces");
            //Scramble_Button.Enabled = false
            IPlugInWrapper Play_Button = FrameworkApplication.GetPlugInWrapper("PuzzleApp_PlayGame");
            IPlugInWrapper New_Button = FrameworkApplication.GetPlugInWrapper("PuzzleApp_NewGame");

            base.Initialize();
            LayoutSelectionChangedEvent.Subscribe(LayoutSelectionCallBack);
            ActivateMapFrameEvent.Subscribe(ActivateMFCallBack);
            return true;

        }
        async public void ActivateMFCallBack(ActivateMapFrameEventArgs args)
        {
            if (args.IsActivated == false) 
            { 
                FrameworkApplication.ActivateTab("PuzzleApp_Tab1");
            }
        }
        async public void LayoutSelectionCallBack(LayoutSelectionChangedEventArgs args)
        {
            if (Globals.selEvents)
            {
                LayoutView layoutView = LayoutView.Active;
                Layout layout = layoutView.Layout;

                TextElement txtElm = layout.FindElement("Instructions") as TextElement;
                TextProperties txtProp = txtElm.TextProperties;

                TextElement statusText = layout.FindElement("Status") as TextElement;
                TextProperties statusProp = statusText.TextProperties;

                var selElm = args.Elements.ToList().FirstOrDefault();  // could also use layoutView.GetSelectedElements().FirstOrDefault();        

                if (Globals.elmType == "MF" && selElm is MapFrame)  //Select appropriate Map Frame
                {
                    //Play sound using relative paths to add-in Resources folder
                    string newGameWavPath = System.IO.Path.Combine(AddinAssemblyLocation(), "Resources", "qbert_jump2.wav");
                    SoundPlayer simpleSound = new SoundPlayer(newGameWavPath);
                    simpleSound.Play();

                    txtProp.Text = "<bol>Instructions:</bol> \n\n  - Select the rectangle where the map frame should be placed.";
                    await QueuedTask.Run(() => txtElm.SetTextProperties(txtProp));
                    Globals.elmType = "REC";
                    Globals.mf_Name = selElm.Name;
                    return;
                }

                if (Globals.elmType == "MF" && selElm is GraphicElement)
                {
                    System.Windows.MessageBox.Show("Hey Bonehead: will you please follow instuctions, you selected the wrong thing!");
                    return;
                }

                else if (Globals.elmType == "REC" && selElm is GraphicElement)  //Select appropriate Rectangle
                {
                    txtProp.Text = "<bol>Instructions: </bol> \n\n  - Select another map frame.";
                    await QueuedTask.Run(() => txtElm.SetTextProperties(txtProp));
                    Globals.elmType = "MF";
                    Globals.i_guesses = Globals.i_guesses + 1;
                    if (selElm.Name == "Rectangle 1" && Globals.mf_Name == "MF1")
                    {
                        MoveMF(selElm.Name);
                    }
                    else if (selElm.Name == "Rectangle 2" && Globals.mf_Name == "MF2")
                    {
                        MoveMF(selElm.Name);
                    }
                    else if (selElm.Name == "Rectangle 3" && Globals.mf_Name == "MF3")
                    {
                        MoveMF(selElm.Name);
                    }
                    else if (selElm.Name == "Rectangle 4" && Globals.mf_Name == "MF4")
                    {
                        MoveMF(selElm.Name);
                    }
                    else if (selElm.Name == "Rectangle 5" && Globals.mf_Name == "MF5")
                    {
                        MoveMF(selElm.Name);
                    }
                    else if (selElm.Name == "Rectangle 6" && Globals.mf_Name == "MF6")
                    {
                        MoveMF(selElm.Name);
                    }
                    else
                    {
                        statusProp.Text = "<bol><clr red='255'> WRONG!!! </clr></bol> <_bol> Try again. You are not very 'spatial'</_bol>";
                        await QueuedTask.Run(() => statusText.SetTextProperties(statusProp));

                        //Play sound using relative paths to add-in Resources folder
                        string newGameWavPath = System.IO.Path.Combine(AddinAssemblyLocation(), "Resources", "qbert_fall.wav");
                        SoundPlayer simpleSound = new SoundPlayer(newGameWavPath);
                        simpleSound.Play();
                    }
                    return;
                }
                if (Globals.elmType == "REC" && selElm is MapFrame)
                {
                    System.Windows.MessageBox.Show("Hey Bonehead: will you please follow instuctions, you selected the wrong thing!");
                    return;
                }
            }
        }

        async public void MoveMF(string elmName)
        {
            Globals.i_correct = Globals.i_correct + 1;

            LayoutView layoutView = LayoutView.Active;
            Layout layout = layoutView.Layout;
            if (elmName == "Rectangle 1")
            {
                MapFrame mf1 = layout.FindElement("MF1") as MapFrame;
                await QueuedTask.Run(() => mf1.SetX(4));
                await QueuedTask.Run(() => mf1.SetY(0.5));
            }
            if (elmName == "Rectangle 2")
            {
                MapFrame mf2 = layout.FindElement("MF2") as MapFrame;
                await QueuedTask.Run(() => mf2.SetX(7));
                await QueuedTask.Run(() => mf2.SetY(0.5));
            }
            if (elmName == "Rectangle 3")
            {
                MapFrame mf3 = layout.FindElement("MF3") as MapFrame;
                await QueuedTask.Run(() => mf3.SetX(10));
                await QueuedTask.Run(() => mf3.SetY(0.5));
            }
            if (elmName == "Rectangle 4")
            {
                MapFrame mf4 = layout.FindElement("MF4") as MapFrame;
                await QueuedTask.Run(() => mf4.SetX(10));
                await QueuedTask.Run(() => mf4.SetY(3.5));
            }
            if (elmName == "Rectangle 5")
            {
                MapFrame mf5 = layout.FindElement("MF5") as MapFrame;
                await QueuedTask.Run(() => mf5.SetX(7));
                await QueuedTask.Run(() => mf5.SetY(3.5));
            }
            if (elmName == "Rectangle 6")
            {
                MapFrame mf6 = layout.FindElement("MF6") as MapFrame;
                await QueuedTask.Run(() => mf6.SetX(4));
                await QueuedTask.Run(() => mf6.SetY(3.5));
            }

            TextElement statusText = layout.FindElement("Status") as TextElement;
            TextProperties statusProp = statusText.TextProperties;
            if (Globals.i_correct == 1)
            {
                statusProp.Text = "Nice job!  You got " + Globals.i_correct.ToString() + " correct out of " + Globals.i_guesses + " attempt.";

                //Play sound using relative paths to add-in Resources folder
                string newGameWavPath = System.IO.Path.Combine(AddinAssemblyLocation(), "Resources", "qbert_jump1.wav");
                SoundPlayer simpleSound = new SoundPlayer(newGameWavPath);
                simpleSound.Play();
            }
            else
            {
                statusProp.Text = "Nice job!  You got " + Globals.i_correct.ToString() + " correct out of " + Globals.i_guesses + " attempts.";

                //Play sound using relative paths to add-in Resources folder
                string newGameWavPath = System.IO.Path.Combine(AddinAssemblyLocation(), "Resources", "qbert_jump1.wav");
                SoundPlayer simpleSound = new SoundPlayer(newGameWavPath);
                simpleSound.Play();
            }
            await QueuedTask.Run(() => statusText.SetTextProperties(statusProp));

            if (Globals.i_correct == 6)  //YOU WIN
            {
                statusProp.Text = "GAME OVER!  You got " + Globals.i_correct.ToString() + " correct out of " + Globals.i_guesses + " attempts.";
                await QueuedTask.Run(() => statusText.SetTextProperties(statusProp));

                //Play sound using relative paths to add-in Resources folder
                string newGameWavPath = System.IO.Path.Combine(AddinAssemblyLocation(), "Resources", "qbert_tune2.wav");
                SoundPlayer simpleSound = new SoundPlayer(newGameWavPath);
                simpleSound.Play();

                //Turn off rectangles
                GraphicElement rec1 = layout.FindElement("Rectangle 1") as GraphicElement;
                await QueuedTask.Run(() => rec1.SetVisible(false));
                GraphicElement rec2 = layout.FindElement("Rectangle 2") as GraphicElement;
                await QueuedTask.Run(() => rec2.SetVisible(false));
                GraphicElement rec3 = layout.FindElement("Rectangle 3") as GraphicElement;
                await QueuedTask.Run(() => rec3.SetVisible(false));
                GraphicElement rec4 = layout.FindElement("Rectangle 4") as GraphicElement;
                await QueuedTask.Run(() => rec4.SetVisible(false));
                GraphicElement rec5 = layout.FindElement("Rectangle 5") as GraphicElement;
                await QueuedTask.Run(() => rec5.SetVisible(false));
                GraphicElement rec6 = layout.FindElement("Rectangle 6") as GraphicElement;
                await QueuedTask.Run(() => rec6.SetVisible(false));

                //Toggle MFs
                MapFrame mf1 = layout.FindElement("MF1") as MapFrame;
                await QueuedTask.Run(() => mf1.SetVisible(false));
                MapFrame mf2 = layout.FindElement("MF2") as MapFrame;
                await QueuedTask.Run(() => mf2.SetVisible(false));
                MapFrame mf3 = layout.FindElement("MF3") as MapFrame;
                await QueuedTask.Run(() => mf3.SetVisible(false));
                MapFrame mf4 = layout.FindElement("MF4") as MapFrame;
                await QueuedTask.Run(() => mf4.SetVisible(false));
                MapFrame mf5 = layout.FindElement("MF5") as MapFrame;
                await QueuedTask.Run(() => mf5.SetVisible(false));
                MapFrame mf6 = layout.FindElement("MF6") as MapFrame;
                await QueuedTask.Run(() => mf6.SetVisible(false));
                MapFrame mainMF = layout.FindElement("Main MF") as MapFrame;
                await QueuedTask.Run(() => mainMF.SetVisible(true));

                //Update title
                TextElement titleText = layout.FindElement("Title") as TextElement;
                TextProperties titleProp = titleText.TextProperties;
                titleProp.Text = "Not any more!";
                await QueuedTask.Run(() => titleText.SetTextProperties(titleProp));

                //New Game         
                TextElement instrText = layout.FindElement("Instructions") as TextElement;
                TextProperties instrProp = instrText.TextProperties;
                instrProp.Text = "<bol>Instructions: </bol> " +
                                  "\n\n\n\n\n\n\n\n\n - Click the 'New Game' command if you want to play again.";
                await QueuedTask.Run(() => instrText.SetTextProperties(instrProp));

                //Zoomto finished puzzle area
                Coordinate2D ll = new Coordinate2D(3, 0);
                Coordinate2D ur = new Coordinate2D(14, 7.5);

                await QueuedTask.Run(() =>
                {
                    Envelope env = EnvelopeBuilder.CreateEnvelope(ll, ur);
                    layoutView.ZoomTo(env);
                });


                //Turn off selection changed events
                Globals.selEvents = false;

            }
        }
        /// <summary>
        /// Called by Framework when ArcGIS Pro is closing
        /// </summary>
        /// <returns>False to prevent Pro from closing, otherwise True</returns>
        protected override bool CanUnload()
        {
            //TODO - add your business logic
            //return false to ~cancel~ Application close
            return true;
        }

        #endregion Overrides

    }
}
