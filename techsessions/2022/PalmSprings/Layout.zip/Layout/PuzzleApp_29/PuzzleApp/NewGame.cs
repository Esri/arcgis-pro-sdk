﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;

//added references
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Threading;
using System.Media;
using System.Threading;

namespace PuzzleApp
{
    internal class NewGame : Button
    {
        public static string AddinAssemblyLocation()
        {
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            return System.IO.Path.GetDirectoryName(Uri.UnescapeDataString(new Uri(asm.CodeBase).LocalPath));
        }
        async protected override void OnClick()
        {
            Globals.mf_Name = "";
            Globals.i_correct = 0;
            Globals.i_guesses = 0;
            Globals.selEvents = false;
            Globals.elmType = "MF";

            //Play sound using relative paths to add-in Resources folder
            string newGameWavPath = System.IO.Path.Combine(AddinAssemblyLocation(), "Resources", "qbert_prize1.wav");
            SoundPlayer simpleSound = new SoundPlayer(newGameWavPath);
            simpleSound.Play();
            Thread.Sleep(1000); //This allows the sound to complete before getting cut off from Create Game Board

            await ProApp.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                FrameworkApplication.SetCurrentToolAsync("esri_layout_selectByRectangleTool");
            }));

            // Call New Game Board command
            IPlugInWrapper wrapper = FrameworkApplication.GetPlugInWrapper("PuzzleApp_CreateGameBoard");
            var command = wrapper as ICommand;
            if ((command != null) && command.CanExecute(null))
                command.Execute(null);
        }
    }
}
