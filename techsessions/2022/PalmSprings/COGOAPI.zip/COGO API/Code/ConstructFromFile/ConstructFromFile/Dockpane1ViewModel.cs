﻿//   Copyright 2019 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Editing.Events;

namespace ConstructFromFile
{
  internal class Dockpane1ViewModel : DockPane
  {
    private const string _dockPaneID = "ConstructFromFile_Dockpane1";
    private const string _menuID = "ConstructFromFile_Dockpane1_Menu";

    private ICommand _browseCmd = null;
    private ICommand _constructCmd = null;

    protected Dockpane1ViewModel() { }

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;



      pane.Activate();
    }

    /// <summary>
    /// Text shown near the top of the DockPane.
    /// </summary>
    private string _heading = "My DockPane";

    public ICommand BrowseToFileCmd
    {
      get
      {
        if (_browseCmd == null)
          _browseCmd = new RelayCommand(() => LoadFile());
        return _browseCmd;
      }
    }

    private void LoadFile()
    {
      MessageBox.Show("Load Text from File");
    }

    private void ConstructFromText()
    {
      MessageBox.Show("Construct from Text");
    }

    public ICommand ConstructFromTextCmd
    {
      get
      {
        if (_constructCmd == null)
          _constructCmd = new RelayCommand(() => ConstructFromText());
        return _constructCmd;
      }
    }



    public string Heading
    {
      get { return _heading; }
      set
      {
        SetProperty(ref _heading, value, () => Heading);
      }
    }

    #region Burger Button

    /// <summary>
    /// Tooltip shown when hovering over the burger button.
    /// </summary>
    public string BurgerButtonTooltip
    {
      get { return "Options"; }
    }

    /// <summary>
    /// Menu shown when burger button is clicked.
    /// </summary>
    public System.Windows.Controls.ContextMenu BurgerButtonMenu
    {
      get { return FrameworkApplication.CreateContextMenu(_menuID); }
    }
    #endregion
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
	internal class Dockpane1_ShowButton : Button
  {
    protected override void OnClick()
    {
      Dockpane1ViewModel.Show();
    }
  }

  /// <summary>
  /// Button implementation for the button on the menu of the burger button.
  /// </summary>
  internal class Dockpane1_MenuButton : Button
  {
    protected override void OnClick()
    {
      _ = MessageBox.Show("Hello Burger Button World!");
    }
  }
}
