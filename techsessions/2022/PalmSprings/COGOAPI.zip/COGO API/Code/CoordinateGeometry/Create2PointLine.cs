﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoordinateGeometrySDK
{
  internal class Create2PointLine : Button
  {
    protected override void OnClick()
    {
      //Check for one selected layer
      if (MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().Count() != 1)
      {
        System.Windows.MessageBox.Show("Please select one line feature layer in the table of contents", "Construct Circular Arc");
        return;
      }

      var featLyr = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().First();

      //Run on MCT
      QueuedTask.Run(() =>
      {
        #region get polyline feature layer
        var fcDefinition = featLyr?.GetFeatureClass()?.GetDefinition();
        if (fcDefinition == null)
          return;

        if (fcDefinition.GetShapeType() != GeometryType.Polyline)
        {
          System.Windows.MessageBox.Show("Please select a line feature layer in the table of contents", "Construct Circular Arc");
          return;
        }
        #endregion

        //Example scenario. Make a straight line that has N10°E bearing, and 100 feet.
        //=====================================================
        //User Entry Values
        //=====================================================
        string QuadrantBearingDirection = "n10-00-0e";
        double dDistance = 100; //in International feet
        //=====================================================

        double dMetersPerUnit = 1;
        if (fcDefinition.GetSpatialReference().IsProjected)
          dMetersPerUnit = fcDefinition.GetSpatialReference().Unit.ConversionFactor;

        //we know the incoming value is in feet, but since we don’t know what the user’s target linear unit is
        //we first convert to metric and then use the metric converter to get the value for the target linear unit
        dDistance *= 0.3048; //first convert to metric 
        //dDistance is now in meters, so divide by meters per unit
        //to get the base distance to be stored in the Distance field
        dDistance /= dMetersPerUnit;

        #region get the ground to grid corrections
        //Get the active map view.
        var mapView = MapView.Active;
        if (mapView?.Map == null)
          return;

        var cimDefinition = mapView.Map?.GetDefinition();
        if (cimDefinition == null) return;
        var cimG2G = cimDefinition.GroundToGridCorrection;

        //These extension methods automatically check if ground to grid is active, etc.
        double dG2G_ScaleFactor = cimG2G.GetConstantScaleFactor();
        double dG2G_DirectionOffsetCorrection = cimG2G.GetDirectionOffset() * Math.PI / 180;
        //this property is in decimal degrees. Converted to radians for use in circular arc creation
        #endregion

        double dDirection = QuadrantBearingDMSToPolarRadians(QuadrantBearingDirection);
        //using DirectionUnitFormatConversion class

        //Now apply the ground to grid corrections
        double dGridDistance = dDistance * dG2G_ScaleFactor;
        double dGridDirection = dDirection + dG2G_DirectionOffsetCorrection;

        var MyStartPoint = MapView.Active.Extent.Center.Coordinate2D; //using the center of the map as a starting point
        if (MyStartPoint.IsEmpty)
          return;

        double vecDirn = PolarRadiansToNorthAzimuthRadians(dGridDirection); //vector constructor uses NorthAzimuth radians

        Coordinate3D pVec1 = new Coordinate3D(MyStartPoint.X, MyStartPoint.Y, 0);
        Coordinate3D pVec2 = new Coordinate3D();
        pVec2.SetPolarComponents(vecDirn, 0, dGridDistance);
        Coordinate2D MyEndPoint = new Coordinate2D(pVec1.AddCoordinate3D(pVec2));
        var MyLine = LineBuilder.CreateLineSegment(MyStartPoint, MyEndPoint);

        //Create the line geometry
        var newPolyline = PolylineBuilder.CreatePolyline(MyLine);

        Dictionary<string, object> MyCOGOAttributes = new Dictionary<string, object>();
        MyCOGOAttributes.Add(fcDefinition.GetShapeField(), newPolyline);

        //check to make sure line is COGO enabled
        if (fcDefinition.IsCOGOEnabled())
        {
          //storing the entered direction in northazimuth decimal degrees
          MyCOGOAttributes.Add("Direction", PolarRadiansToNorthAzimuthDecimalDegrees(dDirection));
          MyCOGOAttributes.Add("Distance", dDistance);
        }

        var op = new EditOperation
        {
          Name = "Construct Line",
          SelectNewFeatures = true
        };
        op.Create(featLyr, MyCOGOAttributes);
        op.Execute();
      });
    }

    private double PolarRadiansToNorthAzimuthDecimalDegrees(double InPolarRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InPolarRadians, ConvDef);
    }

    private double PolarRadiansToNorthAzimuthRadians(double InPolarRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };
      return AngConv.ConvertToDouble(InPolarRadians, ConvDef);
    }

    private double QuadrantBearingDMSToPolarRadians(string InQuadBearingDMS)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.QuadrantBearing,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.DegreesMinutesSeconds,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.Radians
      };
      return AngConv.ConvertToDouble(InQuadBearingDMS, ConvDef);
    }

  }
}
