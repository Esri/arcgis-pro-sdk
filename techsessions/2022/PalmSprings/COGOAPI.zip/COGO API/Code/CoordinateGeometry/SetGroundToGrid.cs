﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

//NOTE:this code does not use the helper extension methods such as: cimG2G.GetDirectionOffset();
//the helper extension methods are best used when READING the settings to avoid having to test for IsEnabled, && UseScale && etc.
//the helper extension methods simplify the code and tests for those for you internally.

namespace CoordinateGeometrySDK
{
  internal class SetGroundToGrid : Button
  {
    protected override async void OnClick()
    {
      //=====================================================
      //User Entry Values
      //=====================================================
      double dDirectionOffsetCorrection = -1.9862107;
      //always stored in decimal degrees, irrespective of project unit settings

      double dScaleFactor = 1;
      //=====================================================

      //Get the active map view.
      var mapView = MapView.Active;
      if (mapView?.Map == null)
        return;

      var cimG2G = await mapView.Map.GetGroundToGridCorrection();

      if (cimG2G == null)
        cimG2G = new CIMGroundToGridCorrection(); 
      // CIM for ground to grid is null for new maps, so initialize it for the first time here.

      //setting the G2G corrections properties, and storing in the CIM
      cimG2G.Enabled = true; //turn on overall ground to grid (main button toggle in Editor ribbon tab)
      cimG2G.UseDirection = true; //turn on Direction Offset (check box on corrections dialog)
      cimG2G.Direction = dDirectionOffsetCorrection; //Direction offset value
      // stored in decimal degrees, irrespective of project unit settings

      cimG2G.UseScale = true;//turn on Distance Factor (check box on corrections dialog)
      cimG2G.ScaleType = GroundToGridScaleType.ConstantFactor; // turn on Constant Scale (radio button on corrections dialog)
      cimG2G.ConstantScaleFactor = dScaleFactor;

      await mapView.Map.SetGroundToGridCorrection(cimG2G);
    }
  }
}
