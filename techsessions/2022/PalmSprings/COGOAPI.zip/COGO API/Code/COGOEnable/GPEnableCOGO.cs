﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COGOEnable
{
  internal class GPEnableCOGO : Button
  {
    protected async override void OnClick()
    {

      string sReportResult = "";
      string errorMessage = await QueuedTask.Run(async () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a line layer in the table of contents.";

        //first get the feature layer that's selected in the table of contents
        var destLineL = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();

        var fcDefinition = destLineL.GetFeatureClass().GetDefinition();
        if (fcDefinition.GetShapeType() != GeometryType.Polyline)
          return "Please select a line layer in the table of contents.";

        bool bIsCOGOEnabled = fcDefinition.IsCOGOEnabled();

        if (bIsCOGOEnabled)
          return "This line layer is already COGO Enabled.";

        var LineFC = destLineL.GetFeatureClass();
        var pFDS = LineFC.GetFeatureDataset();
        var sPathToGDB = pFDS.GetDatastore().GetConnectionString().Replace("DATABASE=", "");
        var sPathToLineFC = Path.Combine(sPathToGDB, pFDS.GetName(), LineFC.GetName());

        try
        {
          await EnableCOGOAsync(sPathToLineFC);
          //removeLayer and re-add
          // destLineL
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "COGO Enable Line Features");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "COGO Enable Line Features");
    }

    protected async Task EnableCOGOAsync(string LineFCPath)
    {
      var progDlg = new ProgressDialog("Enable COGO for line feature class", "Cancel", 100, true);
      progDlg.Show();

      //GP Enable COGO
      GPExecuteToolFlags flags = GPExecuteToolFlags.Default | GPExecuteToolFlags.GPThread;
      var progSrc = new CancelableProgressorSource(progDlg);
      var parameters = Geoprocessing.MakeValueArray(LineFCPath); 
      await Geoprocessing.ExecuteToolAsync("management.EnableCOGO", parameters,
          null, progSrc.Progressor, flags);

      progDlg.Hide();
    }

  }
}
