﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMGraphic
{
  internal class AddSimpleLine : Button
  {
    private List<IDisposable> _graphics = new List<IDisposable>();

    protected override void OnClick()
    {
      //Creating a red line 
      try
      {
        if (_graphics.Count() > 0)
        {
          // clear existing graphic
          foreach (var graphic in _graphics)
            graphic.Dispose();
          _graphics.Clear();
          return;
        }
        QueuedTask.Run(() =>
        {
          Envelope zoomExtent;

          var highwayRoute = "I10";
          var geometry = Module1.GetGeometry("USHighways", $@"route_num = '{highwayRoute}'");
          var lineSymbolRef = SymbolFactory.Instance.ConstructLineSymbol(
                                ColorFactory.Instance.CreateRGBColor(255, 1, 20, 50), 4).MakeSymbolReference();
          var cimGraphic = new CIMLineGraphic()
          {
            Symbol = lineSymbolRef,
            Line = geometry as Polyline
          };
          var graphic = MapView.Active.AddOverlay(cimGraphic);
          _graphics.Add(graphic);
          zoomExtent = geometry.Extent;

          MapView.Active.ZoomTo(zoomExtent.Expand(1.5, 1.5, true), new TimeSpan(0, 0, 1));
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
  }
}
