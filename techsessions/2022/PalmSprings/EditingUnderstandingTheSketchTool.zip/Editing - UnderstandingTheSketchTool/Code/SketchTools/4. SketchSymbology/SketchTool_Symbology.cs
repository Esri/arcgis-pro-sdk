﻿//   Copyright 2022 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace SketchTools
{
  internal class SketchTool_Symbology : MapTool
  {
    public SketchTool_Symbology()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Polygon;
      SketchOutputMode = SketchOutputMode.Map;

      // set the embedded controlID
      ControlID = "SketchTools_SketchSymbology";
    }

    protected override Task OnToolActivateAsync(bool hasMapViewChanged)
    {
      if (EmbeddableControl == null)
        return base.OnToolActivateAsync(hasMapViewChanged);

      // hook the propertyChanged
      EmbeddableControl.PropertyChanged += EmbeddableControl_PropertyChanged;
      return QueuedTask.Run(() =>
      {
        // get the current set of options and set the VM properties
        var segmentOptions = this.GetSketchSegmentSymbolOptions();
        var vertexOptions = this.GetSketchVertexSymbolOptions(VertexSymbolType.RegularUnselected);

        UpdateVM(vertexOptions, segmentOptions);
      });
    }

    protected override Task OnToolDeactivateAsync(bool hasMapViewChanged)
    {
      // cleanup
      if (EmbeddableControl != null)
        EmbeddableControl.PropertyChanged -= EmbeddableControl_PropertyChanged;
      return base.OnToolDeactivateAsync(hasMapViewChanged);
    }

    private bool IsSegmentProperty(string propertyName)
    {
      return (propertyName == "PrimaryColor") ||
              (propertyName == "SecondaryColor") ||
              (propertyName == "LineWidth");
    }

    private bool IsVertexProperty(string propertyName)
    {
      return (propertyName == "Color") ||
              (propertyName == "OutlineColor") ||
              (propertyName == "OutlineWidth") ||
              (propertyName == "Size");
    }

    private async void EmbeddableControl_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
      // if updating the VM, ignore any property changes
      if (_updatingVM)
        return;

      if (IsSegmentProperty(e.PropertyName))
      {
        // get the properties from the VM
        var vm = EmbeddableControl as SketchSymbologyViewModel;
        var primary = vm.PrimaryColor;
        var secondary = vm.SecondaryColor;
        var width = vm.LineWidth;

        // update the segment symbol options
        await QueuedTask.Run(() =>
        {
          var segmentOptions = GetSketchSegmentSymbolOptions();
          segmentOptions.PrimaryColor = primary;
          segmentOptions.SecondaryColor = secondary;
          segmentOptions.Width = width;

          SetSketchSegmentSymbolOptions(segmentOptions);
        });
      }

      else if (IsVertexProperty(e.PropertyName))
      {
        // get the properties from the vm
        var vm = EmbeddableControl as SketchSymbologyViewModel;
        var color = vm.Color;
        var outlineColor = vm.OutlineColor;
        var outlineWidth = vm.OutlineWidth;
        var size = vm.Size;

        // update the vertex symbol options
        await QueuedTask.Run(() =>
        {
          var vertexOptions = GetSketchVertexSymbolOptions(VertexSymbolType.RegularUnselected);
          vertexOptions.Color = color;
          vertexOptions.OutlineColor = outlineColor;
          vertexOptions.OutlineWidth = outlineWidth;
          vertexOptions.Size = size;

          SetSketchVertexSymbolOptions(VertexSymbolType.RegularUnselected, vertexOptions);
        });
      }

      else if (e.PropertyName == "SketchSymbol")
      {
        var sym = await Module1.GetLineSymbol();
        this.SketchSymbol = sym.MakeSymbolReference();
      }
      else if (e.PropertyName == "Reset")
      {
        this.SketchSymbol = null;

        await QueuedTask.Run(() =>
        {
          // get the application options
          var segmentOptions = ApplicationOptions.EditingOptions.GetSegmentSymbolOptions();
          var vertexOptions = ApplicationOptions.EditingOptions.GetVertexSymbolOptions(VertexSymbolType.RegularUnselected);

          // update the VM
          UpdateVM(vertexOptions, segmentOptions);
        
          // reset only 1 vertex type
          SetSketchVertexSymbolOptions(VertexSymbolType.RegularUnselected, vertexOptions);
          SetSketchSegmentSymbolOptions(segmentOptions);


          // OR 

          // reset to application options
          //ResetSketchSegmentSymbolOptions();
          //ResetSketchVertexSymbolOptions();
          
          // and then update the VM

        });

        await ClearSketchAsync();
        await StartSketchAsync();
      }
    }

    private bool _updatingVM = false;

    private void UpdateVM(VertexSymbolOptions vertexOptions, SegmentSymbolOptions segmentOptions)
    {
      var vm = EmbeddableControl as SketchSymbologyViewModel;
      if (vm == null)
        return;

      _updatingVM = true;
      vm.PrimaryColor = segmentOptions.PrimaryColor;
      vm.SecondaryColor = segmentOptions.SecondaryColor;
      vm.LineWidth = segmentOptions.Width;

      vm.Color = vertexOptions.Color;
      vm.OutlineColor = vertexOptions.OutlineColor;
      vm.OutlineWidth = vertexOptions.OutlineWidth;
      vm.Size = vertexOptions.Size;
      _updatingVM = false;
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return base.OnSketchCompleteAsync(geometry);
    }
  }
}
