﻿//   Copyright 2022 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Linq;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;


namespace SketchTools
{
  internal class SketchSymbologyViewModel : EmbeddableControl
  {
    public SketchSymbologyViewModel(XElement options, bool canChangeOptions) : base(options, canChangeOptions) { }

    #region Properties

    #region Vertices

    private CIMColor _color;
    public CIMColor Color
    {
      get => _color;
      set => SetProperty(ref _color, value);
    }

    private CIMColor _outlineColor;
    public CIMColor OutlineColor
    {
      get => _outlineColor;
      set => SetProperty(ref _outlineColor, value);
    }

    private double _outlineWidth;
    public double OutlineWidth
    {
      get => _outlineWidth;
      set => SetProperty(ref _outlineWidth, value);
    }
    private double _size;
    public double Size
    {
      get => _size;
      set => SetProperty(ref _size, value);

    }
    #endregion

    #region Segment

    private CIMColor _primaryColor;
    public CIMColor PrimaryColor
    {
      get => _primaryColor;
      set => SetProperty(ref _primaryColor, value);
    }

    private CIMColor _secondaryColor;
    public CIMColor SecondaryColor
    {
      get => _secondaryColor;
      set => SetProperty(ref _secondaryColor, value);
    }

    private double _width;
    public double LineWidth
    {
      get => _width;
      set => SetProperty(ref _width, value);
    }
    #endregion

    #endregion

    private RelayCommand _resetCmd = null;
    public ICommand ResetCommand
    {
      get
      {
        if (_resetCmd == null)
          _resetCmd = new RelayCommand(OnReset);

        return _resetCmd;
      }
    }

    private void OnReset()
    {
      NotifyPropertyChanged("Reset");
    }

    private RelayCommand _setSketchSymbolCommand = null;
    public ICommand SetSketchSymbolCommand
    {
      get
      {
        if (_setSketchSymbolCommand == null)
          _setSketchSymbolCommand = new RelayCommand(SetSketchSymbol);

        return _setSketchSymbolCommand;
      }
    }

    private void SetSketchSymbol()
    {
      NotifyPropertyChanged("SketchSymbol");
    }
    
  }
}
