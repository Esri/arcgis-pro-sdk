﻿//   Copyright 2022 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SketchTools
{
  class _30_Snippets
  {
    //private void Create()
    //{
    //  Geometry geometry;
    //  var CurrentTemplate;
    //  var op = new EditOperation();

    //  long newFeatureID = -1;
    //  op.Create(CurrentTemplate, geometry, oid => newFeatureID = oid);
    //  bool result = op.Execute();

    //  var token = op.Create(CurrentTemplate, geometry);
    //  if (op.Execute())
    //    long newFeatureID = token.ObjectID.Value;
    //}

    //private void Selection()
    //{
    //  Geometry geometry;
    //  Layer layer = null;
    //  var CurrentTemplate;
    //  var op = new EditOperation();

    //  var features = MapView.Active.GetFeatures(geometry);
    //  op.Move(features, 0.2, 0.3);

    //  var dict = new Dictionary<MapMember, List<long>> ();
    //  dict.Add(layer, new List<long>() { 23, 25 });
    //  op.Move(dict, 0.2, 0.3);

    //  var featuers = SelectionSet.FromDictionary(dict);
    //  op.Move(featuers);
    //}

    //private void Transform()
    //{
    //  Layer layer = null;
    //  var op = new EditOperation();

    //  var transformMethod = new TransformByLinkLayer();
    //  transformMethod.TransformType = TransformMethodType.Affine;
    //  transformMethod.LinkLayer = linkLayer;

    //  op.Transform(layer, transformMethod);


    //  var linkLines = new List<Polyline>();
    //  // add link geometries

    //  var transformMethod = new TransformByLinkLines();
    //  transformMethod.TransformType = transformMethodType.Similarity;
    //  transformMethod.LinkLines = linkLines;

    //  op.Transform(layer, transformMethod);
    //}
  }
}
