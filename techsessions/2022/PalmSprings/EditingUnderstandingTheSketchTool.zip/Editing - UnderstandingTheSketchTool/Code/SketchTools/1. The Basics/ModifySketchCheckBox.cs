﻿using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SketchTools
{
  public class ModifySketchCheckBox : CheckBox
  {
    public ModifySketchCheckBox()
    {
      IsChecked = false;    // start unchecked
    }
    protected override void OnClick()
    {
      Module1.ModifySketch = this.IsChecked.Value;
    }
  }
}
