﻿//   Copyright 2022 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace SketchTools
{
  internal class DifferenceTool_UI : MapTool
  {
    public DifferenceTool_UI()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Polygon;
      SketchOutputMode = SketchOutputMode.Map;

      #region Custom UI
      // change the sketchType
      SketchType = SketchGeometryType.Point;
      // set the embedded control
      ControlID = "SketchTools_DifferenceToolView";
      #endregion
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      return QueuedTask.Run(() =>
      {
        // select features that intersect the geometry
        var select = MapView.Active.SelectFeatures(geometry);
        // filter for polygon features
        var poly_layers = select.Where(kvp => kvp.Key.ShapeType == esriGeometryType.esriGeometryPolygon && kvp.Key is FeatureLayer).ToList();
        if (poly_layers.Count() == 0)
          return false;

        var diffGeometry = geometry;

        #region Custom UI

        // get the buffer parameter from the embedded control
        var vm = EmbeddableControl as DifferenceToolViewModel;
        var buffer = vm.Buffer;

        // buffer the sketch geometry
        diffGeometry = GeometryEngine.Instance.Buffer(geometry, buffer);
        #endregion

        // setup the edit operation
        var editOp = new EditOperation()
        {
          Name = "Difference",
          ErrorMessage = "Difference failed"
        };

        // foreach feature
        foreach (var kvp in poly_layers)
        {
          var layer = kvp.Key;
          foreach (var oid in kvp.Value)
          {
            // load feature
            var insp = new Inspector();
            insp.Load(layer, oid);

            // make sure diffGeometry is in the correct sr
            var dffGeometry_sr = GeometryEngine.Instance.Project(diffGeometry,
                                   layer.GetSpatialReference());

            // get the shape
            var shape = insp["SHAPE"] as Geometry;
            // do the difference
            var newShape = GeometryEngine.Instance.Difference(shape, dffGeometry_sr);

            // assign the new shape
            insp["SHAPE"] = newShape;
            //call modify
            editOp.Modify(insp);
          }
        }
        return editOp.Execute();
      });
    }
  }
}
