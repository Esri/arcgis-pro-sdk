﻿//   Copyright 2022 Esri
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at

//       http://www.apache.org/licenses/LICENSE-2.0

//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace SketchTools
{
  class SketchTableConstructionTool : MapTool
  {
    public SketchTableConstructionTool()
    {
      IsSketchTool = true;
      // set the SketchType
      SketchType = SketchGeometryType.Polygon;
      SketchOutputMode = SketchOutputMode.Map;
      FireSketchEvents = true;
      UseSnapping = true;
      //Gets or sets whether the sketch is for creating a feature and should use the CurrentTemplate.
      UsesCurrentTemplate = true;
    }

    /// <summary>
    /// Called when the "Create" button is clicked. This is where we will create the edit operation and then execute it.
    /// </summary>
    /// <param name="geometry">The geometry created by the sketch - will be null because SketchType = SketchGeometryType.None</param>
    /// <returns>A Task returning a Boolean indicating if the sketch complete event was successfully handled.</returns>
    protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      if (CurrentTemplate == null)
        return Task.FromResult(false);

      if (geometry == null)
        return Task.FromResult(false);

      return QueuedTask.Run(() =>
      {
        // get the features that intersect the sketch geometry
        var features = MapView.Active.GetFeatures(geometry);

        // get the features from the crimes layer only
        var crimesLayer = features.Keys.FirstOrDefault(k => k.Name == "Crimes");
        if (crimesLayer == null)
          return false;

        var crimeOIDs = features[crimesLayer];
        if (crimeOIDs.Count == 0)
          return false;

        // set up a queryfilter to retrieve the records
        QueryFilter qf = new QueryFilter()
        {
          ObjectIDs = crimeOIDs, 
          SubFields = "Major_Offense_Type"
        };

        // initialize my dictionary
        Dictionary<string, long> offenseCounts = new Dictionary<string, long>();

        // search, and collect all the field results
        using (var rowCursor = crimesLayer.Search(qf))
        {
          while (rowCursor.MoveNext())
          {
            using (var record = rowCursor.Current)
            {
              var offenseType = record["Major_Offense_Type"].ToString();

              if (offenseCounts.ContainsKey(offenseType))
                offenseCounts[offenseType]++;
              else
                offenseCounts.Add(offenseType, 1);
            }
          }
        }

        // Create an edit operation
        var createOperation = new EditOperation();
        createOperation.Name = string.Format("Create {0}", CurrentTemplate.StandaloneTable.Name);
        createOperation.SelectNewFeatures = false;

        // create a record for each of the offenses found with the count
        foreach (var key in offenseCounts.Keys)
        {
          var values = new Dictionary<string, object>();
          values.Add("Report_Date", DateTime.Now);
          values.Add("Major_Offense_Type", key);
          values.Add("Count", offenseCounts[key]);

          // Queue row creation
          createOperation.Create(CurrentTemplate.StandaloneTable, values);
        }

        // execute
        createOperation.Execute();

        return true;
      });
    }
  }
}
