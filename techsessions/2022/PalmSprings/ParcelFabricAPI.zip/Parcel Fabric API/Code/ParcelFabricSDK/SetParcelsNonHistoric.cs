﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class SetParcelsNonHistoric : Button
  {
    protected async override void OnClick()
    {
      //Get selection from a parcel fabric type's polygon layer
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Set Parcels Non-Historic");
        return;
      }
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run(async () =>
      {
        try
        { 
          FeatureLayer destPolygonL = null;
          //test to make sure the layer is a parcel type, is historic, and has a selection
          bool bFound = false;
          var ParcelTypesEnum = await myParcelFabricLayer.GetParcelTypeNames();
          foreach (FeatureLayer mapFeatLyr in 
            MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>())
          {
            foreach (string ParcelType in ParcelTypesEnum)
            {
              var layerEnum = await myParcelFabricLayer.GetHistoricParcelPolygonLayerByTypeName(ParcelType);
              foreach (FeatureLayer flyr in layerEnum)
              {
                if (flyr == mapFeatLyr)
                {
                  bFound = mapFeatLyr.SelectionCount > 0;
                  destPolygonL = mapFeatLyr;
                  break;
                }
              }
              if (bFound) break;
            }
            if (bFound) break;
          }
          if (!bFound)
            return "Please select parcels to set as non-historic.";

          var ids = new List<long>(destPolygonL.GetSelection().GetObjectIDs());
          //can do multi layer selection but using single per code above
          var kvp00 = new KeyValuePair<MapMember, List<long>>(destPolygonL, ids);
          var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp00 };
          var editOper = new EditOperation()
          {
            Name = "Set Parcels Non-Historic",
            ProgressMessage = "Set Parcels Non-Historic...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          var peToken= editOper.SetParcelHistoryCurrent(myParcelFabricLayer, sourceFeatures);
          if (!editOper.Execute())
            return editOper.ErrorMessage;
          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetCreated)
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name + 
                " features created." + Environment.NewLine;
            }
          }
          if (FeatSetModified != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetModified)
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + 
                " features modified." + Environment.NewLine;
            }
          }
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Set Parcels Non-Historic");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Set Parcels Non-Historic");
    }
  }
}
