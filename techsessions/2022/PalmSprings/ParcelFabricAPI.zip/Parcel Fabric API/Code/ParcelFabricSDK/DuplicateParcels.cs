﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class DuplicateParcels : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Duplicate Parcels");
        return;
      }
      string sTargetParcelType = 
        Microsoft.VisualBasic.Interaction.InputBox("Target Parcel Type:", "Duplicate Parcels", "Tax");
      if (sTargetParcelType.Trim().Length == 0)
        return;

      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        try
        {
          //get the feature layer that's selected in the table of contents
          var sourceParcelTypePolygonLayer = 
            MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
          //confirm it's a parcel type layer
          string parcelPolygonType = 
            await GetParcelTypeNameFromFeatureLayer(myParcelFabricLayer, sourceParcelTypePolygonLayer, GeometryType.Polygon);
          if (String.IsNullOrEmpty(parcelPolygonType))
            return "Please select the source parcel polygon layer in the table of contents.";
          var ids = new List<long>(sourceParcelTypePolygonLayer.GetSelection().GetObjectIDs());
          if (ids.Count == 0)
            return "No selected " + parcelPolygonType + " parcels found. Please select parcels and try again.";

          var targetFeatLyrEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(sTargetParcelType);
          if (targetFeatLyrEnum.Count()== 0)
            return "No parcel type " + sTargetParcelType + " found.";

          var targetFeatLyr = targetFeatLyrEnum.FirstOrDefault();
          if (targetFeatLyr == null)
            return "";
          var kvp00 = new KeyValuePair<MapMember, List<long>>(sourceParcelTypePolygonLayer, ids);
          var sourceFeatures = new List<KeyValuePair<MapMember, List<long>>> { kvp00 };
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";
          var editOper = new EditOperation()
          {
            Name = "Duplicate Parcels",
            ProgressMessage = "Duplicate Parcels...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          var peToken = editOper.DuplicateParcels(myParcelFabricLayer, sourceFeatures, pRec, targetFeatLyr);
          if (!editOper.Execute())
            return editOper.ErrorMessage;
          var FeatSetCreated = peToken.CreatedFeatures;
          var FeatSetModified = peToken.ModifiedFeatures;
          if (FeatSetCreated != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetCreated)
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name +
                " features created." + Environment.NewLine;
            }
          }
          if (FeatSetModified != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetModified)
            {
              foreach (long oid in kvp.Value)
              {
                //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
                //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
                //ParcelAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + 
                " features modified." + Environment.NewLine;
            }
          }
         }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Duplicate Parcels");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult, "Duplicate Parcels");
    }

    private async Task<string> GetParcelTypeNameFromFeatureLayer(ParcelLayer myParcelFabricLayer, FeatureLayer featLayer, GeometryType geomType)
    {
      if (featLayer == null) //nothing to do return empty string
        return String.Empty;
      IEnumerable<string> parcelTypeNames = await myParcelFabricLayer.GetParcelTypeNames();
      foreach (string parcelTypeName in parcelTypeNames)
      {
        if (geomType == GeometryType.Polygon)
        {
          var polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;

          polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelPolygonLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
        if (geomType == GeometryType.Polyline)
        {
          var lineLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelLineLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;

          lineLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelLineLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
      }
      return String.Empty;
    }
  }
}
