﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class AddParcelFabricToMap : Button
  {
    protected async override void OnClick()
    {
//      string url = @"E:\Data\Renton_6K_2.8.gdb\Fabric\Rent6k_Points";
      string url = @"E:\Data\Renton_6K_2.8.gdb\Fabric\Rent6k";
      Uri uri = new Uri(url);
      await QueuedTask.Run(() => LayerFactory.Instance.CreateLayer(uri, MapView.Active.Map));

      //var myParcelFabricLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      //if (myParcelFabricLayer == null)
      //  MessageBox.Show("Please add a parcel fabric to the map.");

      //string parcelFabricDataset = @"E:\Data\Renton_6K_2.8.gdb\Fabric\Renton6k";
      //await QueuedTask.Run(() =>
      //{
      //  //Remove and then re-add layer
      //  //remove layer
      //  var map = MapView.Active.Map;
      //  map.RemoveLayer(myParcelFabricLayer);

      //  var fabricSourceUri = new Uri(parcelFabricDataset);
      //  //Define the Feature Layer's parameters.
      //  var layerParams = new FeatureLayerCreationParams(fabricSourceUri)
      //  {
      //    //Set visibility
      //    IsVisible = true,
      //  };
      //  var createdFabricLayer = LayerFactory.Instance.CreateLayer<ParcelLayer>(layerParams, MapView.Active.Map);
      //  //MapView.Active.ZoomTo(myParcelFabricLayer); //ZoomTo the updated extent 
      //});

    }
  }
}
