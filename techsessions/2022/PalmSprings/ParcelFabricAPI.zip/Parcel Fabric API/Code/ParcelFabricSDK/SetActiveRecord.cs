﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class SetActiveRecord : Button
  {
    protected async override void OnClick()
    {
      string sExistingRecord = Microsoft.VisualBasic.Interaction.InputBox("Record Name:", 
        "Set Active Parcel Fabric Record", "MyRecordName");
      if (string.IsNullOrEmpty(sExistingRecord))
        return;
      string errorMessage = await QueuedTask.Run( async () =>
      {
        var myParcelFabricLayer = 
          MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        //if there is no fabric in the map then bail
        if (myParcelFabricLayer == null)
          return "There is no fabric layer in the map.";
        try
        {
          bool bSuccess = await myParcelFabricLayer.SetActiveRecordAsync(sExistingRecord);
          if (!bSuccess)
            return "No record called " + sExistingRecord + " was found.";
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Set Active Parcel Record");
    }
  }
}
