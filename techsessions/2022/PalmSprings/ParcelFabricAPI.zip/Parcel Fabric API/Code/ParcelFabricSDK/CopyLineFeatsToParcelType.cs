﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Core.SystemCore;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelFabricSDK
{
  internal class CopyLineFeatsToParcelType : Button
  {
    protected async override void OnClick()
    {
      var myParcelFabricLayer = 
        MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
      if (myParcelFabricLayer == null)
      {
        MessageBox.Show("Please add a parcel fabric to the map.", "Copy Line Features To Parcel Type");
        return;
      }
      string sReportResult = "";
      string errorMessage = await QueuedTask.Run( async () =>
      {
        // check for selected layer
        if (MapView.Active.GetSelectedLayers().Count == 0)
          return "Please select a target parcel polygon layer in the table of contents.";

        //first get the feature layer that's selected in the table of contents
        var destPolygonL = MapView.Active.GetSelectedLayers().OfType<FeatureLayer>().FirstOrDefault();
        try
        {
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";
          string ParcelTypeName = await GetParcelTypeNameFromFeatureLayer(myParcelFabricLayer,
            destPolygonL, GeometryType.Polygon);
          if (String.IsNullOrEmpty(ParcelTypeName))
            return "Please select a target parcel polygon layer in the table of contents.";
          var srcFeatLyr = 
            MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(l => l.Name.Contains("Lines SP") && l.IsVisible);
          if (srcFeatLyr == null)
            return "Source layer with string Lines SP* not found in the table of contents.";
          //now get the line layer for this parcel type
          var destLineLyrEnum = await myParcelFabricLayer.GetParcelLineLayerByTypeName(ParcelTypeName);
          if (destLineLyrEnum.Count() == 0) //make sure there is one in the map
            return "No line layer found.";

          var destLineL = destLineLyrEnum.FirstOrDefault();
          if (destLineL == null || destPolygonL == null)
            return "";
          var editOper = new EditOperation()
          {
            Name = "Copy Line Features To Parcel Type",
            ProgressMessage = "Copy Line Features To Parcel Type...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };
          var ids = new List<long>((srcFeatLyr as FeatureLayer).GetSelection().GetObjectIDs());
          if (ids.Count == 0)
            return "No selected lines were found. Please select line features and try again.";
          
          ParcelEditToken peToken = editOper.CopyLineFeaturesToParcelType(srcFeatLyr, ids, 
            destLineL, destPolygonL);

          if(!editOper.Execute())
            return editOper.ErrorMessage;

          //collect ground to grid correction values
          var mapView = MapView.Active;
          if (mapView?.Map == null)
            return "";

          var pSpatRef = mapView.Map.SpatialReference;

          var cimDefinition = mapView.Map?.GetDefinition();
          if (cimDefinition == null) return "";
          var cimG2G = cimDefinition.GroundToGridCorrection;

          double dScaleFactor = cimG2G.GetConstantScaleFactor();
          double dDirectionOffsetCorrection = cimG2G.GetDirectionOffset();

          var editOper2 = editOper.CreateChainedOperation();
          var FeatSetCreated = peToken.CreatedFeatures;

          Dictionary<string, object> ParcelLineAttributes = new Dictionary<string, object>();

          if (FeatSetCreated != null)
          {
            foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetCreated)
            {
              if (kvp.Key == destPolygonL)
                continue; //skip polygons, we just want to work with the lines
              foreach (long oid in kvp.Value)
              {
                var insp = kvp.Key.Inspect(oid);
                Polyline lineGeom = (Polyline)insp["SHAPE"];

                object[] COGODirectionDistanceRadiusArcLength;

                if (!GetCOGOFromGeometry(lineGeom, pSpatRef, dScaleFactor, dDirectionOffsetCorrection, 
                  out COGODirectionDistanceRadiusArcLength))
                { 
                  editOper2.Abort();
                  return ""; 
                }
                ParcelLineAttributes.Add("Direction", COGODirectionDistanceRadiusArcLength[0]);
                ParcelLineAttributes.Add("Distance", COGODirectionDistanceRadiusArcLength[1]);
                ParcelLineAttributes.Add("Radius", COGODirectionDistanceRadiusArcLength[2]);
                ParcelLineAttributes.Add("ArcLength", COGODirectionDistanceRadiusArcLength[3]);
                ParcelLineAttributes.Add("Rotation", dDirectionOffsetCorrection);
                ParcelLineAttributes.Add("Scale", dScaleFactor);
                ParcelLineAttributes.Add("IsCOGOGround", 1);

                editOper2.Modify(kvp.Key, oid, ParcelLineAttributes);
                ParcelLineAttributes.Clear();
              }
              sReportResult += "There were " + kvp.Value.Count().ToString() + " new " + kvp.Key.Name +
                " features created." + Environment.NewLine;
              editOper2.Execute();
            }
          }
          //if (FeatSetModified != null)
          //{
          //  foreach (KeyValuePair<MapMember, List<long>> kvp in FeatSetModified)
          //  {
          //    foreach (long oid in kvp.Value)
          //    {
          //      //ParcelAttributes.Add("Name", "My" + kvp.Key.Name + " " + oid.ToString());
          //      //editOperation2.Modify(kvp.Key, oid, ParcelAttributes);
          //      //ParcelAttributes.Clear();
          //    }
          //    sReportResult += "There were " + kvp.Value.Count().ToString() + " " + kvp.Key.Name + 
          //      " features modified." + Environment.NewLine;
          //  }
          //}
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage,"Copy Line Features To Parcel Type");
      else if (!string.IsNullOrEmpty(sReportResult))
        MessageBox.Show(sReportResult,"Copy Line Features To Parcel Type");
    }
    private async Task<string> GetParcelTypeNameFromFeatureLayer(ParcelLayer myParcelFabricLayer, FeatureLayer featLayer, GeometryType geomType)
    {
      if (featLayer == null) //nothing to do return empty string
        return String.Empty;

      IEnumerable<string> parcelTypeNames = await myParcelFabricLayer.GetParcelTypeNames();
      foreach (string parcelTypeName in parcelTypeNames)
      {
        if (geomType == GeometryType.Polygon)
        {
          var polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
          polygonLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelPolygonLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in polygonLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
        if (geomType == GeometryType.Polyline)
        {
          var lineLyrParcelTypeEnum = await myParcelFabricLayer.GetParcelLineLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
          lineLyrParcelTypeEnum = await myParcelFabricLayer.GetHistoricParcelLineLayerByTypeName(parcelTypeName);
          foreach (FeatureLayer lyr in lineLyrParcelTypeEnum)
            if (lyr == featLayer)
              return parcelTypeName;
        }
      }
      return String.Empty;
    }

    private bool GetCOGOFromGeometry(Polyline myLineFeature, SpatialReference MapSR, double ScaleFactor, double DirectionOffset, out object[] COGODirectionDistanceRadiusArcLength)
    {
      COGODirectionDistanceRadiusArcLength = new object[4] { DBNull.Value,DBNull.Value,DBNull.Value, DBNull.Value };
      try
      {
        COGODirectionDistanceRadiusArcLength[0] = DBNull.Value;
        COGODirectionDistanceRadiusArcLength[1] = DBNull.Value;

        var GeomSR= myLineFeature.SpatialReference;
        if (GeomSR.IsGeographic && MapSR.IsGeographic)
          return false; //no SDK support for Geodesics till 2.8

        double UnitConversion = 1;

        if (GeomSR.IsGeographic && MapSR.IsProjected)
        { //only need to project if dataset is in a GCS.
          UnitConversion = MapSR.Unit.ConversionFactor; // Meters per unit. Only need this for converting to metric for GCS datasets.
          myLineFeature = GeometryEngine.Instance.Project(myLineFeature, MapSR) as Polyline;
        }

        EllipticArcSegment pCircArc;
        ICollection<Segment> LineSegments = new List<Segment>();
        myLineFeature.GetAllSegments(ref LineSegments);
        int numSegments = LineSegments.Count;

        IList<Segment> iList = LineSegments as IList<Segment>;
        Segment FirstSeg = iList[0];
        Segment LastSeg = iList[numSegments - 1];
        var pLine = LineBuilder.CreateLineSegment(FirstSeg.StartCoordinate, LastSeg.EndCoordinate);
        COGODirectionDistanceRadiusArcLength[0] = 
          PolarRadiansToNorthAzimuthDecimalDegrees(pLine.Angle - DirectionOffset*Math.PI/180);
        COGODirectionDistanceRadiusArcLength[1] = pLine.Length * UnitConversion / ScaleFactor;
        //check if the last segment is a circular arc
        var pCircArcLast = LastSeg as EllipticArcSegment;
        if (pCircArcLast == null)
          return true; //we already know there is no circluar arc COGO
                       //Keep a copy of the center point
        var LastCenterPoint = pCircArcLast.CenterPoint;
        COGODirectionDistanceRadiusArcLength[2] = pCircArcLast.IsCounterClockwise ?
                -pCircArcLast.SemiMajorAxis : Math.Abs(pCircArcLast.SemiMajorAxis); //radius
        double dArcLengthSUM = 0;
        //use 30 times xy tolerance for circular arc segment tangency test
        double dTangencyToleranceTest = MapSR.XYTolerance * 30; //around 3cms if using default XY Tolerance - recommended

        for (int i = 0; i < numSegments; i++)
        {
          pCircArc = iList[i] as EllipticArcSegment;
          if (pCircArc == null)
          {
            COGODirectionDistanceRadiusArcLength[2] = DBNull.Value; //radius
            COGODirectionDistanceRadiusArcLength[3] = DBNull.Value; //arc length
            return true;
          }
          var tolerance = LineBuilder.CreateLineSegment(LastCenterPoint, pCircArc.CenterPoint).Length;
          if (tolerance > dTangencyToleranceTest)
          {
            COGODirectionDistanceRadiusArcLength[2] = DBNull.Value; //radius
            COGODirectionDistanceRadiusArcLength[3] = DBNull.Value; //arc length
            return true;
          }
          dArcLengthSUM += pCircArc.Length; //arc length sum
        }
        //now check to see if the radius and arclength survived and if so, clear the distance
        if (COGODirectionDistanceRadiusArcLength[2] != DBNull.Value)
          COGODirectionDistanceRadiusArcLength[1] = DBNull.Value;

        COGODirectionDistanceRadiusArcLength[3] = dArcLengthSUM * UnitConversion / ScaleFactor;
        COGODirectionDistanceRadiusArcLength[2] = (double)COGODirectionDistanceRadiusArcLength[2] * UnitConversion / ScaleFactor;
        
        return true;
      }
      catch
      {
        return false;
      }
    }

    private static double PolarRadiansToNorthAzimuthDecimalDegrees(double InPolarRadians)
    {
      var AngConv = DirectionUnitFormatConversion.Instance;
      var ConvDef = new ConversionDefinition()
      {
        DirectionTypeIn = ArcGIS.Core.SystemCore.DirectionType.Polar,
        DirectionUnitsIn = ArcGIS.Core.SystemCore.DirectionUnits.Radians,
        DirectionTypeOut = ArcGIS.Core.SystemCore.DirectionType.NorthAzimuth,
        DirectionUnitsOut = ArcGIS.Core.SystemCore.DirectionUnits.DecimalDegrees
      };
      return AngConv.ConvertToDouble(InPolarRadians, ConvDef);
    }
  }
}
