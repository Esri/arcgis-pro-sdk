﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcelRemainder
{
  internal class CreateRemainder : Button
  {
    protected async override void OnClick()
    {
      string sTargetParcelType = "tax";
      if (sTargetParcelType.Trim().Length == 0)
        return;
      string sCookieCutterParcelType = "tax";
      if (sCookieCutterParcelType.Trim().Length == 0)
        return;
      // Note the source and target are of the same parcel type.
      // This is the convention for most record driven parcel workflows.

      //jump to the cim thread
      string errorMessage = await QueuedTask.Run(async () =>
      {
        var myParcelFabricLayer =
          MapView.Active.Map.GetLayersAsFlattenedList().OfType<ParcelLayer>().FirstOrDefault();
        if (myParcelFabricLayer == null)
          return "Please add a parcel layer to the map.";

        //first get the feature layer that's selected in the table of contents
        var featSrcLyr = myParcelFabricLayer.GetParcelPolygonLayerByTypeName(sCookieCutterParcelType).Result.FirstOrDefault();

        if (featSrcLyr.SelectionCount == 0)
          return "There is no selection on the parcel layer.";

        try
        {
          var typeNamesEnum = await myParcelFabricLayer.GetParcelPolygonLayerByTypeName(sTargetParcelType);
          if (typeNamesEnum.Count() == 0)
            return "Target parcel type " + sTargetParcelType + " not found. Please try again.";
          var featTargetLyr = typeNamesEnum.FirstOrDefault();
          var pRec = myParcelFabricLayer.GetActiveRecord();
          if (pRec == null)
            return "There is no Active Record. Please set the active record and try again.";
          var opRemainder = new EditOperation()
          {
            Name = "Remainder",
            ProgressMessage = "Creating remainder parcel...",
            ShowModalMessageAfterFailure = true,
            SelectNewFeatures = true,
            SelectModifiedFeatures = false
          };

          List<long> ids = new List<long>((featSrcLyr as FeatureLayer).GetSelection().GetObjectIDs());
          var myKVP2 = new KeyValuePair<MapMember, List<long>>(featSrcLyr, ids);
          var sourceParcels = new List<KeyValuePair<MapMember, List<long>>> { myKVP2 };

          //Build the Clip geometry and also Confirm all selected parcels belong to the active record
          var enumSel = featSrcLyr.GetSelection().GetObjectIDs().GetEnumerator();
          List<Polygon> polys = new List<Polygon>();
          while (enumSel.MoveNext())
          {
            var pFeatId = enumSel.Current;
            var insp = featSrcLyr.Inspect(pFeatId);
            Polygon poly = (Polygon)insp["SHAPE"];
            polys.Add(poly);
            string sid = (string)insp["CREATEDBYRECORD"];
            Guid guid = new Guid(sid);
            if (guid != pRec.Guid)
            {
              string sMsg = "Parcel with oid " + pFeatId + " is not in" + Environment.NewLine +
              "the active record." + Environment.NewLine + Environment.NewLine +
              "Please select parcels in the active record and try again.";
              enumSel.Dispose();
              return sMsg;
            }
          }
          //union geometry
          var ClipGeometry = GeometryEngine.Instance.Union(polys) as Polygon;

          //get the intersecting non-historic parcels of the target type that are in a different record
          SpatialQueryFilter pSpatQu = new SpatialQueryFilter();
          pSpatQu.FilterGeometry = ClipGeometry;
          pSpatQu.SpatialRelationship = SpatialRelationship.Intersects;
          pSpatQu.WhereClause = "CREATEDBYRECORD <> '{" + Convert.ToString(pRec.Guid) + "}'";
          List<long> idTargetParcel = new List<long>();
          using (RowCursor rowCursor = featTargetLyr.Search(pSpatQu))
          {
            while (rowCursor.MoveNext())
            {
              using (Row rowFeat = rowCursor.Current)
                idTargetParcel.Add(rowFeat.GetObjectID());
            }
          }

          if (idTargetParcel.Count == 0)
          {
            string sMsg = "There are no intersecting parcels from a different record." 
              + Environment.NewLine 
              + Environment.NewLine + "Please select parcels that overlap other parcels from " 
              + Environment.NewLine + "a different record and try again.";
            return sMsg;
          }
          
          opRemainder.Clip(featTargetLyr, idTargetParcel, ClipGeometry, ClipMode.DiscardArea);
          if (!opRemainder.Execute())
            return opRemainder.ErrorMessage;
        }
        catch (Exception ex)
        {
          return ex.Message;
        }
        return "";
      });
      if (!string.IsNullOrEmpty(errorMessage))
        MessageBox.Show(errorMessage, "Create remainder parcels");
      //When active record is set, the original parcel is set historic with RetiredByRecord GUID field
      //When active record is set, the new clipped remainder parcel will be tagged with the Active record.
    }
  }
}
