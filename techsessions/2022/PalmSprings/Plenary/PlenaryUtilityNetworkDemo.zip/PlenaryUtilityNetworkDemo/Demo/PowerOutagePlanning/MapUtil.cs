﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerOutagePlanning
{
  internal class MapUtil
  {
    internal enum LabelType
    {
      Workorder = 0,
      Isolation = 1,
      Switch = 2,
      Other = 3,
      Polygon = 4,
      Powerline = 5,
      ShortestPath = 6
    }

    static Dictionary<GraphicsLayer, Dictionary<LabelType, List<GraphicElement>>> GraphicElements = new Dictionary<GraphicsLayer, Dictionary<LabelType, List<GraphicElement>>>();

    internal static void ClearLabels ()
    {
      foreach (var glKey in GraphicElements.Keys)
      {
        foreach (var key in GraphicElements[glKey].Keys)
          foreach (var graphic in GraphicElements[glKey][key])
            if (graphic != null) glKey.RemoveElement(graphic);
      }
    }

    internal static void ClearLabel (LabelType labelType)
    {
      if (GraphicElements.Count > 0)
      {
        foreach (var graphicsLayer in GraphicElements.Keys)
        {
          if (GraphicElements[graphicsLayer].ContainsKey(labelType))
          {
            foreach (var graphic in GraphicElements[graphicsLayer][labelType])
            {
              graphicsLayer.RemoveElement(graphic);
            }
            GraphicElements[graphicsLayer][labelType].Clear();
          }
        }
      }
    }

    internal static UtilityNetworkLayer GetUtilityNetworkLayer()
    {
      var activeMap = MapView.Active?.Map;
      if (activeMap == null)
      {
        MessageBox.Show("Can't find an active map.  Make sure to activate a map view.");
        return null;
      }

      var utilNetworkLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<UtilityNetworkLayer>().FirstOrDefault();
      if (utilNetworkLayer == null)
      {
        MessageBox.Show("Can't find a Utility Network Layer.");
        return null;
      }
      return utilNetworkLayer;
    }

    private static CIMTextSymbol TextSymbolLarge = null;
    private static CIMTextSymbol TextSymbolSmall = null;
    private static Dictionary<LabelType, (CIMLineSymbol lineSymbol, CIMPolygonSymbol polySymbol, CIMLineSymbol accentSymbol)> CallOutSymbols = new Dictionary<LabelType, (CIMLineSymbol, CIMPolygonSymbol, CIMLineSymbol)>();

    /// <summary>
    /// Call from MCT
    /// </summary>
    /// <param name="labelType"></param>
    /// <param name="geometry"></param>
    /// <param name="label"></param>
    /// <param name="diagramLabels"></param>
    public static void ShowCalloutBox(LabelType labelType, Geometry geometry, 
                                      string label, bool diagramLabels = false)
    {
      var graphicsLayer = GetGraphicsLayer();
      if (graphicsLayer == null || geometry == null) return;

      if (TextSymbolLarge == null)
      {
        TextSymbolLarge = SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 10, "Tahoma", "Bold");
        TextSymbolSmall = SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 8, "Tahoma", "Regular");
      }

      var textSymbol = (labelType == LabelType.Other) ? TextSymbolSmall : TextSymbolLarge;
      
      var textGraphic = new CIMTextGraphic
      {
        Symbol = textSymbol.MakeSymbolReference()
      };
      textGraphic.Placement = Anchor.BottomLeftCorner;

      //Create a call out
      var backgroundCalloutSymbol = new CIMBackgroundCallout();
      var leftLabel = labelType == LabelType.Switch || (labelType == LabelType.Other && !diagramLabels);

      //change color depending on type
      CIMColor accentColor = ColorFactory.Instance.BlackRGB;
      CIMColor backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 255, 232, 50);
      switch (labelType)
      {
        case LabelType.Workorder:
          accentColor = CIMColor.CreateRGBColor(255, 0, 0);
          backgroundColor = ColorFactory.Instance.CreateRGBColor(255, 190, 190, 50);
          if (!CallOutSymbols.ContainsKey(labelType))
          {
            //Leader line
            //Get a line symbol
            var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            //Create a solid fill polygon symbol for the callout.
            var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);
            //accent symbol
            var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            CallOutSymbols.Add(labelType, (lineSymbol, polySymbol, accentSymbol));
          }
          break;
        case LabelType.Powerline:
          accentColor = CIMColor.CreateRGBColor(36, 34, 0);
          backgroundColor = ColorFactory.Instance.CreateRGBColor(236, 234, 152, 50);
          textGraphic.Placement = Anchor.TopRightCorner;
          if (!CallOutSymbols.ContainsKey(labelType))
          {
            //Leader line
            //Get a line symbol
            var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            //Create a solid fill polygon symbol for the callout.
            var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);
            //accent symbol
            var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            CallOutSymbols.Add(labelType, (lineSymbol, polySymbol, accentSymbol));
          }
          break;
        case LabelType.Isolation:
          accentColor = CIMColor.CreateRGBColor(0, 255, 0);
          backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 255, 190, 50);
          if (!CallOutSymbols.ContainsKey(labelType))
          {
            //Leader line
            //Get a line symbol
            var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            //Create a solid fill polygon symbol for the callout.
            var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);
            //accent symbol
            var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            CallOutSymbols.Add(labelType, (lineSymbol, polySymbol, accentSymbol));
          }
          break;
        case LabelType.Switch:
          accentColor = CIMColor.CreateRGBColor(0, 0, 255);
          backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 190, 255, 50);
          textGraphic.Placement = Anchor.BottomRightCorner;
          if (!CallOutSymbols.ContainsKey(labelType))
          {
            //Leader line
            //Get a line symbol
            var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            //Create a solid fill polygon symbol for the callout.
            var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);
            //accent symbol
            var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            CallOutSymbols.Add(labelType, (lineSymbol, polySymbol, accentSymbol));
          }
          break;
        case LabelType.Other:
          accentColor = CIMColor.CreateRGBColor(50, 50, 50);
          backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 190, 255, 50);
          textGraphic.Placement = diagramLabels ? Anchor.TopLeftCorner : Anchor.BottomRightCorner;
          if (!CallOutSymbols.ContainsKey(labelType))
          {
            //Leader line
            //Get a line symbol
            var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            //Create a solid fill polygon symbol for the callout.
            var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);
            //accent symbol
            var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            CallOutSymbols.Add(labelType, (lineSymbol, polySymbol, accentSymbol));
          }
          break;
        default:
          if (!CallOutSymbols.ContainsKey(labelType))
          {
            //Leader line
            //Get a line symbol
            var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            //Create a solid fill polygon symbol for the callout.
            var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);
            //accent symbol
            var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
            CallOutSymbols.Add(labelType, (lineSymbol, polySymbol, accentSymbol));
          }
          break;
      }

      //assign the line to the callout
      backgroundCalloutSymbol.LeaderLineSymbol = CallOutSymbols[labelType].lineSymbol;
      backgroundCalloutSymbol.LineStyle = LeaderLineStyle.Base;
      backgroundCalloutSymbol.LeaderOffset = 2;

      //Assign the polygon to the background callout
      backgroundCalloutSymbol.BackgroundSymbol = CallOutSymbols[labelType].polySymbol;

      //Set margins for the callout
      backgroundCalloutSymbol.Margin = new CIMTextMargin
      {
        Left = 5,
        Right = 5,
        Top = 5,
        Bottom = 5
      };

      //Accent bar
      backgroundCalloutSymbol.AccentBarSymbol = CallOutSymbols[labelType].accentSymbol;

      //Offset for the text
      var textSym = textGraphic.Symbol.Symbol as CIMTextSymbol;
      textSym.OffsetX = leftLabel ? (label.Length > 10 ? -40 : -40) : (labelType == LabelType.Workorder) ? -20 : 20;
      textSym.OffsetY = leftLabel && label.Length > 10 ? -40 : (labelType == LabelType.Other && diagramLabels) ? -20 : 20;
      if (diagramLabels)
      {
        // diagram labels
        if (labelType == LabelType.Workorder)
        {
          textSym.OffsetY *= 3.75;
          textSym.OffsetX *= 5;
        }
        if (labelType == LabelType.Isolation) textSym.OffsetY *= 1.5;
      }
      else
      {
        if (labelType == LabelType.Workorder)
        {
          textSym.OffsetX *= -1;
          textSym.OffsetY *= 1.75;
        }
      }
      //assign the callout to the textSymbol
      textSym.Callout = backgroundCalloutSymbol;

      if (geometry.GeometryType == GeometryType.Point)
      {
        // create a leader point
        CIMLeaderPoint leaderPt = new CIMLeaderPoint
        {
          Point = geometry as MapPoint
        };
        // assign to the textGraphic
        textGraphic.Leaders = new List<CIMLeader>() { leaderPt }.ToArray();
      }

      //now set the text
      textGraphic.Text = label;
      textGraphic.Shape = geometry;
      var graphicElement = graphicsLayer.AddElement(textGraphic);

      if (!GraphicElements.ContainsKey(graphicsLayer))
        GraphicElements.Add(graphicsLayer, new Dictionary<LabelType, List<GraphicElement>>());
      if (GraphicElements[graphicsLayer].ContainsKey(labelType))
        GraphicElements[graphicsLayer][labelType].Add(graphicElement);
      else
        GraphicElements[graphicsLayer].Add(labelType, new List<GraphicElement>() { graphicElement });
      graphicsLayer.ClearSelection();
    }

    private static CIMPolygonSymbol PolySymbolRef = null;

    /// <summary>
    /// Call from MCT
    /// </summary>
    /// <param name="labelType"></param>
    /// <param name="geometry"></param>
    /// <param name="label"></param>
    public static void ShowPolygonCalloutBox(LabelType labelType, Geometry geometry, string label)
    {
      var graphicsLayer = GetGraphicsLayer();
      if (graphicsLayer == null || geometry == null) return;

      //Creating a polygon with a red fill and blue outline.
      if (PolySymbolRef == null)
      {
        CIMStroke outline = SymbolFactory.Instance.ConstructStroke(
             ColorFactory.Instance.GreenRGB, 2.0, SimpleLineStyle.Solid);
        PolySymbolRef = SymbolFactory.Instance.ConstructPolygonSymbol(
             ColorFactory.Instance.CreateRGBColor(190, 255, 190, 50),
             SimpleFillStyle.ForwardDiagonal, outline);
      }

      var graphicElement = graphicsLayer.AddElement(geometry, PolySymbolRef);
      if (!GraphicElements.ContainsKey(graphicsLayer))
        GraphicElements.Add(graphicsLayer, new Dictionary<LabelType, List<GraphicElement>>());
      if (GraphicElements[graphicsLayer].ContainsKey(labelType))
        GraphicElements[graphicsLayer][labelType].Add(graphicElement);
      else
        GraphicElements[graphicsLayer].Add(labelType, new List<GraphicElement>() { graphicElement });
      graphicsLayer.ClearSelection();
      //var textSymbol = (labelType == LabelType.Other) ?
      //  SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 8, "Tahoma", "Regular") :
      //  SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 10, "Tahoma", "Bold");

      //var textGraphic = new CIMTextGraphic
      //{
      //  Symbol = textSymbol.MakeSymbolReference()
      //};
      //textGraphic.Placement = Anchor.BottomLeftCorner;

      ////Create a call out
      //var backgroundCalloutSymbol = new CIMBackgroundCallout();
      //var leftLabel = labelType == LabelType.Switch || labelType == LabelType.Other;

      ////change color depending on type
      //CIMColor accentColor = ColorFactory.Instance.BlackRGB;
      //CIMColor backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 255, 232, 50);
      //switch (labelType)
      //{
      //  case LabelType.Workorder:
      //    accentColor = CIMColor.CreateRGBColor(255, 0, 0);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(255, 190, 190, 50);
      //    break;
      //  case LabelType.Isolation:
      //    accentColor = CIMColor.CreateRGBColor(0, 255, 0);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 255, 190, 50);
      //    break;
      //  case LabelType.Switch:
      //    accentColor = CIMColor.CreateRGBColor(0, 0, 255);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 190, 255, 50);
      //    textGraphic.Placement = Anchor.BottomRightCorner;
      //    break;
      //  case LabelType.Other:
      //    accentColor = CIMColor.CreateRGBColor(50, 50, 50);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 190, 255, 50);
      //    textGraphic.Placement = Anchor.BottomRightCorner;
      //    break;
      //}

      ////Leader line
      ////Get a line symbol
      //var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);

      ////Create a solid fill polygon symbol for the callout.
      //var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);

      ////assign the line to the callout
      //backgroundCalloutSymbol.LeaderLineSymbol = lineSymbol;
      //backgroundCalloutSymbol.LineStyle = LeaderLineStyle.Base;
      //backgroundCalloutSymbol.LeaderOffset = 2;

      ////Assign the polygon to the background callout
      //backgroundCalloutSymbol.BackgroundSymbol = polySymbol;

      ////Set margins for the callout
      //backgroundCalloutSymbol.Margin = new CIMTextMargin
      //{
      //  Left = 5,
      //  Right = 5,
      //  Top = 5,
      //  Bottom = 5
      //};

      ////Accent bar
      //var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
      //backgroundCalloutSymbol.AccentBarSymbol = accentSymbol;

      ////Offset for the text
      //var textSym = textGraphic.Symbol.Symbol as CIMTextSymbol;
      //textSym.OffsetX = leftLabel ? (label.Length > 10 ? -120 : -80) : 20;
      //textSym.OffsetY = leftLabel && label.Length > 10 ? -40 : 20;
      ////assign the callout to the textSymbol
      //textSym.Callout = backgroundCalloutSymbol;

      //if (geometry.GeometryType == GeometryType.Point)
      //{
      //  // create a leader point
      //  CIMLeaderPoint leaderPt = new CIMLeaderPoint
      //  {
      //    Point = geometry as MapPoint
      //  };
      //  // assign to the textGraphic
      //  textGraphic.Leaders = new List<CIMLeader>() { leaderPt }.ToArray();
      //}

      ////now set the text
      //textGraphic.Text = label;
      //textGraphic.Shape = geometry;
      //var graphicElement = graphicsLayer.AddElement(textGraphic);

      //if (!GraphicElements.ContainsKey(graphicsLayer))
      //  GraphicElements.Add(graphicsLayer, new Dictionary<LabelType, List<GraphicElement>>());
      //if (GraphicElements[graphicsLayer].ContainsKey(labelType))
      //  GraphicElements[graphicsLayer][labelType].Add(graphicElement);
      //else
      //  GraphicElements[graphicsLayer].Add(labelType, new List<GraphicElement>() { graphicElement });
      //graphicsLayer.ClearSelection();
    }
    /// <summary>
    /// Call from MCT
    /// </summary>
    /// <param name="labelType"></param>
    /// <param name="geometry"></param>
    public static void ShowLine(LabelType labelType, Geometry geometry)
    {
      var graphicsLayer = GetGraphicsLayer();
      if (graphicsLayer == null || geometry == null) return;

      //Creating a polygon with a red fill and blue outline.
      CIMStroke outline = SymbolFactory.Instance.ConstructStroke(
           ColorFactory.Instance.RedRGB, 2.0, SimpleLineStyle.Solid);
      var lineSymbolRef = SymbolFactory.Instance.ConstructLineSymbol(
           ColorFactory.Instance.CreateRGBColor(255, 1, 20, 50), 4);

      var graphicElement = graphicsLayer.AddElement(geometry, lineSymbolRef);
      if (!GraphicElements.ContainsKey(graphicsLayer))
        GraphicElements.Add(graphicsLayer, new Dictionary<LabelType, List<GraphicElement>>());
      if (GraphicElements[graphicsLayer].ContainsKey(labelType))
        GraphicElements[graphicsLayer][labelType].Add(graphicElement);
      else
        GraphicElements[graphicsLayer].Add(labelType, new List<GraphicElement>() { graphicElement });
      graphicsLayer.ClearSelection();
      //var textSymbol = (labelType == LabelType.Other) ?
      //  SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 8, "Tahoma", "Regular") :
      //  SymbolFactory.Instance.ConstructTextSymbol(ColorFactory.Instance.BlackRGB, 10, "Tahoma", "Bold");

      //var textGraphic = new CIMTextGraphic
      //{
      //  Symbol = textSymbol.MakeSymbolReference()
      //};
      //textGraphic.Placement = Anchor.BottomLeftCorner;

      ////Create a call out
      //var backgroundCalloutSymbol = new CIMBackgroundCallout();
      //var leftLabel = labelType == LabelType.Switch || labelType == LabelType.Other;

      ////change color depending on type
      //CIMColor accentColor = ColorFactory.Instance.BlackRGB;
      //CIMColor backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 255, 232, 50);
      //switch (labelType)
      //{
      //  case LabelType.Workorder:
      //    accentColor = CIMColor.CreateRGBColor(255, 0, 0);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(255, 190, 190, 50);
      //    break;
      //  case LabelType.Isolation:
      //    accentColor = CIMColor.CreateRGBColor(0, 255, 0);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 255, 190, 50);
      //    break;
      //  case LabelType.Switch:
      //    accentColor = CIMColor.CreateRGBColor(0, 0, 255);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 190, 255, 50);
      //    textGraphic.Placement = Anchor.BottomRightCorner;
      //    break;
      //  case LabelType.Other:
      //    accentColor = CIMColor.CreateRGBColor(50, 50, 50);
      //    backgroundColor = ColorFactory.Instance.CreateRGBColor(190, 190, 255, 50);
      //    textGraphic.Placement = Anchor.BottomRightCorner;
      //    break;
      //}

      ////Leader line
      ////Get a line symbol
      //var lineSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);

      ////Create a solid fill polygon symbol for the callout.
      //var polySymbol = SymbolFactory.Instance.ConstructPolygonSymbol(backgroundColor, SimpleFillStyle.Solid);

      ////assign the line to the callout
      //backgroundCalloutSymbol.LeaderLineSymbol = lineSymbol;
      //backgroundCalloutSymbol.LineStyle = LeaderLineStyle.Base;
      //backgroundCalloutSymbol.LeaderOffset = 2;

      ////Assign the polygon to the background callout
      //backgroundCalloutSymbol.BackgroundSymbol = polySymbol;

      ////Set margins for the callout
      //backgroundCalloutSymbol.Margin = new CIMTextMargin
      //{
      //  Left = 5,
      //  Right = 5,
      //  Top = 5,
      //  Bottom = 5
      //};

      ////Accent bar
      //var accentSymbol = SymbolFactory.Instance.ConstructLineSymbol(accentColor, 2, SimpleLineStyle.Solid);
      //backgroundCalloutSymbol.AccentBarSymbol = accentSymbol;

      ////Offset for the text
      //var textSym = textGraphic.Symbol.Symbol as CIMTextSymbol;
      //textSym.OffsetX = leftLabel ? (label.Length > 10 ? -120 : -80) : 20;
      //textSym.OffsetY = leftLabel && label.Length > 10 ? -40 : 20;
      ////assign the callout to the textSymbol
      //textSym.Callout = backgroundCalloutSymbol;

      //if (geometry.GeometryType == GeometryType.Point)
      //{
      //  // create a leader point
      //  CIMLeaderPoint leaderPt = new CIMLeaderPoint
      //  {
      //    Point = geometry as MapPoint
      //  };
      //  // assign to the textGraphic
      //  textGraphic.Leaders = new List<CIMLeader>() { leaderPt }.ToArray();
      //}

      ////now set the text
      //textGraphic.Text = label;
      //textGraphic.Shape = geometry;
      //var graphicElement = graphicsLayer.AddElement(textGraphic);

      //if (!GraphicElements.ContainsKey(graphicsLayer))
      //  GraphicElements.Add(graphicsLayer, new Dictionary<LabelType, List<GraphicElement>>());
      //if (GraphicElements[graphicsLayer].ContainsKey(labelType))
      //  GraphicElements[graphicsLayer][labelType].Add(graphicElement);
      //else
      //  GraphicElements[graphicsLayer].Add(labelType, new List<GraphicElement>() { graphicElement });
      //graphicsLayer.ClearSelection();
    }

    /// <summary>
    /// Call from MCT.
    /// </summary>
    /// <returns></returns>
    internal static GraphicsLayer GetGraphicsLayer ()
    {
      GraphicsLayer graphicsLayer = null;
      if (MapView.Active != null)
      {
        graphicsLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<GraphicsLayer>().FirstOrDefault();
        if (graphicsLayer == null)
        {
          var graphicsLayerCreationParams = new GraphicsLayerCreationParams { Name = "Labels" };
          graphicsLayer = LayerFactory.Instance.CreateLayer<GraphicsLayer>(graphicsLayerCreationParams, MapView.Active.Map,
                  LayerPosition.AutoArrange);
        }
      }
      return graphicsLayer;
    }

    internal static void AutoLabelSwitches(bool labelMap, List<OutageTraceViewElement> outageTraceViewElements,
      Workorder workorder = null, List<OutageTraceViewElement> isolationElements = null)
    {
      if (!labelMap && isolationElements != null)
      {
        foreach (var traceViewElement in isolationElements)
        {
          MapUtil.ShowCalloutBox(MapUtil.LabelType.Isolation, traceViewElement.DiagramShape, 
            $@"Isolation: {traceViewElement.ObjectID}", !labelMap);
        }
        if (workorder != null)
        {
          var twoLiner = $@"WO {workorder?.WorkorderNo}{Environment.NewLine}{workorder.Description}";
          MapUtil.ShowCalloutBox(MapUtil.LabelType.Workorder, workorder.DiagramShape, twoLiner, !labelMap);
        }
      }
      List<long> processedOid = new List<long>();
      foreach (var traceViewElement in outageTraceViewElements)
      {
        var assetGroupName = traceViewElement.AssetGroupName;
        if (assetGroupName.Contains("Switch")
          || assetGroupName.Contains("Fuse"))
        {
          var label = assetGroupName;
          var parts = label.Split(new char[] { ' ' });
          if (parts.Length > 0) label = parts[parts.Length - 1];
          if (processedOid.Contains(traceViewElement.ObjectID)) continue;
          MapUtil.ShowCalloutBox(MapUtil.LabelType.Switch, 
              labelMap ? traceViewElement.MapShape : traceViewElement.DiagramShape,
              $@"{label}{Environment.NewLine}{traceViewElement.ObjectID}");
          processedOid.Add(traceViewElement.ObjectID);
        }
        else if (assetGroupName.Contains("Transformer"))
        {
          var label = "xfmr";
          if (processedOid.Contains(traceViewElement.ObjectID)) continue;
          MapUtil.ShowCalloutBox(MapUtil.LabelType.Other,
            labelMap ? traceViewElement.MapShape : traceViewElement.DiagramShape,
            $@"{label} {traceViewElement.ObjectID}", true);
          processedOid.Add(traceViewElement.ObjectID);
        }
      }
    }

    internal static Envelope UnionGeometries (IEnumerable<Geometry> geometries)
    {
      Envelope envelope = null;
      foreach (var geometry in geometries)
      {
        if (geometry == null) continue;
        envelope = envelope == null ?
          geometry.Extent : envelope.Union(geometry.Extent);
      }
      return envelope.Expand (1.1, 1.2, true);
    }
  }
}
