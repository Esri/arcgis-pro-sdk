﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerOutagePlanning
{
  internal class CustomLayout
  {
    // Width = 29.7, Height = 42, LinearUnit = LinearUnit.Centimeters 
    // computed fields:

    internal static double LayoutTotalWidth = 44;
    internal static double LayoutTotalHeight = 30;
    internal static double LayoutMargin => LayoutTotalWidth / 25;
    internal static double MapLeftOffset => LayoutMargin;
    internal static double MapHeight => (LayoutTotalHeight - MapBottom - 2.0 * LayoutMargin);
    internal static double MapWidth => (LayoutTotalWidth - 2*LayoutMargin)/2;
    internal static double MapBottom => 6*LayoutMargin;
    internal static double DiagramBottom => MapBottom;
    internal static double DiagramLeft => LayoutMargin + MapWidth;
    internal static double TableBottom => LayoutMargin;
    internal static double TableLeftOffset => MapLeftOffset;
    internal static double TableHeight => 4.5*LayoutMargin;
    internal static double TableWidth => 2*MapWidth;

    internal static double TitleLeft = LayoutTotalWidth / 2 - 2 * LayoutMargin;

    internal static double TitleTop = LayoutTotalHeight - 1.5 * LayoutMargin;

    internal static async Task<Layout> CreateCustomLayout (string layoutName, 
      string mapFrameName, 
      string diagFrameName, 
      Envelope mapGeometry,
      Envelope diagramGeometry)
    {
      Layout resultLayout = null;
      try
      {
        resultLayout = await QueuedTask.Run<Layout>(() =>
        {
          if (PowerOutagePlanningModule.DebugActive)
          {
            // Set up Layout page dimensions
            CIMPage newPage = new CIMPage
            {
              //required
              Width = LayoutTotalWidth,
              Height = LayoutTotalHeight,
              Units = LinearUnit.Centimeters
            };
            // create the layout
            Layout layout = LayoutFactory.Instance.CreateLayout(newPage);

            // name the layout
            layout.SetName(layoutName);

            #region Add map Frame showing map view of impacted area by outage
            Coordinate2D llMap = new Coordinate2D(MapLeftOffset, MapBottom);
            Coordinate2D urMAP = new Coordinate2D(MapLeftOffset + MapWidth, MapBottom + MapHeight);
            Envelope envMap = EnvelopeBuilder.CreateEnvelope(llMap, urMAP);

            MapProjectItem mapPrjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals(mapFrameName));
            Map theMap = mapPrjItem.GetMap();            
            #endregion

            MapFrame mfElm = LayoutElementFactory.Instance.CreateMapFrame(layout, envMap, theMap);

            #region Add Schematic Diagram of network affected by power outage
            mfElm.SetName(mapFrameName);
            mfElm.SetCamera(mapGeometry);

            //Scale bar
            Coordinate2D llScalebar = new Coordinate2D(1.5 * MapLeftOffset, MapBottom + LayoutMargin);
            LayoutElementFactory.Instance.CreateScaleBar(layout, llScalebar, mfElm);

            //Add Diagram Frame
            llMap = new Coordinate2D(DiagramLeft, DiagramBottom);
            urMAP = new Coordinate2D(DiagramLeft + MapWidth, DiagramBottom + MapHeight);
            var envDiagram = EnvelopeBuilder.CreateEnvelope(llMap, urMAP);

            //Reference map, create Map Frame and add to layout
            MapProjectItem diagPrjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals(diagFrameName));
            Map theDiagram = diagPrjItem.GetMap();
            #endregion

            MapFrame dfElm = LayoutElementFactory.Instance.CreateMapFrame(layout, envDiagram, theDiagram);

            #region Add Address list of Customers affected by power outage
            dfElm.SetName(diagFrameName);
            dfElm.SetCamera(diagramGeometry);

            // Title: dynamic text: <dyn type="page" property="name"/>
            //Name: <dyn type="layout" name="Layout 120985 1" property="name"/>
            var title = $@"<dyn type=""layout"" name=""{layoutName}"" property=""name"" />";
            Coordinate2D llTitle = new Coordinate2D(TitleLeft, TitleTop);
            var titleGraphics = LayoutElementFactory.Instance.CreatePointTextGraphicElement(layout, llTitle, null) as TextElement;
            titleGraphics.SetTextProperties(new TextProperties(title, "Arial", 16, "Bold"));

            llTitle = new Coordinate2D(2 * LayoutMargin, 0.6 * LayoutMargin);
            title = @"<dyn type=""layout"" name=""LayoutName"" property=""serviceLayerCredits"" />";
            titleGraphics = LayoutElementFactory.Instance.CreatePointTextGraphicElement(layout, llTitle, null) as TextElement;
            titleGraphics.SetTextProperties(new TextProperties(title, "Arial", 8, "Regular"));

            var servicePointTableName = "Parcels";
            #endregion

            AddCustomerDetailsToLayout(layout, theMap, mfElm, servicePointTableName, TableBottom, TableLeftOffset, TableWidth, TableHeight);

            return layout;
          }
          else
          {
            //Set up a page
            CIMPage newPage = new CIMPage
            {
              //required
              Width = LayoutTotalWidth,
              Height = LayoutTotalHeight,
              Units = LinearUnit.Centimeters
            };
            // create the layout
            Layout layout = LayoutFactory.Instance.CreateLayout(newPage);

            // name the layout
            layout.SetName(layoutName);

            #region Add map Frame
            Coordinate2D llMap = new Coordinate2D(MapLeftOffset, MapBottom);
            Coordinate2D urMAP = new Coordinate2D(MapLeftOffset + MapWidth, MapBottom + MapHeight);
            Envelope envMap = EnvelopeBuilder.CreateEnvelope(llMap, urMAP);
            #endregion

            MapProjectItem mapPrjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals(mapFrameName));
            Map theMap = mapPrjItem.GetMap();
            MapFrame mfElm = LayoutElementFactory.Instance.CreateMapFrame(layout, envMap, theMap);

            #region Add Schematic Diagram
            mfElm.SetName(mapFrameName);
            mfElm.SetCamera(mapGeometry);

            //Scale bar
            Coordinate2D llScalebar = new Coordinate2D(1.5 * MapLeftOffset, MapBottom + LayoutMargin);
            LayoutElementFactory.Instance.CreateScaleBar(layout, llScalebar, mfElm);

            //Add Diagram Frame
            llMap = new Coordinate2D(DiagramLeft, DiagramBottom);
            urMAP = new Coordinate2D(DiagramLeft + MapWidth, DiagramBottom + MapHeight);
            var envDiagram = EnvelopeBuilder.CreateEnvelope(llMap, urMAP);
            #endregion

            //Reference map, create Map Frame and add to layout
            MapProjectItem diagPrjItem = Project.Current.GetItems<MapProjectItem>().FirstOrDefault(item => item.Name.Equals(diagFrameName));
            Map theDiagram = diagPrjItem.GetMap();
            MapFrame dfElm = LayoutElementFactory.Instance.CreateMapFrame(layout, envDiagram, theDiagram);

            #region Add Customer details
            dfElm.SetName(diagFrameName);
            dfElm.SetCamera(diagramGeometry);

            // Title: dynamic text: <dyn type="page" property="name"/>
            //Name: <dyn type="layout" name="Layout 120985 1" property="name"/>
            var title = $@"<dyn type=""layout"" name=""{layoutName}"" property=""name"" />";
            Coordinate2D llTitle = new Coordinate2D(TitleLeft, TitleTop);
            var titleGraphics = LayoutElementFactory.Instance.CreatePointTextGraphicElement(layout, llTitle, null) as TextElement;
            titleGraphics.SetTextProperties(new TextProperties(title, "Arial", 16, "Bold"));

            llTitle = new Coordinate2D(2 * LayoutMargin, 0.6 * LayoutMargin);
            title = @"<dyn type=""layout"" name=""LayoutName"" property=""serviceLayerCredits"" />";
            titleGraphics = LayoutElementFactory.Instance.CreatePointTextGraphicElement(layout, llTitle, null) as TextElement;
            titleGraphics.SetTextProperties(new TextProperties(title, "Arial", 8, "Regular"));

            var servicePointTableName = "Parcels";
            #endregion

            AddCustomerDetailsToLayout(layout, theMap, mfElm, servicePointTableName, TableBottom, TableLeftOffset, TableWidth, TableHeight);

            return layout;
          }
        });

        //CREATE, OPEN LAYOUT VIEW (must be in the GUI thread)
        ILayoutPane layoutPane = await LayoutFrameworkExtender.CreateLayoutPaneAsync(ProApp.Panes, resultLayout);
        var cimLayout = await QueuedTask.Run<CIMLayout>(() =>
        {
          return resultLayout.GetDefinition();
        });
      }
      catch (Exception ex)
      {
        MessageBox.Show($@"Error in create layout: {ex}");
      }
      return resultLayout;
    }

    internal static void AddCustomerDetailsToLayout(Layout layout, Map theMap, MapFrame mfElm, string layerName, 
      double tableBottom, double tableLeftOffset, double tableWidth, double tableHeight)
    {
      var lyrs = theMap.FindLayers(layerName, true);
      if (lyrs.Count > 0)
      {
        Layer lyr = lyrs[0];
        //var ptSymbol = GetPointSymbolFromLayer(lyr);
        var tableTop = tableBottom + TableHeight;
        //if (ptSymbol != null)
        //{
        //  var titleBottom = LayoutMargin + TableHeight;
        //  Coordinate2D llSym = new Coordinate2D(tableLeftOffset, titleBottom);
        //  var sym = LayoutElementFactory.Instance.CreatePointGraphicElement(layout, llSym, ptSymbol);

        //  Coordinate2D llText = new Coordinate2D(tableLeftOffset + sym.GetWidth(), titleBottom - sym.GetHeight() / 2);
        //  var text = LayoutElementFactory.Instance.CreatePointTextGraphicElement(layout, llText, lyr.Name);
        //  text.SetAnchor(Anchor.CenterPoint);
        //  text.SetHeight(text.GetHeight());
        //  if (text.GetHeight() > sym.GetHeight())
        //  {
        //    sym.SetLockedAspectRatio(true);
        //    sym.SetHeight(text.GetHeight());
        //    tableTop -= text.GetHeight();
        //  }
        //  else
        //  {
        //    text.SetLockedAspectRatio(true);
        //    text.SetHeight(sym.GetHeight());
        //    tableTop -= sym.GetHeight();
        //  }          
        //}
        Coordinate2D llTab1 = new Coordinate2D(tableLeftOffset, tableBottom);
        Coordinate2D urTab1 = new Coordinate2D(tableLeftOffset + TableWidth, tableTop);
        var tableFrame = LayoutElementFactory.Instance.CreateTableFrame(layout, EnvelopeBuilderEx.CreateEnvelope(llTab1, urTab1), mfElm, lyr, new string[] { "SiteAddress" });
        var def = tableFrame.GetDefinition() as CIMTableFrame;
        def.FittingStrategy = TableFrameFittingStrategy.AdjustColumnsAndSize;
        def.FillingStrategy = TableFrameFillingStrategy.ShowAllRows;
        tableFrame.SetDefinition(def);
      }
    }

    private static CIMPointSymbol GetPointSymbolFromLayer(Layer layer)
    {
      if (!(layer is FeatureLayer)) return null;
      var fLyr = layer as FeatureLayer;
      var renderer = fLyr.GetRenderer() as CIMSimpleRenderer;
      if (renderer == null || renderer.Symbol == null) return null;
      return renderer.Symbol.Symbol as CIMPointSymbol;
    }
  }
}
