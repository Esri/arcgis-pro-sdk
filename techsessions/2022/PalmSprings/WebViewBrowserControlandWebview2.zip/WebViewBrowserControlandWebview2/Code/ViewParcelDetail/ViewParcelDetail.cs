﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewParcelDetail
{
  internal class ViewParcelDetail : MapTool
  {
    public ViewParcelDetail()
    {
      IsSketchTool = true;
      SketchType = SketchGeometryType.Point;
      SketchOutputMode = SketchOutputMode.Map;
    }

    protected override Task OnToolActivateAsync(bool active)
    {
      return base.OnToolActivateAsync(active);
    }

    protected override async Task<bool> OnSketchCompleteAsync(Geometry geometry)
    {
      try
      {
        var parcelLayer = ActiveMapView.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().
               Where(lyr => lyr.Name.Equals("Parcels")).FirstOrDefault();
        if (parcelLayer == null) return false;
        // execute the query on the MCT
        // try to get the qlink attribute
        var parcelInfo = await QueuedTask.Run<(string url, long oid)>(() =>
        {
          // define the spatial query filter
          var spatialQuery = new SpatialQueryFilter() { FilterGeometry = geometry, SpatialRelationship = SpatialRelationship.Intersects };
          using (var rowCursor = parcelLayer.Search(spatialQuery))
          {
            // add the feature IDs into our prepared list
            while (rowCursor.MoveNext())
            {
              using (var feature = rowCursor.Current as Feature)
              {
                return (feature["qpub_link"].ToString(), feature.GetObjectID());
              }
            }
          }
          return (string.Empty, -1);
        });
        if (string.IsNullOrEmpty(parcelInfo.url))
        {
          MessageBox.Show("No parcel details found");
        }
        else
        {
          // select the parcel
          _ = QueuedTask.Run(() =>
            {
              var qf = new QueryFilter() { ObjectIDs = new List<long> { parcelInfo.oid } };
              parcelLayer.Select(qf);
            });
          // Show ProWindow
          var parcelDetailWindow = new ParcelDetailWindow
          {
            // ProWindow needs a window owner
            Owner = FrameworkApplication.Current.MainWindow,
            DataContext = new ParcelDetailWindowVM(parcelInfo.url)
          };
          var dlgResult = parcelDetailWindow.ShowDialog();
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      return true;
    }
  }
}
