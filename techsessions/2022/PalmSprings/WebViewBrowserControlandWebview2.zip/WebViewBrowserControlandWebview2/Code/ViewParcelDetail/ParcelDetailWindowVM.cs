﻿using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewParcelDetail
{
    public class ParcelDetailWindowVM : PropertyChangedBase
    {
        private string _url;

        public ParcelDetailWindowVM(string Url)
        {
            this.Url = Url;
            SourceUri = new Uri(Url);
        }

        public string Url
        {
            get { return _url; }
            set
            {
                SetProperty(ref _url, value, () => Url);
            }
        }

        private Uri _sourceUri = null;
        /// <summary>
        /// SourceUri is used to interface with the WebViewBrowser control
        /// </summary>
        public Uri SourceUri
        {
            get { return _sourceUri; }
            set
            {
                SetProperty(ref _sourceUri, value, () => SourceUri);
                //if (_sourceUri.AbsoluteUri != _navInput)
                //{
                //    _navInput = _sourceUri.AbsoluteUri;
                //    NotifyPropertyChanged(() => NavInput);
                //}
            }
        }

    }
}
