﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProWindowSession
{
  internal class ShowModalProWindow : Button
  {
    protected override void OnClick()
    {
     
        var proWindowModal = new ProWindowModal
        {
          DataContext = new ProWindowViewModel(),
          Owner = FrameworkApplication.Current.MainWindow
        };

      var result = proWindowModal.ShowDialog(); //modal
      if (result == true) //Modal means this line executes. This is why closing event is not needed.
        ZoomToLocation(Module1.SelectedBookmark);
    }

    private void ZoomToLocation(string zoomTo)
    {
       QueuedTask.Run(() => {
        var bookmark = MapView.Active.Map.GetBookmarks().FirstOrDefault(b => b.Name == zoomTo);
        if (bookmark == null) return;
        MapView.Active.ZoomTo(bookmark, new TimeSpan (0, 0, 3)); //time span for modeless
      });

    }

  }
}
