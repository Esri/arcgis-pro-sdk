﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;

namespace ProWindowSession
{
  public class ProWindowViewModel : PropertyChangedBase
  {
    private object _lockCollection = new object();
    
    public ProWindowViewModel()
    {
      BindingOperations.EnableCollectionSynchronization(BookmarksInMap, _lockCollection);
      GetBookmarksInMap();     

    }
    private ObservableCollection<string> _bookmarksInMap = new ObservableCollection<string>();
    public ObservableCollection<string> BookmarksInMap
    {
      get { return _bookmarksInMap; }
      set
      {
        SetProperty(ref _bookmarksInMap, value, () => BookmarksInMap);
      }
    }

    private string _selectedBookmark;
    public string SelectedBookmark
    {
      get
      { return _selectedBookmark; }
      set
      {
        SetProperty(ref _selectedBookmark, value, () => SelectedBookmark);
      }
    }


    private Visibility _isShowCircularAnimation = Visibility.Collapsed;
    public Visibility IsShowCircularAnimation
    {
      get { return _isShowCircularAnimation; }
      set
      {
        SetProperty(ref _isShowCircularAnimation, value, () => IsShowCircularAnimation);
      }
    }

    public ICommand OKCommand
    {
      get
      {
        return new RelayCommand((theWindow) => ClickOK(theWindow as ProWindowModal), () => true);
      }
    }
    public ICommand CancelCommand
    {
      get
      {
        return new RelayCommand((theWindow) => ClickCancel(theWindow as ProWindowModal), () => true);
      }
    }
    public ICommand ZoomCommand
    {
      get
      {
        return new RelayCommand(ZoomToLocation, () => true);
      }
    }

    private void ClickOK(ProWindowModal proWindow)
    {
      Module1.SelectedBookmark = SelectedBookmark;
      proWindow.DialogResult = true;     
      proWindow.Close();
    }
    private void ClickCancel(ProWindowModal proWindow)
    {
      Module1.SelectedBookmark = string.Empty;
      proWindow.DialogResult = false;      
      proWindow.Close();
    }
    private void ZoomToLocation()
    {
      IsShowCircularAnimation = Visibility.Visible;
      QueuedTask.Run(() =>
      {
        var bookmark = MapView.Active.Map.GetBookmarks().FirstOrDefault(b => b.Name == SelectedBookmark);
        if (bookmark == null) return;
        MapView.Active.ZoomTo(bookmark, new TimeSpan(0, 0, 3)); //time span for modeless
        IsShowCircularAnimation = Visibility.Collapsed;
      });
    }
    private async void GetBookmarksInMap()
    {
      if (MapView.Active == null) return;
      await QueuedTask.Run( () => {
        var bmks = MapView.Active.Map.GetBookmarks();
        foreach (var bmk in bmks)
        {
          lock (_lockCollection)
           _bookmarksInMap.Add(bmk.Name);
        }
       
        if (!string.IsNullOrEmpty(Module1.SelectedBookmark))
        {
          SelectedBookmark = Module1.SelectedBookmark;
        }
        else
           if (_bookmarksInMap.Count > 0)
          SelectedBookmark = _bookmarksInMap[0];
      });
    }
  }
}
