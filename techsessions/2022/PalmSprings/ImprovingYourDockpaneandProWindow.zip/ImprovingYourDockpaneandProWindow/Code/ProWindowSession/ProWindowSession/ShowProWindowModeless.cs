﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProWindowSession
{
  internal class ShowProWindowModeless : Button
  {
    private ProWindowModeless _proWindow = null;
    private bool _isOpen = false;
    protected override void OnClick()
    {
      if (!_isOpen)
        FrameworkApplication.State.Activate("ProWindowSession_ModelessOpen_State");
      _isOpen = true;

     
        _proWindow = new ProWindowModeless
        {
          DataContext = new ProWindowViewModel(),
          Owner = FrameworkApplication.Current.MainWindow,
        };
      _proWindow.Closing += _proWindow_Closing;
      _proWindow.Show();
    }

    private void _proWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {      
      _proWindow = null;
      _isOpen = false;
      FrameworkApplication.State.Deactivate("ProWindowSession_ModelessOpen_State");
    }
  }
}
