﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Data.UtilityNetwork.NetworkDiagrams;
using ArcGIS.Core.Data.UtilityNetwork.Trace;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerOutagePlanning
{
  internal static class NetworkConstants
  {
    internal const string ElectricDomainNetwork = "Electric";
    internal const string MediumVoltageTier = "Electric Distribution";
    internal const string ServicePointCategory = "Service Point";
    internal const string PhaseAttributeName = "E:Phases Current";
    internal const string LoadAttributeName = "Customer Load";
    internal const string LineFeatureClassName = "ElectricLine";

    // Constants - used with the starting points table created by the Set Trace Locations tool

    internal const string StartingPointsTableName = "UN_Temp_Starting_Points";
    internal const string PointsSourceIDFieldName = "SourceID";
    internal const string PointsAssetGroupFieldName = "AssetGroupCode";
    internal const string PointsAssetTypeFieldName = "AssetType";
    internal const string PointsGlobalIDFieldName = "FEATUREGLOBALID";
    internal const string PointsTerminalFieldName = "TERMINALID";
    internal const string PointsPercentAlong = "PERCENTALONG";
  }

  /// <summary>
  /// Network tracing utilities
  /// </summary>
  public static class NetworkTrace
  {

    internal static OutageTraceResult RunIsolationTracer(UtilityNetworkLayer utilNetworkLayer,
      Workorder startingWorkorder)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        Success = false,
        Message = "No trace was run",
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };
      using (UtilityNetwork utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer))
      {
        if (utilityNetwork == null)
        {
          outageTraceResult.Message = "Error: No utility network layer found.";
          outageTraceResult.Success = false;
        }
        else if (!NetworkUtil.ValidateDataModel(utilityNetwork))
        {
          outageTraceResult.Message = "Error: This sample is designed for a different utility network data model";
          outageTraceResult.Success = false;
        }
        else
        {
          using (Geodatabase utilityNetworkGeodatabase = utilityNetwork.GetDatastore() as Geodatabase)
          using (UtilityNetworkDefinition utilityNetworkDefinition = utilityNetwork.GetDefinition())
          using (Geodatabase defaultGeodatabase = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(Project.Current.DefaultGeodatabasePath))))
          using (TraceManager traceManager = utilityNetwork.GetTraceManager())
          {
            var startingPointElement = startingWorkorder.GetElement(utilityNetwork, utilityNetworkDefinition);
            outageTraceResult = RunIsolationTrace(utilityNetwork, utilityNetworkGeodatabase,
                                        utilityNetworkDefinition, defaultGeodatabase,
                                        startingPointElement);
          }
        }
      }
      return outageTraceResult;
    }

    internal static OutageTraceResult RunUpStreamTrace(UtilityNetworkLayer utilNetworkLayer,
      Workorder startingWorkorder, IReadOnlyList<Element> barriers)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        Success = false,
        Message = "No trace was run",
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };
      using (UtilityNetwork utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer))
      {
        if (utilityNetwork == null)
        {
          outageTraceResult.Message = "Error: No utility network layer found.";
          outageTraceResult.Success = false;
        }
        else if (!NetworkUtil.ValidateDataModel(utilityNetwork))
        {
          outageTraceResult.Message = "Error: This sample is designed for a different utility network data model";
          outageTraceResult.Success = false;
        }
        else
        {
          using (Geodatabase utilityNetworkGeodatabase = utilityNetwork.GetDatastore() as Geodatabase)
          using (UtilityNetworkDefinition utilityNetworkDefinition = utilityNetwork.GetDefinition())
          using (Geodatabase defaultGeodatabase = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(Project.Current.DefaultGeodatabasePath))))
          using (TraceManager traceManager = utilityNetwork.GetTraceManager())
          {
            var startingPointElement = startingWorkorder.GetElement(utilityNetwork, utilityNetworkDefinition);
            var upstreamTracer = traceManager.GetTracer<UpstreamTracer>();
            outageTraceResult = RunTrace(utilityNetwork, utilityNetworkGeodatabase,
                                        utilityNetworkDefinition, defaultGeodatabase,
                                        upstreamTracer, startingPointElement, false, barriers);
          }
        }
      }
      return outageTraceResult;
    }

    internal static OutageTraceResult RunDownStreamTrace(UtilityNetworkLayer utilNetworkLayer,
      Workorder startingWorkorder)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        Success = false,
        Message = "No trace was run",
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };
      using (UtilityNetwork utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer))
      {
        if (utilityNetwork == null)
        {
          outageTraceResult.Message = "Error: No utility network layer found.";
          outageTraceResult.Success = false;
        }
        else if (!NetworkUtil.ValidateDataModel(utilityNetwork))
        {
          outageTraceResult.Message = "Error: This sample is designed for a different utility network data model";
          outageTraceResult.Success = false;
        }
        else
        {
          using (Geodatabase utilityNetworkGeodatabase = utilityNetwork.GetDatastore() as Geodatabase)
          using (UtilityNetworkDefinition utilityNetworkDefinition = utilityNetwork.GetDefinition())
          using (Geodatabase defaultGeodatabase = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(Project.Current.DefaultGeodatabasePath))))
          using (TraceManager traceManager = utilityNetwork.GetTraceManager())
          {
            var startingPointElement = startingWorkorder.GetElement(utilityNetwork, utilityNetworkDefinition);
            var downstreamTracer = traceManager.GetTracer<DownstreamTracer>();
            outageTraceResult = RunTrace(utilityNetwork, utilityNetworkGeodatabase,
                                        utilityNetworkDefinition, defaultGeodatabase,
                                        downstreamTracer, startingPointElement);
          }
        }
      }
      return outageTraceResult;
    }

    internal static OutageTraceResult RunConnectedTrace(UtilityNetworkLayer utilNetworkLayer,
      Workorder startingWorkorder, IReadOnlyList<Element> barriers)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        Success = false,
        Message = "No trace was run",
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };
      using (UtilityNetwork utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer))
      {
        if (utilityNetwork == null)
        {
          outageTraceResult.Message = "Error: No utility network layer found.";
          outageTraceResult.Success = false;
        }
        else if (!NetworkUtil.ValidateDataModel(utilityNetwork))
        {
          outageTraceResult.Message = "Error: This sample is designed for a different utility network data model";
          outageTraceResult.Success = false;
        }
        else
        {
          using (Geodatabase utilityNetworkGeodatabase = utilityNetwork.GetDatastore() as Geodatabase)
          using (UtilityNetworkDefinition utilityNetworkDefinition = utilityNetwork.GetDefinition())
          using (Geodatabase defaultGeodatabase = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(Project.Current.DefaultGeodatabasePath))))
          using (TraceManager traceManager = utilityNetwork.GetTraceManager())
          {
            var startingPointElement = startingWorkorder.GetElement(utilityNetwork, utilityNetworkDefinition);
            var connectedTracer = traceManager.GetTracer<ConnectedTracer>();
            outageTraceResult = RunTrace(utilityNetwork, utilityNetworkGeodatabase,
                                        utilityNetworkDefinition, defaultGeodatabase,
                                        connectedTracer, startingPointElement, false, barriers);
          }
        }
      }
      return outageTraceResult;
    }

    internal static OutageTraceResult RunShortestPathTrace(UtilityNetworkLayer utilNetworkLayer,
      Workorder startingWorkorder, Element endPoint)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        Success = false,
        Message = "No trace was run",
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };
      using (UtilityNetwork utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer))
      {
        if (utilityNetwork == null)
        {
          outageTraceResult.Message = "Error: No utility network layer found.";
          outageTraceResult.Success = false;
        }
        else if (!NetworkUtil.ValidateDataModel(utilityNetwork))
        {
          outageTraceResult.Message = "Error: This sample is designed for a different utility network data model";
          outageTraceResult.Success = false;
        }
        else
        {
          using (Geodatabase utilityNetworkGeodatabase = utilityNetwork.GetDatastore() as Geodatabase)
          using (UtilityNetworkDefinition utilityNetworkDefinition = utilityNetwork.GetDefinition())
          using (Geodatabase defaultGeodatabase = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(Project.Current.DefaultGeodatabasePath))))
          using (TraceManager traceManager = utilityNetwork.GetTraceManager())
          {
            var startingPointElement = startingWorkorder.GetElement(utilityNetwork, utilityNetworkDefinition);
            var startingPoints = new List<Element>() { startingPointElement, endPoint };
            var shortestPathTracer = traceManager.GetTracer<ShortestPathTracer>();
            outageTraceResult = RunShortPathTrace(utilityNetwork, utilityNetworkGeodatabase,
                                        utilityNetworkDefinition, defaultGeodatabase,
                                        shortestPathTracer, startingPoints);
          }
        }
      }
      return outageTraceResult;
    }

    internal static OutageTraceResult RunIsolationTrace(UtilityNetwork utilityNetwork,
            Geodatabase utilityNetworkGeodatabase,
            UtilityNetworkDefinition utilityNetworkDefinition,
            Geodatabase defaultGeodatabase,
            Element startingPointElement)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };

      // Get the Domain Network and Medium Voltage Tier
      DomainNetwork electricDomainNetwork = utilityNetworkDefinition.GetDomainNetwork(NetworkConstants.ElectricDomainNetwork);

      // Set up the trace configuration
      TraceConfiguration traceConfiguration = new TraceConfiguration
      {
        // Configure the trace to use the electric domain network
        DomainNetwork = electricDomainNetwork
      };

      // Create starting point list and trace argument object
      List<Element> startingPointList = new List<Element>() { startingPointElement };
      try
      {
        if (PowerOutagePlanningModule.DebugActive)
        {
          using (NetworkAttribute isSubNetAttribute = utilityNetworkDefinition.GetNetworkAttribute("Is subnetwork controller"))
          {
            ConditionalExpression subNetCondition = new NetworkAttributeComparison(isSubNetAttribute, Operator.Equal, false);
            traceConfiguration.Filter.Barriers = subNetCondition;
            traceConfiguration.Filter.Scope = TraversabilityScope.JunctionsAndEdges;
            using (var traceManager = utilityNetwork.GetTraceManager())
            {
              // setup up the arguments to rung the isolation trace
              TraceArgument traceArgument = new TraceArgument(startingPointList)
              {
                Configuration = traceConfiguration
              };
              // get an instance of Isolation Trace
              var isolationTracer = traceManager.GetTracer<IsolationTracer>();
              // run the trace
              IReadOnlyList<Result> traceResult = isolationTracer.Trace(traceArgument);

              ElementResult elementResult = traceResult.OfType<ElementResult>().First();
              foreach (var element in elementResult.Elements)
              {
                var traceElement = new OutageTraceElement()
                {
                  AssetGroup = element.AssetGroup,
                  AssetType = element.AssetType,
                  GlobalID = element.GlobalID,
                  NetworkSource = element.NetworkSource,
                  ObjectID = element.ObjectID,
                  Terminal = element.Terminal
                };
                outageTraceResult.OutageTraceElements.Add(traceElement);
                var traceViewElement = new OutageTraceViewElement(element, NetworkUtil.GetRowForElement(utilityNetwork, element));
                outageTraceResult.OutageTraceViewElements.Add(traceViewElement);
              }
            }
          }
        }
        else
        {
          using (NetworkAttribute isSubNetAttribute = utilityNetworkDefinition.GetNetworkAttribute("Is subnetwork controller"))
          {
            ConditionalExpression subNetCondition = new NetworkAttributeComparison(isSubNetAttribute, Operator.Equal, false);
            traceConfiguration.Filter.Barriers = subNetCondition;
            traceConfiguration.Filter.Scope = TraversabilityScope.JunctionsAndEdges;
            using (var traceManager = utilityNetwork.GetTraceManager())
            {
              // setup up the arguments to rung the isolation trace
              TraceArgument traceArgument = new TraceArgument(startingPointList)
              {
                Configuration = traceConfiguration
              };
              // get an instance of Isolation Trace
              var isolationTracer = traceManager.GetTracer<IsolationTracer>();
              // run the trace
              IReadOnlyList<Result> traceResult = isolationTracer.Trace(traceArgument);

              ElementResult elementResult = traceResult.OfType<ElementResult>().First();
              foreach (var element in elementResult.Elements)
              {
                var traceElement = new OutageTraceElement()
                {
                  AssetGroup = element.AssetGroup,
                  AssetType = element.AssetType,
                  GlobalID = element.GlobalID,
                  NetworkSource = element.NetworkSource,
                  ObjectID = element.ObjectID,
                  Terminal = element.Terminal
                };
                outageTraceResult.OutageTraceElements.Add(traceElement);
                var traceViewElement = new OutageTraceViewElement(element, NetworkUtil.GetRowForElement(utilityNetwork, element));
                outageTraceResult.OutageTraceViewElements.Add(traceViewElement);
              }
            }
          }
        }
      }
      catch (Exception e)
      {
        outageTraceResult.Success = false;
        outageTraceResult.Message += $@"Error: {e.Message}";
        return outageTraceResult;
      }
      outageTraceResult.Success = true;
      return outageTraceResult;
    }
    internal static OutageTraceResult RunTrace(UtilityNetwork utilityNetwork,
        Geodatabase utilityNetworkGeodatabase,
        UtilityNetworkDefinition utilityNetworkDefinition,
        Geodatabase defaultGeodatabase,
        Tracer tracer, Element startingPointElement,
        bool addFilter = false, IReadOnlyList<Element> barriers = null)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };

      // Get the Domain Network and Medium Voltage Tier
      DomainNetwork electricDomainNetwork = utilityNetworkDefinition.GetDomainNetwork(NetworkConstants.ElectricDomainNetwork);

      // Set up the trace configuration
      TraceConfiguration traceConfiguration = new TraceConfiguration
      {
        // Configure the trace to use the electric domain network
        DomainNetwork = electricDomainNetwork
      };
      traceConfiguration.IncludeBarriersWithResults = barriers != null;

      // Create starting point list and trace argument object
      List<Element> startingPointList = new List<Element>() { startingPointElement };
      TraceArgument traceArgument = new TraceArgument(startingPointList)
      {
        Configuration = traceConfiguration        
      };
      if (barriers != null)
      {
        traceArgument.Barriers = barriers;
      }

      try
      {
        using (NetworkAttribute isSubNetAttribute = utilityNetworkDefinition.GetNetworkAttribute("Is subnetwork controller"))
        {
          if (addFilter)
          {
            ConditionalExpression subNetCondition = new NetworkAttributeComparison(isSubNetAttribute, Operator.Equal, false);
            traceConfiguration.Filter.Barriers = subNetCondition;
            traceConfiguration.Filter.Scope = TraversabilityScope.JunctionsAndEdges;
          }
          IReadOnlyList<Result> traceResult = tracer.Trace(traceArgument);

          ElementResult elementResult = traceResult.OfType<ElementResult>().First();
          foreach (var element in elementResult.Elements)
          {
            var traceElement = new OutageTraceElement()
            {
              AssetGroup = element.AssetGroup,
              AssetType = element.AssetType,
              GlobalID = element.GlobalID,
              NetworkSource = element.NetworkSource,
              ObjectID = element.ObjectID,
              Terminal = element.Terminal
            };
            outageTraceResult.OutageTraceElements.Add(traceElement);
            var traceViewElement = new OutageTraceViewElement(element, NetworkUtil.GetRowForElement(utilityNetwork, element));
            outageTraceResult.OutageTraceViewElements.Add(traceViewElement);

          }
        }
      }
      catch (Exception e)
      {
        outageTraceResult.Success = false;
        outageTraceResult.Message += $@"Error: {e.Message}";
        return outageTraceResult;
      }
      outageTraceResult.Success = true;
      return outageTraceResult;
    }

    internal static OutageTraceResult RunShortPathTrace(UtilityNetwork utilityNetwork,
          Geodatabase utilityNetworkGeodatabase,
          UtilityNetworkDefinition utilityNetworkDefinition,
          Geodatabase defaultGeodatabase,
          ShortestPathTracer tracer, List<Element> startingPointElements)
    {
      // Create a new results object.  We use this class to pass back a set of data from the worker thread to the UI thread
      OutageTraceResult outageTraceResult = new OutageTraceResult
      {
        OutageTraceElements = new List<OutageTraceElement>(),
        OutageTraceViewElements = new List<OutageTraceViewElement>()
      };

      // Get the Domain Network and Medium Voltage Tier
      DomainNetwork electricDomainNetwork = utilityNetworkDefinition.GetDomainNetwork(NetworkConstants.ElectricDomainNetwork);

      // Set up the trace configuration
      TraceConfiguration traceConfiguration = new TraceConfiguration
      {
        // Configure the trace to use the electric domain network
        DomainNetwork = electricDomainNetwork
      };

      // Create starting point list and trace argument object
      TraceArgument traceArgument = new TraceArgument(startingPointElements)
      {
        Configuration = traceConfiguration
      };
      try
      {
        using (NetworkAttribute shapeLengthAttribute = utilityNetworkDefinition.GetNetworkAttribute("Shape Length"))
        {
          traceArgument.Configuration.ShortestPathNetworkAttribute = shapeLengthAttribute;
          IReadOnlyList<Result> traceResult = tracer.Trace(traceArgument);

          ElementResult elementResult = traceResult.OfType<ElementResult>().First();
          foreach (var element in elementResult.Elements)
          {
            var traceElement = new OutageTraceElement()
            {
              AssetGroup = element.AssetGroup,
              AssetType = element.AssetType,
              GlobalID = element.GlobalID,
              NetworkSource = element.NetworkSource,
              ObjectID = element.ObjectID,
              Terminal = element.Terminal
            };
            outageTraceResult.OutageTraceElements.Add(traceElement);
            var traceViewElement = new OutageTraceViewElement(element, NetworkUtil.GetRowForElement(utilityNetwork, element));
            outageTraceResult.OutageTraceViewElements.Add(traceViewElement);

          }
        }
      }
      catch (Exception e)
      {
        outageTraceResult.Success = false;
        outageTraceResult.Message += $@"Error: {e.Message}";
        return outageTraceResult;
      }
      outageTraceResult.Success = true;
      return outageTraceResult;
    }
  }

  /// <summary>
  /// Represents the result of the load report
  /// </summary>
  /// <remarks>
  /// This class is used to pass back information from the worker thread back to the Button (which executes on a UI thread).  
  /// The Message property is used to return error messages.
  /// </remarks>
  /// 
  internal class OutageTraceResult
  {
    public bool Success { get; set; }
    public string Message { get; set; }
    public List<OutageTraceElement> OutageTraceElements { get; set; }
    public List<OutageTraceViewElement> OutageTraceViewElements { get; set; }
  }

  internal class OutageTraceElement
  {
    //
    // Summary:
    //     Gets the ArcGIS.Core.Data.UtilityNetwork.NetworkSource (usually a table) that
    //     stores the Row represented by the Element.
    public NetworkSource NetworkSource { get; set; }
    //
    // Summary:
    //     Gets the ArcGIS.Core.Data.UtilityNetwork.AssetGroup of the Row represented by
    //     the Element.
    public AssetGroup AssetGroup { get; set; }
    //
    // Summary:
    //     Gets the ArcGIS.Core.Data.UtilityNetwork.AssetType of the Row represented by
    //     the Element.
    public AssetType AssetType { get; set; }
    //
    // Summary:
    //     Gets the GlobalID of the Row represented by the Element.
    public Guid GlobalID { get; set; }
    //
    // Summary:
    //     Gets the ObjectID of the Row represented by the Element.
    //
    // Remarks:
    //     If the Element was constructed using an ArcGIS.Core.Data.UtilityNetwork.Element.AssetType
    //     and GlobalID, rather than a ArcGIS.Core.Data.Row, this property will return a
    //     -1. The Element does not fetch the row to obtain this information if it doesn't
    //     already have it.
    public long ObjectID { get; set; }
    //
    // Summary:
    //     Gets or sets The ArcGIS.Core.Data.UtilityNetwork.Terminal of the Row represented
    //     by the Element.
    //
    // Exceptions:
    //   T:System.ArgumentException:
    //     If value is not null and is not a member of the ArcGIS.Core.Data.UtilityNetwork.TerminalConfiguration
    //     of ArcGIS.Core.Data.UtilityNetwork.Element.AssetType.
    public Terminal Terminal { get; set; }
  }

  internal class OutageTraceViewElement
  {
    public OutageTraceViewElement(Element element, Feature feature)
    {
      Element = element;
      AssetGroupName = element.AssetGroup?.Name;
      AssetTypeName = element.AssetType?.Name;
      NetworkSourceName = element.NetworkSource?.Name;
      NetworkSource = element.NetworkSource;
      ObjectID = element.ObjectID;
      GlobalID = element.GlobalID;
      TerminalName = element.Terminal?.Name;

      MapShape = feature.GetShape().Clone();
    }

    internal string NetworkSourceName { get; set; }

    internal NetworkSource NetworkSource { get; set; }

    internal Geometry MapShape { get; set; }

    internal Geometry MapCenterShape { get; set; }

    internal Geometry OwnerParcel { get; set; }

    internal long OwnerParcelOId { get; set; }

    internal Geometry DiagramShape { get; set; }

    internal Guid GlobalID { get; }

    public long ObjectID { get; set; }

    internal string TerminalName { get; set; }

    internal Element Element { get; set; }

    public string AssetGroupName { get; set; }

    public string Address { get; set; }

    public string AssetTypeName { get; set; }

    internal static bool SetDiagramShape(List<OutageTraceViewElement> outageElements,
      Guid globalId,
      Geometry diagramGeom)
    {
      foreach (var outageElement in outageElements)
      {
        if (outageElement.GlobalID == globalId)
        {
          outageElement.DiagramShape = diagramGeom;
          return true;
        }
      }
      return false;
    }

    internal static void SetOwnerParcelShape(List<OutageTraceViewElement> outageElements, FeatureClass taxParcels)
    {
      foreach (var outageElement in outageElements)
      {
        if (outageElement.MapShape is Polyline geomPoly)
        {
          outageElement.MapCenterShape = GeometryEngine.Instance.MovePointAlongLine(geomPoly, 0.5, true, 0, SegmentExtension.NoExtension);
        }
        if (outageElement.MapShape is MapPoint geomPoint)
        {
          var query = new SpatialQueryFilter() { FilterGeometry = geomPoint, SpatialRelationship = SpatialRelationship.Intersects };
          using (RowCursor cursor = taxParcels.Search(query))
          {
            while (cursor.MoveNext())
            {
              using (Feature currentFeature = cursor.Current as Feature)
              {
                var projectedPoly = GeometryEngine.Instance.Project(currentFeature.GetShape(), geomPoint.SpatialReference);
                outageElement.OwnerParcel = currentFeature.GetShape().Clone();
                outageElement.OwnerParcelOId = currentFeature.GetObjectID();
                var addr = currentFeature["SITEADDRESS"];
                if (addr == null) continue;
                outageElement.Address = addr == null ? "" : addr.ToString();
              }
            }
          }
        }
      }
    }
  }

  internal class NetworkUtil
  {
    internal static DiagramManager GetDiagManager(UtilityNetworkLayer utilNetworkLayer)
    {
      DiagramManager dm = null;
      UtilityNetwork utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer);
      {
        if (utilityNetwork != null) dm = utilityNetwork.GetDiagramManager();
      }
      return dm;
    }

    /// <summary>
    /// GetStartingPointRow
    /// 
    /// This routine opens up the starting points table and tries to read a row.  This table is created in 
    /// the default project workspace when the user first creates a starting point.
    /// 
    /// If the table doesn't exist or is empty, we add an error to our results object a null row.
    /// If the table contains one row, we just return the row
    /// If the table contains more than one row, we return the first row, and log a warning message
    ///		(this tool only works with one starting point)
    /// 
    /// </summary>
    internal static Row GetStartingPointRow(Geodatabase defaultGeodatabase, ref OutageTraceResult results)
    {
      try
      {
        using (FeatureClass startingPointsFeatureClass = defaultGeodatabase.OpenDataset<FeatureClass>(NetworkConstants.StartingPointsTableName))
        using (RowCursor startingPointsCursor = startingPointsFeatureClass.Search())
        {
          if (startingPointsCursor.MoveNext())
          {
            Row row = startingPointsCursor.Current;

            if (startingPointsCursor.MoveNext())
            {
              // If starting points table has more than one row, append warning message
              results.Message += "Multiple starting points found.  Only the first one was used.";
              startingPointsCursor.Current.Dispose();
            }
            return row;

          }
          else
          {
            // If starting points table has no rows, exit with error message
            results.Message += "No starting points found.  Please create one using the Set Trace Locations tool.\n";
            results.Success = false;
            return null;
          }
        }
      }
      // If we cannot open the feature class, an exception is thrown
      catch (Exception)
      {
        results.Message += "No starting points found.  Please create one using the Set Trace Locations tool.\n";
        results.Success = false;
        return null;
      }
    }

    /// <summary>
    /// This routine takes a row from the starting (or barrier) point table and converts it to a [Network] Element that we can use for tracing
    /// </summary>
    /// <param name="pointRow">The Row (either starting point or barrier point)</param>
    /// <param name="utilityNetwork">Utility Network to be used</param>
    /// <param name="definition">Utility Network definition to be used</param>
    /// <returns>newly created element</returns>
    internal static Element GetElementFromPointRow(Row pointRow,
        UtilityNetwork utilityNetwork, UtilityNetworkDefinition definition)
    {
      // Fetch the SourceID, AssetGroupCode, AssetType, GlobalID, and TerminalID values from the starting point row
      int sourceID = (int)pointRow[NetworkConstants.PointsSourceIDFieldName];
      int assetGroupID = (int)pointRow[NetworkConstants.PointsAssetGroupFieldName];
      int assetTypeID = (int)pointRow[NetworkConstants.PointsAssetTypeFieldName];
      Guid globalID = new Guid(pointRow[NetworkConstants.PointsGlobalIDFieldName].ToString());
      int terminalID = (int)pointRow[NetworkConstants.PointsTerminalFieldName];
      double percentAlong = (double)pointRow[NetworkConstants.PointsPercentAlong];

      // Fetch the NetworkSource, AssetGroup, and AssetType objects
      NetworkSource networkSource = definition.GetNetworkSources().First(x => x.ID == sourceID);
      AssetGroup assetGroup = networkSource.GetAssetGroups().First(x => x.Code == assetGroupID);
      AssetType assetType = assetGroup.GetAssetTypes().First(x => x.Code == assetTypeID);

      // Fetch the Terminal object from the ID
      Terminal terminal = null;

      if (assetType.IsTerminalConfigurationSupported())
      {
        TerminalConfiguration terminalConfiguration = assetType.GetTerminalConfiguration();
        terminal = terminalConfiguration.Terminals.First(x => x.ID == terminalID);
      }

      // Create and return a FeatureElement object
      // If we have an edge, set the PercentAlongEdge property; otherwise set the Terminal property
      if (networkSource.Type == SourceType.Edge)
      {
        Element element = utilityNetwork.CreateElement(assetType, globalID);
        element.PercentAlongEdge = percentAlong;
        return element;
      }
      else
      {
        Element element = utilityNetwork.CreateElement(assetType, globalID, terminal);
        return element;
      }
    }

    internal static Element GetElementFromWorkorder(Workorder workorder,
        UtilityNetwork utilityNetwork, UtilityNetworkDefinition definition)
    {
      // Fetch the SourceID, AssetGroupCode, AssetType, GlobalID, and TerminalID values from the starting point row
      int sourceID = workorder.PointsSourceID;
      int assetGroupID = workorder.PointsAssetGroup;
      int assetTypeID = workorder.PointsAssetType;
      Guid globalID = workorder.GlobalId;
      int terminalID = workorder.PointsTerminal;
      double percentAlong = workorder.PointsPercentAlong;

      // Fetch the NetworkSource, AssetGroup, and AssetType objects
      NetworkSource networkSource = definition.GetNetworkSources().First(x => x.ID == sourceID);
      AssetGroup assetGroup = networkSource.GetAssetGroups().First(x => x.Code == assetGroupID);
      AssetType assetType = assetGroup.GetAssetTypes().First(x => x.Code == assetTypeID);

      // Fetch the Terminal object from the ID
      Terminal terminal = null;

      if (assetType.IsTerminalConfigurationSupported())
      {
        TerminalConfiguration terminalConfiguration = assetType.GetTerminalConfiguration();
        terminal = terminalConfiguration.Terminals.First(x => x.ID == terminalID);
      }

      // Create and return a FeatureElement object
      // If we have an edge, set the PercentAlongEdge property; otherwise set the Terminal property
      if (networkSource.Type == SourceType.Edge)
      {
        Element element = utilityNetwork.CreateElement(assetType, globalID);
        element.PercentAlongEdge = percentAlong;
        return element;
      }
      else
      {
        Element element = utilityNetwork.CreateElement(assetType, globalID, terminal);
        return element;
      }
    }

    /// <summary>
    /// This routine validates the utility network schema matches what we are expecting
    /// </summary>
    /// <param name="utilityNetwork"></param>
    /// <returns>true if the data model has all of the correct schema</returns>
    internal static bool ValidateDataModel(UtilityNetwork utilityNetwork)
    {
      bool dataModelIsValid = false;

      using (UtilityNetworkDefinition utilityNetworkDefinition = utilityNetwork.GetDefinition())
      {
        try
        {
          DomainNetwork electricDomainNetwork = utilityNetworkDefinition.GetDomainNetwork(NetworkConstants.ElectricDomainNetwork);
          Tier mediumVoltageTier = electricDomainNetwork.GetTier(NetworkConstants.MediumVoltageTier);
          NetworkAttribute phaseNetworkAttribute = utilityNetworkDefinition.GetNetworkAttribute(NetworkConstants.PhaseAttributeName);
          NetworkAttribute loadNetworkAttribute = utilityNetworkDefinition.GetNetworkAttribute(NetworkConstants.LoadAttributeName);
          if (utilityNetworkDefinition.GetAvailableCategories().Contains(NetworkConstants.ServicePointCategory))
          {
            dataModelIsValid = true;
          }
        }
        catch (Exception) { };

      }
      return dataModelIsValid;
    }

    /// <summary>
    /// GetUtilityNetworkFromFeatureClass - gets a utility network from a layer
    /// </summary>
    /// <param name="layer"></param>
    /// <returns>a UtilityNetwork object, or null if the layer does not reference a utility network</returns>
    internal static UtilityNetwork GetUtilityNetworkFromLayer(Layer layer)
    {

      UtilityNetwork utilityNetwork = null;

      if (layer is UtilityNetworkLayer)
      {
        UtilityNetworkLayer utilityNetworkLayer = layer as UtilityNetworkLayer;
        utilityNetwork = utilityNetworkLayer.GetUtilityNetwork();
      }

      else if (layer is SubtypeGroupLayer)
      {
        CompositeLayer compositeLayer = layer as CompositeLayer;
        utilityNetwork = GetUtilityNetworkFromLayer(compositeLayer.Layers.First());
      }

      else if (layer is FeatureLayer)
      {
        FeatureLayer featureLayer = layer as FeatureLayer;
        using (FeatureClass featureClass = featureLayer.GetFeatureClass())
        {
          if (featureClass.IsControllerDatasetSupported())
          {
            IReadOnlyList<Dataset> controllerDatasets = new List<Dataset>();
            controllerDatasets = featureClass.GetControllerDatasets();
            foreach (Dataset controllerDataset in controllerDatasets)
            {
              if (controllerDataset is UtilityNetwork)
              {
                utilityNetwork = controllerDataset as UtilityNetwork;
              }
              else
              {
                controllerDataset.Dispose();
              }
            }
          }
        }
      }

      else if (layer is GroupLayer)
      {
        CompositeLayer compositeLayer = layer as CompositeLayer;
        foreach (Layer childLayer in compositeLayer.Layers)
        {
          utilityNetwork = GetUtilityNetworkFromLayer(childLayer);
          // Break at the first layer inside a group layer that belongs to a utility network
          if (utilityNetwork != null) break;
        }
      }
      return utilityNetwork;
    }

    internal static Task<List<Guid>> SelectElementsAsync(List<OutageTraceViewElement> viewElements,
      bool bAddToSelection = false, bool bZoomToSelection = false)
    {
      var map = MapView.Active?.Map;
      if (map == null) return null;
      return QueuedTask.Run(() =>
      {
        map.ClearSelection();

        var guids = new List<Guid>();

        var elements = viewElements.Select(e => e.Element);
        var selection = new Dictionary<MapMember, List<long>>();
        var lastLayerName = string.Empty;
        MapMember lastMapMember = null;
        foreach (var element in elements)
        {
          guids.Add(element.GlobalID);
          if (element.NetworkSource.Name != lastLayerName)
          {
            lastLayerName = element.NetworkSource.Name;
            lastMapMember = map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.GetFeatureClass().GetName() == lastLayerName);
            if (lastMapMember == null)
            {
              System.Diagnostics.Trace.WriteLine($@"Unable to load map member for: {lastLayerName}");
            }
          }
          if (lastMapMember == null) continue;
          if (selection.ContainsKey(lastMapMember))
          {
            selection[lastMapMember].Add(element.ObjectID);
          }
          else
          {
            selection.Add(lastMapMember, new List<long>() { element.ObjectID });
          }
        }
        map.SetSelection(selection, bAddToSelection ? SelectionCombinationMethod.Add : SelectionCombinationMethod.New);
        if (bZoomToSelection) _ = MapView.Active.ZoomToSelectedAsync();

        return guids;
      });
    }

    internal static void FlashElement(Element element)
    {
      _ = QueuedTask.Run(() =>
      {
        (FeatureLayer FeatLyr, long Oid) flashElement;
        using (var utilNetwork = GetUtilityNetwork())
        {
          flashElement = GetFeatureLayerOidForElement(element);
        }
        if (flashElement.FeatLyr != null)
        {
          MapView.Active.FlashFeature(flashElement.FeatLyr, flashElement.Oid, true);
        }
      });
    }

    internal static UtilityNetwork GetUtilityNetwork()
    {
      var activeMap = MapView.Active?.Map;
      if (activeMap == null)
      {
        // ("Can't find an active map.  Make sure to activate a map view.");
        return null;
      }
      var utilNetworkLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<UtilityNetworkLayer>().FirstOrDefault();
      if (utilNetworkLayer == null)
      {
        // ("Can't find a Utility Network Layer.");
        return null;
      }
      var utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer);
      return utilityNetwork;
    }

    /// <summary>
    /// Gets a Row for an Element
    /// </summary>
    /// <param name="utilityNetwork">The utility network to which the element belongs</param>
    /// <param name="element">An element in a utility network</param>
    /// <returns>The Row corresponding to the Element (if any)</returns>
    internal static Feature GetRowForElement(UtilityNetwork utilityNetwork, Element element)
    {
      // Get the table from the element
      using (Table table = utilityNetwork.GetTable(element.NetworkSource))
      {
        // Create a query filter to fetch the appropriate row
        QueryFilter queryFilter = new QueryFilter()
        {
          ObjectIDs = new List<long>() { element.ObjectID }
        };

        // Fetch and return the row
        using (RowCursor rowCursor = table.Search(queryFilter))
        {
          if (rowCursor.MoveNext())
          {
            return rowCursor.Current as Feature;
          }
        }
        return null;
      }
    }

    /// <summary>
    /// Gets a feature class and oid for an Element
    /// </summary>
    /// <param name="element">An element in a utility network</param>
    /// <returns>The Row corresponding to the Element (if any)</returns>
    internal static (FeatureLayer FeatLyr, long Oid) GetFeatureLayerOidForElement(Element element)
    {
      if (MapView.Active?.Map != null)
      {
        var lyr = MapView.Active?.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.GetFeatureClass().GetName() == element.NetworkSource.Name);
        return (lyr, element.ObjectID);
      }
      return (null, -1);
    }

  }
}
