﻿using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Editing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerOutagePlanning
{
  /// <summary>
  /// Workorder sample definitions
  /// </summary>
  public class Workorder
  {
    /// <summary>
    /// CTor
    /// </summary>
    /// <param name="currentFeature"></param>
    /// <param name="utilityNetworkPath"></param>
    public Workorder(Feature currentFeature, string utilityNetworkPath)
    {
      var description = currentFeature["Description"].ToString();
      var name = $@"{description}: {currentFeature["DisplayName"]}";
      var lyrName = currentFeature["LayerName"].ToString();
      var oid = currentFeature.GetObjectID();
      var targetOid = Convert.ToInt64(currentFeature["FeatureOid"]);
      var targetGlobalId = Guid.Parse(currentFeature["FeatureGlobalId"].ToString());
      var workorderNo = $@"{currentFeature["WorkorderNo"]}";
      PointsSourceID = Convert.ToInt32(currentFeature[NetworkConstants.PointsSourceIDFieldName]);
      PointsAssetGroup = Convert.ToInt32(currentFeature[NetworkConstants.PointsAssetGroupFieldName]);
      PointsAssetType = Convert.ToInt32(currentFeature[NetworkConstants.PointsAssetTypeFieldName]);
      PointsTerminal = Convert.ToInt32(currentFeature[NetworkConstants.PointsTerminalFieldName]);
      PointsPercentAlong = Convert.ToInt32(currentFeature[NetworkConstants.PointsPercentAlong]);
      Name = name;
      ObjectId = oid;
      var lineShape = GetShapeFromElement(utilityNetworkPath, NetworkConstants.LineFeatureClassName, targetOid);
      if (lineShape != null)
      {
        if (lineShape is Polyline geomPoly)
        {
          MapShape = GeometryEngine.Instance.MovePointAlongLine(geomPoly, 0.5, true, 0, SegmentExtension.NoExtension);
        }
        else
        {
          MapShape = lineShape;
        }
      }
      else
      {
        MapShape = currentFeature.GetShape().Clone();
      }
      TargetLayerName = lyrName;
      TargetFeatureOid = targetOid;
      WorkorderNo = workorderNo;
      GlobalId = targetGlobalId;
      Description = description;
    }

    internal static Geometry GetShapeFromElement(string utilityNetworkPath,
      string lyrName, long oid)
    {
      using (Geodatabase networkGdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(utilityNetworkPath))))
      {
        using (FeatureClass fc = networkGdb.OpenDataset<FeatureClass>(lyrName))
        {
          QueryFilter queryFilter = new QueryFilter()
          {
            ObjectIDs = new List<long>() { oid }
          };

          // Fetch and return the row
          using (RowCursor rowCursor = fc.Search(queryFilter))
          {
            if (rowCursor.MoveNext())
            {
              return (rowCursor.Current as Feature).GetShape().Clone();
            }
          }
          return null;
        }
      }
    }

    /// <summary>
    /// Name of workorder
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Description (type of failure) of work
    /// </summary>
    public string Description { get; set; }

    /// <summary>
    /// Object Id of associated Element
    /// </summary>
    public long ObjectId { get; set; }

    /// <summary>
    /// Global Id of associated Element
    /// </summary>
    public Guid GlobalId { get; set; }

    /// <summary>
    /// Shape location of workorder
    /// </summary>
    public Geometry MapShape { get; set; }

    /// <summary>
    /// Location of Diagram shape
    /// </summary>
    public Geometry DiagramShape { get; set; }

    /// <summary>
    /// target of workorder 
    /// </summary>
    public long TargetFeatureOid { get; set; }

    /// <summary>
    /// target layer of workorder 
    /// </summary>
    public string TargetLayerName { get; set; }

    /// <summary>
    /// workorder No
    /// </summary>
    public string WorkorderNo { get; set; }

    internal int PointsSourceID { get; set; }

    internal int PointsAssetGroup { get; set; }

    internal int PointsAssetType { get; set; }

    internal int PointsTerminal { get; set; }

    internal double PointsPercentAlong { get; set; }

    internal Element GetElement (UtilityNetwork utilityNetwork, UtilityNetworkDefinition definition)
    {
      return NetworkUtil.GetElementFromWorkorder(this, utilityNetwork, definition);
    }
  }
}
