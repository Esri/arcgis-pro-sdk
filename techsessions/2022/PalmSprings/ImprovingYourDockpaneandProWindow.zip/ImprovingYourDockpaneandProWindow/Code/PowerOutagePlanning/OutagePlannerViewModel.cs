﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Data.UtilityNetwork.NetworkDiagrams;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Core.Geoprocessing;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace PowerOutagePlanning
{
  internal class OutagePlannerViewModel : DockPane
  {
    private const string _dockPaneID = "PowerOutage_OutagePlanner";
    private ObservableCollection<Workorder> _workorders = new ObservableCollection<Workorder>();

    private Workorder _workorder = null;

    private readonly object _lockWoCollection = new object();
    private readonly object _lockSECollection = new object();

    private bool _enableIsolate = false;
    private bool _enableConnect = false;
    private bool _enableDiagram = false;
    private bool _enableReport = false;

    private List<string> _filterByItems = new List<string> { "All Assets", "Switches only", "Customer Service Points", "Transformers", "Power lines" };
    private string _filterByItem = string.Empty;
    private string _processWorkorder = string.Empty;
    private string _subnetworkName = "";
    private string _heading1 = "Select a Work Order";
    private string _errorStatus = "";
    private string _downStreamResult = string.Empty;
    private string mapCaption = "Power Outage";

    private ICollectionView _outageTraceViewElements;
    private OutageTraceViewElement _outageTraceViewElement;
    private List<OutageTraceViewElement> _isolationElements = null;
    private List<Guid> _globalIds = new List<Guid>();
    private Dictionary<MapMember, List<long>> _connectedSelection = null;

    private System.Windows.Media.Imaging.BitmapImage _imageUncheck = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"pack://application:,,,/ArcGIS.Desktop.Resources;component/Images/GenericExport16.png"));
    private System.Windows.Media.Imaging.BitmapImage _imageCheck = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"pack://application:,,,/ArcGIS.Desktop.Resources;component/Images/GenericCheckMark16.png"));

    private System.Windows.Media.Imaging.BitmapImage _imageReport;
    private System.Windows.Media.Imaging.BitmapImage _imageDiagram;
    private System.Windows.Media.Imaging.BitmapImage _imageSelect;
    private System.Windows.Media.Imaging.BitmapImage _imageIsolate;
    private System.Windows.Media.Imaging.BitmapImage _imageConnected;

    private System.Windows.Media.Brush _backSelect = System.Windows.Media.Brushes.Pink;
    private System.Windows.Media.Brush _backIsolatePower = System.Windows.Media.Brushes.Pink;
    private System.Windows.Media.Brush _backFindAffected = System.Windows.Media.Brushes.Pink;
    private System.Windows.Media.Brush _backDiagram = System.Windows.Media.Brushes.Pink;
    private System.Windows.Media.Brush _backReport = System.Windows.Media.Brushes.Pink;
    
    private double _maxProgressValue;
    private double _ProgressValue;
    private string _progressText = string.Empty;
    private System.Windows.Visibility _progressBarVisibility = System.Windows.Visibility.Collapsed;
    private System.Windows.Visibility _busyVisibility = System.Windows.Visibility.Visible;

    private static OutagePlannerViewModel _this = null;
    private NetworkDiagram _networkDiagram = null;

    protected OutagePlannerViewModel()
    {
      // TODO: 1. enable _workorders for updates from background threads
      BindingOperations.EnableCollectionSynchronization(_workorders, _lockWoCollection);

      ActiveMapViewChangedEvent.Subscribe(OnActiveMapViewChangedEvent);
      _this = this;
      ImageReport = _imageUncheck;
      ImageDiagram = _imageUncheck;
      ImageSelect = _imageUncheck;
      ImageIsolate = _imageUncheck;
      ImageConnected = _imageUncheck;
      BackSelect = System.Windows.Media.Brushes.Pink;
      BackIsolatePower = System.Windows.Media.Brushes.Pink;
      BackFindAffected = System.Windows.Media.Brushes.Pink;
      BackDiagram = System.Windows.Media.Brushes.Pink;
      BackReport = System.Windows.Media.Brushes.Pink;
    }

    /// <summary>
    /// Initializes async...
    /// </summary>
    /// <returns>A Task that represents InitializeAsync </returns>
    protected override async Task InitializeAsync()
    {
      OnActiveMapViewChangedEvent(null);
      await base.InitializeAsync();
    }

    public ObservableCollection<Workorder> Workorders => _workorders;

    public Workorder Workorder
    {
      get { return _workorder; }
      set
      {
        SetProperty(ref _workorder, value, () => Workorder);

        var mapPanes = ProApp.Panes.OfType<IMapPane>().Where((p) => p.Caption != mapCaption).Cast<Pane>();
        var layoutPanes = ProApp.Panes.OfType<ILayoutPane>().Cast<Pane>();
        foreach (Pane pane in mapPanes)
          ProApp.Panes.ClosePane(pane.InstanceID);
        foreach (Pane pane in layoutPanes)
          ProApp.Panes.ClosePane(pane.InstanceID);
        _ = QueuedTask.Run(() =>
        {
          List<IProjectItem> lstProject = new List<IProjectItem>();
          var projMapItems = Project.Current.Items
              .OfType<MapProjectItem>()
              .Where((p) => !p.Name.Contains(mapCaption)).Cast<IProjectItem>();
          var projLayoutItems = Project.Current.Items
              .OfType<LayoutProjectItem>().Cast<IProjectItem>();
          lstProject.AddRange(projMapItems);
          lstProject.AddRange(projLayoutItems);
          foreach (var pi in lstProject)
            Project.Current.RemoveItem(pi);
        });
        DockPane dockpane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
        if (dockpane == null) return;
        if (!dockpane.IsVisible) dockpane.Activate();
        if (MapView.Active != null && Workorder != null)
        {
          var cam = MapView.Active.Camera;
          cam.Scale = 2000;
          cam.X = (Workorder.MapShape as MapPoint).X;
          cam.Y = (Workorder.MapShape as MapPoint).Y;
          cam.Z = (Workorder.MapShape as MapPoint).Z;
          MapView.Active.ZoomToAsync(cam);
          var featureLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals("Workorders", StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
          if (featureLayer != null)
          {
            _ = QueuedTask.Run(() =>
            {
              var cd = new CIMDefinitionFilter() { Name = "Workorder", DefinitionExpression = $@"objectid = {Workorder.ObjectId}" };
              featureLayer.SetDefinitionFilter(cd);
            });
          }
        }
        ClearAnalyzerSettings();
      }
    }

    private async void ClearAnalyzerSettings()
    {
      if (OutageTraceViewElements != null)
        OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList().Clear();
      ProcessWorkorder = string.Empty;
      SubnetworkName = string.Empty;
      OutageTraceViewElements = null;
      EnableIsolate = false;
      EnableConnect = false;
      EnableDiagram = false;
      EnableReport = false;
      ImageReport = _imageUncheck;
      ImageDiagram = _imageUncheck;
      ImageSelect = _imageUncheck;
      ImageIsolate = _imageUncheck;
      ImageConnected = _imageUncheck;
      BackSelect = System.Windows.Media.Brushes.Pink;
      BackIsolatePower = System.Windows.Media.Brushes.Pink;
      BackFindAffected = System.Windows.Media.Brushes.Pink;
      BackDiagram = System.Windows.Media.Brushes.Pink;
      BackReport = System.Windows.Media.Brushes.Pink;
      //ServiceElements.Clear();

      await QueuedTask.Run(() =>
         {
           MapUtil.ClearLabels();
           MapView.Active?.Map?.ClearSelection();
         });
    }

    #region UI properties

    public double MaxProgressValue
    {
      get { return _maxProgressValue; }
      set
      {
        SetProperty(ref _maxProgressValue, value, () => MaxProgressValue);
      }
    }

    public double ProgressValue
    {
      get { return _ProgressValue; }
      set
      {
        SetProperty(ref _ProgressValue, value, () => ProgressValue);
      }
    }

    public string ProgressText
    {
      get { return _progressText; }
      set
      {
        SetProperty(ref _progressText, value, () => ProgressText);
      }
    }

    public System.Windows.Visibility ProgressBarVisibility
    {
      get { return _progressBarVisibility; }
      set
      {
        SetProperty(ref _progressBarVisibility, value, () => ProgressBarVisibility);
      }
    }

    public System.Windows.Visibility BusyVisibility
    {
      get { return _busyVisibility; }
      set
      { SetProperty(ref _busyVisibility, value, () => BusyVisibility); }
    }

    public ICommand CmdReloadWorkorders
    {
      get
      {
        return new RelayCommand(async () =>
        {
          // TODO: ProgressBar 1) show the Progressbar and set the maxcount
          ProgressBarVisibility = System.Windows.Visibility.Visible;
          MaxProgressValue = Workorders.Count();
          Workorders.Clear();
          // TODO: 5: refresh workorders
          await LoadWorkordersAsync(MapView.Active);
          // TODO: ProgressBar 2) hide the Progressbar 
          ProgressBarVisibility = System.Windows.Visibility.Collapsed;
        });
      }
    }

    public ICommand CmdSelectWorkorder
    {
      get
      {
        return new RelayCommand(async () =>
        {
          //EnableAnalyze = await SelectOneWorkorderAync(Workorder);
          ProcessWorkorder = Workorder.Name;
          var geom = await FindWorkorderTargetFeature(Workorder);
          if (geom != null)
          {
            var twoLiner = $@"{WorkOrderName}{Environment.NewLine}{Workorder.Description}";
            _ = QueuedTask.Run(() =>
            {
              MapUtil.ShowCalloutBox(MapUtil.LabelType.Workorder, Workorder.MapShape, twoLiner);
            });
          }
          BackSelect = System.Windows.Media.Brushes.LightGreen;
          ImageSelect = _imageCheck;
          EnableIsolate = true;
        }, true);
      }
    }

    public ICommand CmdTraceIsolation
    {
      get
      {
        return new RelayCommand(async () =>
        {
          var utilNetworkLayer = MapUtil.GetUtilityNetworkLayer();
          if (utilNetworkLayer == null) return;
          OutageTraceViewElements = null;

          // Find the 'closest' point where to turn off power for our workorder:
          // RunIsolationTrace is used to pass back results from the worker thread to the UI thread that we're currently executing.
          OutageTraceResult traceResults = await QueuedTask.Run<OutageTraceResult>(() =>
          {
            return NetworkTrace.RunIsolationTracer(utilNetworkLayer, Workorder);
          });
          if (!traceResults.Success)
          {
            MessageBox.Show(traceResults.Message);
          }
          else
          {
            OutageTraceViewElements = CollectionViewSource.GetDefaultView(traceResults.OutageTraceViewElements);
            _isolationElements = new List<OutageTraceViewElement>();
            _ = NetworkUtil.SelectElementsAsync(traceResults.OutageTraceViewElements, true);
            if (traceResults.OutageTraceViewElements.Count <= 0)
            {
              MessageBox.Show("Isolation trace couldn't find isolating element in network.");
              return;
            }
            _ = QueuedTask.Run(() =>
            {
              foreach (var viewElement in traceResults.OutageTraceViewElements)
              {
                _isolationElements.Add(viewElement);
                MapUtil.ShowCalloutBox(MapUtil.LabelType.Isolation, viewElement.MapShape, $@"Isolation: {viewElement.ObjectID}");
              }
              var elements = new List<Geometry>
              {
                Workorder.MapShape
              };
              var lstIsoElements = _isolationElements.Select((e) => e.MapShape).ToList();
              elements.AddRange(lstIsoElements);
              var env = MapUtil.UnionGeometries(elements).Expand(1.5, 1.5, true);
              MapView.Active.ZoomTo(env);
            });
            _this.ActionOnGuiThread(() =>
            {
              _this._filterByItem = string.Empty;
              _this.EnableConnect = true;
            });
            // add the upstream trace but ignore the result
            // symbolize the shortPathTraceResults 
            _ = await QueuedTask.Run<OutageTraceResult>(() =>
            {
              var results = NetworkTrace.RunShortestPathTrace(utilNetworkLayer, Workorder, _isolationElements.Select((e) => e.Element).FirstOrDefault());
              MapView.Active?.Map?.ClearSelection();
              var geoms = results.OutageTraceViewElements.Where((e) => e.MapShape.GeometryType == GeometryType.Polyline).Select((e) => e.MapShape).ToList();
              foreach (var geom in geoms)
                MapUtil.ShowLine(MapUtil.LabelType.ShortestPath, geom);
              return results;
            });

          }
          BackIsolatePower = System.Windows.Media.Brushes.LightGreen;
          ImageIsolate = _imageCheck;
        }, true);
      }
    }

    public ICommand CmdTraceUpStream
    {
      get
      {
        return new RelayCommand(async () =>
        {
          var utilNetworkLayer = MapUtil.GetUtilityNetworkLayer();
          if (utilNetworkLayer == null) return;

          // Generate our report.  The LoadTraceResults class is used to pass back results from the worker thread to the UI thread that we're currently executing.
          OutageTraceResult traceResults = await QueuedTask.Run<OutageTraceResult>(() =>
          {
            return NetworkTrace.RunUpStreamTrace(utilNetworkLayer, Workorder, null);
          });
          if (!traceResults.Success)
          {
            MessageBox.Show(traceResults.Message);
          }
          else
          {
            _ = NetworkUtil.SelectElementsAsync(traceResults.OutageTraceViewElements, false, true);
            OutageTraceViewElements = CollectionViewSource.GetDefaultView(traceResults.OutageTraceViewElements);
            
            DownStreamResult = $@"Trace: {traceResults.Success}{Environment.NewLine}{traceResults.Message}";

            _this.ActionOnGuiThread(() =>
            {
              _this._filterByItem = string.Empty;
            });
          }
        }, true);
      }
    }

    public ICommand CmdTraceDownStream
    {
      get
      {
        return new RelayCommand(async () =>
        {
          var utilNetworkLayer = MapUtil.GetUtilityNetworkLayer();
          if (utilNetworkLayer == null) return;

          // Generate our report.  The LoadTraceResults class is used to pass back results from the worker thread to the UI thread that we're currently executing.
          OutageTraceResult traceResults = await QueuedTask.Run<OutageTraceResult>(() =>
          {
            return NetworkTrace.RunDownStreamTrace(utilNetworkLayer, Workorder);
          });
          if (!traceResults.Success)
          {
            MessageBox.Show(traceResults.Message);
          }
          else
          {
            _ = NetworkUtil.SelectElementsAsync(traceResults.OutageTraceViewElements);
            OutageTraceViewElements = CollectionViewSource.GetDefaultView(traceResults.OutageTraceViewElements);

            _this.ActionOnGuiThread(() =>
            {
              _this._filterByItem = string.Empty;
            });
          }
        }, true);
      }
    }

    public ICommand CmdTraceConnected
    {
      get
      {
        return new RelayCommand(async () =>
        {
          var utilNetworkLayer = MapUtil.GetUtilityNetworkLayer();
          if (utilNetworkLayer == null) return;
          FilterByItem = "All Assets";
          OutageTraceViewElements = null;
          _ = QueuedTask.Run(() => MapView.Active?.Map?.ClearSelection());

          // Generate our report.  The LoadTraceResults class is used to pass back results from the worker thread to the UI thread that we're currently executing.
          OutageTraceResult traceResults = await QueuedTask.Run<OutageTraceResult>(() =>
          {
            return NetworkTrace.RunConnectedTrace(utilNetworkLayer, Workorder, _isolationElements.Select((e) => e.Element).ToList());
          });
          if (!traceResults.Success)
          {
            MessageBox.Show(traceResults.Message);
          }
          else
          {
            _globalIds = await NetworkUtil.SelectElementsAsync(traceResults.OutageTraceViewElements);
            OutageTraceViewElements = CollectionViewSource.GetDefaultView(traceResults.OutageTraceViewElements);
            _ = QueuedTask.Run(() =>
            {
              MapUtil.ClearLabel(MapUtil.LabelType.Other);
              MapUtil.AutoLabelSwitches(true, traceResults.OutageTraceViewElements);

              var elements = traceResults.OutageTraceViewElements.Select((e) => e.MapShape).ToList();
              var env = MapUtil.UnionGeometries(elements);
              _connectedSelection = MapView.Active.Map.GetSelection();
              MapView.Active.Map.ClearSelection();
              MapView.Active.ZoomTo(env);
              var geoms = traceResults.OutageTraceViewElements
                  .Where((e) => e.MapShape.GeometryType == GeometryType.Polyline
                    && e.AssetGroupName.Contains("Medium"))
                  .Select((e) => e.MapShape).ToList();
              foreach (var geom in geoms)
                MapUtil.ShowLine(MapUtil.LabelType.ShortestPath, geom);
            });

            // collect customer locations
            var featureLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Contains("Parcels")).FirstOrDefault();
            if (featureLayer != null)
            {
              _ = QueuedTask.Run(() =>
              {
                // correct geometries and do overlays against parcel layer
                var woPath = System.IO.Path.Combine(Project.Current.HomeFolderPath, "Workorder.gdb");
                using (Geodatabase workorderGdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(woPath))))
                {
                  using (FeatureClass fc = workorderGdb.OpenDataset<FeatureClass>("TaxParcels"))
                  {
                    OutageTraceViewElement.SetOwnerParcelShape(OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList(),
                     fc);
                  }
                }
                // display only parcels that are part of the power outage area
                var oids = traceResults.OutageTraceViewElements.Where((e) => e.OwnerParcel != null).Select((e) => e.OwnerParcelOId).ToList();
                var oidList = string.Join(",", oids);
                var cd = new CIMDefinitionFilter() { Name = "Service Points", DefinitionExpression = $@"objectid in ({oidList})" };
                featureLayer.SetDefinitionFilter(cd);
              });
            }
            _this.ActionOnGuiThread(() =>
            {
              _this.EnableDiagram = true;
            });
          }
          BackFindAffected = System.Windows.Media.Brushes.LightGreen;
          ImageConnected = _imageCheck;
        }, true);
      }
    }

    public ICommand CmdZoomToSelection
    {
      get
      {
        return new RelayCommand(() =>
        {
          var activeMap = MapView.Active?.Map;
          if (activeMap == null)
          {
            MessageBox.Show("Can't find an active map.  Make sure to activate a map view.");
          }
          else
            _ = MapView.Active.ZoomToSelectedAsync();
        }, () =>
        {
          var activeMap = MapView.Active?.Map;
          if (activeMap == null) return false;
          return activeMap.SelectionCount > 0;
        });
      }
    }

    public ICommand CmdAutolabel
    {
      get
      {
        return new RelayCommand(async () =>
        {
          try
          {
            await QueuedTask.Run(() =>
            {
              MapUtil.ClearLabels();

              var elementQuery = new DiagramElementQueryByElementTypes();
              elementQuery.QueryDiagramEdgeElement = true;
              elementQuery.QueryDiagramJunctionElement = true;
              elementQuery.QueryDiagramContainerElement = false;

              var queryResult = _networkDiagram.QueryDiagramElements(elementQuery);

              var traceElements = OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList();
              // Create a NetworkDiagramSubset object to read this set of diagram elements
              foreach (var diagElement in queryResult.DiagramJunctionElements)
              {
                var geom = diagElement.Shape.Clone();
                if (geom.IsEmpty) continue;
                OutageTraceViewElement.SetDiagramShape(traceElements, diagElement.AssociatedGlobalID, geom);
                OutageTraceViewElement.SetDiagramShape(_isolationElements, diagElement.AssociatedGlobalID, geom);
                if (Workorder.GlobalId == diagElement.AssociatedGlobalID)
                {
                  Workorder.DiagramShape = geom;
                }
              }
              foreach (var diagElement in queryResult.DiagramEdgeElements)
              {
                var geom = diagElement.Shape.Clone();
                if (geom.IsEmpty) continue;
                if (geom is Polyline geomPoly)
                {
                  geom = GeometryEngine.Instance.MovePointAlongLine(geomPoly, 0.5, true, 0, SegmentExtension.NoExtension);
                }
                OutageTraceViewElement.SetDiagramShape(traceElements, diagElement.AssociatedGlobalID, geom);
                OutageTraceViewElement.SetDiagramShape(_isolationElements, diagElement.AssociatedGlobalID, geom);
                if (Workorder.GlobalId == diagElement.AssociatedGlobalID)
                {
                  Workorder.DiagramShape = geom;
                }
              }
              var lstElements = OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList();
              var lstIsoElements = _isolationElements.ToList();
              MapUtil.AutoLabelSwitches(false, lstElements, Workorder, lstIsoElements);

              var elements = lstElements.Select((e) => e.DiagramShape).ToList();
              var env = MapUtil.UnionGeometries(elements);
              MapView.Active.ZoomTo(env);
            });
          }
          catch (Exception ex)
          {
            MessageBox.Show($@"Error creating diagram: {ex.ToString()}");
          }
        }, true);
      }
    }

    public ICommand CmdCreateDiagram
    {
      get
      {
        return new RelayCommand(async () =>
        {
          try
          {
            if (PowerOutagePlanningModule.DebugActive)
            {
              UtilityNetworkLayer utilNetworkLayer = MapUtil.GetUtilityNetworkLayer();
              if (utilNetworkLayer == null) return;
              await QueuedTask.Run(async () =>
              {
                var utilityNetwork = NetworkUtil.GetUtilityNetworkFromLayer(utilNetworkLayer);

                // create an utility network diagram using the 'basic' template
                var diagramManager = utilityNetwork.GetDiagramManager();
                var template = diagramManager.GetDiagramTemplate("Basic"); // SimplifiedDiagrams

                #region Error checks
                if (template == null)
                {
                  MessageBox.Show("Error unable to find 'Basic' Diagram template");
                  return;
                }
                if (_globalIds == null || _globalIds.Count() == 0)
                {
                  MessageBox.Show("Error: selected set for diagram is empty");
                  return;
                }
                #endregion

                // Create the diagram & diagram map using the given template and the global ids of
                // all elements to be shown in the diagram
                _networkDiagram = diagramManager.CreateNetworkDiagram(template, _globalIds);

                // apply radial tree layout as the schematic view
                var layoutParameters = new RadialTreeDiagramLayoutParameters();
                _networkDiagram.ApplyLayout(layoutParameters);

                var newMap = MapFactory.Instance.CreateMap(WorkOrderName, ArcGIS.Core.CIM.MapType.NetworkDiagram, MapViewingMode.Map);

                //Add the diagram to the map
                var diagramLayer = newMap.AddDiagramLayer(_networkDiagram);

                #region Use diagram extent to see if you should rotate
                var isolateElement = _isolationElements.Select((e) => e.Element).FirstOrDefault();
                var rotateDiagram = isolateElement != null;
                if (rotateDiagram)
                {
                  DiagramElementQueryByElementTypes query = new DiagramElementQueryByElementTypes
                  {
                    QueryDiagramContainerElement = false,
                    QueryDiagramEdgeElement = false,
                    QueryDiagramJunctionElement = true
                  };
                  rotateDiagram = false;
                  var diagElementQueryResult = _networkDiagram.QueryDiagramElements(query);
                  foreach (var diagElement in diagElementQueryResult.DiagramJunctionElements)
                  {
                    if (isolateElement.GlobalID == diagElement.AssociatedGlobalID)
                    {
                      _networkDiagram.AddFlag(NetworkDiagramFlagType.PivotJunction, diagElement.ID);
                      rotateDiagram = true;
                      break;
                    }
                  }
                  if (rotateDiagram)
                  {
                    //  //rotate if needed using diagram extent
                    //  var layoutRotationParameters = new RotateTreeDiagramLayoutParameters();
                    //  layoutRotationParameters.Rotation = 90.0;
                    //  layoutRotationParameters.RotateJunction = false;
                    //  layoutRotationParameters.PreserveContainers = false;
                    //  _networkDiagram.ApplyLayout(layoutRotationParameters, InvocationTarget.SynchronousService);
                    var parameters = Geoprocessing.MakeValueArray(diagramLayer, false, 90.0, false, false);
                    var gpResult = await Geoprocessing.ExecuteToolAsync("nd.ApplyRotateTreeLayout", parameters, null, null,
                        (eventName, o) =>
                        {
                          ErrorStatus = $@"GP event: {eventName} {o.ToString()}";
                          System.Diagnostics.Debug.WriteLine(ErrorStatus);
                        });
                    if (gpResult.IsFailed)
                    {
                      Geoprocessing.ShowMessageBox(gpResult.Messages, "GP failed",
                       gpResult.IsFailed ? GPMessageBoxStyle.Error : GPMessageBoxStyle.Default);
                    }
                  }
                }
                #endregion

                // Open the diagram map
                var mapPane = await ArcGIS.Desktop.Core.ProApp.Panes.CreateMapPaneAsync(newMap, MapViewingMode.Map);
                if (mapPane == null)
                  return;

                // label some of the diagram elements
                var elementQuery = new DiagramElementQueryByElementTypes
                {
                  QueryDiagramEdgeElement = true,
                  QueryDiagramJunctionElement = true,
                  QueryDiagramContainerElement = false
                };

                var queryResult = _networkDiagram.QueryDiagramElements(elementQuery);

                var traceElements = OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList();
                // Create a NetworkDiagramSubset object to read this set of diagram elements
                foreach (var diagElement in queryResult.DiagramJunctionElements)
                {
                  var geom = diagElement.Shape.Clone();
                  if (geom.IsEmpty) continue;
                  OutageTraceViewElement.SetDiagramShape(traceElements, diagElement.AssociatedGlobalID, geom);
                  OutageTraceViewElement.SetDiagramShape(_isolationElements, diagElement.AssociatedGlobalID, geom);
                  if (Workorder.GlobalId == diagElement.AssociatedGlobalID)
                  {
                    Workorder.DiagramShape = geom;
                  }
                }
                foreach (var diagElement in queryResult.DiagramEdgeElements)
                {
                  var geom = diagElement.Shape.Clone();
                  if (geom.IsEmpty) continue;
                  if (geom is Polyline geomPoly)
                  {
                    geom = GeometryEngine.Instance.MovePointAlongLine(geomPoly, 0.5, true, 0, SegmentExtension.NoExtension);
                  }
                  OutageTraceViewElement.SetDiagramShape(traceElements, diagElement.AssociatedGlobalID, geom);
                  OutageTraceViewElement.SetDiagramShape(_isolationElements, diagElement.AssociatedGlobalID, geom);
                  if (Workorder.GlobalId == diagElement.AssociatedGlobalID)
                  {
                    Workorder.DiagramShape = geom;
                  }
                }
                var lstElements = OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList();
                var lstIsoElements = _isolationElements.ToList();
                MapUtil.AutoLabelSwitches(false, lstElements, Workorder, lstIsoElements);

                var elements = lstElements.Select((e) => e.DiagramShape).ToList();
                var env = MapUtil.UnionGeometries(elements);
                MapView.Active.ZoomTo(env);
                MapUtil.ClearLabel(MapUtil.LabelType.Polygon);
              });
            }
            else
            {
              var utilNetworkLayer = MapUtil.GetUtilityNetworkLayer();
              if (utilNetworkLayer == null) return;
              {
                await QueuedTask.Run(async () =>
                {
                  // create an utility network diagram using the 'basic' template
                  var diagramManager = NetworkUtil.GetDiagManager(utilNetworkLayer);
                  var template = diagramManager.GetDiagramTemplate("Basic"); // SimplifiedDiagrams

                  #region Error checks
                  if (template == null)
                  {
                    MessageBox.Show("Error unable to find 'Basic' Diagram template");
                    return;
                  }
                  if (_globalIds == null || _globalIds.Count() == 0)
                  {
                    MessageBox.Show("Error: selected set for diagram is empty");
                    return;
                  }
                  #endregion

                  // Create the diagram & diagram map using the given template and the global ids of
                  // all elements to be shown in the diagram
                  _networkDiagram = diagramManager.CreateNetworkDiagram(template, _globalIds);

                  // apply radial tree layout as the schematic view
                  var layoutParameters = new RadialTreeDiagramLayoutParameters();
                  _networkDiagram.ApplyLayout(layoutParameters);

                  var newMap = MapFactory.Instance.CreateMap(WorkOrderName, ArcGIS.Core.CIM.MapType.NetworkDiagram, MapViewingMode.Map);
                  if (newMap == null)
                    return;

                  //Add the diagram to the map
                  var diagramLayer = newMap.AddDiagramLayer(_networkDiagram);

                  #region Use diagram extent to see if you should rotate
                  var isolateElement = _isolationElements.Select((e) => e.Element).FirstOrDefault();
                  var rotateDiagram = isolateElement != null;
                  if (rotateDiagram)
                  {
                    DiagramElementQueryByElementTypes query = new DiagramElementQueryByElementTypes
                    {
                      QueryDiagramContainerElement = false,
                      QueryDiagramEdgeElement = false,
                      QueryDiagramJunctionElement = true
                    };
                    rotateDiagram = false;
                    var diagElementQueryResult = _networkDiagram.QueryDiagramElements(query);
                    foreach (var diagElement in diagElementQueryResult.DiagramJunctionElements)
                    {
                      if (isolateElement.GlobalID == diagElement.AssociatedGlobalID)
                      {
                        _networkDiagram.AddFlag(NetworkDiagramFlagType.PivotJunction, diagElement.ID);
                        rotateDiagram = true;
                        break;
                      }
                    }
                  }
                  #endregion

                  // Open the diagram map
                  var mapPane = await ArcGIS.Desktop.Core.ProApp.Panes.CreateMapPaneAsync(newMap, MapViewingMode.Map);
                  if (mapPane == null)
                    return;

                if (rotateDiagram)
                {
                    //  //rotate if needed using diagram extent
                    //  var layoutRotationParameters = new RotateTreeDiagramLayoutParameters();
                    //  layoutRotationParameters.Rotation = 90.0;
                    //  layoutRotationParameters.RotateJunction = false;
                    //  layoutRotationParameters.PreserveContainers = false;
                    //  _networkDiagram.ApplyLayout(layoutRotationParameters, InvocationTarget.SynchronousService);
                    ErrorStatus = $@"Starting GP Task ApplyRotateTreeLayout{Environment.NewLine}";
                    // TODO: Geoprocessing feedback in message form
                    var parameters = Geoprocessing.MakeValueArray(diagramLayer, false, 90.0, false, false);
                    var gpResult = await Geoprocessing.ExecuteToolAsync("nd.ApplyRotateTreeLayout", parameters, null, null,
                        (eventName, o) =>
                        {
                          ActionOnGuiThread(() =>
                          {
                            ErrorStatus += $@"GP event: {eventName} {o.ToString()} {Environment.NewLine}";
                          });
                        });
                    if (gpResult != null && gpResult.IsFailed)
                    {
                      Geoprocessing.ShowMessageBox(gpResult.Messages, "GP failed",
                       gpResult.IsFailed ? GPMessageBoxStyle.Error : GPMessageBoxStyle.Default);
                    }
                  }
                  // add labels
                  var elementQuery = new DiagramElementQueryByElementTypes();
                  elementQuery.QueryDiagramEdgeElement = true;
                  elementQuery.QueryDiagramJunctionElement = true;
                  elementQuery.QueryDiagramContainerElement = false;

                  var queryResult = _networkDiagram.QueryDiagramElements(elementQuery);

                  var traceElements = OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList();
                  // Create a NetworkDiagramSubset object to read this set of diagram elements
                  foreach (var diagElement in queryResult.DiagramJunctionElements)
                  {
                    var geom = diagElement.Shape.Clone();
                    if (geom.IsEmpty) continue;
                    OutageTraceViewElement.SetDiagramShape(traceElements, diagElement.AssociatedGlobalID, geom);
                    OutageTraceViewElement.SetDiagramShape(_isolationElements, diagElement.AssociatedGlobalID, geom);
                    if (Workorder.GlobalId == diagElement.AssociatedGlobalID)
                    {
                      Workorder.DiagramShape = geom;
                    }
                  }
                  foreach (var diagElement in queryResult.DiagramEdgeElements)
                  {
                    var geom = diagElement.Shape.Clone();
                    if (geom.IsEmpty) continue;
                    if (geom is Polyline geomPoly)
                    {
                      geom = GeometryEngine.Instance.MovePointAlongLine(geomPoly, 0.5, true, 0, SegmentExtension.NoExtension);
                    }
                    OutageTraceViewElement.SetDiagramShape(traceElements, diagElement.AssociatedGlobalID, geom);
                    OutageTraceViewElement.SetDiagramShape(_isolationElements, diagElement.AssociatedGlobalID, geom);
                    if (Workorder.GlobalId == diagElement.AssociatedGlobalID)
                    {
                      Workorder.DiagramShape = geom;
                    }
                  }
                  var lstElements = OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList();
                  var lstIsoElements = _isolationElements.ToList();
                  MapUtil.AutoLabelSwitches(false, lstElements, Workorder, lstIsoElements);

                  var elements = lstElements.Select((e) => e.DiagramShape).ToList();
                  var env = MapUtil.UnionGeometries(elements);
                  MapView.Active.ZoomTo(env);
                  MapUtil.ClearLabel(MapUtil.LabelType.Polygon);
                });
              }
            }
          }
          catch (Exception ex)
          {
            MessageBox.Show($@"Error creating diagram: {ex.ToString()}");
          }
          BackDiagram = System.Windows.Media.Brushes.LightGreen;
          ImageDiagram = _imageCheck;
          EnableReport = true;
        }, true);
      }
    }

    public ICommand CmdCreateReport
    {
      get
      {
        return new RelayCommand(async () =>
        {
          try
          {
            var lstMapElements = OutageTraceViewElements.SourceCollection.Cast<OutageTraceViewElement>().ToList();
            var mapEnvelope = MapUtil.UnionGeometries(lstMapElements.Where((e) => e.MapShape != null).Select((e) => e.MapShape));
            var diagramEnvelope = MapUtil.UnionGeometries(lstMapElements.Where((e) => e.DiagramShape != null).Select((e) => e.DiagramShape));
            mapEnvelope = mapEnvelope.Expand(1.25, 1, true);
            diagramEnvelope = diagramEnvelope.Expand(1.1, 1, true);
            _ = await CustomLayout.CreateCustomLayout(LayoutName, MapName, WorkOrderName, mapEnvelope, diagramEnvelope);
          }
          catch (Exception ex)
          {
            MessageBox.Show($@"Error creating Layout: {ex}");
          }
          BackReport = System.Windows.Media.Brushes.LightGreen;
          ImageReport = _imageCheck;
          PowerOutagePlanningModule.DebugActive = !PowerOutagePlanningModule.DebugActive;
        });
      }
    }

    public ICommand CmdCopyStart
    {
      get
      {
        return new RelayCommand(async () =>
        {
          try
          {
            await QueuedTask.Run(() =>
            {
              Random rnd = new Random();
              Dictionary<string, object> attributes = new Dictionary<string, object>();

              //create workorder feature from starting point
              var woLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals("Workorders", StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
              var spLayer = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals("Start Points", StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
              var allSelection = MapView.Active.Map.GetSelection();
              foreach (var mapMember in allSelection.Keys)
              {
                if (mapMember.Name.Equals("Start Points", StringComparison.CurrentCultureIgnoreCase))
                {
                  var qf = new QueryFilter()
                  {
                    ObjectIDs = allSelection[mapMember]
                  };
                  using (var rc = spLayer.Search(qf))
                  {
                    if (rc.MoveNext())
                    {
                      using (var feat = rc.Current as Feature)
                      {
                        var flds = feat.GetFields();
                        foreach (var fld in flds)
                        {
                          if (fld.Name.Equals("OBJECTID")) continue;
                          if (fld.Name.Equals("GLOBALID")) continue;

                          if (fld.Name == "Shape")
                            attributes.Add(fld.Name, feat.GetShape().Clone());
                          else
                            attributes.Add(fld.Name, feat[fld.Name]);
                        }
                      }
                    }
                  }
                }
              }
              if (attributes.Count() == 0) return;

              //create and execute the edit operation
              var createOp = new EditOperation()
              {
                Name = "Create WO",
                SelectModifiedFeatures = false,
                SelectNewFeatures = false
              };
              var woNo = rnd.Next(10000, 99999);
              attributes.Add("Description", "Corona failures");
              attributes.Add("WorkorderNo", woNo.ToString());
              createOp.Create(woLayer, attributes);
              var ok = createOp.Execute();
              if (!ok) MessageBox.Show($@"WO Create failed: {createOp.ErrorMessage}");

            });
          }
          catch (Exception ex)
          {
            MessageBox.Show($@"Error copying: {ex}");
          }
        });
      }
    }

    public System.Windows.Media.Brush BackSelect
    {
      get { return _backSelect; }
      set
      {
        SetProperty(ref _backSelect, value, () => BackSelect);
      }
    }

    public System.Windows.Media.Brush BackIsolatePower
    {
      get { return _backIsolatePower; }
      set
      {
        SetProperty(ref _backIsolatePower, value, () => BackIsolatePower);
      }
    }

    public System.Windows.Media.Brush BackFindAffected
    {
      get { return _backFindAffected; }
      set
      {
        SetProperty(ref _backFindAffected, value, () => BackFindAffected);
      }
    }

    public System.Windows.Media.Brush BackDiagram
    {
      get { return _backDiagram; }
      set
      {
        SetProperty(ref _backDiagram, value, () => BackDiagram);
      }
    }

    public System.Windows.Media.Brush BackReport
    {
      get { return _backReport; }
      set
      {
        SetProperty(ref _backReport, value, () => BackReport);
      }
    }

    public System.Windows.Media.Imaging.BitmapImage ImageReport
    {
      get { return _imageReport; }
      set
      {
        SetProperty(ref _imageReport, value, () => ImageReport);
      }
    }

    public System.Windows.Media.Imaging.BitmapImage ImageDiagram
    {
      get { return _imageDiagram; }
      set
      {
        SetProperty(ref _imageDiagram, value, () => ImageDiagram);
      }
    }

    public System.Windows.Media.Imaging.BitmapImage ImageSelect
    {
      get { return _imageSelect; }
      set
      {
        SetProperty(ref _imageSelect, value, () => ImageSelect);
      }
    }

    public System.Windows.Media.Imaging.BitmapImage ImageIsolate
    {
      get { return _imageIsolate; }
      set
      {
        SetProperty(ref _imageIsolate, value, () => ImageIsolate);
      }
    }

    public System.Windows.Media.Imaging.BitmapImage ImageConnected
    {
      get { return _imageConnected; }
      set
      {
        SetProperty(ref _imageConnected, value, () => ImageConnected);
      }
    }

    public bool EnableIsolate
    {
      get { return _enableIsolate; }
      set
      {
        SetProperty(ref _enableIsolate, value, () => EnableIsolate);
      }
    }

    public bool EnableConnect
    {
      get { return _enableConnect; }
      set
      {
        SetProperty(ref _enableConnect, value, () => EnableConnect);
      }
    }

    public bool EnableDiagram
    {
      get { return _enableDiagram; }
      set
      {
        SetProperty(ref _enableDiagram, value, () => EnableDiagram);
      }
    }

    public bool EnableReport
    {
      get { return _enableReport; }
      set
      {
        SetProperty(ref _enableReport, value, () => EnableReport);
      }
    }

    public string FilterByItem
    {
      get { return _filterByItem; }
      set
      {
        SetProperty(ref _filterByItem, value, () => FilterByItem);
        if (OutageTraceViewElements == null) return;
        switch (_filterByItem)
        {
          case "Switches only":
            OutageTraceViewElements.Filter = new Predicate<object>(IsSwitch);
            break;
          case "Customer Service Points":
            OutageTraceViewElements.Filter = new Predicate<object>(IsServicePoint);
            break;
          case "Transformers":
            OutageTraceViewElements.Filter = new Predicate<object>(IsTransformer);
            break;
          case "Power lines":
            OutageTraceViewElements.Filter = new Predicate<object>(IsPowerline);
            break;
          default:
            OutageTraceViewElements.Filter = null;
            break;
        }

      }
    }

    public List<string> FilterByItems
    {
      get { return _filterByItems; }
      set
      {
        SetProperty(ref _filterByItems, value, () => FilterByItems);
      }
    }

    /// <summary>
    /// Process work order
    /// </summary>
    public string ProcessWorkorder
    {
      get { return _processWorkorder; }
      set
      {
        SetProperty(ref _processWorkorder, value, () => ProcessWorkorder);
      }
    }

    public string DownStreamResult
    {
      get { return _downStreamResult; }
      set
      {
        SetProperty(ref _downStreamResult, value, () => DownStreamResult);
      }
    }

    public string SubnetworkName
    {
      get { return _subnetworkName; }
      set
      {
        SetProperty(ref _subnetworkName, value, () => SubnetworkName);
      }
    }

    /// <summary>
    /// Text shown near the top of the DockPane.
    /// </summary>
    public string Heading1
    {
      get { return _heading1; }
      set
      {
        SetProperty(ref _heading1, value, () => Heading1);
      }
    }

    /// <summary>
    /// Text shown Error Status
    /// </summary>
    public string ErrorStatus
    {
      get { return _errorStatus; }
      set
      {
        SetProperty(ref _errorStatus, value, () => ErrorStatus);
      }
    }

    public ICollectionView OutageTraceViewElements
    {
      get { return _outageTraceViewElements; }
      set
      {
        SetProperty(ref _outageTraceViewElements, value, () => OutageTraceViewElements);
      }
    }

    public OutageTraceViewElement OutageTraceViewElement
    {
      get { return _outageTraceViewElement; }
      set
      {
        SetProperty(ref _outageTraceViewElement, value, () => OutageTraceViewElement);
        if (_outageTraceViewElement != null)
        {
          var mapPane = ProApp.Panes.OfType<IMapPane>().Where((p) => p.Caption == mapCaption).Cast<Pane>().FirstOrDefault();
          if (mapPane != null) mapPane.Activate();

          var label = _outageTraceViewElement.AssetGroupName;
          var parts = label.Split(new char[] { ' ' });
          if (parts.Length > 0) label = parts[parts.Length - 1];
          _ = QueuedTask.Run(() =>
          {
            // restore selection
            var mapMember = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().FirstOrDefault(fl => fl.GetFeatureClass().GetName() == NetworkConstants.LineFeatureClassName);
            if (mapMember != null && _connectedSelection != null && _connectedSelection.ContainsKey(mapMember))
            {
              var sel = new Dictionary<MapMember, List<long>>();
              sel.Add(mapMember, _connectedSelection[mapMember]);
              MapView.Active.Map.SetSelection(sel);
            }
            if (_outageTraceViewElement.MapCenterShape != null)
            {
              // for power lines we use the center shape to place the label
              MapUtil.ShowCalloutBox(MapUtil.LabelType.Powerline, _outageTraceViewElement.MapCenterShape, $@"{label} {_outageTraceViewElement.ObjectID}");
            }
            else
            {
              // if we have an owner parcel we symbolize the owner parcel and then label
              if (_outageTraceViewElement.OwnerParcel != null)
              {
                MapUtil.ClearLabel(MapUtil.LabelType.Polygon);

                // symbolize the owner parcel
                MapUtil.ShowPolygonCalloutBox(MapUtil.LabelType.Polygon, _outageTraceViewElement.OwnerParcel, $@"Service Point: {Environment.NewLine}{_outageTraceViewElement.Address}");

                // label the service point                
                MapUtil.ShowCalloutBox(MapUtil.LabelType.Polygon, _outageTraceViewElement.MapShape, $@"Service Point: {Environment.NewLine}{_outageTraceViewElement.Address}");
              }
              else
              {
                MapUtil.ShowCalloutBox(MapUtil.LabelType.Other, _outageTraceViewElement.MapShape, $@"{label} {_outageTraceViewElement.ObjectID}");
              }
            }
            // now we zoom to the selection 
            if (_outageTraceViewElement.OwnerParcel != null)
            {
              var env = EnvelopeBuilderEx.CreateEnvelope(_outageTraceViewElement.OwnerParcel.Extent).Expand(1.5, 1.5, true);
              MapView.Active.ZoomToAsync(env);
            }
            else
            {
              if (_outageTraceViewElement.MapShape is MapPoint mp)
              {
                if (mp != null)
                {
                  var xMin = mp.X - 20;
                  var xMax = mp.X + 20;
                  var yMin = mp.Y - 20;
                  var yMax = mp.Y + 20;
                  var env = EnvelopeBuilderEx.CreateEnvelope(xMin, yMin, xMax, yMax, mp.SpatialReference).Expand(2, 2, true);
                  MapView.Active.ZoomToAsync(env);
                }
              }
              else
              {
                if (_outageTraceViewElement.MapShape != null
                && _outageTraceViewElement.MapShape.Extent != null)
                {
                  MapView.Active.ZoomToAsync(_outageTraceViewElement.MapShape.Extent.Expand(2, 2, true));
                }
              }
            }
          });
        }
      }
    }

    #endregion UI properties

    #region Helpers

    internal string WorkOrderName => $@"WO {Workorder?.WorkorderNo}";

    internal string LayoutName => $@"Work order # {Workorder?.WorkorderNo}";

    internal string MapName => "Power Outage";

    private bool IsSwitch(object element)
    {
      var theElement = element as OutageTraceViewElement;
      return (theElement.AssetGroupName.Contains("Switch") || theElement.AssetGroupName.Contains("Fuse"));
    }

    private bool IsServicePoint(object element)
    {
      var theElement = element as OutageTraceViewElement;
      return (theElement.AssetGroupName.Contains("Service"));
    }

    private bool IsTransformer(object element)
    {
      var theElement = element as OutageTraceViewElement;
      return (theElement.AssetGroupName.Contains("Transformer"));
    }

    private bool IsPowerline(object element)
    {
      var theElement = element as OutageTraceViewElement;
      return (theElement.AssetGroupName.Contains("Conductor"));
    }

    private async void OnActiveMapViewChangedEvent(ActiveMapViewChangedEventArgs changeEventArg)
    {
      if (_this == null) return;
      var active = false;
      if (changeEventArg == null)
      {
        var activeMapView = MapView.Active;
        if (activeMapView == null) active = false;
        else active = MapView.Active.Map != null;
      }
      else
      {
        active = changeEventArg.IncomingView != null;
      }
      if (this.Workorders.Count == 0 && active)
      {
        await LoadWorkordersAsync(changeEventArg == null ? MapView.Active : changeEventArg.IncomingView);
        // TODO: BusyVisibility for WaitingCursor Control  
        BusyVisibility = System.Windows.Visibility.Collapsed;
      }
    }

    private async Task<Geometry> FindWorkorderTargetFeature(Workorder workorder)
    {
      Geometry geometry = null;
      if (MapView.Active?.Map == null) return geometry;
      var featLyr = MapView.Active.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals(workorder.TargetLayerName, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
      var subnetworkName = string.Empty;
      var error = string.Empty;

      await QueuedTask.Run(() =>
      {
        using (var rowCursor = featLyr.Search(new QueryFilter() { ObjectIDs = new long[] { workorder.TargetFeatureOid } }))
        {
          while (rowCursor.MoveNext())
          {
            int idx = rowCursor.FindField("SUBNETWORKNAME");
            if (idx < 0) break;
            using (Feature currentFeature = rowCursor.Current as Feature)
            {
              geometry = currentFeature.GetShape().Clone();
              var newSubnetworkName = currentFeature[idx].ToString();
              if (string.IsNullOrEmpty(subnetworkName))
              {
                subnetworkName = newSubnetworkName;
              }
              else
              {
                if (newSubnetworkName != subnetworkName)
                {
                  error = $@"Error: Workorder cannot span more than one Subnetwork: {newSubnetworkName} {subnetworkName}";
                  break;
                }
              }
            }
          }
        }
      });
      if (!string.IsNullOrEmpty(error))
        subnetworkName = error;

      ActionOnGuiThread(() =>
      {
        SubnetworkName = subnetworkName;
      });
      return geometry;
    }

    private async Task LoadWorkordersAsync(MapView activeMapView)
    {
      var result = await QueuedTask.Run<string>(() =>
      {
        var error = string.Empty;

        try
        { 
          // TODO: 2. enable _workorders for updates from background threads
          lock (_lockWoCollection)
          {
            _workorders.Clear();
          }
          int loadedCount = 0;
          var woPath = System.IO.Path.Combine(Project.Current.HomeFolderPath, "Workorder.gdb");
          var unPath = System.IO.Path.Combine(Project.Current.HomeFolderPath, "NapervilleElectricSDKData.gdb");
          if (!System.IO.Directory.Exists (unPath) || !System.IO.Directory.Exists(woPath))
          {
            return "The proper dataset for the sample was not loaded";
          }
          using (Geodatabase workorderGdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(woPath))))
          {
            using (FeatureClass fc = workorderGdb.OpenDataset<FeatureClass>("workorders"))
            {
              using (RowCursor cursor = fc.Search())
              {
                while (cursor.MoveNext())
                {
                  using (Feature currentFeature = cursor.Current as Feature)
                  {
                    var newWo = new Workorder(currentFeature, unPath);
                    // TODO: 3. add records - enable _workorders for updates from background threads
                    lock (_lockWoCollection)
                      _workorders.Add(newWo);
                    ActionOnGuiThread(() =>
                    {
                      // TODO: ProgressBar 3) update the Progressbar
                      if (MaxProgressValue > 0 && loadedCount <= MaxProgressValue)
                      {
                        // TODO: ProgressBar 4) show Progressbar text
                        ProgressText = $@"Loaded: {++loadedCount}";
                        ProgressValue = loadedCount;
                      }
                    });
                    #region Get data from external system
                    if (MaxProgressValue > 0)
                      System.Threading.Thread.Sleep(3000);
                    #endregion
                  }
                }
              }
            }
          }
          var woLayer = activeMapView.Map.GetLayersAsFlattenedList().OfType<FeatureLayer>().Where(fl => fl.Name.Equals("Workorders", StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
          if (woLayer != null)
          {
            var cd = new CIMDefinitionFilter() { Name = "Workorder", DefinitionExpression = $@"objectid = -1" };
            woLayer.SetDefinitionFilter(cd);
          }
          //// update the workorder feature
          ////create and execute the edit operation
          //var updateOp = new EditOperation()
          //{
          //  Name = "Fix wo locations",
          //  SelectModifiedFeatures = false,
          //  SelectNewFeatures = false
          //};
          //foreach (var wo in _workorders)
          //{
          //  updateOp.Modify(woLayer, wo.ObjectId, wo.MapShape);
          //}
          //var ok = updateOp.Execute();
          //if (!ok) MessageBox.Show($@"WO Edit failed: {updateOp.ErrorMessage}");
        }
        catch (Exception ex)
        {
          error = $@"Error finding work order row: {ex.ToString()}";
        }
        return error;
      }
      );
      NotifyPropertyChanged(() => Workorders);
      ErrorStatus = result;
    }

    /// <summary>
    /// We have to ensure that GUI updates are only done from the GUI thread.
    /// </summary>
    private void ActionOnGuiThread(Action theAction)
    {
      if (System.Windows.Application.Current.Dispatcher.CheckAccess())
      {
        //We are on the GUI thread
        theAction();
      }
      else
      {
        //Using the dispatcher to perform this action on the GUI thread.
        ProApp.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, theAction);
      }
    }

    private async Task<bool> SelectOneWorkorderAync(Workorder selectedWorkorder)
    {
      return await QueuedTask.Run<bool>(() =>
      {
        var hasSelection = false;
        try
        {
          Dictionary<string, object> newAttributes = new Dictionary<string, object>();
          var woPath = System.IO.Path.Combine(Project.Current.HomeFolderPath, "Workorder.gdb");
          if (selectedWorkorder != null)
          {
            using (Geodatabase workorderGdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(woPath))))
            {
              using (FeatureClass fc = workorderGdb.OpenDataset<FeatureClass>("workorders"))
              {
                using (RowCursor cursor = fc.Search(new QueryFilter() { ObjectIDs = new long[] { selectedWorkorder.ObjectId } }))
                {
                  while (cursor.MoveNext())
                  {
                    using (Feature currentFeature = cursor.Current as Feature)
                    {
                      var fields = cursor.GetFields();
                      // copy all fields except the last two fields
                      for (int idx = 0; idx < fields.Count - 2; idx++)
                      {
                        var currentField = fields[idx];
                        if (currentField.IsEditable)
                          newAttributes.Add(GetName(currentField), currentFeature[idx]);
                      }
                    }
                  }
                }
              }
            }
          }
          using (Geodatabase workorderGdb = new Geodatabase(new FileGeodatabaseConnectionPath(new Uri(Project.Current.DefaultGeodatabasePath))))
          {
            using (FeatureClass fc = workorderGdb.OpenDataset<FeatureClass>(NetworkConstants.StartingPointsTableName))
            {
              // delete the existing content
              fc.DeleteRows(new QueryFilter());
              if (newAttributes.Count > 0)
              {
                using (RowBuffer rowBuffer = fc.CreateRowBuffer())
                {
                  foreach (var fieldName in newAttributes.Keys)
                  {
                    rowBuffer[fieldName] = newAttributes[fieldName];
                  }
                  workorderGdb.ApplyEdits(() =>
                  {
                    hasSelection = true;
                    var newFeature = fc.CreateRow(rowBuffer);
                    System.Diagnostics.Trace.WriteLine($@"Created feature [oid:{newFeature.GetObjectID()}] in {fc.GetName()}");
                  });
                }
              }
            }
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show($@"FeatureClassExists Error: {ex.ToString()}");
          return false;
        }
        return hasSelection;
      }
      );
    }

    private string GetName(Field field)
    {
      return string.IsNullOrEmpty(field.AliasName) ? field.Name : field.AliasName;
    }

    #endregion Helpers

    #region Static

    /// <summary>
    /// Show the DockPane.
    /// </summary>
    internal static void Show()
    {
      DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
      if (pane == null)
        return;
      pane.Activate();
    }

    #endregion Static
  }

  /// <summary>
  /// Button implementation to show the DockPane.
  /// </summary>
  internal class OutagePlanner_ShowButton : Button
  {
    protected override void OnClick()
    {
      OutagePlannerViewModel.Show();
    }
  }
}
