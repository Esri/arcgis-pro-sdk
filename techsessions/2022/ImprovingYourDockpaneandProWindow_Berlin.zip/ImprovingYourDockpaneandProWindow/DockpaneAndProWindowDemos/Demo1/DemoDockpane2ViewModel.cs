﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using DockpaneAndProWindowDemos.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace DockpaneAndProWindowDemos.Demo1
{
	internal class DemoDockpane2ViewModel : DockPane
	{
		private const string _dockPaneID = "DockpaneAndProWindowDemos_Demo2_DemoDockpane";

		protected DemoDockpane2ViewModel() { }

		private bool _isLoading = false;
		private double _progressValue = 0.0;
		private string _progressText = string.Empty;

		private ICommand _loadFeaturesCmd = null;
		private ICommand _clearFeaturesCmd = null;

		protected override Task InitializeAsync()
		{
			BindingOperations.EnableCollectionSynchronization(
				Module1.Current.FeatureInfo, Module1._lock);
			return base.InitializeAsync();
		}
		/// <summary>
		/// Show the DockPane.
		/// </summary>
		internal static void Show()
		{
			DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
			if (pane == null)
				return;

			pane.Activate();
		}

		/// <summary>
		/// Text shown near the top of the DockPane.
		/// </summary>
		private string _heading = "Dockpane2 Demo";
		public string Heading
		{
			get => _heading;
			set => SetProperty(ref _heading, value);
		}

		private string _layerName = "FacilitySitePoint";
		public string LayerName
		{
			get => _layerName;
			set => SetProperty(ref _layerName, value);
		}

		public bool IsLoading
		{
			get => _isLoading;
			set => SetProperty(ref _isLoading, value);
		}

		public double ProgressValue
		{
			get
			{
				return _progressValue;
			}
			set
			{
				SetProperty(ref _progressValue, value);
			}
		}

		public string ProgressText
		{
			get
			{
				return _progressText;
			}
			set
			{
				SetProperty(ref _progressText, value);
			}
		}

		public ICommand LoadFeaturesCmd
		{
			get
			{
				if (_loadFeaturesCmd == null)
				{
					_loadFeaturesCmd = new RelayCommand(() =>
					{

						#region Guts
						var fl = MapView.Active.Map.GetLayersAsFlattenedList()
								.OfType<FeatureLayer>().FirstOrDefault(lyr => lyr.Name == "FacilitySitePoint");
						if (fl == null)
							return;

						ProgressValue = 0;

						this.IsLoading = true;
						LayerName = fl.Name;

						QueuedTask.Run(async () =>
						{
							#region Get Layer
							var def = fl.GetDefinition() as CIMFeatureLayer;
							var display_fld = def.FeatureTable.DisplayField;
							var display_fld_idx = fl.GetTable().GetDefinition().FindField(display_fld);
							#endregion

							using (var rc = fl.Select().Search())
							{
								int loadedCount = 0;
								while (rc.MoveNext())
								{
									var display_fld_value = rc.Current[display_fld_idx].ToString();
									var info = $"{rc.Current.GetObjectID()} {display_fld_value}";

									//Update the Observable collection
									lock(Module1._lock)
										Module1.Current.FeatureInfo.Add(info);
									await Task.Delay(250);//Remove this for no delay!

									if (ProgressValue >= 100)
										ProgressValue = 10.0;
									else
										ProgressValue += 10;
									ProgressText = $@"Loaded: {++loadedCount}";

									//or FrameworkApplication.Current.Dispatcher.BeginInvoke
									FrameworkApplication.Current.Dispatcher.Invoke(() =>
									{
										//Any code here will run on the UI

									});

								}
							}
							this.IsLoading = false;
						});
						#endregion
					});
				}
				return _loadFeaturesCmd;
			}
		}

		public ICommand ClearFeaturesCmd
		{
			get
			{
				if (_clearFeaturesCmd == null)
				{
					_clearFeaturesCmd = new RelayCommand(() =>
					{
						DemoHelper.ClearFeatures();
					});
				}
				return _clearFeaturesCmd;
			}
		}

		public ObservableCollection<string> FeatureInfo => Module1.Current.FeatureInfo;
	}

	/// <summary>
	/// Button implementation to show the DockPane.
	/// </summary>
	internal class DemoDockpane2_ShowButton : Button
	{
		protected override void OnClick()
		{
			DemoDockpane2ViewModel.Show();
		}
	}
}
