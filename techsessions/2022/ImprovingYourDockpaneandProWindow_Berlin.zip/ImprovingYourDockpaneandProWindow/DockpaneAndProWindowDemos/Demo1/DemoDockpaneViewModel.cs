﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using DockpaneAndProWindowDemos.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;

namespace DockpaneAndProWindowDemos.Demo1
{
	internal class DemoDockpaneViewModel : DockPane
	{
		private const string _dockPaneID = "DockpaneAndProWindowDemos_Demo1_DemoDockpane";

		protected DemoDockpaneViewModel() { }

		private ICommand _loadFeaturesCmd = null;
		private ICommand _clearFeaturesCmd = null;

		protected override Task InitializeAsync()
		{
			//BindingOperations.EnableCollectionSynchronization(
			//	Module1.Current.FeatureInfo, Module1._lock);
			return base.InitializeAsync();
		}
		/// <summary>
		/// Show the DockPane.
		/// </summary>
		internal static void Show()
		{
			DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
			if (pane == null)
				return;

			pane.Activate();
		}

		/// <summary>
		/// Text shown near the top of the DockPane.
		/// </summary>
		private string _heading = "Dockpane Demo";
		public string Heading
		{
			get => _heading;
			set => SetProperty(ref _heading, value);
		}

		private string _layerName = "FacilitySitePoint";
		public string LayerName
		{
			get => _layerName;
			set => SetProperty(ref _layerName, value);
		}


		public ICommand LoadFeaturesCmd
		{
			get
			{
				if (_loadFeaturesCmd == null)
				{
					_loadFeaturesCmd = new RelayCommand(() =>
					{
						var fl = MapView.Active.Map.GetLayersAsFlattenedList()
								.OfType<FeatureLayer>().FirstOrDefault(lyr => lyr.Name == "FacilitySitePoint");
						if (fl == null)
							return;

						LayerName = fl.Name;
						
						QueuedTask.Run (() =>
						{
							#region Get Layer
							var def = fl.GetDefinition() as CIMFeatureLayer;
							var display_fld = def.FeatureTable.DisplayField;
							var display_fld_idx = fl.GetTable().GetDefinition().FindField(display_fld);
							#endregion

							using (var rc = fl.Select().Search())
							{
								while (rc.MoveNext())
								{
									var display_fld_value = rc.Current[display_fld_idx].ToString();
									var info = $"{rc.Current.GetObjectID()} {display_fld_value}";

									//Update the Observable collection
									Module1.Current.FeatureInfo.Add(info);

									//await Task.Delay(250);
									
								}
							}
						});
					});
				}
				return _loadFeaturesCmd;
			}
		}

		public ICommand ClearFeaturesCmd
		{
			get
			{
				if (_clearFeaturesCmd == null)
				{
					_clearFeaturesCmd = new RelayCommand(() =>
					{
						Module1.Current.FeatureInfo.Clear();
					});
				}
				return _clearFeaturesCmd;
			}
		}

		public ObservableCollection<string> FeatureInfo => Module1.Current.FeatureInfo;
	}
	/// <summary>
	/// Button implementation to show the DockPane.
	/// </summary>
	internal class DemoDockpane_ShowButton : Button
	{
		protected override void OnClick()
		{
			DemoDockpaneViewModel.Show();
		}
	}
}
