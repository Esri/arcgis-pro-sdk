﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DockpaneAndProWindowDemos.Demo2
{
	internal class ShowProWindowModeless : Button
	{

		private ProWindowModeless _prowindowmodeless = null;
		protected override void OnClick() {

			if (_prowindowmodeless != null)
				return;

			//Use class instance variable.
			_prowindowmodeless = new ProWindowModeless();
			_prowindowmodeless.DataContext = new ProWindowDialogModelessViewModel();
			_prowindowmodeless.Owner = FrameworkApplication.Current.MainWindow;

			//Handle closed to clean up
			_prowindowmodeless.Closed += (o, e) => { 
				_prowindowmodeless = null;

			};
			_prowindowmodeless.Show();//DialogResult is not necessary
		}

	}
}
