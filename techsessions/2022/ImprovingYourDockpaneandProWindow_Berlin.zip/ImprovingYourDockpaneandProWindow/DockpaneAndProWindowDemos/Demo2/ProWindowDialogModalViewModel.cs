﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace DockpaneAndProWindowDemos.Demo2
{
	internal class ProWindowDialogModalViewModel : PropertyChangedBase
	{
		private ObservableCollection<string> _bookmarksInMap = new ObservableCollection<string>();
		public ObservableCollection<string> BookmarksInMap => _bookmarksInMap;
		private static readonly object _lock = new object();
		public ProWindowDialogModalViewModel()
		{
			BindingOperations.EnableCollectionSynchronization(BookmarksInMap, _lock);
			GetBookmarksInMap();
		}

		private string _selectedBookmark;
		public string SelectedBookmarkName
		{
			get
			{ 
				return _selectedBookmark; 
			}
			set
			{
				SetProperty(ref _selectedBookmark, value, () => SelectedBookmarkName);
			}
		}

		private ICommand _okCmd = null;
		public ICommand OKCmd
		{
			get
			{
				if (_okCmd == null)
				{
					_okCmd = new RelayCommand(
						             (param) => CloseDialog((ProWindowModal)param, true),
						                     () => !string.IsNullOrEmpty(SelectedBookmarkName));
				}
				return _okCmd;
			}
		}

		private ICommand _cancelCmd = null;
		public ICommand CancelCmd
		{
			get
			{
				if (_cancelCmd == null)
				{
					_cancelCmd = new RelayCommand(
						(param) => CloseDialog((ProWindowModal)param, false), () => true);
				}
				return _cancelCmd;
			}
		}

		private void CloseDialog(ProWindowModal dlg, bool result)
		{
			dlg.DialogResult = result;
			dlg.Close();
		}

		private async void GetBookmarksInMap()
		{
			if (MapView.Active == null) return;

			await QueuedTask.Run(() => {
				var bmks = MapView.Active.Map.GetBookmarks();
				foreach (var bmk in bmks)
				{
					lock (_lock)
						_bookmarksInMap.Add(bmk.Name);
				}
				SelectedBookmarkName = "";
			});
		}
	}
}
