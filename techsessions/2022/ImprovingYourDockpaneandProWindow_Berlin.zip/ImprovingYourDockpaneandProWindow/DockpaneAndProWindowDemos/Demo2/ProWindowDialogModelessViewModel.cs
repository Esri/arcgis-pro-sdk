﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace DockpaneAndProWindowDemos.Demo2
{
	internal class ProWindowDialogModelessViewModel : PropertyChangedBase
	{
		private ObservableCollection<string> _bookmarksInMap = new ObservableCollection<string>();
		public ObservableCollection<string> BookmarksInMap => _bookmarksInMap;
		private static readonly object _lock = new object();

		public ProWindowDialogModelessViewModel()
		{
			BindingOperations.EnableCollectionSynchronization(BookmarksInMap, _lock);
			GetBookmarksInMap();
		}

		private string _selectedBookmark;
		public string SelectedBookmarkName
		{
			get
			{ return _selectedBookmark; }
			set
			{
				SetProperty(ref _selectedBookmark, value, () => SelectedBookmarkName);
			}
		}

		private ICommand _zoomCmd = null;
		public ICommand ZoomCmd
		{
			get
			{
				if (_zoomCmd == null)
				{
					_zoomCmd = new RelayCommand(
						()=> Module1.Current.ZoomToBookmark(this.SelectedBookmarkName),
						() => !string.IsNullOrEmpty(this.SelectedBookmarkName));
				}
				return _zoomCmd;
			}
		}


		private ICommand _closeCmd = null;
		public ICommand CloseCmd
		{
			get
			{
				if (_closeCmd == null)
				{
					_closeCmd = new RelayCommand(
						(param) => CloseDialog((ProWindowModeless)param), () => true);
				}
				return _closeCmd;
			}
		}

		private void CloseDialog(ProWindowModeless dlg)
		{
			dlg.Close();
		}

		private async void GetBookmarksInMap()
		{
			if (MapView.Active == null) return;

			await QueuedTask.Run(() => {
				var bmks = MapView.Active.Map.GetBookmarks();
				foreach (var bmk in bmks)
				{
					lock (_lock)
						_bookmarksInMap.Add(bmk.Name);
				}
				SelectedBookmarkName = "";
				//if (_bookmarksInMap.Count > 0)
				//	SelectedBookmarkName = _bookmarksInMap[0];
			});
		}
	}
}
