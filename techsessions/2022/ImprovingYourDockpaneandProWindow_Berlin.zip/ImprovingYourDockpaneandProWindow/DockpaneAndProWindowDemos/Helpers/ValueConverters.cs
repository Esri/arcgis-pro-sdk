﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace DockpaneAndProWindowDemos.Helpers
{
  /// <summary>
  /// Converts the given bool to a Visibility
  /// </summary>
  public class BoolToVisibilityConverter : IValueConverter
  {

    /// <summary>
    /// Convert True to Visible and False to Hidden
    /// </summary>
    public Object Convert(Object value, Type targetType, Object parameter, CultureInfo culture)
    {
      if (value == null)
        return Visibility.Hidden;
      bool val = (bool)value;
      return val ? Visibility.Visible : Visibility.Hidden;
    }

    /// <summary>
    /// Not implemented
    /// </summary>
    public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo culture)
    {
      throw new InvalidOperationException("Converter cannot convert back.");
    }

  }

  public class BoolToNotBoolConverter : IValueConverter
  {
    /// <summary>
    /// Convert True to Visible and False to Hidden
    /// </summary>
    public Object Convert(Object value, Type targetType, Object parameter, CultureInfo culture)
    {
      if (value == null)
        return true;
      bool val = (bool)value;
      return !val;
    }

    /// <summary>
    /// Not implemented
    /// </summary>
    public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo culture)
    {
      throw new InvalidOperationException("Converter cannot convert back.");
    }
  }
}
