﻿using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DockpaneAndProWindowDemos.Helpers
{
	internal static class DemoHelper
	{

		internal async static void LoadFeatures(FeatureLayer fl)
		{
			var def = fl.GetDefinition() as CIMFeatureLayer;
			var display_fld = def.FeatureTable.DisplayField;
			var display_fld_idx = fl.GetTable().GetDefinition().FindField(display_fld);

			using (var rc = fl.Select().Search())
			{
				while(rc.MoveNext())
				{
					var display_fld_value = rc.Current[display_fld_idx].ToString();
					var info = $"{rc.Current.GetObjectID()} {display_fld_value}";
					lock(Module1._lock)
						Module1.Current.FeatureInfo.Add(info);
					await Task.Delay(250);//remove this for no delay! 
				}
			}
		}

		internal static void ClearFeatures()
		{
			lock (Module1._lock)
				Module1.Current.FeatureInfo.Clear();
		}
	}
}
